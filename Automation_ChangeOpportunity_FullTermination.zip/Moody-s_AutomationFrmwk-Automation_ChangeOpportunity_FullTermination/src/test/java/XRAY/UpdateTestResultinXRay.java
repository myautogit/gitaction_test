package XRAY;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.JiraxRaySupport;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class UpdateTestResultinXRay extends TestBase{

    JiraxRaySupport jiraxRaySupport;

    @BeforeMethod
    public void setUp() {
        jiraxRaySupport = new JiraxRaySupport();
    }
    @Test()
    public void updateTestResult() {
        jiraxRaySupport.uploadTestResult();
    }
}
