package com.crm.qa.sfdc.contract.newsales.testcases;

import app.getxray.xray.testng.annotations.XrayTest;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.*;
import com.crm.qa.util.AllureListener;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.openRecordBySFDCID;
import static com.crm.qa.util.ReusableLibrary.readExcelRows;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class, AllureListener.class})
public class VerifyNewSalesContractCreation extends TestBase {

    public TestBase testBase;
    public ReusableLibrary reusableLibrary;
    public WebDriver driver;
    Properties prop;
    LoginPage loginPage;
    HomePage homePage;
    AccountPage accountPage;
    ContactPage contactPage;
    TaskPage taskPage;
    CampaignPage campaignPage;
    OpportunityPage opportunityPage;
    QuotePage quotePage;
    AgreementPage agreementPage;
    OrderPage orderPage;
    FulfillmentPage fulfillmentPage;
    ReusableBusinessLibrary reusableBusinessLibrary;
    LinkedHashMap<String, String> opportunityData;
    List<LinkedHashMap<String, String>> quoteData;
    LinkedHashMap<String, String> agreementData;

    @BeforeMethod
    public void setUp() {
        testBase = new TestBase();
        prop = reusableLibrary.initializeProperties();
        driver = testBase.initialization();
        driver.get(prop.getProperty("App_URL"));
        loggerManager.getLogger().info(prop.getProperty("Browser") + " browser launched successfully");
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        accountPage = new AccountPage(driver);
        contactPage = new ContactPage(driver);
        opportunityPage = new OpportunityPage(driver);
        taskPage = new TaskPage(driver);
        campaignPage = new CampaignPage(driver);
        quotePage = new QuotePage(driver);
        agreementPage = new AgreementPage(driver);
        orderPage = new OrderPage(driver);
        fulfillmentPage = new FulfillmentPage(driver);
        reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
        opportunityData = new LinkedHashMap<>();
        quoteData = new ArrayList<>();
        agreementData = new LinkedHashMap<>();
    }

    @Test(description = "Verify that user is able to activate a Single Year New Sales Agreement")
    @Severity(SeverityLevel.NORMAL)
    @Description("MASFDCMNE-23161,MACPQMNE-4846")
    @XrayTest(key = "MASFDCMNE-34228")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("TestDataDependency")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearContractingProcess(Method method) {
        TCDependency = "verifySingleYearQuoteCreation";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        agreementData = readExcelRows(agreementsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(quoteData.get(0).get("SFDCRecordID"));
        quoteAndAgreementTotal = quotePage.getQuoteTotal();
        proposalID = quotePage.getProposalID();
        oppyName = quotePage.getOpportunityName();
        quotePage.clickOnCreateAgreementWithLineItemsBtn();
        agreementPage.createAndActivateAgreement(agreementData, opportunityData);
        expectedStartDate = agreementPage.getAgreementStartDate();
        expectedEndDate = agreementPage.getAgreementEndDate();
        agreementPage.navigateToAgreementLineItemsRelatedList();
        agreementPage.verifyAgreementLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to activate a Trial New Sales Agreement")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7639")
    @XrayTest(key = "MACPQMNE-7639")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("TestDataDependency")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearTrialContractingProcess(Method method) {
        TCDependency = "verifyTrialNewSalesQuoteCreations";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        agreementData = readExcelRows(agreementsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(quoteData.get(0).get("SFDCRecordID"));
        quoteAndAgreementTotal = quotePage.getQuoteTotal();
        proposalID = quotePage.getProposalID();
        oppyName = quotePage.getOpportunityName();
        quotePage.clickOnCreateAgreementWithLineItemsBtn();
        agreementPage.createAndActivateAgreement(agreementData, opportunityData);
    }
    @Test(description = "Verify that user is able to activate a Single Year Change Agreement")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7815")
    @XrayTest(key = "MACPQMNE-7815")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("Change"), @Tag("TestDataDependency")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearContractingProcessChangeOppyAddNewProduct(Method method) {
        //depedencies:
        //run the following testcases in the order listed before running this method:
        // (1) verifyQuoteCreationChangeOppyAddNewProduct
        TCDependency = "verifySingleYearQuoteCreation";
        quoteTCdependency= "verifyQuoteCreationChangeOppyAddNewProduct";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath,quoteTCdependency);
        agreementData = readExcelRows(agreementsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(quoteData.get(0).get("SFDCRecordID"));
        quoteAndAgreementTotal = quotePage.getQuoteTotal();
        proposalID = quotePage.getProposalID();
        oppyName = quotePage.getOpportunityName();
        quotePage.clickOnCreateAgreementWithLineItemsBtn();
        agreementPage.createAndActivateAgreement(agreementData, opportunityData);
    }

    @Test(description = "Verify that user is able to activate a Single Year New Sales Agreement with Kompany products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7879")
    @XrayTest(key = "MACPQMNE-7879")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("TestDataDependency")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearContractingProcess_KompanyProducts(Method method) {
        TCDependency = "verifySingleYearQuoteCreation_KompanyProducts";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        agreementData = readExcelRows(agreementsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(quoteData.get(0).get("SFDCRecordID"));
        quoteAndAgreementTotal = quotePage.getQuoteTotal();
        proposalID = quotePage.getProposalID();
        oppyName = quotePage.getOpportunityName();
        quotePage.clickOnCreateAgreementWithLineItemsBtn();
        agreementPage.createAndActivateAgreement(agreementData, opportunityData);
        expectedStartDate = agreementPage.getAgreementStartDate();
        expectedEndDate = agreementPage.getAgreementEndDate();
        agreementPage.navigateToAgreementLineItemsRelatedList();
        agreementPage.verifyAgreementLineItems(quoteData);
    }


    @AfterMethod
    public void tearDown(){
        if (driver != null) {
            driver.quit();
        }
    }
}
