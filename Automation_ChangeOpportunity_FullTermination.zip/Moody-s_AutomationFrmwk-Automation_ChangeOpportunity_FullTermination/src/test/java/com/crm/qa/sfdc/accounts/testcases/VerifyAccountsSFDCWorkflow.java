package com.crm.qa.sfdc.accounts.testcases;


import app.getxray.xray.testng.annotations.XrayTest;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.*;
import com.crm.qa.util.AllureListener;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Properties;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.readExcelData;
import static com.crm.qa.util.ReusableLibrary.readExcelRows;

@Listeners({ app.getxray.xray.testng.listeners.XrayListener.class, AllureListener.class })
public class VerifyAccountsSFDCWorkflow extends TestBase {

    public TestBase testBase;
    public ReusableLibrary reusableLibrary;
    public WebDriver driver;
    Properties prop;
    LoginPage loginPage;
    HomePage homePage;
    AccountPage accountPage;
    LinkedHashMap<String, String> accountData;
    ReusableBusinessLibrary reusableBusinessLibrary;

    ContactPage contactPage;
    OpportunityPage opportunityPage;
    private String profileName;


    @BeforeMethod
    public void setUp() {
        testBase = new TestBase();
        prop = reusableLibrary.initializeProperties();
        driver = testBase.initialization();
        driver.get(prop.getProperty("App_URL"));
        loggerManager.getLogger().info(prop.getProperty("Browser") + " browser launched successfully");
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        accountPage = new AccountPage(driver);
        accountData = new LinkedHashMap<>();
        reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
        contactPage = new ContactPage(driver);
        opportunityPage=new OpportunityPage(driver);
    }

    @Test(description = "Verify that a field exists when creating a legal contracting entity from Account")
    @Severity(SeverityLevel.NORMAL)
    @Description("When creating a legal contracting entity fromm Account, the primary state picklist field should have Telangana as picklist value")
    @XrayTest(key = "MASFDCMNE-29448")
    @Tags({ @Tag("AccountFieldVerification"),@Tag("Positive") })
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyPickListFieldOnLegalContractingEntityCreationFromAccount(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.navigateToAgreementsTabOnAccount();
        accountPage.clickNewLegalContractingEntity();
        accountPage.filloutLegalContractingEntityMandatoryFields(accountData);
        accountPage.saveLegalContractingEntity();
    }

    @Test(description = "Verify that a list exists of legal contracting entities on Account page")
    @Severity(SeverityLevel.NORMAL)
    @Description("When a an account record is opened, under the agreements tab a legal contracting entities list should be there")
    @XrayTest(key = "MASFDCMNE-10208")
    @Tags({ @Tag("AccountFieldVerification"), @Tag("Positive")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyLegalContractingEntitiesListOnAccountPage_MarketingUserBvD(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        homePage.loginAs("Marketing User - BvD");
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.navigateToAgreementsTabOnAccount();
        accountPage.verifyLegalContractingEntitiesList();
    }
    @Test(description = "New Account Team Member Creation and Validation  for some fields on Account Team Member Record by Sales Rep Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-22725, MASFDCMNE-22577, MASFDCMNE-22578, MASFDCMNE-20993")
    @XrayTest(key = "MASFDCMNE-33723")
    @Tags({@Tag("AccountCreation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_SalesRep(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateAccountTeamMemberDetails(accountData);
        accountPage.validateSourceFieldValueOnAccountTeamMember();
        accountPage.validateTeamMemberActiveFieldandItsDefaultValue();
        accountPage.validateHelpTextForAccountTeamMemberFields();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value should not be updated on existing Account Team Member Record with Sales Rep profile when user edits Account Team Member Record")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33726")
    @XrayTest(key = "MASFDCMNE-33726")
    @Tags({@Tag("AccountUpdation"), @Tag("Negative"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedOnAccountTeamMember_SalesRep(Method Method){
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.validateSourceFieldValueUpdatedOnAccountTeamMember();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "New Account Team Member Creation and Validation for some fields on Account Team Member Record by Operation Analyst Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-22725,MASFDCMNE-22577, MASFDCMNE-22578, MASFDCMNE-20993")
    @XrayTest(key = "MASFDCMNE-33727")
    @Tags({@Tag("AccountCreation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_OperationAnalyst(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateAccountTeamMemberDetails(accountData);
        accountPage.validateSourceFieldValueOnAccountTeamMember();
        accountPage.validateTeamMemberActiveFieldandItsDefaultValue();
        accountPage.validateHelpTextForAccountTeamMemberFields();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value should not be updated on existing Account Team Member Record with Operation Analyst profile when user edits Account Team Member Record")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33737")
    @XrayTest(key = "MASFDCMNE-33737")
    @Tags({@Tag("AccountUpdation"), @Tag("Negative"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedOnAccountTeamMember_OperationAnalyst(Method Method){
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.validateSourceFieldValueUpdatedOnAccountTeamMember();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "New Account Team Member Creation and Validation for some fields on Account Team Member Record by Customer Success Account Development Specialist Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-22725,MASFDCMNE-22577, MASFDCMNE-22578, MASFDCMNE-20993")
    @XrayTest(key = "MASFDCMNE-33728")
    @Tags({@Tag("AccountCreation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_CustomerSuccessAccountDevelopmentSpecialist(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateAccountTeamMemberDetails(accountData);
        accountPage.validateSourceFieldValueOnAccountTeamMember();
        accountPage.validateTeamMemberActiveFieldandItsDefaultValue();
        accountPage.validateHelpTextForAccountTeamMemberFields();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value should not be updated on existing Account Team Member Record with Customer Success / Account Development Specialist profile when user edits Account Team Member Record")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33739")
    @XrayTest(key = "MASFDCMNE-33739")
    @Tags({@Tag("AccountUpdation"), @Tag("Negative"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedOnAccountTeamMember_CustomerSuccessAccountDevelopmentSpecialist(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.validateSourceFieldValueUpdatedOnAccountTeamMember();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "New Account Team Member Creation and Validation for some fields on Account Team Member Record by Data Management Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-22725, MASFDCMNE-22577, MASFDCMNE-22578, MASFDCMNE-20993")
    @XrayTest(key = "MASFDCMNE-33729")
    @Tags({@Tag("AccountCreation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_DataManagement(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateAccountTeamMemberDetails(accountData);
        accountPage.validateSourceFieldValueOnAccountTeamMember();
        accountPage.validateTeamMemberActiveFieldandItsDefaultValue();
        accountPage.validateHelpTextForAccountTeamMemberFields();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value should not be updated on existing Account Team Member Record with  Data Management profile when user edits Account Team Member Record")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33740")
    @XrayTest(key = "MASFDCMNE-33740")
    @Tags({@Tag("AccountUpdation"), @Tag("Negative"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedOnAccountTeamMember_DataManagement(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.validateSourceFieldValueUpdatedOnAccountTeamMember();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "New Account Team Member Creation and Validation for some fields on Account Team Member Record by Business Admin Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-22725,MASFDCMNE-22577, MASFDCMNE-22578, MASFDCMNE-20993")
    @XrayTest(key = "MASFDCMNE-33730")
    @Tags({@Tag("AccountCreation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_BusinessAdmin(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateAccountTeamMemberDetails(accountData);
        accountPage.validateSourceFieldValueOnAccountTeamMember();
        accountPage.validateTeamMemberActiveFieldandItsDefaultValue();
        accountPage.validateHelpTextForAccountTeamMemberFields();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value should not be updated on existing Account Team Member Record with Business Admin profile when user edits Account Team Member Record")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33741")
    @XrayTest(key = "MASFDCMNE-33741")
    @Tags({@Tag("AccountUpdation"), @Tag("Negative"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedOnAccountTeamMember_BusinessAdmin(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.validateSourceFieldValueUpdatedOnAccountTeamMember();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "New Account Team Member Creation and Validation for some fields on Account Team Member Record by System Admin Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-22724, MASFDCMNE-22577, MASFDCMNE-22578, MASFDCMNE-20993")
    @XrayTest(key = "MASFDCMNE-33722")
    @Tags({@Tag("AccountCreation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_SystemAdmin(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("System Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateAccountTeamMemberDetails(accountData);
        accountPage.validateSourceFieldValueOnAccountTeamMember();
        accountPage.validateTeamMemberActiveFieldandItsDefaultValue();
        accountPage.validateHelpTextForAccountTeamMemberFields();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value should not be updated on existing Account Team Member Record with  System Admin profile when user edits Account Team Member Recorde")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33742")
    @XrayTest(key = "MASFDCMNE-33742")
    @Tags({@Tag("AccountUpdation"), @Tag("Negative"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedOnAccountTeamMember_SystemAdmin(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("System Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.validateSourceFieldValueUpdatedOnAccountTeamMember();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value is Updated from Manual to Sales on Account Team Member Record by System Admin Profile when user tries to edit Account Team Member Record created by Sales Rep Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33724")
    @XrayTest(key = "MASFDCMNE-33724")
    @Tags({@Tag("AccountCreation"),@Tag("AccountUpdation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedFromManualToSalesOnAccountTeamMember(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        String recordId= accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        homePage.loginAs("System Admin");
        accountPage.navigateToAccountPageWithRecordId(recordId);
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateSourceFieldValueIsManual();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.validateSourceFieldValueUpdatedFromManualToSales();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Source Field Value is Updated from Sales to Manual on Account Team Member Record by Sales Rep Profile when user tries to edit Account Team Member Record created by System Admin Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33725")
    @XrayTest(key = "MASFDCMNE-33725")
    @Tags({@Tag("AccountCreation"),@Tag("AccountUpdation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifySourceFieldValueUpdatedFromSalesToManualOnAccountTeamMember(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("System Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        String recordId= accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        homePage.loginAs("Sales Rep");
        accountPage.navigateToAccountPageWithRecordId(recordId);
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateSourceFieldValueIsSales();
        accountPage.editAccountTeamMember();
        accountPage.editAndSaveAccountTeamMemberDetails();
        accountPage.verifySourceFieldValueUpdatedFromSalesToManual();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Users should be able to add Team Members or Users to any Role and should be able to edit existing team member record to add them to New Roles on Account Team Member Record  by Product Specialist/Account Manager Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-15026")
    @XrayTest(key = "MASFDCMNE-15026")
    @Tags({@Tag("AccountCreation"),@Tag("AccountUpdation"), @Tag("Positive"), @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("https://test.salesforce.com/")
    public void verifyAccountTeamMemberCreationAndRoleFieldValueUpdation_ProductSpecialistAccountManager(Method Method) {
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.clickOnDetailsTabOnAccountPage();
        accountPage.clickOnTeamSubTabFromDetailsTabOnAccountPage();
        accountPage.clickOnNewAddTeamMemberButton();
        accountPage.addandSaveNewTeamMemberDetails();
        accountPage.navigateToAccountTeamMemberRecord();
        accountPage.validateAccountTeamMemberDetails(accountData);
        accountPage.editAccountTeamMember();
        accountPage.updateRoleFieldValueOnAccountTeamMember();
        accountPage.validateRoleFieldValueOnAccountTeamMember();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify new Standard Account creation")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-6293 with mandatory fields using Save button by Sales Rep profile")
    @XrayTest(key = "MASFDCMNE-6293")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Business Admin profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33072")
    @XrayTest(key = "MASFDCMNE-33072")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Client Service profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33071")
    @XrayTest(key = "MASFDCMNE-33071")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33070")
    @XrayTest(key = "MASFDCMNE-33070")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Data Contributor profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33069")
    @XrayTest(key = "MASFDCMNE-33069")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Data Management profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33068")
    @XrayTest(key = "MASFDCMNE-33068")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33067")
    @XrayTest(key = "MASFDCMNE-33067")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Fulfillment Associate profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33066")
    @XrayTest(key = "MASFDCMNE-33066")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Created with mandatory fields using Save button by Operations Analyst profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33063")
    @XrayTest(key = "MASFDCMNE-33063")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33062")
    @XrayTest(key = "MASFDCMNE-33062")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33061")
    @XrayTest(key = "MASFDCMNE-33061")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by Sales Manager profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33060")
    @XrayTest(key = "MASFDCMNE-33060")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Standard Account Creation with mandatory fields using Save button by System Administrator profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33059")
    @XrayTest(key = "MASFDCMNE-33059")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify new Competitor Account creation")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-6294 with mandatory fields using Save button by Sales Rep profile")
    @XrayTest(key = "MASFDCMNE-6294")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Business Admin profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33102")
    @XrayTest(key = "MASFDCMNE-33102")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Client Service profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33103")
    @XrayTest(key = "MASFDCMNE-33103")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33104")
    @XrayTest(key = "MASFDCMNE-33104")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Data Contributor profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33105")
    @XrayTest(key = "MASFDCMNE-33105")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Data Management profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33106")
    @XrayTest(key = "MASFDCMNE-33106")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33107")
    @XrayTest(key = "MASFDCMNE-33107")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Fulfillment Associate profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33108")
    @XrayTest(key = "MASFDCMNE-33108")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Operations Analyst profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33110")
    @XrayTest(key = "MASFDCMNE-33110")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33111")
    @XrayTest(key = "MASFDCMNE-33111")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33112")
    @XrayTest(key = "MASFDCMNE-33112")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by Sales Manager profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33113")
    @XrayTest(key = "MASFDCMNE-33113")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "New Competitor Account Creation with mandatory fields using Save button by System Administrator profile")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Covers: MASFDCMNE-33114")
    @XrayTest(key = "MASFDCMNE-33114")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive"), @Tag("Sanity")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33027")
    @XrayTest(key = "MASFDCMNE-33027")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33115")
    @XrayTest(key = "MASFDCMNE-33115")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33116")
    @XrayTest(key = "MASFDCMNE-33116")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33117")
    @XrayTest(key = "MASFDCMNE-33117")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33118")
    @XrayTest(key = "MASFDCMNE-33118")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33119")
    @XrayTest(key = "MASFDCMNE-33119")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33120")
    @XrayTest(key = "MASFDCMNE-33120")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33121")
    @XrayTest(key = "MASFDCMNE-33121")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33123")
    @XrayTest(key = "MASFDCMNE-33123")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33124")
    @XrayTest(key = "MASFDCMNE-33124")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33125")
    @XrayTest(key = "MASFDCMNE-33125")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33126")
    @XrayTest(key = "MASFDCMNE-33126")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory fields using Save and New button by Operations Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33127")
    @XrayTest(key = "MASFDCMNE-33127")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryInfoUsingSaveAndNewBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33028")
    @XrayTest(key = "MASFDCMNE-33028")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33129")
    @XrayTest(key = "MASFDCMNE-33129")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33130")
    @XrayTest(key = "MASFDCMNE-33130")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33131")
    @XrayTest(key = "MASFDCMNE-33131")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33132")
    @XrayTest(key = "MASFDCMNE-33132")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33133")
    @XrayTest(key = "MASFDCMNE-33133")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33134")
    @XrayTest(key = "MASFDCMNE-33134")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33135")
    @XrayTest(key = "MASFDCMNE-33135")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Operations Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33137")
    @XrayTest(key = "MASFDCMNE-33137")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33138")
    @XrayTest(key = "MASFDCMNE-33138")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33139")
    @XrayTest(key = "MASFDCMNE-33139")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33140")
    @XrayTest(key = "MASFDCMNE-33140")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory fields using Save and New button by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33141")
    @XrayTest(key = "MASFDCMNE-33141")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryInfoUsingSaveAndNewBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAccountWithSaveAndNewButton(accountData);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", accountName);
        accountPage.validateMandatoryAccountInfo(accountData);
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33029")
    @XrayTest(key = "MASFDCMNE-33029")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Operation Analyst")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33186")
    @XrayTest(key = "MASFDCMNE-33186")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33187")
    @XrayTest(key = "MASFDCMNE-33187")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33188")
    @XrayTest(key = "MASFDCMNE-33188")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33189")
    @XrayTest(key = "MASFDCMNE-33189")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33190")
    @XrayTest(key = "MASFDCMNE-33190")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33191")
    @XrayTest(key = "MASFDCMNE-33191")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33192")
    @XrayTest(key = "MASFDCMNE-33192")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33194")
    @XrayTest(key = "MASFDCMNE-33194")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33195")
    @XrayTest(key = "MASFDCMNE-33195")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33197")
    @XrayTest(key = "MASFDCMNE-33197")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33198")
    @XrayTest(key = "MASFDCMNE-33198")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33199")
    @XrayTest(key = "MASFDCMNE-33199")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccountUsingSaveButton_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33030")
    @XrayTest(key = "MASFDCMNE-33030")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33200")
    @XrayTest(key = "MASFDCMNE-33200")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Operation Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33203")
    @XrayTest(key = "MASFDCMNE-33203")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33204")
    @XrayTest(key = "MASFDCMNE-33204")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33205")
    @XrayTest(key = "MASFDCMNE-33205")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33206")
    @XrayTest(key = "MASFDCMNE-33206")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33207")
    @XrayTest(key = "MASFDCMNE-33207")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33208")
    @XrayTest(key = "MASFDCMNE-33208")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33211")
    @XrayTest(key = "MASFDCMNE-33211")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33212")
    @XrayTest(key = "MASFDCMNE-33212")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33213")
    @XrayTest(key = "MASFDCMNE-33213")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33214")
    @XrayTest(key = "MASFDCMNE-33214")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save button by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33215")
    @XrayTest(key = "MASFDCMNE-33215")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33031")
    @XrayTest(key = "MASFDCMNE-33031")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33216")
    @XrayTest(key = "MASFDCMNE-33216")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33217")
    @XrayTest(key = "MASFDCMNE-33217")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33219")
    @XrayTest(key = "MASFDCMNE-33219")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33220")
    @XrayTest(key = "MASFDCMNE-33220")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33221")
    @XrayTest(key = "MASFDCMNE-33221")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33222")
    @XrayTest(key = "MASFDCMNE-33222")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33223")
    @XrayTest(key = "MASFDCMNE-33223")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33224")
    @XrayTest(key = "MASFDCMNE-33224")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33225")
    @XrayTest(key = "MASFDCMNE-33225")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by Operations Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33226")
    @XrayTest(key = "MASFDCMNE-33226")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33227")
    @XrayTest(key = "MASFDCMNE-33227")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Standard Account record without mandatory fields using Save and New button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33227")
    @XrayTest(key = "MASFDCMNE-33227")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnStdAccUsingSaveAndNewBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Standard Account");
        accountPage.enterOptionalFieldsOnStandardAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33032")
    @XrayTest(key = "MASFDCMNE-33032")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33231")
    @XrayTest(key = "MASFDCMNE-33231")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Operations Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33232")
    @XrayTest(key = "MASFDCMNE-33232")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_OperationsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33233")
    @XrayTest(key = "MASFDCMNE-33233")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33234")
    @XrayTest(key = "MASFDCMNE-33234")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33235")
    @XrayTest(key = "MASFDCMNE-33235")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33236")
    @XrayTest(key = "MASFDCMNE-33236")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33237")
    @XrayTest(key = "MASFDCMNE-33237")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33239")
    @XrayTest(key = "MASFDCMNE-33239")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33240")
    @XrayTest(key = "MASFDCMNE-33240")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33241")
    @XrayTest(key = "MASFDCMNE-33241")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33243")
    @XrayTest(key = "MASFDCMNE-33243")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }

    @Test(description = "Verify the validation message when user tries to create a new Competitor Account record without mandatory fields using Save and New button by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33230")
    @XrayTest(key = "MASFDCMNE-33230")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Negative")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMissingMandatoryInfoErrorOnCompetitorAccUsingSaveAndNewBtn_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.selectAccountRecordType("Competitor Account");
        accountPage.enterOptionalFieldsOnCompetitorAccount(accountData);
        accountPage.validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton();
    }
    @Test(description = "Verify that New Task and New Event buttons exist on a record")
    @Severity(SeverityLevel.MINOR)
    @Description("Verifies the presence of New Task and New Event buttons on account, contact, and opportunity records")
    @XrayTest(key = "MASFDCMNE-7304")
    @Tags({@Tag("Positive"), @Tag("VerifyButtonsOnRecord"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyNewTaskAndNewEventButtonsOnRecords_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        //navigate to a recently created opportunity
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickOnRecentlyCreatedRecord();
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Task");
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Event");
        //navigate to a recently created contact
        reusableBusinessLibrary.openSFDCTab("Contacts");
        reusableBusinessLibrary.clickOnRecentlyCreatedRecord();
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Task");
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Event");
        //create new account
        reusableBusinessLibrary.openSFDCTab("Accounts");
        reusableBusinessLibrary.clickOnRecentlyCreatedRecord();
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Task");
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Event");
    }

    @Test(description = "Verify that New Task and New Event buttons exist on a record")
    @Severity(SeverityLevel.MINOR)
    @Description("Verifies the presence of New Task and New Event buttons on account, contact, and opportunity records")
    @XrayTest(key = "MASFDCMNE-7304")
    @Tags({@Tag("Positive"), @Tag("VerifyButtonsOnRecord"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyNewTaskAndNewEventButtonsOnRecords_OpsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        //navigate to a recently created opportunity
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickOnRecentlyCreatedRecord();
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Task");
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Event");
        //navigate to a recently created contact
        reusableBusinessLibrary.openSFDCTab("Contacts");
        reusableBusinessLibrary.clickOnRecentlyCreatedRecord();
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Task");
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Event");
        //navigate to a recently created Account
        reusableBusinessLibrary.openSFDCTab("Accounts");
        reusableBusinessLibrary.clickOnRecentlyCreatedRecord();
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Task");
        reusableBusinessLibrary.verifyBtnIsDisplayed("New Event");
    }

    @Test(description = "New oppy must not get create if an account has Company Status = Unknown")
    @Severity(SeverityLevel.NORMAL)
    @Description("Opportunity creation with Account having Company Status as Unknown")
    @XrayTest(key = "MASFDCMNE-24639")
    @Owner("Sayon Das")
    @Tags({@Tag("AccountOpportunityCreation"), @Tag("Negative")})
    @Link("https://test.salesforce.com/")
    public void validateOpportunityCreationwithAccountCompanyasUnknown(Method method){
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.clickEditButton();
        accountPage.updateAccountCompanyStatusInfo("Unknown");
        reusableBusinessLibrary.openSFDCSubTab("Opportunities");
        accountPage.clickNewSalesOpenOpportunityFromOpportunitySubTab();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(readExcelRows(opportunitiesFilePath, TCName).get(0));
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateErrorInfo();
    }

    @Test(description = "New oppy must not get create if an account has Company Status = Inactive")
    @Severity(SeverityLevel.NORMAL)
    @Description("Opportunity creation with Account having Company Status as Inactive")
    @XrayTest(key = "MASFDCMNE-24639")
    @Owner("Sayon Das")
    @Tags({@Tag("AccountOpportunityCreation"), @Tag("Negative")})
    @Link("https://test.salesforce.com/")
    public void validateOpportunityCreationwithAccountCompanyasInactive(Method method){
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.clickEditButton();
        accountPage.updateAccountCompanyStatusInfo("Inactive");
        reusableBusinessLibrary.openSFDCSubTab("Opportunities");
        accountPage.clickNewSalesOpenOpportunityFromOpportunitySubTab();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(readExcelRows(opportunitiesFilePath, TCName).get(0));
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateErrorInfo();
    }

    @Test(description = "Regression scenario: Opportunity creation when parent account of the sold account has the location and sold to account is missing the account locations")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify opportunity creation when parent account of the sold account has the location and sold to account is missing the account locations")
    @XrayTest(key = "MASFDCMNE-18926")
    @Owner("Sayon Das")
    @Tags({@Tag("AccountOpportunityCreation"), @Tag("Positive")})
    @Link("https://test.salesforce.com/")
    public void validateOpportunityCreationwithChildAccount(Method method){
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        accountPage.clickEditButton();
        accountPage.updateParentAccount(accountData);
        reusableBusinessLibrary.openSFDCSubTab("Opportunities");
        accountPage.clickNewSalesOpenOpportunityFromOpportunitySubTab();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(readExcelRows(opportunitiesFilePath, TCName).get(0));
        reusableBusinessLibrary.clickSaveBtn();
        accountPage.validateOpportunityCreationinAccountPage();
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33388")
    @XrayTest(key = "MASFDCMNE-33388")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Operations Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33390")
    @XrayTest(key = "MASFDCMNE-33390")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33389")
    @XrayTest(key = "MASFDCMNE-33389")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33391")
    @XrayTest(key = "MASFDCMNE-33391")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33392")
    @XrayTest(key = "MASFDCMNE-33392")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33393")
    @XrayTest(key = "MASFDCMNE-33393")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33394")
    @XrayTest(key = "MASFDCMNE-33394")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33395")
    @XrayTest(key = "MASFDCMNE-33395")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33397")
    @XrayTest(key = "MASFDCMNE-33397")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33400")
    @XrayTest(key = "MASFDCMNE-33400")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33401")
    @XrayTest(key = "MASFDCMNE-33401")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33402")
    @XrayTest(key = "MASFDCMNE-33402")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Standard Account record with mandatory and optional fields by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33403")
    @XrayTest(key = "MASFDCMNE-33403")
    @Tags({@Tag("StandardAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyStdAccCreationWithMandatoryAndOptionalInfo_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33387")
    @XrayTest(key = "MASFDCMNE-33387")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Operation Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33404")
    @XrayTest(key = "MASFDCMNE-33404")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33405")
    @XrayTest(key = "MASFDCMNE-33405")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33409")
    @XrayTest(key = "MASFDCMNE-33409")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33412")
    @XrayTest(key = "MASFDCMNE-33412")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33414")
    @XrayTest(key = "MASFDCMNE-33414")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33416")
    @XrayTest(key = "MASFDCMNE-33416")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33417")
    @XrayTest(key = "MASFDCMNE-33417")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33418")
    @XrayTest(key = "MASFDCMNE-33418")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33419")
    @XrayTest(key = "MASFDCMNE-33419")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33420")
    @XrayTest(key = "MASFDCMNE-33420")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33421")
    @XrayTest(key = "MASFDCMNE-33421")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to create a new Competitor Account record with mandatory and optional fields by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33422")
    @XrayTest(key = "MASFDCMNE-33422")
    @Tags({@Tag("CompetitorAccountCreation"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyCompetitorAccCreationWithMandatoryAndOptionalInfo_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.validateMandatoryAccountInfo(accountData);
        accountPage.validateOptionalInfoOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Operation Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33423")
    @XrayTest(key = "MASFDCMNE-33423")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33424")
    @XrayTest(key = "MASFDCMNE-33424")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33425")
    @XrayTest(key = "MASFDCMNE-33425")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33426")
    @XrayTest(key = "MASFDCMNE-33426")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33427")
    @XrayTest(key = "MASFDCMNE-33427")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33273")
    @XrayTest(key = "MASFDCMNE-33273")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33428")
    @XrayTest(key = "MASFDCMNE-33428")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33429")
    @XrayTest(key = "MASFDCMNE-33429")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33430")
    @XrayTest(key = "MASFDCMNE-33430")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33431")
    @XrayTest(key = "MASFDCMNE-33431")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by ERS Practice Lead / Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33432")
    @XrayTest(key = "MASFDCMNE-33432")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33433")
    @XrayTest(key = "MASFDCMNE-33433")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Standard Account record by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33434")
    @XrayTest(key = "MASFDCMNE-33434")
    @Tags({@Tag("StandardAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingStdAcc_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnStandardAccount(accountData);
        accountPage.validateUpdatedFieldsOnStandardAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Sales Rep profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33275")
    @XrayTest(key = "MASFDCMNE-33275")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Operation Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33437")
    @XrayTest(key = "MASFDCMNE-33437")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by System Administrator profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33438")
    @XrayTest(key = "MASFDCMNE-33438")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_SystemAdministrator(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Customer Success / Account Development Specialist profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33439")
    @XrayTest(key = "MASFDCMNE-33439")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_CustomerSuccessAccountDevelopmentSpecialist(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Customer Success / Account Development Specialist");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Product Specialist/Account Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33442")
    @XrayTest(key = "MASFDCMNE-33442")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Product Strategy / Product Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33440")
    @XrayTest(key = "MASFDCMNE-33440")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_ProductStrategyProductManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Strategy / Product Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Client Service profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33441")
    @XrayTest(key = "MASFDCMNE-33441")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Client Service");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Data Management profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33443")
    @XrayTest(key = "MASFDCMNE-33443")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_DataManagement(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Management");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33444")
    @XrayTest(key = "MASFDCMNE-33444")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by ERS Practice Lead/Project Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33445")
    @XrayTest(key = "MASFDCMNE-33445")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_ERSPracticeLeadProjectManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Fulfillment Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33446")
    @XrayTest(key = "MASFDCMNE-33446")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_FulfillmentAssociate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Fulfillment Associate");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Data Contributor profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33447")
    @XrayTest(key = "MASFDCMNE-33447")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_DataContributor(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Data Contributor");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user is able to edit a Competitor Account record by Sales Manager profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33448")
    @XrayTest(key = "MASFDCMNE-33448")
    @Tags({@Tag("CompetitorAccountUpdate"), @Tag("Positive")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void editFieldsOnExistingCompetitorAcc_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(accountData);
        accountPage.getAccountIDAndStoreInExcel();
        accountPage.editFieldsOnCompetitorAccount(accountData);
        accountPage.validateUpdatedFieldsOnCompetitorAccount(accountData);
    }

    @Test(description = "Verify that user should be able to create a new contact from Contacts tab on Account page_SalesRep")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression"+" Covers: MASFDCMNE-22693 & MASFDCMNE-25995")
    @XrayTest(key = "MASFDCMNE-33713")
    @Owner("Rishi Saini")
    @Tags({@Tag("AccountWorkflow"), @Tag("CreateContactFromAccount"), @Tag("Positive")})
    @Link("https://test.salesforce.com/")
    public void createContactFromAccount_SalesRep(Method Method){
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        String RecordID = ReusableLibrary.readExcelData(accountsFilePath, TCName, "SFDC Account ID");
        loginPage.login();
        homePage.loginAs("Sales Rep");
        accountPage.navigateToAccountPageWithRecordId(RecordID);
        accountPage.getAccountDetailsForValidation();
        accountPage.clickOnContactSubTabFromAccountPage();
        contactPage.enterRequiredFieldsOnContactCreatedFromAccount();
        contactPage.saveContactandNavigatetoNewContactRecord();
        contactPage.validateContactDetails();
    }

    @Test(description = "Verify that user should be able to create a new contact from Contacts tab on Account page_OperationalAnaylst")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression"+" Covers: MASFDCMNE-22693 & MASFDCMNE-25995")
    @XrayTest(key = "MASFDCMNE-33714")
    @Owner("Rishi Saini")
    @Tags({@Tag("AccountWorkflow"), @Tag("CreateContactFromAccount"), @Tag("Positive")})
    @Link("https://test.salesforce.com/")
    public void createContactFromAccount_OperationalAnalyst(Method Method){
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        String RecordID = ReusableLibrary.readExcelData(accountsFilePath, TCName, "SFDC Account ID");
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        accountPage.navigateToAccountPageWithRecordId(RecordID);
        accountPage.getAccountDetailsForValidation();
        accountPage.clickOnContactSubTabFromAccountPage();
        contactPage.enterRequiredFieldsOnContactCreatedFromAccount();
        contactPage.saveContactandNavigatetoNewContactRecord();
        contactPage.validateContactDetails();
    }

    @Test(description = "Verify that user should be able to create a new contact from Contacts tab on Account page_DataManagement")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression"+" Covers: MASFDCMNE-22693 & MASFDCMNE-25995")
    @XrayTest(key = "MASFDCMNE-33716")
    @Owner("Rishi Saini")
    @Tags({@Tag("AccountWorkflow"), @Tag("CreateContactFromAccount"), @Tag("Positive")})
    @Link("https://test.salesforce.com/")
    public void createContactFromAccount_DataManagement(Method Method){
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        String RecordID = ReusableLibrary.readExcelData(accountsFilePath, TCName, "SFDC Account ID");
        loginPage.login();
        homePage.loginAs("Data Management");
        accountPage.navigateToAccountPageWithRecordId(RecordID);
        accountPage.getAccountDetailsForValidation();
        accountPage.clickOnContactSubTabFromAccountPage();
        contactPage.enterRequiredFieldsOnContactCreatedFromAccount();
        contactPage.saveContactandNavigatetoNewContactRecord();
        contactPage.validateContactDetails();
    }

    @Test(description = "Verify that user should be able to create a new contact from Contacts tab on Account page_Business Admin")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression"+" Covers: MASFDCMNE-22693 & MASFDCMNE-25995")
    @XrayTest(key = "MASFDCMNE-33717")
    @Owner("Rishi Saini")
    @Tags({@Tag("AccountWorkflow"), @Tag("CreateContactFromAccount"), @Tag("Positive")})
    @Link("https://test.salesforce.com/")
    public void createContactFromAccount_BusinessAdmin(Method Method){
        TCName = Method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        String RecordID = ReusableLibrary.readExcelData(accountsFilePath, TCName, "SFDC Account ID");
        loginPage.login();
        homePage.loginAs("Business Admin");
        accountPage.navigateToAccountPageWithRecordId(RecordID);
        accountPage.getAccountDetailsForValidation();
        accountPage.clickOnContactSubTabFromAccountPage();
        contactPage.enterRequiredFieldsOnContactCreatedFromAccount();
        contactPage.saveContactandNavigatetoNewContactRecord();
        contactPage.validateContactDetails();
    }
    @Test(description = "Create Account from Orbis")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Create Account from orbis, covers MASFDCMNE-7988")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7988")
    public void createAccountFromOrbis(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openOrbisSearch();
        homePage.orbisSearchwithCompany(readExcelData(accountsFilePath,TCName,"CompanyNametoSearch"));
        homePage.orbisRecordtoImport("Account");
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify Orbis SF Account Linkage")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify Orbis SF Account linkage available from Account Details page. Covers MASFDCMNE-7993" )
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7993")
    public void verifyOrbisAccountLinkage(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
        accountPage.unlinkAccountfromOrbisValidateLinkage();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify ability to access account on orbis")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify user can search Account from Orbis and access to navigate to Orbis account page. Covers MASFDCMNE-7992")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7992")
    public void verifyAbilitytoAccessAccountonOrbis(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openOrbisSearch();
        homePage.orbisSearchwithCompany(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"Account Name"));
        homePage.verifyOrbisResultAccountAvailability();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify ability to access orbis account hierarchy, reports")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify user can link account from Orbis and access hierarchy, reports. Covers MASFDCMNE-7990")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7990")
    public void verifyAbilitytoAccessOrbisHierarchyReports(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
        accountPage.linkAccountfromOrbisifNotLinkedAlready();
        accountPage.verifyOrbisHierarchyReportsAccessibility();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify Orbis panel added to Account page")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify Orbis panel added to Account page, covers MASFDCMNE-7987")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7987")
    public void verifyOrbisPanelAddedtoAccountOnceImport(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openOrbisSearch();
        homePage.orbisSearchwithCompany(readExcelData(accountsFilePath,TCName,"CompanyNametoSearch"));
        homePage.orbisRecordtoImport("Account");
        accountPage.accessOrbisSFDCAccount_ValidateOrbisPanel();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify certain profiles do not have access to unlink Orbis account")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify certain profiles do not have access to unlink Orbis account, covers MASFDCMNE-7986")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7986")
    public void verifyProfilesUnableToUnlinkAcctfrmOrbis_ClientService(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Client Service");
        homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
        if (accountPage.isAccountLinktoOrbis()) {
            accountPage.verifyAbsenceofUnlinkAccountfromOrbis();
        } else {
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
            homePage.loginAs("Business Admin");
            homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
            accountPage.linkAccountfromOrbisifNotLinkedAlready();
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
            homePage.loginAs("Client Service");
            homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
            if (accountPage.isAccountLinktoOrbis()) {
                accountPage.verifyAbsenceofUnlinkAccountfromOrbis();
            }
        }
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify that the Orbis account is linked with existing SFDC account .")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify that the ORBIS account is linked with existing SFDC account by validating BVDid exist. Covers MASFDCMNE-7985")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7985")
    public void verifyOrbisAccountLinkwithExistingSFDCAccount(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
        accountPage.linkAccountfromOrbisifNotLinkedAlready();
        accountPage.verifyBvdIDExist();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify that user has ability to search for accounts that are not in SFDC")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify that user has ability to search for accounts that are not in SFDC, covers MASFDCMNE-7982")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7982")
    public void verifyUserCanSearchAccountNotInSFDC(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openOrbisSearch();
        homePage.orbisSearchwithCompany(readExcelData(accountsFilePath,TCName,"CompanyNametoSearch"));
        homePage.orbisSearchShowsRecordNotInSFDC();
        homePage.changeOrbisSearchCriteria("Bank");
        homePage.orbisSearchShowsRecordNotInSFDC();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");

    }

    @Test(description = "Verify that user is able to import an account from ORBIS to SFDC, use of update CRM from orbis account page")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify that user is able to import an account from ORBIS to SFDC, use of update CRM from orbis account page, covers MASFDCMNE-7981")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7981")
    public void verifyUserAbletoImportOrbisAccttoSFDCwithUpdateCRM(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openOrbisSearch();
        homePage.orbisSearchwithCompany(readExcelData(accountsFilePath,TCName,"CompanyNametoSearch"));
        homePage.importOrbisAccountwithActionUpdateCRM();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify user would be able to unlink SFDC account from Orbis data.")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify user would be able to unlink SFDC account from Orbis data. Covers MASFDCMNE-7978" )
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7978")
    public void verifyUserUnlinkOrbisAccountandComponentDisappeared(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
        accountPage.unlinkAccountfromOrbisValidateLinkage();

        accountPage.verifyOrbisComponentdoesnotExist();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify ability to update an existing SFDC account with Orbis info.")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify ability to update an existing SFDC account with Orbis info. Covers MASFDCMNE-7989" )
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-7989")
    public void verifyAbilitytoUpdateSFDCAccountwithOrbisInfo(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
        accountPage.linkAccountfromOrbisifNotLinkedAlready();
        accountPage.updateSFDCAccountwithOrbisInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @Test(description = "Verify certain profiles do not have access to unlink Orbis account")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify certain profiles do not have access to unlink Orbis account, covers MASFDCMNE-33757")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Account"),@Tag("Orbis")})
    @XrayTest(key = "MASFDCMNE-33757")
    public void verifyProfilesUnableToUnlinkAcctfrmOrbis_ERSPracticeLeadPM(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
        if (accountPage.isAccountLinktoOrbis()) {
            accountPage.verifyAbsenceofUnlinkAccountfromOrbis();
        } else {
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
            homePage.loginAs("Business Admin");
            homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
            accountPage.linkAccountfromOrbisifNotLinkedAlready();
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
            homePage.loginAs("ERS Practice Lead/Project Manager");
            homePage.openSFDCRecordByID(ReusableLibrary.readExcelData(accountsFilePath,method.getName(),"SFDC Account ID"));
            if (accountPage.isAccountLinktoOrbis()) {
                accountPage.verifyAbsenceofUnlinkAccountfromOrbis();
            }
        }
        loggerManager.getLogger().info("Test case: " + TCName + " completed");
    }

    @AfterMethod
    public void tearDown(){
        if (driver != null) {
            driver.quit();
        }
    }
}