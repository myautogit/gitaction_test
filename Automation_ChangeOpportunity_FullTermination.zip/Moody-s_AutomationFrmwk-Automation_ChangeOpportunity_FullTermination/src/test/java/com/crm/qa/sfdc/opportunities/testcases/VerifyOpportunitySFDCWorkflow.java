package com.crm.qa.sfdc.opportunities.testcases;

import app.getxray.xray.testng.annotations.XrayTest;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.*;
import com.crm.qa.util.AllureListener;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.openRecordBySFDCID;
import static com.crm.qa.util.ReusableLibrary.*;
import static com.crm.qa.util.ReusableLibrary.currentDatePlusMonths;
import static com.crm.qa.util.ReusableLibrary.readExcelRows;

import static com.crm.qa.util.ReusableLibrary.readExcelData;


@Listeners({app.getxray.xray.testng.listeners.XrayListener.class, AllureListener.class})
public class VerifyOpportunitySFDCWorkflow extends TestBase {
    public TestBase testBase;
    public ReusableLibrary reusableLibrary;
    public WebDriver driver;
    Properties prop;
    LoginPage loginPage;
    HomePage homePage;
    AccountPage accountPage;
    ContactPage contactPage;
    TaskPage taskPage;
    CampaignPage campaignPage;
    OpportunityPage opportunityPage;
    QuotePage quotePage;
    ReusableBusinessLibrary reusableBusinessLibrary;
    LinkedHashMap<String, String> accountData;
    LinkedHashMap<String, String> opportunityData;
    List<LinkedHashMap<String, String>> quoteData;

    @BeforeMethod
    public void setUp() {
        testBase = new TestBase();
        prop = reusableLibrary.initializeProperties();
        driver = testBase.initialization();
        driver.get(prop.getProperty("App_URL"));
        loggerManager.getLogger().info(prop.getProperty("Browser") + " browser launched successfully");
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        accountPage = new AccountPage(driver);
        contactPage = new ContactPage(driver);
        opportunityPage = new OpportunityPage(driver);
        taskPage = new TaskPage(driver);
        campaignPage = new CampaignPage(driver);
        quotePage = new QuotePage(driver);
        reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
        accountData = new LinkedHashMap<>();
        opportunityData = new LinkedHashMap<>();
        quoteData = new ArrayList<>();
    }

    @Test(description = "Verify that a multi year opportunity can be created from account")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that a multi year opportunity can be created from account record")
    @XrayTest(key = "MASFDCMNE-20934")
    @Tags({@Tag("Positive"), @Tag("AccountOpportunityCreation"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void createMultiYearOpportunityFromAccount(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        reusableBusinessLibrary.openSFDCSubTab("Opportunities");
        accountPage.clickNewSalesOpenOpportunityFromOpportunitySubTab();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        accountPage.navigateToNewlyCreatedOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
    }

    @Test(description = "Verify that a single year opportunity can be created from account")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that a single year opportunity can be created from account")
    @XrayTest(key = "MASFDCMNE-20924")
    @Tags({@Tag("Positive"), @Tag("AccountOpportunityCreation"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void createSingleYearOpportunityFromAccount(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        accountPage.createStandardAccountWithSaveButton(accountData);
        reusableBusinessLibrary.openSFDCSubTab("Opportunities");
        accountPage.clickNewSalesOpenOpportunityFromOpportunitySubTab();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        accountPage.navigateToNewlyCreatedOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
    }

    @Test(description = "Create a new opportunity and verify a field on it")
    @Severity(SeverityLevel.NORMAL)
    @Description("Create a new opportunity and verify record type field once it is created")
    @XrayTest(key = "MASFDCMNE-20731")
    @Owner("Vatsala Bahal")
    @Tags({@Tag("Positive"), @Tag("OpportunityCreation"), @Tag("ExistingData")})
    @Link("SFDC: https://test.salesforce.com/")
    public void createOpportunityAndVerifyRecordTypeField(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        opportunityPage.createNewSalesOpportunityWithMandatoryFieldsAndSave(opportunityData);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify creation of opportunity with different Contract Specialist than the login profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that opportunity can be successfully created when the Contract Specialist entered in the opportunity is different from the login profile user and both are operation analysts")
    @XrayTest(key = "MASFDCMNE-12293")
    @Tags({@Tag("Positive"), @Tag("OpportunityCreation"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void createOpportunityWithDifferentContractSpecialistProfile(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        opportunityPage.createNewSalesOpportunityWithMandatoryFieldsAndSave(opportunityData);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify SDR user is able to capture information on the Opportunity.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Edit fields on New Sales Opportunity and ensure that fields are updated accordingly")
    @XrayTest(key = "MASFDCMNE-20741")
    @Tags({@Tag("Positive"), @Tag("EditOpportunity")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void editFieldsAndUpdateOpportunity(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        opportunityPage.createNewSalesOpportunityWithMandatoryFieldsAndSave(opportunityData);
        opportunityPage.editFieldsOnNewSalesOpportunity(opportunityData);
        opportunityPage.validateUpdatedFieldsOnNewSalesOpportunity(opportunityData);
    }

    @Test(description = "Verify SDR user is able to progress the opportunity through different stages.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify opportunity can be changed to all the possible stages")
    @XrayTest(key = "MASFDCMNE-20781")
    @Tags({@Tag("Positive"), @Tag("EditOpportunity"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyStageChangeOnOpportunity(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Opportunities", opportunityData.get("OpportunityName"));
        opportunityPage.verifyOpportunityRecordType();
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.changeStages(opportunityData.get("OpportunityRecordType"));
    }
    @Test(description = "Verify SDR user is able to override the probability.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify probability of opportunity conversion can be overridden on an existing opportunity")
    @XrayTest(key = "MASFDCMNE-20779")
    @Tags({@Tag("Positive"), @Tag("EditOpportunity"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyProbabilityOverrideOnOpportunity(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        opportunityPage.createNewSalesOpportunityWithMandatoryFieldsAndSave(opportunityData);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.overrideProbabilityOnOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(readExcelRows(opportunitiesFilePath, TCName).get(0));
    }

    @Test(description = "Verify Affiliate Sales Opportunity Creation  using Save button by Sales Rep Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33838")
    @XrayTest(key = "MASFDCMNE-33838")
    @Tags({@Tag("Positive"), @Tag("OpportunityCreation") , @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyAffiliateSalesOpportunityCreationUsingSaveBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterAffiliateSalesOpportunityDetails();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateAffiliateSalesOpportunityDetails();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Affiliate Sales Opportunity Creation  using Save button by Operation Analyst Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33839")
    @XrayTest(key = "MASFDCMNE-33839")
    @Tags({@Tag("Positive"), @Tag("OpportunityCreation") , @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyAffiliateSalesOpportunityCreationUsingSaveBtn_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterAffiliateSalesOpportunityDetails();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateAffiliateSalesOpportunityDetails();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Affiliate Sales Opportunity Creation  using Save and New  button by Sales Rep Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33840")
    @XrayTest(key = "MASFDCMNE-33840")
    @Tags({@Tag("Positive"), @Tag("OpportunityCreation") , @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyAffiliateSalesOpportunityCreationUsingSaveAndNewBtn_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterAffiliateSalesOpportunityDetails();
        reusableBusinessLibrary.clickSaveAndNewBtn();
        opportunityPage.cancelOpportunityRecordPage();
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Opportunities", oppyName);
        opportunityPage.validateAffiliateSalesOpportunityDetails();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify Affiliate Sales Opportunity Creation  using Save and New  button by Operation Analyst Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-33841")
    @XrayTest(key = "MASFDCMNE-33841")
    @Tags({@Tag("Positive"), @Tag("OpportunityCreation") , @Tag("Sanity")})
    @Owner("Bhagyashree Wani")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyAffiliateSalesOpportunityCreationUsingSaveAndNewBtn_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterAffiliateSalesOpportunityDetails();
        reusableBusinessLibrary.clickSaveAndNewBtn();
        opportunityPage.cancelOpportunityRecordPage();
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Opportunities", oppyName);
        opportunityPage.validateAffiliateSalesOpportunityDetails();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify that the values Product and Prime Partner is added to the field Partnership/Alliance: Sale Type on New Sale opportunity")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-30318, MASFDCMNE-24614")
    @XrayTest(key = "MASFDCMNE-33799")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyPartnershipAllianceSalesTypePicklistValueOnNewSale(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        openRecordBySFDCID(accountData.get("SFDC Account ID"));
        reusableBusinessLibrary.clickEditBtn();
        accountPage.deselectAllPartnershipAllianceAuthorizationValues();
        accountPage.selectPartnershipAllianceAuthorization(readExcelData(accountsFilePath, TCName, "PartnershipAllianceAuthorization"));
        reusableBusinessLibrary.clickSaveBtn();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.selectAccountNameOnOpportunity(accountData.get("Account Name"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.selectPartnerAccountOnOpportunity(accountData.get("Account Name"));
        opportunityPage.selectPartnershipAllianceSalesTypeValue(readExcelData(opportunitiesFilePath, TCName, "PartnershipAllianceSalesType"));
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyPartnershipAllianceSalesTypeValue(readExcelData(opportunitiesFilePath, TCName, "PartnershipAllianceSalesType"));
    }

    @Test(description = "Verify that the values Product and Prime Partner is added to the field Partnership/Alliance: Sale Type on Renewal Sales opportunity")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-30321, MASFDCMNE-24615")
    @XrayTest(key = "MASFDCMNE-33800")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("ExistingData"), @Tag("RenewalSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyPartnershipAllianceSalesTypePicklistValueOnRenewalSale(Method method) {
        TCName = method.getName();
        accountData = readExcelRows(accountsFilePath, TCName).get(0);
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.selectRelatedToThirdPartyOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "OppyThirdPartyOption"));
        opportunityPage.selectPartnerAccountOnOpportunity(accountData.get("Account Name"));
        opportunityPage.selectPartnershipAllianceSalesTypeValue(readExcelData(opportunitiesFilePath, TCName, "PartnershipAllianceSalesType"));
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyPartnershipAllianceSalesTypeValue(readExcelData(opportunitiesFilePath, TCName, "PartnershipAllianceSalesType"));
    }

    @Test(description = "Verify that a new opportunity stage is created called SDR Qualified.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-17880")
    @XrayTest(key = "MASFDCMNE-17880")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityStageValues(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        opportunityPage.verifyOpportunityStages("SDR Qualified", "New Sales");
        opportunityPage.verifyOpportunityStages("SDR Qualified", "Opportunity Lite");
    }

    @Test(description = "Verify that left arrow symbol for Renewal Opportunity and right arrow symbol for Source Opportunity is present")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-26329,MASFDCMNE-26330")
    @XrayTest(key = "MASFDCMNE-33801")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("ExistingData"), @Tag("RenewalSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyRenewalOpportunityAndSourceIcons(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        opportunityPage.verifyRenewalSourceRightArrowIcon();
        opportunityPage.clickRenewalSourceIcon();
        opportunityPage.verifyRenewalOpportunityLeftArrowIcon();
    }

    @Test(description = "Verify the sequence of the fields under Services Data section on the Opportunity")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-27577,MASFDCMNE-13718")
    @XrayTest(key = "MASFDCMNE-33864")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("ExistingData"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyServiceDataSectionFields(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        homePage.checkMoodysApp();
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        opportunityPage.verifyServiceDataSectionFields(readExcelData(opportunitiesFilePath, TCName, "ServiceDataSectionFields"));
    }

    @Test(description = "Quip tab must be available on opportunity record")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-26268")
    @XrayTest(key = "MASFDCMNE-26268")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyQuipTabOnOpportunity(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyQuipTab();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        homePage.loginAs("Sales Manager");
        openRecordBySFDCID(oppyID);
        opportunityPage.verifyQuipTab();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        homePage.loginAs("Sales Administrator");
        openRecordBySFDCID(oppyID);
        opportunityPage.verifyQuipTab();
    }

    @Test(description = "Verify that updated dates on opportunity should get reflected to the quote and the Proposal Name is displayed instead of the Account Name under the Proposal Related List on Opportunity ")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-12195,MASFDCMNE-15030")
    @XrayTest(key = "MASFDCMNE-33865")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyDatesUpdateFromOpportunityToQuote(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.updateDatesOnOpportunity();
        opportunityPage.verifyDatesOnOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.navigateToQuoteFromApttus();
        quotePage.verifyQuoteDates(newStartDate, newEndDate);
        openRecordBySFDCID(oppyID);
        opportunityPage.verifyProposalNameFieldOnOpportunity();
    }

    @Test(description = "Verify that the field 'Mismatched Allocation' should not be visible for any profile users on opportunity.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-18583")
    @XrayTest(key = "MASFDCMNE-18583")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Negative"), @Tag("ExistingData"), @Tag("NewSales"), @Tag("RenewalSales"), @Tag("ChangeOpportunity")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyMismatchedAllocationField(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyMismatchedAllocationFieldVisibility();
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        opportunityPage.verifyMismatchedAllocationFieldVisibility();
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ChangeOpportunityID"));
        opportunityPage.verifyMismatchedAllocationFieldVisibility();
    }

    @Test(description = "Verify that Key Attribute Crediting report link is available under quick links section and Fulfillment and Order related lists are added to right on Opportunity page by Sales Rep profile user")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-10211,MASFDCMNE-33803")
    @XrayTest(key = "MASFDCMNE-33802")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyOrderFulfillmentRelatedListAndCreditingReport_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOrderAndFulfillmentRelatedList();
        opportunityPage.verifyKeyAttributesCreditingReportIcon();
    }

    @Test(description = "Verify that the Key Attribute Attributes Crediting report link is available under quick links section and Fulfillment and Order related lists are added to right on Opportunity page by Operations Analyst profile user")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33804,MASFDCMNE-18913")
    @XrayTest(key = "MASFDCMNE-33874")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyOrderFulfillmentRelatedListAndCreditingReport_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOrderAndFulfillmentRelatedList();
        opportunityPage.verifyKeyAttributesCreditingReportIcon();

    }

    @Test(description = "Sales Rep profile user should have access to 'Manual Opportunity Override' Checkbox on Opportunity")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-13310")
    @XrayTest(key = "MASFDCMNE-13310")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyOwnerAssignedManually_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOwnerAssignedManuallyCheckbox();
    }

    @Test(description = "Sales Manager profile user should have access to 'Manual Opportunity Override' Checkbox on Opportunity")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33805")
    @XrayTest(key = "MASFDCMNE-33805")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyOwnerAssignedManually_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOwnerAssignedManuallyCheckbox();
    }

    @Test(description = "Product Specialist/Account Manager Profile Should have access to 'Manual Opportunity Override' Checkbox on Opportunity")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-33806")
    @XrayTest(key = "MASFDCMNE-33806")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyOwnerAssignedManually_ProductSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOwnerAssignedManuallyCheckbox();
    }

    @Test(description = "Email functionality on Opportunity page layout by Operations Analyst profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-8381")
    @XrayTest(key = "MASFDCMNE-8381")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyEmailFunctionalityOnOpportunity_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.sendEmailFromActivityTabOnOpportunity();
        opportunityPage.verifyEmailDetails(opportunityPage.getSoldToContactAddressOnOpportunity());
    }

    @Test(description = "Verify Email functionality on Opportunity page layout by Business Admin profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-8381")
    @XrayTest(key = "MASFDCMNE-34036")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyEmailFunctionalityOnOpportunity_BusinessAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.sendEmailFromActivityTabOnOpportunity();
        opportunityPage.verifyEmailDetails(opportunityPage.getSoldToContactAddressOnOpportunity());
    }

    @Test(description = "Verify the fields and list view headers on New Sales Opportunity page layout")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-13807,MASFDCMNE-25414,MASFDCMNE-22823,MASFDCMNE-20165,MASFDCMNE-27577,MASFDCMNE-13718,MASFDCMNE-28673,MASFDCMNE-28671,MASFDCMNE-26280,MASFDCMNE-28681,MASFDCMNE-10228,MASFDCMNE-12937")
    @XrayTest(key = "MASFDCMNE-33897")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyNewSalesOpportunityPageLayout(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.enterNewSalesOpportunityDetailsWithCustomDates(getCurrentDateInMMddyyyyFormat(), currentDatePlusMonths(23));
        opportunityPage.saveOpportunity();
        opportunityPage.verifyCommitAmountAndManagerNotesFields();
        opportunityPage.verifyMultiyearCheckboxNotChecked();
        opportunityPage.verifyERSDOAFieldNotDisplayed();
        opportunityPage.verifyBusinessSectorToSegmentFieldRename();
        opportunityPage.verifyUsageTypePicklistValues(readExcelData(opportunitiesFilePath, TCName, "UsageTypePicklistValues"));
        opportunityPage.verifyPrimaryCampaignSourceField();
        opportunityPage.verifyRegulatoryPicklistValues(readExcelData(opportunitiesFilePath, TCName, "RegulatoryPicklistValues"));
        opportunityPage.verifyRegulatoryPicklistValuesSorted();
        openRecordBySFDCID(oppyID);
        opportunityPage.navigateToContactRolesRelatedList();
        opportunityPage.verifyContactRolesColumnSequence(readExcelData(opportunitiesFilePath, TCName, "ContactRolesColumns"));
        opportunityPage.navigateToContactRolesRecord();
        opportunityPage.verifyContactRoleRecordFields(readExcelData(opportunitiesFilePath, TCName, "ContactRoleFields"));
        openRecordBySFDCID(oppyID);
        opportunityPage.navigateToProductsRelatedList();
        opportunityPage.verifyOpportunityProductsColumnSequence(readExcelData(opportunitiesFilePath, TCName, "OpportunityProductsColumns"));
    }

    @Test(description = "Verify the fields and custom links section on Renewal Sales Opportunity page layout")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-515, MASFDCMNE-10228,MASFDCMNE-25414,MASFDCMNE-22904,MASFDCMNE-13722")
    @XrayTest(key = "MASFDCMNE-33898")
    @Tags({@Tag("Opportunity"), @Tag("PageLayoutValidation"), @Tag("Positive"), @Tag("RenewalSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyRenewalSalesOpportunityPageLayout(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        opportunityPage.verifyServiceDataSectionFields(readExcelData(opportunitiesFilePath, TCName, "ServiceDataSectionFields"));
        opportunityPage.verifyERSDOAFieldNotDisplayed();
        opportunityPage.verifyRegulatoryPicklistValues(readExcelData(opportunitiesFilePath, TCName, "RegulatoryPicklistValues"));
        opportunityPage.verifyRegulatoryPicklistValuesSorted();
        opportunityPage.verifyPrimaryCampaignSourceField();
        opportunityPage.verifyCustomLinksSection();
    }

    @Test(description = "Verify there should be no changes in the existing currency values on the oppurtunity  page.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify all the currencies are displayed in the currencies drop down on the opportunity page.")
    @XrayTest(key = "MASFDCMNE-3274")
    @Tags({@Tag("OpportunityCurrency"), @Tag("Positive")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityCurrencyDropdown(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.verifyCurrencyValues();
    }

    @Test(description = "Verify the Warning Message when user changes the currency at the Opportunity.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify the Warning Message when user changes the currency at the Opportunity with quotes associated with it")
    @XrayTest(key = "MASFDCMNE-17299")
    @Tags({@Tag("OpportunityCurrency"), @Tag("Negative")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyWarningMsgOnChangeCurrencyValuewithActiveQuoteOppy(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        opportunityPage.updateCurrencyValue();
        opportunityPage.verifyCurrencyChnageWarningMessage();
    }

    @Test(description = "Verify opportunity creation with GBP currency")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify opportunity creation with GBP currency")
    @XrayTest(key = "MASFDCMNE-34054")
    @Tags({@Tag("OpportunityCreation"), @Tag("Positive")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityCreationWithGBPCurrency(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.overrideCurrencyValue();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify opportunity creation with CAD currency")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify opportunity creation with CAD currency")
    @XrayTest(key = "MASFDCMNE-34055")
    @Tags({@Tag("OpportunityCreation"), @Tag("Positive")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityCreationWithCADCurrency(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.overrideCurrencyValue();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify opportunity creation with EUR currency")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify opportunity creation with EUR currency")
    @XrayTest(key = "MASFDCMNE-34056")
    @Tags({@Tag("OpportunityCreation"), @Tag("Positive")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityCreationWithEURCurrency(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.overrideCurrencyValue();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify opportunity creation with SGD currency")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify opportunity creation with SGD currency")
    @XrayTest(key = "MASFDCMNE-34057")
    @Tags({@Tag("OpportunityCreation"), @Tag("Positive")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityCreationWithSGDCurrency(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.overrideCurrencyValue();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify opportunity creation with CYP currency")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify opportunity creation with CYP currency")
    @XrayTest(key = "MASFDCMNE-34058")
    @Tags({@Tag("OpportunityCreation"), @Tag("Positive")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityCreationWithCYPCurrency(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.overrideCurrencyValue();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Access of 'Product Strategy – Marketo Admin' should not get affected for Opportunity, Products, Cases, Events, Contacts, Campaigns, Tasks, Accounts, Leads objects")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-9320")
    @XrayTest(key = "MASFDCMNE-9320")
    @Tags({@Tag("Positive"), @Tag("Access")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyAccessOfObjectsUnderProductStrategyMarketoAdminProfile(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.openSFDCTab("Products");
        reusableBusinessLibrary.openSFDCTab("Cases");
        reusableBusinessLibrary.openSFDCTab("Contacts");
        reusableBusinessLibrary.openSFDCTab("Campaigns");
        reusableBusinessLibrary.openSFDCTab("Tasks");
        reusableBusinessLibrary.openSFDCTab("Accounts");
        reusableBusinessLibrary.openSFDCTab("Leads");
    }
    @Test(description = "'Reason Lost' field on affiliate opportunity should be editable to Sales Associate profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-6171")
    @XrayTest(key = "MASFDCMNE-6171")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyAccessofReasonLostFieldOnAffiliateOpportunity(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.selectRecordType("New Sales");
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.selectReasonLostFieldOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateReasonLostFieldOnOpportunity();
    }
    @Test(description = "Verify that user is able to Edit Renewal Opportunity Stages Sales Rep Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-20727")
    @XrayTest(key = "MASFDCMNE-34179")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyEditAccessOfStageFieldOnRenewalOpportunity_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.changeStages(readExcelData(opportunitiesFilePath, TCName, "OpportunityRecordType"));
    }
    @Test(description = "Verify that user is able to Edit Renewal Opportunity Stages Operations Analyst Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-20727")
    @XrayTest(key = "MASFDCMNE-34178")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyEditAccessOfStageFieldOnRenewalOpportunity_OpsAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.changeStages(readExcelData(opportunitiesFilePath, TCName, "OpportunityRecordType"));
    }

    @Test(description = "Read write access to fields 'Partnership/Alliance' on Opportunity on object for Profile SalesRep")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers:MASFDCMNE-11915")
    @XrayTest(key = "MASFDCMNE-34127")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyAccessOfPartnershipAllianceFields_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.selectRecordType("New Sales");
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.selectPartnershipAllianceToolOnOpportunity(opportunityData.get("Partnership_AllianceTool"));
        opportunityPage.selectPartnershipAllianceSalesTypeValue(opportunityData.get("PartnershipAllianceSalesType"));
        opportunityPage.enterReferralEntitlementOnOpportunity(opportunityData.get("ReferralEntitlement"));
        opportunityPage.selectPartnerAccountOnOpportunity(opportunityData.get("AccountName"));
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validatePartnershipAllianceFieldsOnOpportunity();
    }
    @Test(description = "Read write access to fields 'Partnership/Alliance' on Opportunity on object for Profile Sales Manager")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers:MASFDCMNE-11915")
    @XrayTest(key = "MASFDCMNE-34125")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyAccessOfPartnershipAllianceFields_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.selectRecordType("New Sales");
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.selectPartnershipAllianceToolOnOpportunity(opportunityData.get("Partnership_AllianceTool"));
        opportunityPage.selectPartnershipAllianceSalesTypeValue(opportunityData.get("PartnershipAllianceSalesType"));
        opportunityPage.enterReferralEntitlementOnOpportunity(opportunityData.get("ReferralEntitlement"));
        opportunityPage.selectPartnerAccountOnOpportunity(opportunityData.get("AccountName"));
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validatePartnershipAllianceFieldsOnOpportunity();
    }


    @Test(description = "Verify that the Permission Set PSE Operation and PSE Project Managers has Edit access to the Field Service Probability on Opportunity.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-19277, MASFDCMNE-19373")
    @XrayTest(key = "MASFDCMNE-34107")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyAccessOfServicesProbabilityFieldOnOpportunity(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("ERS Practice Lead/Project Manager with Permission Set PSE-Project Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterServicesProbabilityFieldOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateServicesProbabilityFieldOnOpportunity();
        homePage.logoutFromProxyProfile();
        homePage.checkMoodysApp();
        homePage.loginAs("ERS Practice Lead/Project Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterServicesProbabilityFieldOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateServicesProbabilityFieldOnOpportunity();

    }
    @Test(description = "Client Service Manager profile should not be able to edit the opportunities, it should only have read access.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-19737")
    @XrayTest(key = "MASFDCMNE-19737")
    @Tags({@Tag("Opportunity"), @Tag("Negative"), @Tag("NewSales"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityCannotBeEditedUnderClientServiceManagerProfile(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Client Service Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        opportunityPage.verifyInvisibilityOfEditButton();
    }
    @Test(description = "Request 2 - Sales Manager profile user can edit fields such as Services Owner and Consulting Comments present on Renewal Opportunity record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-31201")
    @XrayTest(key = "MASFDCMNE-31201")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("RenewalSales"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyFieldsCanBeEditedOnRenewalOpportunitySalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterServicesOwnerAndConsultingCommentsOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateServicesOwnerAndConsultingCommentsOnOpportunity();
    }
    @Test(description = "Request 2 - Sales Representative profile user can edit fields such as Services Owner and Consulting Comments present on Renewal Opportunity record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-31198")
    @XrayTest(key = "MASFDCMNE-31198")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("RenewalSales"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyFieldsCanBeEditedOnRenewalOpportunitySalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "RenewalOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterServicesOwnerAndConsultingCommentsOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateServicesOwnerAndConsultingCommentsOnOpportunity();

    }
    @Test(description = "Request 2 - Sales Representative profile user can edit fields such as Services Owner and Consulting Comments present on New Sales Opportunity record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-31196")
    @XrayTest(key = "MASFDCMNE-31196")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("NewSales"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyFieldsCanBeEditedOnNewSalesOpportunitySalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterServicesOwnerAndConsultingCommentsOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateServicesOwnerAndConsultingCommentsOnOpportunity();
    }
    @Test(description = "Request 2 - Sales Manager profile user can edit fields such as Services Owner and Consulting Comments present on New Sales Opportunity record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-31197")
    @XrayTest(key = "MASFDCMNE-31197")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("NewSales"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyFieldsCanBeEditedOnNewSalesOpportunitySalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterServicesOwnerAndConsultingCommentsOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateServicesOwnerAndConsultingCommentsOnOpportunity();
    }

    @Test(description = "Test revoke permission to delete opportunities and quotes FPA Reporting Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-12677")
    @XrayTest(key = "MASFDCMNE-34170")
    @Tags({@Tag("Opportunity"), @Tag("Negative"), @Tag("Permission"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyPermissionToDeleteOpportunities_FPAReporting(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("FPA Reporting");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        opportunityPage.verifyInvisibilityOfDeleteButton();
    }

    @Test(description = "Test revoke permission to delete opportunities and quotes Product Specialist Account Manager Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-12677")
    @XrayTest(key = "MASFDCMNE-34171")
    @Tags({@Tag("Opportunity"), @Tag("Negative"), @Tag("Permission"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyPermissionToDeleteOpportunities_ProudctSpecialistAccountManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Specialist/Account Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        opportunityPage.verifyInvisibilityOfDeleteButton();
    }

    @Test(description = "Test revoke permission to delete opportunities and quotes Sales Admin Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-12677")
    @XrayTest(key = "MASFDCMNE-34174")
    @Tags({@Tag("Opportunity"), @Tag("Negative"), @Tag("Permission"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyPermissionToDeleteOpportunities_SalesAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Administrator");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        opportunityPage.verifyInvisibilityOfDeleteButton();
    }
    @Test(description = "Test revoke permission to delete opportunities and quotes Sales Rep Profile")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-12677")
    @XrayTest(key = "MASFDCMNE-34175")
    @Tags({@Tag("Opportunity"), @Tag("Negative"), @Tag("Permission"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyPermissionToDeleteOpportunities_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        opportunityPage.verifyInvisibilityOfDeleteButton();
    }

    @Test(description = "All quick links on opportunity should be visible to users with profile Customer Success/Account Development Specialist.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that when opening any opportunity quick links should be visible for PSA App and not visible for Client Services App")
    @XrayTest(key = "MASFDCMNE-21110")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
        public void verifyQuickLinksOnOpportunityShouldBeVisible(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        homePage.logoutFromProxyProfile();
        homePage.checkMoodysApp();
        homePage.loginAs("Customer Success / Account Development Specialist With Permission Set PSE");
        reusableBusinessLibrary.switchToApp("PSA");
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Opportunities",oppyName);
        opportunityPage.verifyQuickLinksAreVisibleOnOpportunity();
        reusableBusinessLibrary.switchToApp("Client Services");
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Opportunities",oppyName);
        opportunityPage.verifyQuickLinksAreInvisibleOnOpportunity();


    }
    @Test(description = "Edit access to the new fields on Opportunity UI Sales Rep")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-26281")
    @XrayTest(key = "MASFDCMNE-34166")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyEditAccessToNewFieldsOnOpportunity_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterCommitAmountOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateCommitAmountFieldOnOpportunity();
    }

    @Test(description = "Edit access to the new fields on Opportunity UI Sales Manager")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-26281")
    @XrayTest(key = "MASFDCMNE-34165")
    @Tags({@Tag("Opportunity"), @Tag("Positive"), @Tag("Access"), @Tag("ExistingData")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyEditAccessToNewFieldsOnOpportunity_SalesManager(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Manager");
        openRecordBySFDCID(readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        reusableBusinessLibrary.clickEditBtn();
        opportunityPage.clearAndEnterCommitAmountOnOpportunity();
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.validateCommitAmountFieldOnOpportunity();
    }


    @Test(description = "Verify Site profile access available for Sales Rep")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify Site profile access available for Sales Rep. Covers MASFDCMNE-34017")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34017")
    public void verifyAccesstoSiteProfile_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
    }
    @Test(description = "Verify user can access Site Profile details page - Sales Rep")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify user can access Site Profile details page - Sales Rep. Covers MASFDCMNE-34018")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34018")
    public void verifySiteProfileDetailPageAccess_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
        opportunityPage.openSiteProfileDetail();
    }

    @Test(description = "Verify sites are available on Site Profile details page - Sales Rep")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify sites are available on Site Profile details page - Sales Rep. Covers MASFDCMNE-34019")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34019")
    public void verifySitesAvaialbleOnSiteProfileDetail_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
        opportunityPage.openSiteProfileDetail();
        opportunityPage.siteNameExistToAddSiteProfile();
    }

    @Test(description = "Verify user can add site profile from site profile details page - Sales Rep")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify user can add site profile from site profile details page - Sales Rep. Covers MASFDCMNE-34251")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34251")
    public void verifyUsercanAddSiteProfile_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
        opportunityPage.openSiteProfileDetail();
        opportunityPage.siteNameExistToAddSiteProfile();
        opportunityPage.addSiteProfilefromSiteProfileDetailPage();
    }

    @Test(description = "Verify Site profile access available for Operation Analyst")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify Site profile access available for Operation Analyst. Covers MASFDCMNE-34185")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34185")
    public void verifyAccesstoSiteProfile_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
    }
    @Test(description = "Verify user can access Site Profile details page - Operation Analyst")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify user can access Site Profile details page - Operation Analyst. Covers MASFDCMNE-34186")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34186")
    public void verifySiteProfileDetailPageAccess_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
        opportunityPage.openSiteProfileDetail();

    }

    @Test(description = "Verify sites are available on Site Profile details page - Operation Analyst")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify sites are available on Site Profile details page - Operation Analyst. Covers MASFDCMNE-34187")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34187")
    public void verifySitesAvaialbleOnSiteProfileDetail_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
        opportunityPage.openSiteProfileDetail();
        opportunityPage.siteNameExistToAddSiteProfile();
    }

    @Test(description = "Verify user can add site profile from site profile details page - Operation Analyst")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Verify user can add site profile from site profile details page - Operation Analyst. Covers MASFDCMNE-34250")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Opportunity"),@Tag("SiteProfile")})
    @XrayTest(key = "MASFDCMNE-34250")
    public void verifyUsercanAddSiteProfile_OperationAnalyst(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
        opportunityPage.verifyAccesstoSiteProfile();
        opportunityPage.openSiteProfileDetail();
        opportunityPage.siteNameExistToAddSiteProfile();
        opportunityPage.addSiteProfilefromSiteProfileDetailPage();

    }

    @Test(description = "Verify Trial opportunity creation as Sales Rep")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify Trail Sales creation from an opportunity record")
    @XrayTest(key = "MACPQMNE-7354")
    @Tags({@Tag("TrailSales"), @Tag("Positive")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyTrialSalesCreationFromOpportunity(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.enterOpportunityTrialDates(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.verifyTrialButton();
        }

    @AfterMethod
    public void tearDown(){
        if (driver != null) {
            driver.quit();
        }
    }
}