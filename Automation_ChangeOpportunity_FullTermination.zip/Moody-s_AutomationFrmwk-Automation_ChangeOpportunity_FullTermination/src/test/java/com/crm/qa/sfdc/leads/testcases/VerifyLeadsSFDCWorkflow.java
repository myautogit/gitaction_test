package com.crm.qa.sfdc.leads.testcases;

import app.getxray.xray.testng.annotations.XrayTest;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.*;
import com.crm.qa.util.AllureListener;
import com.crm.qa.util.JiraxRaySupport;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Properties;
import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.AbstractDataLibrary.sfdcLeadEmail;
import static com.crm.qa.util.ReusableLibrary.readExcelData;
import static com.crm.qa.util.ReusableLibrary.readExcelRows;

@Listeners({ app.getxray.xray.testng.listeners.XrayListener.class, AllureListener.class })
public class VerifyLeadsSFDCWorkflow extends TestBase {
    public TestBase testBase;
    public ReusableLibrary reusableLibrary;
    public WebDriver driver;
    Properties prop;
    LoginPage loginPage;
    HomePage homePage;
    LeadPage leadPage;
    AccountPage accountPage;
    ContactPage contactPage;
    TaskPage taskPage;
    CampaignPage campaignPage;
    OpportunityPage opportunityPage;
    ReusableBusinessLibrary reusableBusinessLibrary;

    JiraxRaySupport jiraxRaySupport;
    LinkedHashMap<String,String> leadData, contactAddressDetailsBeforeConversion, contactAddressDetailsAfterConversion, accountAddressDetailsBeforeConversion, accountAddressDetailsAfterConversion, taskData,campaignData;

    String accountPhoneBeforeConversion, accountPhoneAfterConversion;


    @BeforeMethod
    public void setUp() {
        testBase = new TestBase();
        prop = reusableLibrary.initializeProperties();
        driver = testBase.initialization();
        driver.get(prop.getProperty("App_URL"));
        loggerManager.getLogger().info(prop.getProperty("Browser") + " browser launched successfully");
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        leadPage = new LeadPage(driver);
        leadData = new LinkedHashMap<>();
        accountPage = new AccountPage(driver);
        contactPage = new ContactPage(driver);
        opportunityPage = new OpportunityPage(driver);
        taskPage = new TaskPage(driver);
        campaignPage = new CampaignPage(driver);
        reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
        contactAddressDetailsBeforeConversion = new LinkedHashMap<>();
        contactAddressDetailsAfterConversion = new LinkedHashMap<>();
        accountAddressDetailsBeforeConversion = new LinkedHashMap<>();
        accountAddressDetailsAfterConversion = new LinkedHashMap<>();
        taskData = new LinkedHashMap<>();
        campaignData = new LinkedHashMap<>();
        reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
    }

    @Test(description = "Verify the address validation errors that are triggered at the time of Lead conversion.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-27395, MASFDCMNE-27147, MASFDCMNE-27143")
    @XrayTest(key = "MASFDCMNE-32693")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyAddressValidationsOnLeadToContactConversion(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.verifyContactAddressValidation(leadData.get("Existing Account"));
    }

    @Test(description = "Lead should get convert successfully if Country, State or City is not populated and converted with existing account and existing contact.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-27146")
    @XrayTest(key = "MASFDCMNE-27146")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadConvWithOnlyStreetAndExistingAccountContact(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.updateLeadAddress("", leadData.get("Primary Street 1"), "");
        leadPage.convertLeadToOpportunityWithExistingAccountContact(leadData.get("Existing Account"), leadData.get("Existing Contact"));
    }

    @Test(description = "Validation error should not come when Country, Street or City are missing on the lead and converted to existing account and existing contact.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-26882")
    @XrayTest(key = "MASFDCMNE-26882")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadConvWithMissingAddressAndExistingAccountContact(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.updateLeadAddress("", "", "");
        leadPage.convertLeadToOpportunityWithExistingAccountContact(leadData.get("Existing Account"), leadData.get("Existing Contact"));
    }

    @Test(description = "Validation error should not come when populate only country as Canada on lead, State and Postal Code are missing and converted to existing account and existing contact.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-26884")
    @XrayTest(key = "MASFDCMNE-26884")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadConvWithOnlyCountryAndExistingAccountContact_Canada(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.updateLeadAddress("Canada", "", "");
        leadPage.convertLeadToOpportunityWithExistingAccountContact(leadData.get("Existing Account"), leadData.get("Existing Contact"));
    }

    @Test(description = "Validation error should not come when populate only country as United States on lead, State and Postal Code are missing and converted to existing account and existing contact.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-26883")
    @XrayTest(key = "MASFDCMNE-26883")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadConvWithOnlyCountryAndExistingAccountContact_US(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.updateLeadAddress("United States", "", "");
        leadPage.convertLeadToOpportunityWithExistingAccountContact(leadData.get("Existing Account"), leadData.get("Existing Contact"));
    }

    @Test(description = "Address information should not be updated for Existing Contact used for Lead Conversion")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-28630")
    @XrayTest(key = "MASFDCMNE-28630")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyNoAddressUpdateForExistingContactPostLeadConv(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        leadPage.openLeadRecordByID(leadData.get("Existing Contact SFDC ID"));
        contactAddressDetailsBeforeConversion = contactPage.getContactAddressDetails();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.convertLeadToOpportunityWithExistingContact(leadData.get("Existing Contact"));
        leadPage.openConvertedContact(leadData.get("Existing Contact"));
        contactAddressDetailsAfterConversion = contactPage.getContactAddressDetails();
        leadPage.compareAddressBeforeAndAfterLeadConversion("Contact", contactAddressDetailsBeforeConversion, contactAddressDetailsAfterConversion);
    }

    @Test(description = "This test case validates that address information and phone should not be updated for Existing Account used for Lead Conversion.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-25266,MASFDCMNE-21541,MASFDCMNE-18603,MASFDCMNE-18581,MASFDCMNE-18580")
    @XrayTest(key = "MASFDCMNE-32692")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyNoAddressAndPhoneUpdateOnExistingAccountPostLeadConv(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openSFDCRecordByID(leadData.get("Existing Account SFDC ID"));
        accountAddressDetailsBeforeConversion = accountPage.getAccountAddressDetails();
        accountPhoneBeforeConversion = accountPage.getAccountPhone();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.convertLeadToOpportunityWithExistingAccount(leadData.get("Existing Account"));
        leadPage.openConvertedAccount(leadData.get("Existing Account"));
        accountAddressDetailsAfterConversion = accountPage.getAccountAddressDetails();
        accountPhoneAfterConversion = accountPage.getAccountPhone();
        leadPage.compareAddressBeforeAndAfterLeadConversion("Account", accountAddressDetailsBeforeConversion, accountAddressDetailsAfterConversion);
        accountPage.comparePhoneBeforeAndAfterLeadConversion("Account", accountPhoneBeforeConversion, accountPhoneAfterConversion);
    }

    @Test(description = "Verify that lead conversion does not update Account Primary State Field where Blank.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-18603")
    @XrayTest(key = "MASFDCMNE-18603")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyNoAccountStateUpdateWhenBlankPostLeadConv(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openSFDCRecordByID(leadData.get("Existing Account SFDC ID"));
        accountPage.clearAccountStateIfPopopulated();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.convertLeadToOpportunityWithExistingAccount(leadData.get("Existing Account"));
        leadPage.openConvertedAccount(leadData.get("Existing Account"));
        accountPage.verifyAccountStatePostLeadConv();
    }

    @Test(description = "Verify that users should be able to convert any Lead into a Contact with existing account.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-18582,MASFDCMNE-17986")
    @XrayTest(key = "MASFDCMNE-32793")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadToContactConversionWithExistingAccount(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        String existingAccount = readExcelData(leadsFilePath, TCName, "Existing Account");
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        String leadName = leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.convertLeadToContactWithExistingAccount(existingAccount);
        leadPage.verifyLeadConversionMessage();
        leadPage.openConvertedContact(leadName);
        contactPage.verifyConvertedContactWithExistingAccount(existingAccount);
    }

    @Test(description = "'Converted - No Opportunity' value should be available under Status picklist on Lead record and Converted Status picklist on Lead Conversion screen")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-1797,MASFDCMNE-10359")
    @XrayTest(key = "MASFDCMNE-32795")
    @Tags({@Tag("Regression"), @Tag("Lead"), @Tag("LeadConversion")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyConvertedNoOpportunityStatusValue(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.verifyValueInLeadStatusPicklist("Converted - No Opportunity");
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.verifyConvertedStatusOption("Converted - No Opportunity");
    }

    @Test(description = "User should not be able to make Business type field blank on Lead, if value is populated for that field.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that user should not be able to make Business type field blank on Lead, if value is populated for that field")
    @XrayTest(key = "MASFDCMNE-28848")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyBusinessTypeErrorOnLead(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.verifyBusinessTypeError();
    }

    @Test(description = "This test case covers  the address validation errors that are triggered at the time of Lead to Opportunity Conversion.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-25265, MASFDCMNE-25264, MASFDCMNE-25259, MASFDCMNE-25258, MASFDCMNE-25257, MASFDCMNE-25256, MASFDCMNE-21396, MASFDCMNE-21397, MASFDCMNE-27393")
    @XrayTest(key = "MASFDCMNE-32426")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyAddressValidationsOnLeadConversion(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.verifyAddressValidationOnLeadConversion();
    }

    @Test(description = "This test case covers the Lead Conversion flow without populating Function field, and Zip Code for Country than US and Canada on the Lead. It also validates the Record Type and Sold to Contact on the converted Opportunity.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-28849,MASFDCMNE-21557,MASFDCMNE-17945,MASFDCMNE-18141,MASFDCMNE-18927")
    @XrayTest(key = "MASFDCMNE-32425")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadToOppyConversionWithoutFunctionAndZipCode(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        String leadName = leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.clearZipCodeOnLead();
        reusableBusinessLibrary.clickEditBtn();
        leadPage.fillLeadDetailsInSFDC(leadData);
        accountPage.convertLeadToOpportunity(leadName);
        opportunityPage.verifyOpportunityRecordType();
        opportunityPage.verifySoldToContactOnOpportunity(leadName);
    }

    @Test(description = "This test case validates the creation of Account Location on converting Lead into Account. It also validates that user is able to convert a Lead to an Opportunity with Function value populated.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-28850,MASFDCMNE-21542,MASFDCMNE-30898,MASFDCMNE-25216")
    @XrayTest(key = "MASFDCMNE-32691")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyAccountLocationOnLeadToAccountConversion(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        String leadName = leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.populateFunctionAndLeadSource(leadData);
        accountPage.convertLeadToOpportunity(leadName);
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.convertLeadToAccountWithExistingContact(leadName);
        leadPage.openConvertedAccount(companyText);
        accountPage.verifyAccountLocationOnConvertedAccount(leadData);
    }

    @Test(description = "Verify the flow of address from Lead to converted Contact and duplicate email validation on Lead Conversion.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covers: MASFDCMNE-28625,MASFDCMNE-19394,MASFDCMNE-25411,MASFDCMNE-22694,MASFDCMNE-28847,MASFDCMNE-22836,MASFDCMNE-20922")
    @XrayTest(key = "MASFDCMNE-32424")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyContactAddressValidationPostLeadConversion(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        String leadName = leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.performLeadConversion();
        leadPage.openConvertedContact(leadName);
        contactPage.verifyAddressOnConvertedContact(leadData);
        String leadEmail = sfdcLeadEmail;
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.updateLeadEmail(leadEmail);
        leadPage.convertLead();
        leadPage.verifyContactExistsValidationError();
    }

    @Test(description = "If a contact of record type contact exists with same email, then only an OA user should be able to create a new contact during lead conversion.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case validates that OA user can convert a lead to Contact when a contact already exists with the same email.")
    @XrayTest(key = "MASFDCMNE-24130")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadConversionWithDuplicateEmail(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        String leadEmail = sfdcLeadEmail;
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.updateLeadEmail(leadEmail);
        leadPage.performLeadConversion();
    }

    @Test(description = "This test case covers the validation of error message that is displayed when user clicks on 'Convert to Opportunity' button on lead task.")
    @Severity(SeverityLevel.NORMAL)
    @Description("MASFDCMNE-1868,MASFDCMNE-17316")
    @XrayTest(key = "MASFDCMNE-32690")
    @Tags({@Tag("Regression"), @Tag("LeadConversion"), @Tag("Lead")} )
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyLeadTaskConversionError(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.createLeadTaskInSFDC();
        leadPage.verifyConvertToOpportunityErrorOnLeadTask();
    }

    @Test(description = "User should be able to create a new lead with mandatory info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression" + "Covers: MASFDCMNE-19891, MASFDCMNE-20921")
    @XrayTest(key = "MASFDCMNE-32573")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("Sanity")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryInfo_SalesRep(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory info using Save and New Button.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32382")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadUsingSaveAndNewButton_SalesRep(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveAndNewLead();
        leadPage.navigateToLeadRecord();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify that if mandatory fields are missing user should get an error message while saving the lead.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32383")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("NegativeScenario")})
    @Link("https://test.salesforce.com/")
    public void saveLeadWithMissingMandatoryField_SalesRep(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterOptionalFields();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory and optional info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32265")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryAndOptionalInfo_SalesRep(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.enterOptionalFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        leadPage.validateLeadOptionalInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to add Lead Source Details and update other info on Existing Lead Record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-6404, MASFDCMNE-22541")
    @XrayTest(key = "MASFDCMNE-32570")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate")})
    @Link("https://test.salesforce.com/")
    public void addLeadSourceDetailsOnExistingLead_SalesRep(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryInfo_SalesRep";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        leadPage.saveOnEditLead();
        leadPage.validateUpdatedLeadInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should not be able to update Lead Source Details field on existing records if already populated.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression" + "Covers: MASFDCMNE-22535, MASFDCMNE-22533")
    @XrayTest(key = "MASFDCMNE-32575")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate"), @Tag("Negative")})
    @Link("https://test.salesforce.com/")
    public void updateLeadSourceDetailsOnExistingLead_SalesRep(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryAndOptionalInfo_SalesRep";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression" + "Covers: MASFDCMNE-19891, MASFDCMNE-20921")
    @XrayTest(key = "MASFDCMNE-32573")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("Sanity")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryInfo_MarketingUser(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory info using Save and New Button.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32382")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadUsingSaveAndNewButton_MarketingUser(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveAndNewLead();
        leadPage.navigateToLeadRecord();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify that if mandatory fields are missing user should get an error message while saving the lead.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32383")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("NegativeScenario")})
    @Link("https://test.salesforce.com/")
    public void saveLeadWithMissingMandatoryField_MarketingUser(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterOptionalFields();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory and optional info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32265")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryAndOptionalInfo_MarketingUser(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.enterOptionalFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        leadPage.validateLeadOptionalInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to add Lead Source Details and update other info on Existing Lead Record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-6404, MASFDCMNE-22541")
    @XrayTest(key = "MASFDCMNE-32570")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate")})
    @Link("https://test.salesforce.com/")
    public void addLeadSourceDetailsOnExistingLead_MarketingUser(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryInfo_MarketingUser";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        leadPage.saveOnEditLead();
        leadPage.validateUpdatedLeadInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should not be able to update Lead Source Details field on existing records if already populated.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression" + "Covers: MASFDCMNE-22535, MASFDCMNE-22533")
    @XrayTest(key = "MASFDCMNE-32575")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate"), @Tag("Negative")})
    @Link("https://test.salesforce.com/")
    public void updateLeadSourceDetailsOnExistingLead_MarketingUser(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryAndOptionalInfo_MarketingUser";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression" + "Covers: MASFDCMNE-19891, MASFDCMNE-20921")
    @XrayTest(key = "MASFDCMNE-32573")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("Sanity")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryInfo_EventsAndOutreach(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory info using Save and New Button.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32382")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadUsingSaveAndNewButton_EventsAndOutreach(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveAndNewLead();
        leadPage.navigateToLeadRecord();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify that if mandatory fields are missing user should get an error message while saving the lead.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32383")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("NegativeScenario")})
    @Link("https://test.salesforce.com/")
    public void saveLeadWithMissingMandatoryField_EventsAndOutreach(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterOptionalFields();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory and optional info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32265")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryAndOptionalInfo_EventsAndOutreach(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.enterOptionalFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        leadPage.validateLeadOptionalInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to add Lead Source Details and update other info on Existing Lead Record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-6404, MASFDCMNE-22541")
    @XrayTest(key = "MASFDCMNE-32570")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate")})
    @Link("https://test.salesforce.com/")
    public void addLeadSourceDetailsOnExistingLead_EventsAndOutreach(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryInfo_EventsAndOutreach";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        leadPage.saveOnEditLead();
        leadPage.validateUpdatedLeadInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should not be able to update Lead Source Details field on existing records if already populated.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression" + "Covers: MASFDCMNE-22535, MASFDCMNE-22533")
    @XrayTest(key = "MASFDCMNE-32575")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate"), @Tag("Negative")})
    @Link("https://test.salesforce.com/")
    public void updateLeadSourceDetailsOnExistingLead_EventsAndOutreach(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryAndOptionalInfo_EventsAndOutreach";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }


    @Test(description = "User should be able to create a new lead with mandatory info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression" + "Covers: MASFDCMNE-19891, MASFDCMNE-20921")
    @XrayTest(key = "MASFDCMNE-32573")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("Sanity")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryInfo_ProductStrategyMarketoAdmin(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory info using Save and New Button.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32382")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadUsingSaveAndNewButton_ProductStrategyMarketoAdmin(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveAndNewLead();
        leadPage.navigateToLeadRecord();
        leadPage.validateLeadMandatoryInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Verify that if mandatory fields are missing user should get an error message while saving the lead.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32383")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation"), @Tag("NegativeScenario")})
    @Link("https://test.salesforce.com/")
    public void saveLeadWithMissingMandatoryField_ProductStrategyMarketoAdmin(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterOptionalFields();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to create a new lead with mandatory and optional info.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("Regression")
    @XrayTest(key = "MASFDCMNE-32265")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataCreation")})
    @Link("https://test.salesforce.com/")
    public void createLeadWithMandatoryAndOptionalInfo_ProductStrategyMarketoAdmin(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.enterOptionalFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        leadPage.validateLeadMandatoryInfo();
        leadPage.validateLeadOptionalInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should be able to add Lead Source Details and update other info on Existing Lead Record.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers: MASFDCMNE-6404, MASFDCMNE-22541")
    @XrayTest(key = "MASFDCMNE-32570")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate")})
    @Link("https://test.salesforce.com/")
    public void addLeadSourceDetailsOnExistingLead_ProductStrategyMarketoAdmin(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryInfo_ProductStrategyMarketoAdmin";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        leadPage.saveAndNewLead();
        leadPage.openLeadRecordByID(sfdcLeadID);
        leadPage.validateUpdatedLeadInfo();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "User should not be able to update Lead Source Details field on existing records if already populated.")
    @Severity(SeverityLevel.MINOR)
    @Description("Regression" + "Covers: MASFDCMNE-22535, MASFDCMNE-22533")
    @XrayTest(key = "MASFDCMNE-32575")
    @Owner("Rishi")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("LeadDataUpdate"), @Tag("Negative")})
    @Link("https://test.salesforce.com/")
    public void updateLeadSourceDetailsOnExistingLead_ProductStrategyMarketoAdmin(Method method) {
        TCName = method.getName();
        TCDependency = "createLeadWithMandatoryAndOptionalInfo_ProductStrategyMarketoAdmin";
        String sfdcLeadID = ReusableLibrary.readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID");
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        leadPage.openLeadRecordByID(sfdcLeadID);
        reusableBusinessLibrary.clickEditBtn();
        leadPage.editLeadDetail();
        reusableBusinessLibrary.clickSaveBtn();
        leadPage.checkErrorOnLeadCreationScreen();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Address and Phone details should be updated on Lead Record using 'Update Address/Phone' Button and should be displayed on Converted Account and Contact")
    @Severity(SeverityLevel.NORMAL)
    @Description("Regression" + "Covers :MASFDCMNE-25213,MASFDCMNE-25214,MASFDCMNE-25215,MASFDCMNE-29307,MASFDCMNE-25267,MASFDCMNE-25218,MASFDCMNE-25220")
    @XrayTest(key = "MTA-62")
    @Owner("Bhagyashree Wani")
    @Tags({@Tag("Regression"), @Tag("LeadWorkflow"), @Tag("UpdateAddressBtnVerification"), @Tag("Sanity"), @Tag("AddressPhoneDetailsVerificationOnLeadConversion")})
    @Link("https://test.salesforce.com/")

    public void VerifyUpdateAddressPhoneOnLead(Method method) throws InterruptedException {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        reusableBusinessLibrary.clickShowMoreActionsBtn();
        leadPage.verifyUpdateAddressPhoneLink();
        leadPage.saveAddressPhoneDetailsInfo();
        leadPage.validateAddressPhoneDetails();
        leadPage.performLeadConversion();
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", companyText);
        accountPage.verifyAddressPhoneOnConvertedAccount();
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Contacts", firstNameText+" "+lastNameText);
        contactPage.verifyAddressPhoneOnConvertedContact();
        loggerManager.getLogger().info("Test case: " + TCName + " completed successfully");
    }

    @Test(description = "Create Lead from Orbis")
    @Severity(SeverityLevel.NORMAL)
    @Owner("Hemal Shah")
    @Description("Create lead from orbis")
    @Tags({@Tag("Smoke"),@Tag("Regression"),@Tag("Lead")})
    @XrayTest(key = "MTA-69")
    public void createLeadFromOrbis(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.openOrbisSearch();
        homePage.orbisSearchwithCompany(readExcelData(leadsFilePath,TCName,"CompanyNametoSearch"));
        homePage.orbisRecordtoImport("Lead");
    }
    @Test(description = "Verify that Lead Source Field Exists when Task is created.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case creates two tasks from task page and verifies that the Lead Source Fields exists once the task is created.")
    @XrayTest(key = "MASFDCMNE-17337")
    @Tags({ @Tag("Regression"), @Tag("Lead"), @Tag("Task")})
    @Owner("Vatsala Bahal")
    @Link(" SFDC: https://test.salesforce.com/")
    public void  verifyLeadSourceFieldWhenTaskIsCreated(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        reusableBusinessLibrary.openSFDCTab("Tasks");
        taskPage.createNewTask("Lead Task");
        taskPage.verifyTaskISCreated();
        taskPage.verifyLeadSourceFieldExistsOnTask();

    }
    @Test(description = "Verify that country field is updated in task record upon being updated")
    @Severity(SeverityLevel.NORMAL)
    @Description("Covered: MASFDCMNE-31128, MASFDCMNE-31127")
    @XrayTest(key = "MASFDCMNE-32805")
    @Tags({ @Tag("Regression"), @Tag("Lead"), @Tag("Task"), @Tag("TestDataDependency")})
    @Owner("Vatsala Bahal")
    @Link("SFDC: https://test.salesforce.com/")
    public void verifyCountryFieldSyncFromTaskToLeadUponUpdation(Method method) {
        TCName = method.getName();
        leadData = readExcelRows(leadsFilePath, TCName).get(0);
        taskData = readExcelRows(tasksFilePath, TCName).get(0);
        campaignData = readExcelRows(campaignsFilePath, TCName).get(0);
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        homePage.openLeadtab();
        leadPage.navigateToLeadCreationScreen();
        leadPage.enterMandatoryFields();
        leadPage.saveLead();
        leadPage.getLeadIDAndStoreInExcel();
        //create a new campaign and add a lead to it
        reusableBusinessLibrary.openSFDCTab("Campaigns");
        campaignPage.clickNewCampaign();
        campaignPage.fillOutNewCampaignMandatoryFields(campaignData.get("Region"), campaignData.get("Campaign Name"),campaignData.get("Campaign Type"), campaignData.get("Business Type"));
        campaignPage.clickCampaignDetails();
        campaignPage.addLeadToCampaign();
        //create a task for the lead and check that the country field is synced in both the lead and task
        campaignPage.navigateToLead();
        leadPage.createLeadTaskInSFDC();
        taskPage.verifyCountryValueInTaskRecord(countryValue);
        //Update the country field in the lead and check if it is synced in the task
        taskPage.navigateToLeadFromTaskPage();
        leadPage.updateLeadAddress(leadData.get("Secondary Country"), leadData.get("Secondary Street"), leadData.get("Secondary City"));
        leadPage.navigateToTaskFromLeadPage();
        //Update the country field in the task and check if it is still synced with the lead
        taskPage.updateTaskCountryField(taskData.get("Country"));
        taskPage.verifyCountryValueInTaskRecord(leadData.get("Secondary Country"));

    }

    @AfterMethod
    public void tearDown(){
        if (driver != null) {
            driver.quit();
        }
    }
}