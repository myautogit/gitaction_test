package com.crm.qa.sfdc.marketoleads.testcases;

import app.getxray.xray.testng.annotations.XrayTest;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.*;
import com.crm.qa.util.AllureListener;
import com.crm.qa.util.JiraxRaySupport;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;

@Listeners({ app.getxray.xray.testng.listeners.XrayListener.class, AllureListener.class })
public class VerifyMarketoLeadIntegration extends TestBase{

    public TestBase testBase;
    public ReusableLibrary reusableLibrary;
    public WebDriver driver;
    Properties prop;
    LoginPage loginPage;
    HomePage homePage;
    LeadPage leadPage;
    TaskPage taskPage;
    AccountPage accountPage;

    JiraxRaySupport jiraxRaySupport;
    List<LinkedHashMap<String,String>> leadData;
    List<LinkedHashMap<String,String>> taskData;

    @BeforeMethod
    public void setUp() {
        testBase = new TestBase();
        prop = reusableLibrary.initializeProperties();
        driver = testBase.initialization();
        loggerManager.getLogger().info(browserName + " browser launched successfully");
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        leadPage = new LeadPage(driver);
        taskPage = new TaskPage(driver);
        jiraxRaySupport = new JiraxRaySupport();
        taskData = new ArrayList<>();
        leadData = new ArrayList<>();
        accountPage = new AccountPage(driver);
    }

    @Test(description = "Verify that user is able to create a lead in Marketo and syncing it to SFDC.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("This test case covers the end to end flow of creating a lead in Marketo and syncing it to SFDC with Marketing User.")
    @XrayTest(key = "MASFDCMNE-32295")
    @Tags({@Tag("Sanity"), @Tag("Regression"), @Tag("Marketo"), @Tag("TestDataDependency"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyMarketoToSFDCLeadSync_MarketingUser(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName);

        //Login to Marketo, create a lead and sync to SFDC
        loginPage.loginToMarketo();
        String leadName = leadPage.createLeadInMarketo(leadData.get(0));
        leadPage.syncLeadToSFDC();
        String sfdcLeadID = leadPage.getSFDCLeadIDFromMarketo();

        //Login to SFDC and verify the lead record
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        leadPage.openLeadRecordByID(sfdcLeadID);
        leadPage.verifyRecordInSFDC(leadName);
        leadPage.verifyLeadOwner("Marketing Queue", leadPage.leadOwnerQueueName);
        leadPage.verifyLeadRecordType();
        leadPage.changeLeadOwner(leadData.get(0).get("Lead Owner"));
    }

    @Test(description = "Verify that changes made to lead data in Marketo should be synced back to SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers updating the lead details in Marketo and verifying the updated details in SFDC with Marketing User.")
    @XrayTest(key = "MASFDCMNE-32294")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadUpdateFromMarketoToSFDC_MarketingUser(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_MarketingUser");

        //Update the lead details in Marketo and sync to SFDC
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.updateLeadFieldsInMarketo();
        leadPage.syncLeadToSFDC();

        //Login to SFDC and verify the updated lead details
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyFieldUpdateInSFDC();
        leadPage.verifyStatusDropdownOptionValues(leadData.get(0).get("Expected Lead Status Values"));
    }

    @Test(description = "Verify that user is able to sync back to Marketo any changes made to lead data in SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers updating the lead details in SFDC and verifying the updated details in Marketo with Marketing User.")
    @XrayTest(key = "MASFDCMNE-32299")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadUpdateFromSFDCToMarketo_MarketingUser(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_MarketingUser");

        //Update the Lead details in SFDC and verify in Marketo
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.updateLeadFieldsInSFDC(leadData.get(0));
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.syncLeadToSFDC();
        leadPage.verifyFieldUpdateInMarketo(leadData.get(0));
    }

    @Test(description = "Verify that user is able to create a lead task in Marketo and sync it to SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers the end to end flow of creating a lead task in Marketo and verifying it in SFDC with Marketing User.")
    @XrayTest(key = "MASFDCMNE-32300")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadTaskSyncFromMarketoToSFDC_MarketingUser(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_MarketingUser");
        String leadName = leadData.get(0).get("First Name") + " " + leadData.get(0).get("Last Name");

        //Create a lead task in Marketo and verify in SFDC
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.createLeadTaskInMarketo();
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Marketing User - BvD");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyLeadTaskCreationInSFDC(leadName);
        leadPage.verifyLeadTaskType();
        leadPage.verifyLeadTaskStatusOptions(leadData.get(0).get("Expected Lead Task Status Values"));
        leadPage.verifyLeadTaskLocation(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyLeadTaskAssignmentNotification(leadName, leadData.get(0).get("Company"), leadData.get(0).get("Email"));
    }


    @Test(description = "Verify that user is able to create a lead in Marketo and syncing it to SFDC.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("This test case covers the end to end flow of creating a lead in Marketo and syncing it to SFDC with Events & Outreach User.")
    @XrayTest(key = "MASFDCMNE-32295")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("TestDataDependency"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyMarketoToSFDCLeadSync_EventsAndOutreach(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName);

        //Login to Marketo, create a lead and sync to SFDC
        loginPage.loginToMarketo();
        String leadName = leadPage.createLeadInMarketo(leadData.get(0));
        leadPage.syncLeadToSFDC();
        String sfdcLeadID = leadPage.getSFDCLeadIDFromMarketo();

        //Login to SFDC and verify the lead record
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        leadPage.openLeadRecordByID(sfdcLeadID);
        leadPage.verifyRecordInSFDC(leadName);
        leadPage.verifyLeadOwner("Marketing Queue", leadPage.leadOwnerQueueName);
        leadPage.verifyLeadRecordType();
        leadPage.changeLeadOwner(leadData.get(0).get("Lead Owner"));
    }

    @Test(description = "Verify that changes made to lead data in Marketo should be synced back to SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers updating the lead details in Marketo and verifying the updated details in SFDC with Events & Outreach User.")
    @XrayTest(key = "MASFDCMNE-32294")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadUpdateFromMarketoToSFDC_EventsAndOutreach(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_EventsAndOutreach");

        //Update the lead details in Marketo and sync to SFDC
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.updateLeadFieldsInMarketo();
        leadPage.syncLeadToSFDC();

        //Login to SFDC and verify the updated lead details
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyFieldUpdateInSFDC();
        leadPage.verifyStatusDropdownOptionValues(leadData.get(0).get("Expected Lead Status Values"));
    }

    @Test(description = "Verify that user is able to create a lead task in Marketo and sync it to SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers the end to end flow of creating a lead task in Marketo and verifying it in SFDC with Events & Outreach User.")
    @XrayTest(key = "MASFDCMNE-32300")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadTaskSyncFromMarketoToSFDC_EventsAndOutreach(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_EventsAndOutreach");
        String leadName = leadData.get(0).get("First Name") + " " + leadData.get(0).get("Last Name");

        //Create a lead task in Marketo and verify in SFDC
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.createLeadTaskInMarketo();
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Events & Outreach");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyLeadTaskCreationInSFDC(leadName);
        leadPage.verifyLeadTaskType();
        leadPage.verifyLeadTaskStatusOptions(leadData.get(0).get("Expected Lead Task Status Values"));
        leadPage.verifyLeadTaskLocation(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyLeadTaskAssignmentNotification(leadName, leadData.get(0).get("Company"), leadData.get(0).get("Email"));
    }

    @Test(description = "Verify that user is able to create a lead in Marketo and syncing it to SFDC.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("This test case covers the end to end flow of creating a lead in Marketo and syncing it to SFDC with Product Strategy -  Marketo Admin User.")
    @XrayTest(key = "MASFDCMNE-32295")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("TestDataDependency"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyMarketoToSFDCLeadSync_ProductStrategyMarketoAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName);

        //Login to Marketo, create a lead and sync to SFDC
        loginPage.loginToMarketo();
        String leadName = leadPage.createLeadInMarketo(leadData.get(0));
        leadPage.syncLeadToSFDC();
        String sfdcLeadID = leadPage.getSFDCLeadIDFromMarketo();

        //Login to SFDC and verify the lead record
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        leadPage.openLeadRecordByID(sfdcLeadID);
        leadPage.verifyRecordInSFDC(leadName);
        leadPage.verifyLeadOwner("Marketing Queue", leadPage.leadOwnerQueueName);
        leadPage.verifyLeadRecordType();
        leadPage.changeLeadOwner(leadData.get(0).get("Lead Owner"));
    }

    @Test(description = "Verify that changes made to lead data in Marketo should be synced back to SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers updating the lead details in Marketo and verifying the updated details in SFDC with Product Strategy - Marketo Admin User.")
    @XrayTest(key = "MASFDCMNE-32294")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadUpdateFromMarketoToSFDC_ProductStrategyMarketoAdmin(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_ProductStrategyMarketoAdmin");

        //Update the lead details in Marketo and sync to SFDC
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.updateLeadFieldsInMarketo();
        leadPage.syncLeadToSFDC();

        //Login to SFDC and verify the updated lead details
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyFieldUpdateInSFDC();
        leadPage.verifyStatusDropdownOptionValues(leadData.get(0).get("Expected Lead Status Values"));
    }

    @Test(description = "Verify that user is able to create a lead in Marketo and syncing it to SFDC.")
    @Severity(SeverityLevel.CRITICAL)
    @Description("This test case covers the end to end flow of creating a lead in Marketo and syncing it to SFDC with Sales Rep User.")
    @XrayTest(key = "MASFDCMNE-32295")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("TestDataDependency"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyMarketoToSFDCLeadSync_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName);

        //Login to Marketo, create a lead and sync to SFDC
        loginPage.loginToMarketo();
        String leadName = leadPage.createLeadInMarketo(leadData.get(0));
        leadPage.syncLeadToSFDC();
        String sfdcLeadID = leadPage.getSFDCLeadIDFromMarketo();

        //Login to SFDC and verify the lead record
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Sales Rep");
        leadPage.openLeadRecordByID(sfdcLeadID);
        leadPage.verifyRecordInSFDC(leadName);
        leadPage.verifyLeadOwner("Marketing Queue", leadPage.leadOwnerQueueName);
        leadPage.verifyLeadRecordType();
        leadPage.changeLeadOwner(leadData.get(0).get("Lead Owner"));
    }

    @Test(description = "Verify that changes made to lead data in Marketo should be synced back to SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers updating the lead details in Marketo and verifying the updated details in SFDC with Sales Rep User.")
    @XrayTest(key = "MASFDCMNE-32294")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadUpdateFromMarketoToSFDC_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_SalesRep");

        //Update the lead details in Marketo and sync to SFDC
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.updateLeadFieldsInMarketo();
        leadPage.syncLeadToSFDC();

        //Login to SFDC and verify the updated lead details
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Sales Rep");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyFieldUpdateInSFDC();
        leadPage.verifyStatusDropdownOptionValues(leadData.get(0).get("Expected Lead Status Values"));
    }

    @Test(description = "Verify that user is able to sync back to Marketo any changes made to lead data in SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers updating the lead details in SFDC and verifying the updated details in Marketo with Sales Rep User.")
    @XrayTest(key = "MASFDCMNE-32299")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadUpdateFromSFDCToMarketo_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_SalesRep");

        //Update the Lead details in SFDC and verify in Marketo
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Sales Rep");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.updateLeadFieldsInSFDC(leadData.get(0));
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.syncLeadToSFDC();
        leadPage.verifyFieldUpdateInMarketo(leadData.get(0));
    }

    @Test(description = "Verify that user is able to create a lead task in Marketo and sync it to SFDC.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers the end to end flow of creating a lead task in Marketo and verifying it in SFDC with Sales Rep User.")
    @XrayTest(key = "MASFDCMNE-32300")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadTaskSyncFromMarketoToSFDC_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, "verifyMarketoToSFDCLeadSync_SalesRep");
        String leadName = leadData.get(0).get("First Name") + " " + leadData.get(0).get("Last Name");

        //Create a lead task in Marketo and verify in SFDC
        loginPage.loginToMarketo();
        driver.get(leadData.get(0).get("Marketo Lead URL"));
        leadPage.createLeadTaskInMarketo();
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Sales Rep");
        leadPage.openLeadRecordByID(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyLeadTaskCreationInSFDC(leadName);
        leadPage.verifyLeadTaskType();
        leadPage.verifyLeadTaskStatusOptions(leadData.get(0).get("Expected Lead Task Status Values"));
        leadPage.verifyLeadTaskLocation(leadData.get(0).get("SFDC Lead ID"));
        leadPage.verifyLeadTaskAssignmentNotification(leadName, leadData.get(0).get("Company"), leadData.get(0).get("Email"));
    }

    @Test(description = "Verify that user is able to create and sync a lead from Marketo to SFDC and then convert it to Opportunity.")
    @Severity(SeverityLevel.NORMAL)
    @Description("This test case covers the end to end flow of creating and syncing a lead from Marketo to SFDC and then converting it to Opportunity with Sales Rep User.")
    @XrayTest(key = "MASFDCMNE-32302")
    @Tags({@Tag("Regression"), @Tag("Marketo"), @Tag("Lead")})
    @Owner("Arshin Shaikh")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyLeadConversionInSFDCOnMarketoLead_SalesRep(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName);

        //Login to Marketo, create a lead and sync to SFDC
        loginPage.loginToMarketo();
        String leadName = leadPage.createLeadInMarketo(leadData.get(0));
        leadPage.syncLeadToSFDC();
        String sfdcLeadID = leadPage.getSFDCLeadIDFromMarketo();

        //Login to SFDC and convert the integrated Lead to Opportunity
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Sales Rep");
        leadPage.openLeadRecordByID(sfdcLeadID);
        leadPage.editLead();
        leadPage.fillLeadDetailsInSFDC(leadData.get(0));
        accountPage.convertLeadToOpportunity(leadName);
    }


    @Test(description = "Verify that country field is updated in task record when lead is updated.")
    @Severity(SeverityLevel.NORMAL)
    @Description("Checks if the country field is synced between lead and task records, after the country field in the lead is updated.")
    @XrayTest(key = "MASFDCMNE-31124")
    @Tags({ @Tag("Regression"), @Tag("Marketo"), @Tag("TestDataDependency"), @Tag("Lead")})
    @Owner("Vatsala Bahal")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyCountryFieldUpdatedAfterChangeInLead(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName);

        //Login to Marketo, create a lead and sync to SFDC
        loginPage.loginToMarketo();
        leadPage.createLeadInMarketo(leadData.get(0));
        leadPage.syncLeadToSFDC();
        String sfdcLeadID = leadPage.getSFDCLeadIDFromMarketo();

        //Login to SFDC and open lead record
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        leadPage.openLeadRecordByID(sfdcLeadID);

        //update country field in lead record and check if it is synced with task country field
        leadPage.updateCountryFieldForLeadInSFDC(leadData.get(0).get("Primary Country"));
        leadPage.createLeadTaskInSFDC();
        taskPage.verifyCountryValueInTaskRecord(countryValue);
        taskPage.navigateToLeadFromTaskPage();
        leadPage.updateCountryFieldForLeadInSFDC(leadData.get(0).get("Secondary Country"));
        leadPage.navigateToTaskFromLeadPage();
        taskPage.verifyCountryValueInTaskRecord(countryValue);

    }
    @Test(description = "Country field should be synced after task is updated")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that the country field of the lead matches the corresponding task country field after the country field is updated in the task.")
    @XrayTest(key = "MTA-67")
    @Tags({ @Tag("Regression"), @Tag("Marketo"), @Tag("TestDataDependency"), @Tag("Lead"), @Tag("Task")})
    @Owner("Vatsala Bahal")
    @Link("Marketo: https://app.marketo.com/homepage/login, SFDC: https://test.salesforce.com/")
    public void verifyCountryFieldIsSyncedPostTaskUpdate(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        leadData = readExcelRows(leadsFilePath, TCName);
        taskData = readExcelRows(tasksFilePath, TCName);

        //Login to Marketo, create a lead and sync to SFDC
        loginPage.loginToMarketo();
        leadPage.createLeadInMarketo(leadData.get(0));
        leadPage.syncLeadToSFDC();
        String sfdcLeadID = leadPage.getSFDCLeadIDFromMarketo();

        //Login to SFDC and open lead record
        driver.get(getConfigProperty("App_URL"));
        loginPage.login();
        homePage.loginAs("Product Strategy - Marketo Admin");
        leadPage.openLeadRecordByID(sfdcLeadID);
        //update country field in lead record and check if it is synced with task country field
        leadPage.updateCountryFieldForLeadInSFDC(leadData.get(0).get("Primary Country"));

        leadPage.createLeadTaskInSFDC();
        taskPage.verifyCountryValueInTaskRecord(countryValue);
        //Update the country field in the task and check if it is still synced with lead
        taskPage.updateTaskCountryField(taskData.get(0).get("Country"));
        taskPage.verifyCountryValueInTaskRecord(countryValue);

    }
    @AfterMethod
    public void tearDown(){
        if (driver != null) {
            driver.quit();
        }
    }
}
