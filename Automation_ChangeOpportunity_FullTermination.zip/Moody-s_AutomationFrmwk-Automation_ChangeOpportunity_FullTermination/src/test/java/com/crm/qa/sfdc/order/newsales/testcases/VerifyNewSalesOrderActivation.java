package com.crm.qa.sfdc.order.newsales.testcases;

import app.getxray.xray.testng.annotations.XrayTest;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.*;
import com.crm.qa.util.AllureListener;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.AbstractDataLibrary.agreementTCDependency;
import static com.crm.qa.util.ReusableBusinessLibrary.openRecordBySFDCID;
import static com.crm.qa.util.ReusableLibrary.readExcelRows;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class, AllureListener.class})
public class VerifyNewSalesOrderActivation extends TestBase {

    public TestBase testBase;
    public ReusableLibrary reusableLibrary;
    public WebDriver driver;
    Properties prop;
    LoginPage loginPage;
    HomePage homePage;
    AccountPage accountPage;
    ContactPage contactPage;
    TaskPage taskPage;
    CampaignPage campaignPage;
    OpportunityPage opportunityPage;
    QuotePage quotePage;
    AgreementPage agreementPage;
    OrderPage orderPage;
    FulfillmentPage fulfillmentPage;
    ReusableBusinessLibrary reusableBusinessLibrary;
    LinkedHashMap<String, String> opportunityData;
    List<LinkedHashMap<String, String>> quoteData;
    List<LinkedHashMap<String, String>> originalQuoteData;
    LinkedHashMap<String, String> agreementData;

    @BeforeMethod
    public void setUp() {
        testBase = new TestBase();
        prop = reusableLibrary.initializeProperties();
        driver = testBase.initialization();
        driver.get(prop.getProperty("App_URL"));
        loggerManager.getLogger().info(prop.getProperty("Browser") + " browser launched successfully");
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        accountPage = new AccountPage(driver);
        contactPage = new ContactPage(driver);
        opportunityPage = new OpportunityPage(driver);
        taskPage = new TaskPage(driver);
        campaignPage = new CampaignPage(driver);
        quotePage = new QuotePage(driver);
        agreementPage = new AgreementPage(driver);
        orderPage = new OrderPage(driver);
        fulfillmentPage = new FulfillmentPage(driver);
        reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
        opportunityData = new LinkedHashMap<>();
        quoteData = new ArrayList<>();
        originalQuoteData = new ArrayList<>();
        agreementData = new LinkedHashMap<>();
    }

    @Test(description = "Verify that user is able to book a Single Year New Sales Order")
    @Severity(SeverityLevel.NORMAL)
    @Description("MASFDCMNE-23161,MACPQMNE-4846")
    @XrayTest(key = "MASFDCMNE-34229")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("TestDataDependency")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearOrderProcess(Method method) {
        //depedencies:
        //run the following testcases in the order listed before running this method:
        // (1) verifyQuoteCreationChangeOppyAddNewProduct, (2) verifySingleYearContractingProcessChangeOppyAddNewProduct
        TCDependency = "verifySingleYearQuoteCreation";
        agreementTCDependency = "verifySingleYearContractingProcess";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        agreementData = readExcelRows(agreementsFilePath, agreementTCDependency).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.getAgreementDetails();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.navigateToOrderFromAgreement();
        orderPage.validateAndAcceptOrder();
        orderPage.navigateToOrderLineItems();
        orderPage.verifyOrderLineItems(quoteData);
        openRecordBySFDCID(orderRecordID);
        orderPage.clickOnFulfillmentLink();
        fulfillmentPage.verifyFulfillmentDetails(agreementData, opportunityData);
        fulfillmentPage.navigateToAssetLineItemsRelatedList();
        fulfillmentPage.verifyAssetLineItems(quoteData);
        openRecordBySFDCID(fulfillmentRecordID);
        fulfillmentPage.navigateToAccountEntitlementRelatedList();
        fulfillmentPage.verifyAccountEntitlements(quoteData);
    }

    @Test(description = "Verify that user is able to book a Single Year Trial New Sales Order")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7640")
    @XrayTest(key = "MACPQMNE-7640")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("TestDataDependency")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearTrialOrderProcess(Method method) {
        TCDependency = "verifyTrialNewSalesQuoteCreations";
        agreementTCDependency = "verifySingleYearTrialContractingProcess";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        originalQuoteData = readExcelRows(quotesFilePath, TCDependency);
        agreementData = readExcelRows(agreementsFilePath, agreementTCDependency).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.getAgreementDetails();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.navigateToOrderFromAgreement();
        orderPage.validateAndAcceptOrder();
    }
    @Test(description = "Verify that user is able to book a Single Year Change Order")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7816")
    @XrayTest(key = "MACPQMNE-7816")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("ChangeOppy"), @Tag("TestDataDependency")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearOrderChangeOppy(Method method) {

        TCDependency = "verifyQuoteCreationChangeOppyAddNewProduct";
        agreementTCDependency = "verifySingleYearContractingProcessChangeOppyAddNewProduct";
        quoteTCdependency ="verifySingleYearQuoteCreation";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency); //represents the quote data from the change opportunity
        originalQuoteData = readExcelRows(quotesFilePath, quoteTCdependency); //represents the quote data from the original opportunity
        agreementData = readExcelRows(agreementsFilePath, agreementTCDependency).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.getAgreementDetails();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.navigateToOrderFromAgreement();
        orderPage.validateAndAcceptOrder();
        orderPage.navigateToOrderLineItems();
        orderPage.verifyOrderLineItems(quoteData);
        openRecordBySFDCID(orderRecordID);
        orderPage.clickOnFulfillmentLink();
        fulfillmentPage.verifyFulfillmentDetails(agreementData, opportunityData);
        fulfillmentPage.navigateToAssetLineItemsRelatedList();
        fulfillmentPage.verifyAssetLineItems_ChangeOppy(quoteData, originalQuoteData);
        openRecordBySFDCID(fulfillmentRecordID);
        fulfillmentPage.navigateToAccountEntitlementRelatedList();
        fulfillmentPage.verifyAccountEntitlements_ChangeOppy(quoteData, originalQuoteData);
    }

    @Test(description = "Verify that user is able to book a Single Year New Sales Order with Kompany products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7881")
    @XrayTest(key = "MACPQMNE-7881")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("TestDataDependency")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearOrderProcess_KompanyProducts(Method method) {
        //dependencies:
        //run the following testcases in the order listed before running this method:
        // (1) verifySingleYearQuoteCreation_KompanyProducts, (2) verifySingleYearContractingProcess_KompanyProducts
        TCDependency = "verifySingleYearQuoteCreation_KompanyProducts";
        agreementTCDependency = "verifySingleYearContractingProcess_KompanyProducts";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        agreementData = readExcelRows(agreementsFilePath, agreementTCDependency).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.getAgreementDetails();
        openRecordBySFDCID(agreementData.get("SFDCRecordID"));
        agreementPage.navigateToOrderFromAgreement();
        orderPage.validateAndAcceptOrder();
        orderPage.navigateToOrderLineItems();
        orderPage.verifyOrderLineItems(quoteData);
        openRecordBySFDCID(orderRecordID);
        orderPage.clickOnFulfillmentLink();
        fulfillmentPage.verifyFulfillmentDetails(agreementData, opportunityData);
        fulfillmentPage.navigateToAssetLineItemsRelatedList();
        fulfillmentPage.verifyAssetLineItems(quoteData);
    }

    @AfterMethod
    public void tearDown(){
        if (driver != null) {
            driver.quit();
        }
    }

}
