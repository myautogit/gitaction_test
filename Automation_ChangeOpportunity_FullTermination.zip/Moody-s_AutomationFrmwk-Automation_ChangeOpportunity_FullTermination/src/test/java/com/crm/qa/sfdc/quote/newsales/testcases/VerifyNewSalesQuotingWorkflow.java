package com.crm.qa.sfdc.quote.newsales.testcases;

import app.getxray.xray.testng.annotations.XrayTest;
import com.crm.qa.base.TestBase;
import com.crm.qa.pages.*;
import com.crm.qa.util.AllureListener;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.*;
import io.qameta.allure.testng.Tag;
import io.qameta.allure.testng.Tags;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.AbstractDataLibrary.TCName;
import static com.crm.qa.util.ReusableBusinessLibrary.getSFDCRecordIDFromURL;
import static com.crm.qa.util.ReusableBusinessLibrary.openRecordBySFDCID;
import static com.crm.qa.util.ReusableLibrary.*;

@Listeners({app.getxray.xray.testng.listeners.XrayListener.class, AllureListener.class})
public class VerifyNewSalesQuotingWorkflow extends TestBase {

    public TestBase testBase;
    public ReusableLibrary reusableLibrary;
    public WebDriver driver;
    Properties prop;
    LoginPage loginPage;
    HomePage homePage;
    AccountPage accountPage;
    ContactPage contactPage;
    TaskPage taskPage;
    CampaignPage campaignPage;
    OpportunityPage opportunityPage;
    QuotePage quotePage;
    AgreementPage agreementPage;
    OrderPage orderPage;
    FulfillmentPage fulfillmentPage;
    ReusableBusinessLibrary reusableBusinessLibrary;
    LinkedHashMap<String, String> opportunityData;
    List<LinkedHashMap<String, String>> quoteData;
    LinkedHashMap<String, String> agreementData;
    LinkedHashMap<String, String> fulfillmentData;

    @BeforeMethod
    public void setUp() {
        testBase = new TestBase();
        prop = reusableLibrary.initializeProperties();
        driver = testBase.initialization();
        driver.get(prop.getProperty("App_URL"));
        loggerManager.getLogger().info(prop.getProperty("Browser") + " browser launched successfully");
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        accountPage = new AccountPage(driver);
        contactPage = new ContactPage(driver);
        opportunityPage = new OpportunityPage(driver);
        taskPage = new TaskPage(driver);
        campaignPage = new CampaignPage(driver);
        quotePage = new QuotePage(driver);
        agreementPage = new AgreementPage(driver);
        orderPage = new OrderPage(driver);
        fulfillmentPage = new FulfillmentPage(driver);
        reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
        opportunityData = new LinkedHashMap<>();
        quoteData = new ArrayList<>();
        agreementData = new LinkedHashMap<>();
        fulfillmentData = new LinkedHashMap<>();
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with different products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MASFDCMNE-23161,MACPQMNE-4846. Products: Standalone Products (68829, 69944, 71572, 71126), Bundle Products with pricing at header level (66199), Bundle Products with pricing at option level (69981), Zero Dollar Product (70440), Flat Price Product (69981), Auto-Inclusion Product (67684 - auto-included with 71126)")
    @XrayTest(key = "MASFDCMNE-34227")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.selectOpportunityCurrency();
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Request 6: Operational Analyst field must get renamed as Contract Specialist")
    @Severity(SeverityLevel.NORMAL)
    @Description("MASFDCMNE-23161")
    @XrayTest(key = "MASFDCMNE-23161")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyContractSpecialistField(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Business Admin");
        homePage.checkMoodysApp();
        openRecordBySFDCID(opportunityData.get("ExistingUsageAndOverageByAsset"));
        reusableBusinessLibrary.checkFieldRenameOnSFDCRecord("Operations Analyst", "Contract Specialist", "Active Asset");
        openRecordBySFDCID(opportunityData.get("ExistingUsageAndOverageByFirm"));
        reusableBusinessLibrary.checkFieldRenameOnSFDCRecord("Operations Analyst", "Contract Specialist", "Fulfillment Name");
        openRecordBySFDCID(opportunityData.get("ExistingSalesOrder"));
        reusableBusinessLibrary.checkFieldRenameOnSFDCRecord("Operations Analyst", "Contract Specialist", "Submit Status");
        openRecordBySFDCID(opportunityData.get("ExistingSalesOrderLine"));
        reusableBusinessLibrary.checkFieldRenameOnSFDCRecord("Operations Analyst", "Contract Specialist", "Report Format");
    }

    @Test(description = "Verify that Product Forecast field is visible on Opportunity Product and transaction locations are created on the Quote after it is finalized")
    @Severity(SeverityLevel.NORMAL)
    @Description("MASFDCMNE-20163,MASFDCMNE-16400")
    @XrayTest(key = "MASFDCMNE-34255")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyOpportunityFieldAndLocations(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.navigateToTransactionLocationsRelatedList();
        quotePage.verifyTransactionLocations(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.navigateToOpportunityProductRecord();
        opportunityPage.verifyProductForecastDateFieldOnOppyProduct();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        homePage.loginAs("Sales Manager");
        openRecordBySFDCID(oppyID);
        opportunityPage.navigateToOpportunityProductRecord();
        opportunityPage.verifyProductForecastDateFieldOnOppyProduct();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        homePage.loginAs("Product Specialist/Account Manager");
        openRecordBySFDCID(oppyID);
        opportunityPage.navigateToOpportunityProductRecord();
        opportunityPage.verifyProductForecastDateFieldOnOppyProduct();
    }

    @Test(description = "Visibility of the warning message on the opportunity")
    @Severity(SeverityLevel.NORMAL)
    @Description("MASFDCMNE-29488")
    @XrayTest(key = "MASFDCMNE-29488")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySoldToContactChangeWarningMessageOnOppy(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        openRecordBySFDCID(oppyID);
        opportunityPage.updateSoldToContactOnOpportunity(opportunityData.get("NewSoldToContact"));
        opportunityPage.verifySoldToContactChangeWarningMessage();
        openRecordBySFDCID(proposalRecordID);
        quotePage.verifyQuoteStage("Approved");
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with one time products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7095, One Time Products")
    @XrayTest(key = "MACPQMNE-7095")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("OneTimeProducts"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_OneTimeProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with RMS package products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7187, RMS Products")
    @XrayTest(key = "MACPQMNE-7187")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("RMSProducts"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_RMSPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a Quote with bundle products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7333, general flow for two types of bundle products: pricing at bundle header, pricing at option level")
    @XrayTest(key = "MACPQMNE-7333")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("BundleProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_BundleProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with Cortera products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-4917, MACPQMNE-7323. Products: Non Usage Products (70665, 70226, 70238), Usage Products with No Commitment (70383), Usage Products with Simple Commitment (70384), Usage Product with Advanced Commitment (70380), Usage Products with Contract Committed Price (70749, 70406, 70387)")
    @XrayTest(key = "MACPQMNE-7323")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("CorteraProducts")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_CorteraProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnOptionLineItemsForUsageProducts(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with Catylist products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7350. Products: Non-Usage Product (70090), Usage Product (70088)")
    @XrayTest(key = "MACPQMNE-7350")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("CatylistProducts")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_CatylistProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.adjustFirstUsageTierForOverageLine(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnOptionLineItemsForUsageProducts(quoteData);
    }

    @Test(description = "Verify that user is able to create trial quote")
    @Severity(SeverityLevel.NORMAL)
    @Description("Verify that user is able to create trail quote")
    @XrayTest(key = "MACPQMNE-7358")
    @Tags({@Tag("Positive"), @Tag("TrailQuote"), @Tag("NewSales")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyTrialNewSalesQuoteCreations(Method method){
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.verifyOpportunityCreationFormIsVisible();
        opportunityPage.enterNewSalesOpportunity(opportunityData);
        opportunityPage.enterOpportunityTrialDates(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        opportunityPage.saveOpportunity();
        opportunityPage.verifyOpportunityIsSaved();
        opportunityPage.clickCreateTrialButton();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with Axis products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7459, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7459")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a 3 Multi Year Quote with bundle products ")
    @Severity(SeverityLevel.NORMAL)
    @Description("tests quotes which are multi year for bundle products")
    @XrayTest(key = "MACPQMNE-7489")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("BundleProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearBundleProducts_3Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a 2 Multi Year Quote with bundle products ")
    @Severity(SeverityLevel.NORMAL)
    @Description("Tests quotes which are multi year for bundle products")
    @XrayTest(key = "MACPQMNE-7490")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("BundleProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearBundleProducts_2Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a 5 Year Quote with bundle products")
    @Severity(SeverityLevel.NORMAL)
    @Description("Tests quotes which are multi year for bundle products")
    @XrayTest(key = "MACPQMNE-7346")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("BundleProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearBundleProducts_5Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a 7 Year Quote with bundle products ")
    @Severity(SeverityLevel.NORMAL)
    @Description("Tests quotes which are multi year for bundle products")
    @XrayTest(key = "MACPQMNE-7491")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("BundleProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearBundleProducts_7Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with RMS non-package products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7483, RMS non-package products")
    @XrayTest(key = "MACPQMNE-7483")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("RMSProducts"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_RMSNonPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }
    @Test(description = "Verify that user is able to configure and finalize multi year quote(2yrs) with Axis products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7597, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7597")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifyMulti2YearQuoteCreation_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize multi year quote(3yrs) with Axis products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7598, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7598")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifyMulti3YearQuoteCreation_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize multi year quote(5yrs) with Axis products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7599, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7599")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifyMulti5YearQuoteCreation_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a 2 Year Quote with One time products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7521")
    @XrayTest(key = "MACPQMNE-7521")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("OneTimeProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearOneTimeProducts_2Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }
    @Test(description = "Verify that user is able to configure and finalize a 3 Year Quote with One time products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7522")
    @XrayTest(key = "MACPQMNE-7522")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("OneTimeProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearOneTimeProducts_3Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);

    }
    @Test(description = "Verify that user is able to configure and finalize a 5 Year Quote with One time products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7523")
    @XrayTest(key = "MACPQMNE-7523")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("OneTimeProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearOneTimeProducts_5Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }
    @Test(description = "Verify that user is able to configure and finalize a 7 Year Quote with One time products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7524")
    @XrayTest(key = "MACPQMNE-7524")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("OneTimeProducts"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearOneTimeProducts_7Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for US Region - Level 1")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-3508")
    @XrayTest(key = "MACPQMNE-3508")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Level1(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel1ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for US Region - Level 2")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7554")
    @XrayTest(key = "MACPQMNE-7554")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Level2(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel2ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for US Region - Level 3")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7555")
    @XrayTest(key = "MACPQMNE-7555")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Level3(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel3ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for US Region - Level 4")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7556")
    @XrayTest(key = "MACPQMNE-7556")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Level4(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel4ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for US Region - Level 5")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7556")
    @XrayTest(key = "MACPQMNE-7556")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Level5(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel5ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for EMEA Region - Level 1")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-3509")
    @XrayTest(key = "MACPQMNE-3509")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Level1(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (EMEA Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel1ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for EMEA Region - Level 2")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7559")
    @XrayTest(key = "MACPQMNE-7559")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Level2(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (EMEA Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel2ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for EMEA Region - Level 3")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7560")
    @XrayTest(key = "MACPQMNE-7560")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Level3(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (EMEA Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel3ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for EMEA Region - Level 4")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7561")
    @XrayTest(key = "MACPQMNE-7561")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Level4(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (EMEA Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel4ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for EMEA Region - Level 5")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7562")
    @XrayTest(key = "MACPQMNE-7562")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Level5(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (EMEA Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel5ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for APAC Region - Level 1")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-3510")
    @XrayTest(key = "MACPQMNE-3510")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Level1(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (APAC Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel1ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for APAC Region - Level 2")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7564")
    @XrayTest(key = "MACPQMNE-7564")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Level2(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (APAC Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel2ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for APAC Region - Level 3")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7565")
    @XrayTest(key = "MACPQMNE-7565")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Level3(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (APAC Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel3ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for APAC Region - Level 4")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7566")
    @XrayTest(key = "MACPQMNE-7566")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Level4(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (APAC Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel4ApprovalOnNewSaleQuote(quoteData);
    }

    @Test(description = "Verify the Quote Approval Process for Single Year New Sales Quote for APAC Region - Level 5")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7567")
    @XrayTest(key = "MACPQMNE-7567")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Level5(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep (APAC Region)");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        quotePage.verifyLevel5ApprovalOnNewSaleQuote(quoteData);
    }


    @Test(description = "Verify that user is able to configure and finalize a quote with kompany products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7543, Kompany Products")
    @XrayTest(key = "MACPQMNE-7543")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("Kompany Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_KompanyProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }
    @Test(description = "Verify that user is able to configure and finalize a quote with Grid products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7634, Grid Products")
    @XrayTest(key = "MACPQMNE-7634")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("Grid Products"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreation_GridProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify Trail Quote convertion to New Sales Quote")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7638")
    @XrayTest(key = "MACPQMNE-7638")
    @Tags({@Tag("Positive"), @Tag("TrailQuoteConversion"), @Tag("NewSales")})
    @Owner("Sayon Das")
    @Link("https://test.salesforce.com/")
    public void verifyTrlQuoteConverstiontoNewSalesQuote(Method method){
        TCDependency = "verifyTrialNewSalesQuoteCreations";
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        openRecordBySFDCID(quoteData.get(0).get("SFDCRecordID"));
        quotePage.clickCloneLineItem();
        quotePage.validateCloneQuote();
        quotePage.clickConfigureProduct();
        quotePage.validateCartTotal();
        quotePage.finalizeQuote();
    }

    @Test(description = "Verify that user is able to configure and finalize a 2 Year Quote with regular products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7631")
    @XrayTest(key = "MACPQMNE-7631")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RegularProducts"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearRegularProducts_2Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify that user is able to configure and finalize a 3 Year Quote with regular products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7629")
    @XrayTest(key = "MACPQMNE-7629")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RegularProducts"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearRegularProducts_3Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);

    }

    @Test(description = "Verify that user is able to configure and finalize a 5 Year Quote with regular products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7630")
    @XrayTest(key = "MACPQMNE-7630")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RegularProducts"), @Tag("NewSales")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearRegularProducts_5Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        openRecordBySFDCID(oppyID);
        opportunityPage.validateMandatoryOpportunityInfo(opportunityData);
    }

    @Test(description = "Verify that user is able to configure and finalize a 2 Year Quote with Cortera products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7668, Cortera Products")
    @XrayTest(key = "MACPQMNE-7668")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("Cortera Products"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearCorteraProducts_2Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }
    @Test(description = "Verify that user is able to configure and finalize a 3 Year Quote with Cortera products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7669, Cortera Products")
    @XrayTest(key = "MACPQMNE-7669")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("Cortera Products"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearCorteraProducts_3Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }
    @Test(description = "Verify that user is able to configure and finalize a 5 Year Quote with Cortera products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7670, Cortera Products")
    @XrayTest(key = "MACPQMNE-7670")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("Cortera Products"), @Tag("NewSales")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_MultiYearCorteraProducts_5Year(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for US Region - Level 1")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7687")
    @XrayTest(key = "MACPQMNE-7687")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Part2_Level1(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalUSRegion_Level1";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level1B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        String quoteRecordID_Level1C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[2];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 1B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level1B, "Level 1B");
        quotePage.completeApproval("Sales Rep_Line Manager", quoteRecordID_Level1B, "Level 1B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level1B, opportunityData, quoteData);

        //Verify Approval Level 1C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level1C, "Level 1C");
        quotePage.completeApproval("Sales Rep_Segment Lead", quoteRecordID_Level1C, "Level 1C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level1C, opportunityData, quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for US Region - Level 2")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7686")
    @XrayTest(key = "MACPQMNE-7686")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Part2_Level2(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalUSRegion_Level2";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level2B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[0];
        String quoteRecordID_Level2C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 2B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level2B, "Level 2B");
        quotePage.completeApproval("Sales Rep_Line Manager", quoteRecordID_Level2B, "Level 2B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level2B, opportunityData, quoteData);

        //Verify Approval Level 2C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level2C, "Level 2C");
        quotePage.completeApproval("Sales Rep_Segment Lead", quoteRecordID_Level2C, "Level 2C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level2C, opportunityData, quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for US Region - Level 3")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7685")
    @XrayTest(key = "MACPQMNE-7685")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalUSRegion_Part2_Level3(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalUSRegion_Level3";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level3B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[0];
        String quoteRecordID_Level3C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 3B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level3B, "Level 3B");
        quotePage.completeApproval("Sales Rep_Segment Lead", quoteRecordID_Level3B, "Level 3B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level3B, opportunityData, quoteData);

        //Verify Approval Level 3C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level3C, "Level 3C");
        quotePage.completeApproval("Sales Rep_Regional GM", quoteRecordID_Level3C, "Level 3C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level3C, opportunityData, quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for APAC Region - Level 1")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7684")
    @XrayTest(key = "MACPQMNE-7684")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Part2_Level1(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalAPACRegion_Level1";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level1B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        String quoteRecordID_Level1C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[2];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 1B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level1B, "Level 1B");
        quotePage.completeApproval("Sales Rep_Line Manager_APAC Region", quoteRecordID_Level1B, "Level 1B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level1B, opportunityData, quoteData);

        //Verify Approval Level 1C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level1C, "Level 1C");
        quotePage.completeApproval("Sales Rep_Segment Lead_APAC Region", quoteRecordID_Level1C, "Level 2C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level1C, opportunityData, quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for APAC Region - Level 2")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7683")
    @XrayTest(key = "MACPQMNE-7683")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Part2_Level2(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalAPACRegion_Level2";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level2B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[0];
        String quoteRecordID_Level2C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 2B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level2B, "Level 2B");
        quotePage.completeApproval("Sales Rep_Line Manager_APAC Region", quoteRecordID_Level2B, "Level 2B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level2B, opportunityData, quoteData);

        //Verify Approval Level 2C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level2C, "Level 2C");
        quotePage.completeApproval("Sales Rep_Segment Lead_APAC Region", quoteRecordID_Level2C, "Level 2C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level2C, opportunityData, quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for APAC Region - Level 3")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7682")
    @XrayTest(key = "MACPQMNE-7682")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalAPACRegion_Part2_Level3(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalAPACRegion_Level3";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level3B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[0];
        String quoteRecordID_Level3C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 3B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level3B, "Level 3B");
        quotePage.completeApproval("Sales Rep_Segment Lead_APAC Region", quoteRecordID_Level3B, "Level 3B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level3B, opportunityData, quoteData);

        //Verify Approval Level 3C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level3C, "Level 3C");
        quotePage.completeApproval("Sales Rep_Regional GM_APAC Region", quoteRecordID_Level3C, "Level 3C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level3C, opportunityData, quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for EMEA Region - Level 1")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7681")
    @XrayTest(key = "MACPQMNE-7681")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Part2_Level1(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalEMEARegion_Level1";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level1B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        String quoteRecordID_Level1C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[2];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 1B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level1B, "Level 1B");
        quotePage.completeApproval("Sales Rep_Line Manager_EMEA Region", quoteRecordID_Level1B, "Level 1B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level1B, opportunityData, quoteData);

        //Verify Approval Level 1C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level1C, "Level 1C");
        quotePage.completeApproval("Sales Rep_Segment Lead_EMEA Region", quoteRecordID_Level1C, "Level 1C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level1C, opportunityData, quoteData);

    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for EMEA Region - Level 2")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7680")
    @XrayTest(key = "MACPQMNE-7680")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Part2_Level2(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalEMEARegion_Level2";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level2B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[0];
        String quoteRecordID_Level2C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 2B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level2B, "Level 2B");
        quotePage.completeApproval("Sales Rep_Line Manager_EMEA Region", quoteRecordID_Level2B, "Level 2B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level2B, opportunityData, quoteData);

        //Verify Approval Level 2C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level2C, "Level 2C");
        quotePage.completeApproval("Sales Rep_Segment Lead_EMEA Region", quoteRecordID_Level2C, "Level 2C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level2C, opportunityData, quoteData);
    }

    @Test(description = "Verify that approver is able to approve the Single Year New Sales Quote for EMEA Region - Level 3")
    @Severity(SeverityLevel.CRITICAL)
    @Description("MACPQMNE-7679")
    @XrayTest(key = "MACPQMNE-7679")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("ApprovalProcess")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearNewSalesQuoteApprovalEMEARegion_Part2_Level3(Method method) {
        TCName = method.getName();
        TCDependency = "verifySingleYearNewSalesQuoteApprovalEMEARegion_Level3";
        opportunityData = readExcelRows(opportunitiesFilePath, TCDependency).get(0);
        quoteData = readExcelRows(quotesFilePath, TCDependency);
        String quoteRecordID_Level3B = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[0];
        String quoteRecordID_Level3C = readExcelData(quotesFilePath, TCDependency, "SFDCRecordID").split(",")[1];
        loggerManager.getLogger().info("Starting test case: " + TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();

        //Verify Approval Level 3B which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level3B, "Level 3B");
        quotePage.completeApproval("Sales Rep_Segment Lead_EMEA Region", quoteRecordID_Level3B, "Level 3B");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level3B, opportunityData, quoteData);

        //Verify Approval Level 3C which involves submitting the Quote for approval, approving it and then validating the Quote and PLI details
        quotePage.submitQuoteForApproval(quoteRecordID_Level3C, "Level 3C");
        quotePage.completeApproval("Sales Rep_Regional GM_EMEA Region", quoteRecordID_Level3C, "Level 3C");
        quotePage.validateQuoteAndPLIDetails(quoteRecordID_Level3C, opportunityData, quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 2 Year quote with RMS Package Products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7749, RMS Package Products")
    @XrayTest(key = "MACPQMNE-7749")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RMS Package Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear2QuoteCreation_RMSPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.copyLineItemsAsPerNumberOfYear(quoteData);
        quotePage.updateMultiYearDatesOnRMSCart(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 3 Year quote with RMS Package Products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7750, RMS Package Products")
    @XrayTest(key = "MACPQMNE-7750")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RMS Package Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear3QuoteCreation_RMSPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.copyLineItemsAsPerNumberOfYear(quoteData);
        quotePage.updateMultiYearDatesOnRMSCart(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 5 Year quote with RMS Package Products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7751, RMS Package Products")
    @XrayTest(key = "MACPQMNE-7751")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RMS Package Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear5QuoteCreation_RMSPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.copyLineItemsAsPerNumberOfYear(quoteData);
        quotePage.updateMultiYearDatesOnRMSCart(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 2 Year quote with RMS Non-Package Products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7752, RMS Non-Package Products")
    @XrayTest(key = "MACPQMNE-7752")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RMS Non-Package Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear2QuoteCreation_RMSNonPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.copyLineItemsAsPerNumberOfYear(quoteData);
        quotePage.updateMultiYearDatesOnRMSCart(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 3 Year quote with RMS Non-Package Products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7753, RMS Non-Package Products")
    @XrayTest(key = "MACPQMNE-7753")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RMS Non-Package Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear3QuoteCreation_RMSNonPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.copyLineItemsAsPerNumberOfYear(quoteData);
        quotePage.updateMultiYearDatesOnRMSCart(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 5 Year quote with RMS Non-Package Products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7754, RMS Non-Package Products")
    @XrayTest(key = "MACPQMNE-7754")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("RMS Non-Package Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear5QuoteCreation_RMSNonPackageProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.copyLineItemsAsPerNumberOfYear(quoteData);
        quotePage.updateMultiYearDatesOnRMSCart(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 2 year quote with Kompany products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7765, Kompany Products")
    @XrayTest(key = "MACPQMNE-7765")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("Kompany Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear2QuoteCreation_KompanyProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 3 year quote with Kompany products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7766, Kompany Products")
    @XrayTest(key = "MACPQMNE-7766")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("Kompany Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear3QuoteCreation_KompanyProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize 5 year quote with Kompany products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7767, Kompany Products")
    @XrayTest(key = "MACPQMNE-7767")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("Kompany Products"), @Tag("NewSales")})
    @Owner("Rishi Saini")
    @Link("https://test.salesforce.com/")
    public void verifyMultiYear5QuoteCreation_KompanyProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }
    @Test(description = "Verify that user is able to change opportunity and add new product with existing data")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7813")
    @XrayTest(key = "MACPQMNE-7813")
    @Tags({@Tag("Positive"), @Tag("Existing Data"),@Tag("SingleYearQuote"), @Tag("ChangeOppy"), @Tag("AddNewProduct")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreationChangeOppyAddNewProduct_ExistingData(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        quoteData = readExcelRows(quotesFilePath, TCName);
        fulfillmentData = readExcelRows(fulfillmentsFilePath, TCName).get(0);
        expectedStartDate = fulfillmentData.get("FulfillmentStartDate");
        expectedEndDate = fulfillmentData.get("FulfillmentEndDate");
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        openRecordBySFDCID(fulfillmentData.get("SFDCRecordID"));
        fulfillmentPage.clickCreateChangeOppy();
        opportunityPage.navigateToProposalFromOpportunity();
        quotePage.enterDefaultCategoryAndDefaultReasonFieldOnQuote("Midterm Add: New Product", "New Sale");
        reusableBusinessLibrary.clickSaveBtn();
        quotePage.validateDefaultCategoryAndDefaultReasonFieldOnQuote("Midterm Add: New Product", "New Sale");
        oppyName = quotePage.getOpportunityName();
        quotePage.clickConfigureProductsOnQuote();
        quotePage.clickCatalogProducts();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }
    @Test(description = "Verify that user is able to change opportunity and add new product with new data")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7834")
    @XrayTest(key = "MACPQMNE-7814")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"),@Tag("ChangeOppy"),@Tag("AddNewProduct"), @Tag("TestDataDependency")})
    @Owner("Vatsala Bahal")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreationChangeOppyAddNewProduct(Method method) {
        //depedencies:
        //run the following testcases in the order listed before running this method:
        // (1) verifySingleYearQuoteCreation, (2) verifySingleYearContractingProcess, (3) verifySingleYearOrderProcess
        TCName = method.getName();
        agreementTCDependency = "verifySingleYearContractingProcess";
        loggerManager.getLogger().info("Starting test case: " + TCName);
        quoteData = readExcelRows(quotesFilePath, TCName);
        agreementData = readExcelRows(agreementsFilePath, agreementTCDependency).get(0);
        expectedStartDate = getCurrentDateInMMddyyyyFormat();
        expectedEndDate = subtractDays(currentDatePlusYears(1),1);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Tasks", agreementData.get("OrderNo"));
        orderPage.clickOnFulfillmentLink();
        fulfillmentPage.storeFulfillmentTotalInExcel();
        fulfillmentPage.clickCreateChangeOppy();
        opportunityPage.storeChangeOpportunityInformationInExcel();
        opportunityPage.navigateToProposalFromOpportunity();
        quotePage.enterDefaultCategoryAndDefaultReasonFieldOnQuote("Midterm Add: New Product", "New Sale");
        reusableBusinessLibrary.clickSaveBtn();
        quotePage.validateDefaultCategoryAndDefaultReasonFieldOnQuote("Midterm Add: New Product", "New Sale");
        oppyName = quotePage.getOpportunityName();
        quotePage.clickConfigureProductsOnQuote();
        quotePage.clickCatalogProducts();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a quote with Axis products-quarterly config")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7776, MTA-153, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7776")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreationQuarterly_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize a single year quote without Axis user keys")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7777, MTA-162, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7777")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifySingleYearQuoteCreationNonUserKeys_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize multi year quote without Axis user keys-2yrs")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7778, MTA-152, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7778")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_2YrMultiYearNonUserKeys_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.configurePriceRamp();
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }
//      WIP : changes will be included on next commit/PR
    @Test(description = "Verify that user is able to configure and finalize multi year quote with Axis user keys-2yrs")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7779, Products with user keys and non user keys added.")
    @XrayTest(key = "MACPQMNE-7779")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("NewSales"), @Tag("AxisProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verifyQuoteCreation_2YrMultiYearUserKeys_AxisProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.manualPriceRamp(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to configure and finalize multiyear quote with Catylist products")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7857. Products: Non-Usage Product (70090), Usage Product (70088)")
    @XrayTest(key = "MACPQMNE-7857")
    @Tags({@Tag("Positive"), @Tag("MultiYearQuote"), @Tag("NewSales"), @Tag("CatylistProducts")})
    @Owner("Hemal Shah")
    @Link("https://test.salesforce.com/")
    public void verify2yrMultiYearQuoteCreation_CatylistProducts(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        opportunityData = readExcelRows(opportunitiesFilePath, TCName).get(0);
        quoteData = readExcelRows(quotesFilePath, TCName);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        opportunityPage.selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        opportunityPage.enterNewSalesOpportunityFromAccountRecord(opportunityData);
        opportunityPage.saveOpportunity();
        opportunityPage.createQuoteFromOpportunity();
        quotePage.addAndConfigureProductsOnApttus(quoteData);
        quotePage.adjustFirstUsageTierForOverageLine(quoteData);
        quotePage.manualPriceRamp(quoteData);
        quotePage.validateCartPage(quoteData);
        quotePage.finalizeQuote();
        quotePage.verifyNewSaleQuoteDetails(opportunityData);
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnLineItems(quoteData);
        reusableBusinessLibrary.verifyFieldsOnOptionLineItemsForUsageProducts(quoteData);
    }

    @Test(description = "Verify that user is able to terminate a product completely from an existing Contract")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-3506")
    @XrayTest(key = "MACPQMNE-3506")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("ChangeOppy"), @Tag("FullTermination"), @Tag("ExistingData")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyChangeOppyFullTerminationOnOneLine_ExistingData(Method method) {
        TCName = method.getName();
        loggerManager.getLogger().info("Starting test case: " + TCName);
        fulfillmentData = readExcelRows(fulfillmentsFilePath, TCName).get(0);
        loginPage.login();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        openRecordBySFDCID(fulfillmentData.get("SFDCRecordID"));
        fulfillmentPage.clickCreateChangeOppy();
        opportunityPage.navigateToProposalFromOpportunity();
        expectedStartDate = quotePage.getQuoteExpectedStartDate();
        oppyName = quotePage.getOpportunityName();
        expectedStartDate = quotePage.getQuoteExpectedStartDate();
        proposalRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        quotePage.enterDefaultCategoryAndDefaultReasonFieldOnQuote("Midterm Cancel or Downgrade", "Price");
        reusableBusinessLibrary.clickSaveBtn();
        quotePage.validateDefaultCategoryAndDefaultReasonFieldOnProposal();
        pageRefresh(driver);
        quotePage.clickConfigureProduct();
        quotePage.performFullTerminationOnFirstLine();
        quotePage.verifyCartLineDetailsPostFullTermination();
        quotePage.clickOnSubmitForApprovalBtn();
        quotePage.submitQuoteForApproval();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        quotePage.approveQuoteWithMultipleApprovers();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        openRecordBySFDCID(proposalRecordID);
        quotePage.verifyQuoteStage("Approved");
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @Test(description = "Verify that user is able to terminate a product completely from a newly created Contract")
    @Severity(SeverityLevel.NORMAL)
    @Description("MACPQMNE-7877")
    @XrayTest(key = "MACPQMNE-7877")
    @Tags({@Tag("Positive"), @Tag("SingleYearQuote"), @Tag("ChangeOppy"), @Tag("FullTermination"), @Tag("TestDataDependency")})
    @Owner("Arshin Shaikh")
    @Link("https://test.salesforce.com/")
    public void verifyChangeOppyFullTerminationOnOneLine_NewData(Method method) {
        //dependencies:
        //run the following testcases in the order listed before running this method:
        // (1) verifySingleYearQuoteCreation_KompanyProducts, (2) verifySingleYearContractingProcess_KompanyProducts, (3) verifySingleYearOrderProcess_KompanyProducts
        TCName = method.getName();
        agreementTCDependency = "verifySingleYearContractingProcess_KompanyProducts";
        loggerManager.getLogger().info("Starting test case: " + TCName);
        agreementData = readExcelRows(agreementsFilePath, agreementTCDependency).get(0);
        loginPage.login();
        homePage.loginAs("Operation Analyst");
        homePage.checkMoodysApp();
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Orders", agreementData.get("OrderNo"));
        orderPage.clickOnFulfillmentLink();
        fulfillmentPage.clickCreateChangeOppy();
        opportunityPage.navigateToProposalFromOpportunity();
        expectedStartDate = quotePage.getQuoteExpectedStartDate();
        oppyName = quotePage.getOpportunityName();
        expectedStartDate = quotePage.getQuoteExpectedStartDate();
        proposalRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        quotePage.enterDefaultCategoryAndDefaultReasonFieldOnQuote("Midterm Cancel or Downgrade", "Price");
        reusableBusinessLibrary.clickSaveBtn();
        quotePage.validateDefaultCategoryAndDefaultReasonFieldOnProposal();
        pageRefresh(driver);
        quotePage.clickConfigureProduct();
        quotePage.performFullTerminationOnFirstLine();
        quotePage.verifyCartLineDetailsPostFullTermination();
        quotePage.clickOnSubmitForApprovalBtn();
        quotePage.submitQuoteForApproval();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
        quotePage.approveQuoteWithMultipleApprovers();
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        openRecordBySFDCID(proposalRecordID);
        quotePage.verifyQuoteStage("Approved");
        quotePage.verifyQuoteActions();
        quotePage.verifyReadyForAgreementButton();
        quotePage.navigateToProposalLineItemsRelatedList();
        quotePage.verifyProposalLineItems(quoteData);
    }

    @AfterMethod
    public void tearDown(){
        if (driver != null) {
            driver.quit();
        }
    }
}
