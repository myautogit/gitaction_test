package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.*;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.getSFDCRecordIDFromURL;
import static com.crm.qa.util.ReusableBusinessLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;

/**
 * This class contains methods related to the Agreement functionality.
 * Author: Arshin Shaikh
 * Last Modified By: Arshin Shaikh
 * Date: 12/02/2024
 * Comment: Created new class and added method for the end to end flow of Agreement activation process
 */
public class AgreementPage extends TestBase {

    public AgreementPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();
    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
    HomePage homePage = new HomePage(driver);

    //Page Factory - OR:

    @FindBy(xpath = "//iframe[@scrolling='yes']")
    WebElement agreementRecordTypeSelectionFrame;

    @FindBy(xpath = "//label[contains(text(),'Record Type')]/following-sibling::select")
    WebElement agreementRecordTypeSelectionDropdown;

    @FindBy(xpath = "//span[text()[normalize-space()='For Order Form Agreement: Legal Contracting Entity, Ship To Contact, Bill To Contact, Payment Terms, Billing Cycle fields should be completed before generating document.']]")
    WebElement infoMessage;

    @FindBy(xpath = "//label[text()='Related Quote/Proposal']")
    WebElement relatedQuoteProposalLabel;

    @FindBy(xpath = "//label[text()='Client Party Signed Date']")
    WebElement clientPartySignedDateLabel;

    @FindBy(xpath = "//button[text()='Legal Contracting Entity']")
    WebElement legalContractingEntityButton;

    @FindBy(xpath = "//h4[text()='Legal Contracting Entity']")
    WebElement legalContractingEntityHeader;

    @FindBy(xpath = "//button[text()='New Legal Contracting Entity']")
    WebElement newLegalContractingEntityButton;

    @FindBy(xpath = "(//label[text()='Legal Contracting Entity Name']/following::input)[1]")
    WebElement legalContractingEntityNameTextfield;

    @FindBy(xpath = "//span[text()='Country of Registration']/following::select")
    WebElement countryOfRegistrationDropdown;

    By entityNameLink(String entityName){
        return By.xpath("//div[@title=\"" + entityName + "\"]");
    }

    @FindBy(xpath = "//a[contains(@href,'Legal_Contracting_Entity')]")
    WebElement legalContractingEntityLinkOnAgreementPage;

    @FindBy(xpath = "//span[@title='Legal Contracting Entity']")
    WebElement legalContractingEntitySectionLabel;

    @FindBy(xpath = "//label[text()='Executed Copy Mailed Out Date']")
    WebElement executedCopyMailedOutDateLabelOnEditPage;

    @FindBy(xpath = "//div[text()='Termination Right']")
    WebElement terminationRightLabelOnEditPage;

    @FindBy(xpath = "//label[text()='Primary Street 1']/following::textarea")
    WebElement primaryStreet1TextFieldOnLCE;

    @FindBy(xpath = "(//label[text()='Primary City']/following::input)[1]")
    WebElement primaryCityTextFieldOnLCE;

    @FindBy(xpath = "(//label[text()='Primary State']/following::input)[1]")
    WebElement primaryStateTextFieldOnLCE;

    @FindBy(xpath = "(//label[text()='Primary Zip/Postal Code']/following::input)[1]")
    WebElement primaryZipPostalCodeTextFieldOnLCE;

    By stateOptionOnLCE(String countryName){
        return By.xpath("//span[text()='" + countryName + "']");
    }

    @FindBy(xpath = "//iframe[@title='External Web Page']")
    WebElement generateAgreementPageFrame;

    @FindBy(xpath = "//input[@value='Generate']")
    WebElement generateAgreementBtn;

    @FindBy(xpath = "//script/following-sibling::input[@value='OK']")
    WebElement generateAgreementOKBtn;

    @FindBy(xpath = "//button[text()='Submit for Approval']")
    WebElement submitForApprovalBtn;

    @FindBy(xpath = "//span[text()='Submit']")
    WebElement submitBtn;

    @FindBy(xpath = "//a[@title='Approve']")
    WebElement approveBtnOnApprovalHistory;

    @FindBy(xpath = "//span[text()='Approve']")
    WebElement approveBtnOnPopupWindow;

    @FindBy(xpath = "//a[@title='Legal Review Required = True']//following::span[text()='Approved']")
    WebElement legalApprovedStatusOnApprovalHistory;

    @FindBy(xpath = "//a[@title='Finance Review Required = True']//following::span[text()='Approved']")
    WebElement financeApprovedStatusOnApprovalHistory;

    @FindBy(xpath = "//td//label[contains(@class,'checkbox')]")
    WebElement agreementFileOnSendForSignaturesPage;

    @FindBy(xpath = "//button[text()='Next']")
    WebElement nextButtonOnSendForSignaturesPage;

    @FindBy(xpath = "//button[text()='Send']")
    WebElement sendButtonOnSendForSignaturesPage;

    @FindBy(xpath = "//h3/span[@title='Key Dates']")
    WebElement keyDatesSectionLabelOnEditPage;

    @FindBy(xpath = "//td[@data-label='Publish']//label")
    WebElement publishToggleBtn;
    
    @FindBy(xpath = "//button[text()='Activate']")
    WebElement activateBtn;

    @FindBy(xpath = "//footer//button[text()='Activate']")
    WebElement activateBtnOnPopupWindow;

    @FindBy(xpath = "//span[text()='MA E-CounterSignature' and contains(@class,'field')]")
    WebElement maECounterSignatureFieldLabel;

    @FindBy(xpath = "//lightning-primitive-cell-factory[@data-label='Order Number']//a")
    WebElement orderNumberLink;

    //Actions:

    /**
     * This method selects the Agreement Record Type
     * @param recordType - Agreement Record Type to be selected
     */
    @Step("Select Agreement Record Type as {recordType}")
    public void selectAgreementRecordType(String recordType) {
        waitforFrametoLoad(driver, agreementRecordTypeSelectionFrame);
        waitForElementToBeVisible(driver, agreementRecordTypeSelectionDropdown);
        selectByIndex(driver, agreementRecordTypeSelectionDropdown, getOptionIndex(driver, agreementRecordTypeSelectionDropdown, recordType));
        elementClick(driver, reusableBusinessLibrary.recordTypeSelectionContinueButton);
        switchToDefaultContent(driver);
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        waitForUrlToContain(driver, "Apttus__APTS_Agreement__c");
        Assert.assertTrue(driver.getCurrentUrl().contains("Apttus__APTS_Agreement__c"), "Failed to select Agreement Record Type as: " + recordType);
        loggerManager.getLogger().info("Selected Agreement Record Type as: " + recordType);
    }

    /**
     * This method verifies the Agreement Info Message displayed on the Agreement for populating the fields
     */
    @Step("Verify Agreement Info Message displayed on the Agreement for populating the fields")
    public void verifyAgreementInfoMessage() {
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, infoMessage);
        Assert.assertTrue(isElementDisplayed(driver, infoMessage), "Info message is not displayed on the Agreement for populating the fields");
        loggerManager.getLogger().info("Info message is displayed on the Agreement for populating the fields");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method populates the fields on the Agreement before generating it
     * @param agreementData - Agreement data to be populated
     */
    @Step("Populate fields on the Agreement before generating it")
    public void fillAgreementDetails(LinkedHashMap<String, String> agreementData) {
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistListElement("MA Contracting Entity"));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("MA Contracting Entity")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistOptionElement(agreementData.get("MAContractingEntity")));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement(agreementData.get("MAContractingEntity"))));
        loggerManager.getLogger().info("Selected MA Contracting Entity as: " + agreementData.get("MAContractingEntity"));

       selectAgreementTypeOnAgreement(agreementData);

        scrollToElement(driver, relatedQuoteProposalLabel);
        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldElement("MA Legal Representative"));
        sendKeysToElement(driver, driver.findElement(reusableBusinessLibrary.textfieldElement("MA Legal Representative")), agreementData.get("MALegalRepresentative"));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldResult(agreementData.get("MALegalRepresentative")));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.textfieldResult(agreementData.get("MALegalRepresentative"))));
        loggerManager.getLogger().info("Entered MA Legal Representative as: " + agreementData.get("MALegalRepresentative"));

        scrollToElement(driver, clientPartySignedDateLabel);
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistListElement("Contains Auto-Renewal Clause"));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("Contains Auto-Renewal Clause")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistOptionElement(agreementData.get("ContainsAutoRenewalClause")));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement(agreementData.get("ContainsAutoRenewalClause"))));
        loggerManager.getLogger().info("Selected Contains Auto-Renewal Clause as: " + agreementData.get("ContainsAutoRenewalClause"));

        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldElement("Renewal Notice Days"));
        sendKeysToElement(driver, driver.findElement(reusableBusinessLibrary.textfieldElement("Renewal Notice Days")), agreementData.get("RenewalNoticeDays"));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldResult(agreementData.get("RenewalNoticeDays")));
        loggerManager.getLogger().info("Entered Renewal Notice Days as: " + agreementData.get("RenewalNoticeDays"));

        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistListElement("Billing Cycle"));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("Billing Cycle")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistOptionElement(agreementData.get("BillingCycle")));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement(agreementData.get("BillingCycle"))));
        loggerManager.getLogger().info("Selected Billing Cycle as: " + agreementData.get("BillingCycle"));

        scrollToElement(driver, executedCopyMailedOutDateLabelOnEditPage);
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistListElement("Payment Terms"));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("Payment Terms")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistOptionElement(agreementData.get("PaymentTerms")));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement(agreementData.get("PaymentTerms"))));
        loggerManager.getLogger().info("Selected Payment Terms as: " + agreementData.get("PaymentTerms"));

        if (agreementData.get("TerminationRight").contains(",")) {
            String[] terminationRights = agreementData.get("TerminationRight").split(",");
            for (String terminationRight : terminationRights) {
                waitForElementToBePresent(driver, reusableBusinessLibrary.multiSelectPicklistOption(terminationRight));
                elementClick(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistOption(terminationRight)));
                elementClick(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistMoveToChosenButton("Termination Right")));
            }
        }
        else {
            waitForElementToBePresent(driver, reusableBusinessLibrary.multiSelectPicklistOption(agreementData.get("TerminationRight")));
            elementClick(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistOption(agreementData.get("TerminationRight"))));
            elementClick(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistMoveToChosenButton("Termination Right")));
        }
        loggerManager.getLogger().info("Selected Termination Right as: " + agreementData.get("TerminationRight"));
        takeScreenshot(TCName, driver);

        scrollToElement(driver, terminationRightLabelOnEditPage);
        if (agreementData.get("IncludedOptions").contains(",")) {
            String[] includedOptions = agreementData.get("IncludedOptions").split(",");
            for (String includedOption : includedOptions) {
                waitForElementToBePresent(driver, reusableBusinessLibrary.multiSelectPicklistOption(includedOption));
                elementClick(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistOption(includedOption)));
                elementClick(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistMoveToChosenButton("Included Options")));
            }
        }
        else {
            waitForElementToBePresent(driver, reusableBusinessLibrary.multiSelectPicklistOption(agreementData.get("IncludedOptions")));
            elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistOption(agreementData.get("IncludedOptions"))));
            elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.multiSelectPicklistMoveToChosenButton("Included Options")));
        }
        loggerManager.getLogger().info("Selected Included Options as: " + agreementData.get("IncludedOptions"));

        selectFeeRestrictionOnAgreement(agreementData);

        loggerManager.getLogger().info("Agreement details are populated successfully");
    }

    /**
     * This method selects the Agreement Type on the Agreement form
     * @param agreementData - The data containing the Agreement Type to be selected
     */
    @Step("Select Agreement Type on Agreement")
    public void selectAgreementTypeOnAgreement(LinkedHashMap<String, String> agreementData)
    {
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistListElement("Agreement Type"));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("Agreement Type")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistOptionElement(agreementData.get("AgreementType")));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement(agreementData.get("AgreementType"))));
        loggerManager.getLogger().info("Selected Agreement Type as: " + agreementData.get("AgreementType"));
        takeScreenshot(TCName, driver);

    }
    /**
     * This method selects the Fee Restriction on the Agreement form
     * @param agreementData - The data containing the Agreement Type to be selected
     */
    @Step("Select Fee Restriction on Agreement")
    public void selectFeeRestrictionOnAgreement(LinkedHashMap<String, String> agreementData)
    {
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistListElement("Fee Increase Restriction"));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("Fee Increase Restriction")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.picklistOptionElement(agreementData.get("FeeIncreaseRestriction")));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement(agreementData.get("FeeIncreaseRestriction"))));
        loggerManager.getLogger().info("Selected Fee Increase Restriction as: " + agreementData.get("FeeIncreaseRestriction"));
        takeScreenshot(TCName, driver);
    }
    /**
     * This method clicks on Legal Contracting Entity button
     */
    public void clickLegalContractingEntityBtn(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        waitForElementToBeClickable(driver, legalContractingEntityButton);
        elementClick(driver, legalContractingEntityButton);
        waitForElementToBeVisible(driver, legalContractingEntityHeader);
        Assert.assertTrue(isElementDisplayed(driver, legalContractingEntityHeader), "Failed to click on Legal Contracting Entity button");
        loggerManager.getLogger().info("Clicked on Legal Contracting Entity button");
    }

    /**
     * This method creates a new Legal Contracting Entity
     * @param agreementData - Agreement data to be populated
     * @param accountName - The name to be given to the Legal Contracting Entity
     */
    public void createNewLegalContractingEntity(LinkedHashMap<String, String> agreementData, String accountName){
        waitForElementToBeVisible(driver, newLegalContractingEntityButton);
        elementClick(driver, newLegalContractingEntityButton);
        Assert.assertTrue(isElementDisplayed(driver, legalContractingEntityNameTextfield), "Failed to click on New Legal Contracting Entity button");
        loggerManager.getLogger().info("Clicked on New Legal Contracting Entity button");
        waitForElementToBeVisible(driver, legalContractingEntityNameTextfield);
        sendKeysToElement(driver, legalContractingEntityNameTextfield, accountName);
        waitForElementToBeVisible(driver, countryOfRegistrationDropdown);
        selectByValue(driver, countryOfRegistrationDropdown, agreementData.get("LCECountry"));
        waitForElementToBeVisible(driver, primaryStreet1TextFieldOnLCE);
        sendKeysToElement(driver, primaryStreet1TextFieldOnLCE, agreementData.get("LCEPrimaryStreet1"));
        waitForElementToBeVisible(driver, primaryCityTextFieldOnLCE);
        sendKeysToElement(driver, primaryCityTextFieldOnLCE, agreementData.get("LCEPrimaryCity"));
        waitForElementToBeVisible(driver, primaryStateTextFieldOnLCE);
        elementClickByJS(driver, primaryStateTextFieldOnLCE);
        waitForElementToBePresent(driver, stateOptionOnLCE(agreementData.get("LCEPrimaryState")));
        elementClickByJS(driver, driver.findElement(stateOptionOnLCE(agreementData.get("LCEPrimaryState"))));
        waitForElementToBeVisible(driver, primaryZipPostalCodeTextFieldOnLCE);
        sendKeysToElement(driver, primaryZipPostalCodeTextFieldOnLCE, agreementData.get("LCEPrimaryPostalCode"));
        loggerManager.getLogger().info("Entered Legal Contracting Entity details successfully");
        reusableBusinessLibrary.clickSaveBtnUsingActionClass(driver);
        takeScreenshot(TCName, driver);
        elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
        waitForElementToBeVisible(driver, reusableBusinessLibrary.showMoreActionsButton);
        Assert.assertTrue(isElementDisplayed(driver, reusableBusinessLibrary.showMoreActionsButton), "Failed to create New Legal Contracting Entity");
        loggerManager.getLogger().info("Created New Legal Contracting Entity successfully");
    }

    /**
     * This method selects the Legal Contracting Entity
     * @param entityName - The name of the Legal Contracting Entity to be selected
     */
    public void selectLegalContractingEntity(String entityName){
        waitForElementToBePresent(driver, entityNameLink(entityName));
        elementClick(driver, driver.findElement(entityNameLink(entityName)));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        waitForElementToBeVisible(driver, reusableBusinessLibrary.showMoreActionsButton);
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Total Partner Charges"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Total Partner Charges")));
        Assert.assertTrue(isElementDisplayed(driver, legalContractingEntityLinkOnAgreementPage), "Failed to select New Legal Contracting Entity");
        loggerManager.getLogger().info("Selected Legal Contracting Entity as: " + entityName);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method creates and activates the Agreement
     * @param agreementData - Agreement data to be populated
     * @param opportunityData - Opportunity data to be validated on the Agreement
     */
    @Step("Create and Activate Agreement")
    public void createAndActivateAgreement(LinkedHashMap<String, String> agreementData, LinkedHashMap<String, String> opportunityData){
        selectAgreementRecordType(agreementData.get("AgreementRecordType"));
        if (!TCName.contains("ChangeOppy"))
        {
            verifyAgreementInfoMessage();
        }

        agreementRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(agreementsFilePath, TCName, "SFDCRecordID", agreementRecordID);
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Agreement Name"));

        reusableBusinessLibrary.clickEditBtn();
        if (TCName.contains("ChangeOppy"))
        {
            selectAgreementTypeOnAgreement(agreementData);
            selectFeeRestrictionOnAgreement(agreementData);
        }
        else{
            fillAgreementDetails(agreementData);
        }

        reusableBusinessLibrary.clickSaveBtn();
        addLegalContractingEntityOnAgreement(agreementData, readExcelData(opportunitiesFilePath,TCDependency, "AccountName"));
        verifyAgreementStatus("Request");
        verifyAgreementStatusCategory("Request");
        verifyAgreementDetails(agreementData, opportunityData);
        generateAgreement();
        scrollToElement(driver, reusableBusinessLibrary.showAllQuickLink);
        agreementName = getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement Name")));
        scrollToTop(driver);
        submitAgreementForApproval();
        provideLegalApproval();
        provideFinanceApproval();
        if(agreementApprovalFlag) {
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
            homePage.loginAs("Operation Analyst");
        }
        openRecordBySFDCID(agreementRecordID);
        sendForSignatures();
        populateSignedDates();
        activateAgreement();
    }

    /**
     * This method adds Legal Contracting Entity on the Agreement
     * @param agreementData - Agreement data to be populated
     * @param accountName - The name of the Legal Contracting Entity to be added
     */
    public void addLegalContractingEntityOnAgreement(LinkedHashMap<String, String> agreementData, String accountName){
        clickLegalContractingEntityBtn();
        waitForElementToBePresent(driver, entityNameLink(accountName));
        if(isElementPresent(driver, entityNameLink(accountName))){
            selectLegalContractingEntity(accountName);
            loggerManager.getLogger().info("Selected already existing Legal Contracting Entity as: " + accountName);
        }
        else {
            createNewLegalContractingEntity(agreementData, accountName);
            clickLegalContractingEntityBtn();
            selectLegalContractingEntity(accountName);
            loggerManager.getLogger().info("Created and selected New Legal Contracting Entity as: " + accountName);
        }
    }

    /**
     * This method generates the Agreement
     */
    public void generateAgreement(){
        scrollToTop(driver);
        reusableBusinessLibrary.clickQuickAction("Generate");
        waitforFrametoLoad(driver, generateAgreementPageFrame);
        waitForElementToBeVisible(driver, generateAgreementBtn);
        takeScreenshot(TCName, driver);
        elementClickByJS(driver, generateAgreementBtn);
        waitForElementToBeVisible(driver, generateAgreementOKBtn);
        elementClickByJS(driver, generateAgreementOKBtn);
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Agreement | Salesforce"), "Failed to generate Agreement");
        loggerManager.getLogger().info("Agreement is generated successfully");
        switchToDefaultContent(driver);
        verifyAgreementStatus("Author Contract");
        verifyAgreementStatusCategory("In Authoring");
    }

    /**
     * This method submits the Agreement for Approval
     */
    @Step("Submit Agreement for Approval")
    public void submitAgreementForApproval(){
        waitForElementToBeVisible(driver, submitForApprovalBtn);
        elementClick(driver, submitForApprovalBtn);
        waitForElementToBeVisible(driver, submitBtn);
        elementClick(driver, submitBtn);
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Agreement | Salesforce"), "Failed to submit Agreement for Approval");
        loggerManager.getLogger().info("Agreement is submitted for Approval successfully");
    }

    /**
     * This method provides Legal Approval on the Agreement
     */
    @Step("Provide Legal Approval on the Agreement")
    public void provideLegalApproval(){
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Record Type"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Record Type")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status"));
        if(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status"))).equals("Legal Approval Requested")){
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
//          homePage.loginAs("Legal Representative");    We can uncomment this line if the functional team wants to use Legal Rep for legal approval
            openRecordBySFDCID(agreementRecordID);
            approveAgreement();
            waitForElementToBeVisible(driver, legalApprovedStatusOnApprovalHistory);
            Assert.assertTrue(isElementDisplayed(driver, legalApprovedStatusOnApprovalHistory), "Failed to provide Legal Approval on the Agreement");
            loggerManager.getLogger().info("Legal approval is completed successfully on the Agreement");
            takeScreenshot(TCName, driver);
            openRecordBySFDCID(agreementRecordID);
            agreementApprovalFlag = true;
        }
    }

    /**
     * This method provides Finance Approval on the Agreement
     */
    @Step("Provide Finance Approval on the Agreement")
    public void provideFinanceApproval(){
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Contracting Country"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Contracting Country")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status"));
        if(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status"))).equals("Finance Approval Requested")){
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
//          homePage.loginAs("Finance Admin");      We can uncomment this line if the functional team wants to use Finance Admin for finance approval
            openRecordBySFDCID(agreementRecordID);
            approveAgreement();
            openRecordBySFDCID(agreementRecordID);
            waitForElementToBeVisible(driver, financeApprovedStatusOnApprovalHistory);
            Assert.assertTrue(isElementDisplayed(driver, financeApprovedStatusOnApprovalHistory), "Failed to provide Finance Approval on the Agreement");
            loggerManager.getLogger().info("Finance approval is completed successfully on the Agreement");
            takeScreenshot(TCName, driver);
            agreementApprovalFlag = true;
        }
    }

    /**
     * This method approves the Agreement
     */
    @Step("Approve the Agreement")
    private void approveAgreement() {
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Total Partner Charges"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Total Partner Charges")));
        reusableBusinessLibrary.clickOnRelatedList("Approval History");
        waitForPageTitleToContain(driver, "Approval History");
        Assert.assertEquals(driver.getTitle(), "Approval History | Salesforce", "Failed to navigate to Approval History page");
        loggerManager.getLogger().info("Navigated to Approval History related List successfully");
        takeScreenshot(TCName, driver);
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, approveBtnOnApprovalHistory);
        elementClick(driver, approveBtnOnApprovalHistory);
        waitForElementToBeVisible(driver, approveBtnOnPopupWindow);
        takeScreenshot(TCName, driver);
        elementClick(driver, approveBtnOnPopupWindow);
        loggerManager.getLogger().info("Clicked on Approve button");
    }

    /**
     * This method sends the Agreement for Signatures
     */
    public void sendForSignatures(){
        switchToDefaultContent(driver);
        reusableBusinessLibrary.clickQuickAction("Send for Signatures");
        waitForPageTitleToContain(driver, "Lightning Experience | Salesforce");
        acceptAlert();
        waitForElementToBeVisible(driver, agreementFileOnSendForSignaturesPage);
        takeScreenshot(TCName, driver);
        elementClick(driver, agreementFileOnSendForSignaturesPage);
        waitForElementToBeVisible(driver, nextButtonOnSendForSignaturesPage);
        elementClick(driver, nextButtonOnSendForSignaturesPage);
        try {
            Thread.sleep(9000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForElementToBeVisible(driver, sendButtonOnSendForSignaturesPage);
        elementClickByJS(driver, sendButtonOnSendForSignaturesPage);
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Agreement | Salesforce"), "Failed to send Agreement for Signatures");
        loggerManager.getLogger().info("Agreement is sent for Signatures successfully");
        verifyAgreementStatus("Other Party Signatures");
        verifyAgreementStatusCategory("In Signatures");
    }

    /**
     * This method populates the Client Part Signed Date and MA Signed Date on the Agreement
     */
    @Step("Populate Client Party Signed Date and MA Signed Date on the Agreement")
    public void populateSignedDates(){
        reusableBusinessLibrary.clickEditBtn();
        waitForElementToBeVisible(driver, keyDatesSectionLabelOnEditPage);
        scrollToElement(driver, keyDatesSectionLabelOnEditPage);
        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldElement("Client Party Signed Date"));
        sendKeysToElement(driver, driver.findElement(reusableBusinessLibrary.textfieldElement("Client Party Signed Date")), getCurrentDateInMMddyyyyFormat());
        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldElement("MA Signed Date"));
        sendKeysToElement(driver, driver.findElement(reusableBusinessLibrary.textfieldElement("MA Signed Date")), getCurrentDateInMMddyyyyFormat());
        reusableBusinessLibrary.clickSaveBtn();
        try {
            Thread.sleep(3000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        if(driver.getTitle().contains("Edit"))
            reusableBusinessLibrary.clickSaveBtn();
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Agreement | Salesforce"), "Failed to populate Signed Dates on the Agreement");
        loggerManager.getLogger().info("Populated Signed Dates on the Agreement successfully");
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("edit")));
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        verifyAgreementStatus("Fully Signed");
        verifyAgreementStatusCategory("In Signatures");
    }

    /**
     * This method activates the Agreement
     */
    @Step("Activate the Agreement")
    public void activateAgreement(){
        scrollToTop(driver);
        reusableBusinessLibrary.clickQuickAction("Activate (Conga)");
        waitForPageTitleToContain(driver, "Lightning Experience | Salesforce");
        Assert.assertEquals(driver.getTitle(), "Lightning Experience | Salesforce", "Failed to navigate to Activate Agreement page");
        waitForElementToBeVisible(driver, publishToggleBtn);
        takeScreenshot(TCName, driver);
        elementClick(driver, publishToggleBtn);
        waitForElementToBeVisible(driver, activateBtn);
        elementClick(driver, activateBtn);
        waitForElementToBeVisible(driver, activateBtnOnPopupWindow);
        elementClick(driver, activateBtnOnPopupWindow);
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Agreement | Salesforce"), "Failed to Activate the Agreement");
        loggerManager.getLogger().info("Agreement is activated successfully");
        verifyAgreementStatus("Activated");
        verifyAgreementStatusCategory("In Effect");
    }

    /**
     * This method verifies the Agreement Status
     * @param expectedStatus - Expected Agreement Status
     */
    @Step("Verify Agreement Status as {expectedStatus}")
    public void verifyAgreementStatus(String expectedStatus){
        scrollToTop(driver);
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("MA Contracting Entity"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("MA Contracting Entity")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status"));
        Assert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status"))), expectedStatus, "Failed to verify Agreement Status");
        loggerManager.getLogger().info("Verified Agreement Status as: " + expectedStatus);
    }

    /**
     * This method verifies the Agreement Status Category
     * @param expectedStatusCategory - Expected Agreement Status Category
     */
    @Step("Verify Agreement Status Category as {expectedStatusCategory}")
    public void verifyAgreementStatusCategory(String expectedStatusCategory){
        scrollToTop(driver);
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("MA Contracting Entity"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("MA Contracting Entity")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status Category"));
        Assert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status Category"))), expectedStatusCategory, "Failed to verify Agreement Status Category");
        loggerManager.getLogger().info("Verified Agreement Status Category as: " + expectedStatusCategory);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the details on the Agreement record
     * @param agreementData - Agreement data to be validated
     * @param opportunityData - Opportunity data to be validated
     */
    @Step("Verify the value of fields on the Agreement Page")
    public void verifyAgreementDetails(LinkedHashMap<String, String> agreementData, LinkedHashMap<String, String> opportunityData) {
        waitForElementToBeVisible(driver, reusableBusinessLibrary.showAllQuickLink);
        scrollToElement(driver, reusableBusinessLibrary.showAllQuickLink);
        Allure.step("Verify that value of MA Contracting Entity is " + agreementData.get("MAContractingEntity"), step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("MA Contracting Entity"))), agreementData.get("MAContractingEntity"), "MA Contracting Entity is not displayed as expected.");
        });
        Allure.step("Verify that value of Record Type is " + agreementData.get("AgreementRecordType"), step -> {
            softAssert.assertEquals(getElementText(driver, reusableBusinessLibrary.recordTypeValue), agreementData.get("AgreementRecordType"), "Record Type is not displayed as expected.");
        });
        Allure.step("Verify that value of Agreement Type is " + agreementData.get("AgreementType"), step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement Type"))), agreementData.get("AgreementType"), "Agreement Type is not displayed as expected.");
        });
        Allure.step("Verify that Total Agreement Value is same as Quote Total: " + quoteAndAgreementTotal, step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Total Agreement Value"))), quoteAndAgreementTotal, "Total Agreement Value is not displayed as expected.");
        });
        Allure.step("Verify that value of Account is " + opportunityData.get("AccountName"), step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Account", opportunityData.get("AccountName")))), "Account is not displayed as expected.");
        });
        Allure.step("Verify that value of Opportunity is " + oppyName, step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Related Opportunity", oppyName))), "Opportunity is not displayed as expected.");
        });
        Allure.step("Verify that value of Related Quote/Proposal is " + proposalID, step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Related Quote/Proposal", proposalID))), "Related Quote/Proposal is not displayed as expected.");
        });
        Allure.step("Verify that value of Primary Contact is " + opportunityData.get("SoldToContactName"), step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Primary Contact", opportunityData.get("SoldToContactName")))), "Primary Contact is not displayed as expected.");
        });
        Allure.step("Verify that value of Contract Specialist is " + opportunityData.get("ContractSpecialistName"), step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Contract Specialist",opportunityData.get("ContractSpecialistName")))), "Contract Specialist is not displayed as expected.");
        });
        Allure.step("Verify that value of MA Legal Representative is " + opportunityData.get("MALegalRepresentative"), step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("MA Legal Representative",agreementData.get("MALegalRepresentative")))), "MA Legal Representative is not displayed as expected.");
        });
        Allure.step("Verify that value of Ship To Contact " + opportunityData.get("SoldToContactName"), step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Ship To Contact", opportunityData.get("SoldToContactName")))), "Ship To Contact is not displayed as expected.");
        });
        Allure.step("Verify that value of Bill To Contact " + opportunityData.get("SoldToContactName"), step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Bill To Contact", opportunityData.get("SoldToContactName")))), "Bill To Contact is not displayed as expected.");
        });
        takeScreenshot(TCName, driver);
        scrollToElement(driver, legalContractingEntitySectionLabel);
        Allure.step("Verify that value of Agreement Start Date is " +getCurrentDateInMMddyyyyFormat() , step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement Start Date"))), getCurrentDateInMMddyyyyFormat(), "Agreement Start Date is not displayed as expected.");
        });
        if(TCName.contains("Trial")){
            trialEndDate = currentDatePlusDays(15);
            Allure.step("Verify that value of Agreement End Date is " + trialEndDate, step -> {
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement End Date"))), trialEndDate, "Agreement End Date is not displayed as expected.");
            });
        }else {
            Allure.step("Verify that value of Agreement End Date is " + currentDatePlusDays(364), step -> {
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement End Date"))), currentDatePlusDays(364), "Agreement End Date is not displayed as expected.");
            });
        }
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Agreement Details are validated successfully");
    }

    /**
     * This method navigates to the Agreement Line Items related list
     */
    @Step("Navigate to Agreement Line Items related list")
    public void navigateToAgreementLineItemsRelatedList(){
        scrollToTop(driver);
        waitForElementToBePresent(driver, reusableBusinessLibrary.quickLink("Agreement Line Items"));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.quickLink("Agreement Line Items")));
        waitForPageTitleToContain(driver, "Agreement Line Items");
        Assert.assertTrue(driver.getTitle().contains("Agreement Line Items"), "Failed to navigate to Agreement Line Items related list");
        loggerManager.getLogger().info("Navigated to Agreement Line Items related list successfully");
    }

    /**
     * This method verifies that Agreement Line Items are displayed on the Agreement
     * @param quoteData - Product details to be validated from the Quote
     */
    @Step("Verify that Agreement Line Items are displayed on the Agreement")
    public void verifyAgreementLineItems(List<LinkedHashMap<String, String>> quoteData) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        List<String> actualStartDate = new ArrayList<>();
        setScreenZoom(driver,75);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Agreement Line Items"));
        List<WebElement> agreementLineItems = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Agreement Line Items"));
        for (WebElement agreementLineItem : agreementLineItems) {
            String dataLabel = agreementLineItem.getAttribute("data-label");
            if (dataLabel != null)
                if (dataLabel.equals("Term Start Date")) {
                    actualStartDate.add(getElementText(driver, agreementLineItem));
                }
        }

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Agreement Line Items","Agreement Line Description"));
        List<WebElement> agreementLineItemsProductNames = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Agreement Line Items","Agreement Line Description"));
        for (WebElement agreementLineItemsProductName : agreementLineItemsProductNames) {
            String productName = getElementText(driver, agreementLineItemsProductName);
            actualProductNames.add(productName);
        }

        // Get all product names including any option products from the quote data
        for (LinkedHashMap<String, String> data : quoteData) {
            expectedProductNames.add(data.get("ProductName"));
            if (data.get("ProductType").equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(",");
                expectedProductNames.addAll(Arrays.asList(optionProducts));
            }
        }
        Allure.step("Verify that Agreement Line Item is created for all products" + expectedProductNames, step -> {
            softAssert.assertEquals(actualProductNames, expectedProductNames, "Agreement Line Items are not created for all products");
        });

        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Agreement Line Items","Sales Price"));
        List<WebElement> agreementLineItemsPrice = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Agreement Line Items","Sales Price"));
        reusableBusinessLibrary.verifyLineItemsPrice(quoteData, agreementLineItemsProductNames, agreementLineItemsPrice);

        Allure.step("Verify that Term Start Date is " + expectedStartDate + " on Agreement Line Items ", step -> {
            softAssert.assertTrue(actualStartDate.stream().allMatch(val -> val.equals(expectedStartDate)), "Term Start Date is not displayed as expected. Actual: " + actualStartDate + " Expected: " + expectedStartDate);
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Agreement Line Items are displayed correctly on the Agreement");
        setScreenZoom(driver,100);
    }

    /**
     * This method navigates to the Order record from the Agreement
     */
    @Step("Navigate to Order record from Agreement")
    public void navigateToOrderFromAgreement(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Total Partner Charges"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Total Partner Charges")));
        scrollToElement(driver, maECounterSignatureFieldLabel);
        reusableBusinessLibrary.clickOnRelatedList("Orders");
        waitForPageTitleToContain(driver, "Orders | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Orders | Salesforce"), "Failed to navigate to Orders related list");
        loggerManager.getLogger().info("Navigated to Orders related list successfully");
        takeScreenshot(TCName, driver);
        waitForElementToBeVisible(driver, orderNumberLink);
        elementClickByJS(driver, orderNumberLink);
        waitForUrlToContain(driver, "Apttus_Config2__Order__c");
        Assert.assertTrue(driver.getCurrentUrl().contains("Apttus_Config2__Order__c"), "Failed to navigate to Order record");
        loggerManager.getLogger().info("Navigated to Order record successfully");
        orderRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
    }

    /**
     * This method gets the value of the agreement total
     * @return - The value of the Agreement Total
     */
    @Step("Get the value of Agreement Total")
    public String getAgreementTotal(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Contracting Country"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Contracting Country")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Total Agreement Value"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Total Agreement Value")));
    }

    /**
     * This method gets the value of the related Proposal ID on the Agreement record
     * @return - The value of the Proposal ID
     */
    @Step("Get the value of Proposal ID")
    public String getRelatedProposalID(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.linkFieldValue("Related Quote/Proposal"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.linkFieldValue("Related Quote/Proposal")));
    }

    /**
     * This method gets the value of the related Opportunity Name on the Agreement record
     * @return - The value of the Opportunity Name
     */
    @Step("Get the value of Opportunity Name")
    public String getOpportunityName(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.linkFieldValue("Related Opportunity"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.linkFieldValue("Related Opportunity")));
    }

    /**
     * This method gets the value of the Agreement Start Date on the Agreement record
     * @return - The value of the Agreement Start Date
     */
    @Step("Get the value of Agreement Start Date")
    public String getAgreementStartDate(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Legal Contracting Entity"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Total Partner Charges")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Legal Contracting Entity"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Legal Contracting Entity")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Agreement Start Date"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement Start Date")));
    }

    /**
     * This method gets the value of the Agreement End Date on the Agreement record
     * @return - The value of the Agreement End Date
     */
    @Step("Get the value of Agreement End Date")
    public String getAgreementEndDate(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Total Partner Charges"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Total Partner Charges")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Legal Contracting Entity"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Legal Contracting Entity")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Agreement End Date"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement End Date")));
    }

    /**
     * This method gets the value of the Agreement Name on the Agreement record
     * @return - The value of the Agreement Name
     */
    @Step("Get the value of Agreement Name")
    public String getAgreementName(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Agreement Name"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Agreement Name")));
    }

    /**
     * This method gets the Agreement details
     */
    public void getAgreementDetails(){
        quoteAndAgreementTotal = getAgreementTotal();
        proposalID = getRelatedProposalID();
        oppyName = getOpportunityName();
        expectedStartDate = getAgreementStartDate();
        expectedEndDate = getAgreementEndDate();
        agreementName = getAgreementName();
    }

}