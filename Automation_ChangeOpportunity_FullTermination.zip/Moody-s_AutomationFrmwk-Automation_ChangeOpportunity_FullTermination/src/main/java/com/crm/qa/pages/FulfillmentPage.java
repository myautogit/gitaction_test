package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;
import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.getSFDCRecordIDFromURL;
import static com.crm.qa.util.ReusableLibrary.*;

import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class contains methods related to the Fulfillment functionality.
 * Author: Arshin Shaikh
 * Last Modified By: Arshin Shaikh
 * Date: 12/02/2024
 * Comment: Created new class and added method for verifying Fulfillment details, Asset Line Items and Account Entitlements
 */
public class FulfillmentPage extends TestBase {

    public FulfillmentPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();

    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);

    // Page Factory - OR:
    @FindBy(xpath = "//a[contains(@href,'ChangeOpp')]")
    WebElement createChangeOpportunityBtn;

    //Actions:

    /**
     * This method verifies the value of fields on the Fulfillment Page
     *
     * @param agreementData - Agreement data to be validated on the Fulfillment
     * @param opportunityData - Opportunity data to be validated on the Fulfillment
     */
    @Step("Verify the value of fields on the Fulfillment Page")
    public void verifyFulfillmentDetails(LinkedHashMap<String, String> agreementData, LinkedHashMap<String, String> opportunityData) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, reusableBusinessLibrary.showAllQuickLink);
        scrollToElement(driver, reusableBusinessLibrary.showAllQuickLink);
        Allure.step("Verify that value of Business Unit is " + agreementData.get("MAContractingEntity"), step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Business Unit"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Business Unit"))), agreementData.get("MAContractingEntity"), "Business Unit is not displayed as expected.");
        });
        Allure.step("Verify that value of Fulfillment Owner is " + readExcelDataWithSheet(userCredentialsFilePath, prop.getProperty("LoginAs"), "Operation Analyst", "User"), step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Fulfillment Owner", readExcelDataWithSheet(userCredentialsFilePath, prop.getProperty("LoginAs"), "Operation Analyst", "User")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Fulfillment Owner", readExcelDataWithSheet(userCredentialsFilePath, prop.getProperty("LoginAs"), "Operation Analyst", "User")))), "Fulfillment Owner is not displayed as expected.");
        });
        Allure.step("Verify that value of Fulfillment Record Type is Sales Contract", step -> {
            waitForElementToBeVisible(driver, reusableBusinessLibrary.recordTypeValue);
            softAssert.assertEquals(getElementText(driver, reusableBusinessLibrary.recordTypeValue), "Sales Contract", "Fulfillment Record Type is not displayed as expected.");
        });
        Allure.step("Verify that value of Status is Client Signed", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status"))), "Client Signed", "Status is not displayed as expected.");
        });

        verifyFulfillmentTotal();

        Allure.step("Verify that value of Account Name is " + opportunityData.get("AccountName"), step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Account Name", opportunityData.get("AccountName")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Account Name", opportunityData.get("AccountName")))), "Account Name is not displayed as expected.");
        });
        Allure.step("Verify that value of Opportunity is " + oppyName, step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkFieldValue("Opportunity"));
            //ensure that the opportunityname as saved on the agreement contains the opportunity name displayed on the fulfillment page
            softAssert.assertTrue(oppyName.contains(getElementText(driver, driver.findElement(reusableBusinessLibrary.linkFieldValue("Opportunity")))), "New Opportunity is not displayed as expected.");
        });
        Allure.step("Verify that value of Latest Order is " + readExcelData(agreementsFilePath, TCName, "OrderNo"), step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Latest Order", readExcelData(agreementsFilePath, TCName, "OrderNo")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Latest Order", readExcelData(agreementsFilePath, agreementTCDependency, "OrderNo")))), "Latest Order is not displayed as expected.");
        });
        takeScreenshot(TCName, driver);
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status")));
        Allure.step("Verify that value of Fulfillment Start is " + expectedStartDate, step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Fulfillment Start"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Fulfillment Start"))), expectedStartDate, "Fulfillment Start is not displayed as expected.");
        });
        Allure.step("Verify that value of Fulfillment End is " + expectedEndDate, step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Fulfillment End"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Fulfillment End"))), expectedEndDate, "Fulfillment End is not displayed as expected.");
        });
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Create Change Opportunity"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Create Change Opportunity")));
        Allure.step("Verify that value of Customer Signed Date is " + expectedStartDate, step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Customer Signed Date"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Customer Signed Date"))), expectedStartDate, "Customer Signed Date is not displayed as expected.");
        });
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Fulfillment Details are validated successfully");
        fulfillmentRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
    }


    /**
     * Stores the current fulfillment total in the fulfillment excel sheet
     */
    @Step("Store Fulfillment Information in Excel")
    public void storeFulfillmentTotalInExcel() {
        reusableBusinessLibrary.verifyBtnIsDisplayed("Edit");
        waitForElementToBeVisible(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Fulfillment Total")));
        String fulfillmentTotal = extractNumber(driver.findElement(reusableBusinessLibrary.textFieldValue("Fulfillment Total")).getText());
        writeToExcel(fulfillmentsFilePath, TCName, "PreviousFulfillmentTotal", fulfillmentTotal);
    }

    /**
     * This method verifies the Fulfillment Total on the Fulfillment page.
     * It checks if the Fulfillment Total matches the expected value based on the type of Quote (New or Change).
     * For a new Quote, it verifies that the Fulfillment Total is the same as the Quote Total.
     * For a change Quote, it verifies that the Fulfillment Total is the sum of the current Quote Total and the previous Fulfillment Total.
     */
    @Step("Verify Fulfillment Total on fulfillment page")
    public void verifyFulfillmentTotal() {

        switch (readExcelData(opportunitiesFilePath, TCDependency, "ABOType")) {
            case "New":
                Allure.step("Verify that Fulfillment Total is same as Quote Total: " + quoteAndAgreementTotal, step -> {
                    waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Fulfillment Total"));
                    softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Fulfillment Total"))), quoteAndAgreementTotal, "Fulfillment Total is not displayed as expected.");
                });
                break;
            case "Change":
                Allure.step("Verify that Fulfillment Total is current Quote Total + previous quote total ", step -> {
                    waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Fulfillment Total"));
                    String actualFulfillmentTotal = extractNumber(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Fulfillment Total"))));
                    String expectedFulfillmentTotal = Double.toString(Double.parseDouble(readExcelData(fulfillmentsFilePath, TCDependency, "PreviousFulfillmentTotal")) + Double.parseDouble(extractNumber(quoteAndAgreementTotal)));
                    softAssert.assertEquals(actualFulfillmentTotal, expectedFulfillmentTotal, "Fulfillment Total is not displayed as expected.");
                });
                break;
        }
    }
    /**
     * This method navigates to the Asset Line Items related list on the Fulfillment record
     */
    @Step("Navigate to Asset Line Items related list")
    public void navigateToAssetLineItemsRelatedList() {
        scrollToTop(driver);
        reusableBusinessLibrary.openSFDCSubTab("Assets/Entitlements");
        reusableBusinessLibrary.clickOnRelatedList("Asset Line Items");
        waitForPageTitleToContain(driver, "Asset Line Items | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Asset Line Items | Salesforce"), "Failed to navigate to Asset Line Items related list");
        loggerManager.getLogger().info("Navigated to Asset Line Items related list successfully");
    }

    /**
     * This method verifies the Asset Line Items on the Fulfillment record
     *
     * @param quoteData - Product details from the quote to be validated on the Asset Line Items
     */
    @Step("Verify that Asset Line Items are displayed on the Fulfillment")
    public void verifyAssetLineItems(List<LinkedHashMap<String, String>> quoteData) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        List<String> actualStartDate = new ArrayList<>();
        List<String> actualEndDate = new ArrayList<>();
        setScreenZoom(driver, 75);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Asset Line Items"));
        List<WebElement> assetLineItems = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Asset Line Items"));
        for (WebElement assetLineItem : assetLineItems) {
            waitForElementToBeVisible(driver, assetLineItem);
            String dataLabel = assetLineItem.getAttribute("data-label");
            if (dataLabel != null)
                switch (dataLabel) {
                    case "Description":
                        actualProductNames.add(getElementText(driver, assetLineItem));
                        break;
                    case "Term Start Date":
                        actualStartDate.add(getElementText(driver, assetLineItem));
                        break;
                    case "End Date":
                        actualEndDate.add(getElementText(driver, assetLineItem));
                        break;
                    default:
                        break;
                }
        }

        // Get all product names including any option products from the quote data
        for (LinkedHashMap<String, String> data : quoteData) {
            expectedProductNames.add(data.get("ProductName"));
            if (data.get("ProductType").equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(",");
                expectedProductNames.addAll(Arrays.asList(optionProducts));
            }
        }
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Description"));
        Allure.step("Verify that Asset Line Item is created for all products" + expectedProductNames, step -> {
            softAssert.assertTrue(new HashSet<>(actualProductNames).containsAll(expectedProductNames) && new HashSet<>(expectedProductNames).containsAll(actualProductNames), "Asset Line Item is not created for all products");
        });
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Description"));
        List<WebElement> assetLineItemsProductNames = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Description"));
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Sales Price"));
        List<WebElement> assetLineItemsPrice = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Sales Price"));
        reusableBusinessLibrary.verifyLineItemsPrice(quoteData, assetLineItemsProductNames, assetLineItemsPrice);

        Allure.step("Verify that Term Start Date is " + expectedStartDate + " on Asset Line Items ", step -> {
            softAssert.assertTrue(actualStartDate.stream().allMatch(val -> val.equals(expectedStartDate)), "Term Start Date is not displayed as expected");
        });
        Allure.step("Verify that End Date is " + expectedEndDate + " on Asset Line Items ", step -> {
            softAssert.assertTrue(actualEndDate.stream().allMatch(val -> val.equals(expectedEndDate)), "End Date is not displayed as expected");
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Asset Line Items are displayed correctly on the Fulfillment");
        setScreenZoom(driver, 100);
    }

    /**
     * This method navigates to the Account Entitlement related list on the Fulfillment record
     */
    @Step("Navigate to Account Entitlement related list")
    public void navigateToAccountEntitlementRelatedList() {
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, reusableBusinessLibrary.showAllQuickLink);
        reusableBusinessLibrary.openSFDCSubTab("Assets/Entitlements");
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedList("Asset Line Items"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.relatedList("Asset Line Items")));
        reusableBusinessLibrary.clickOnRelatedList("Account Entitlement");
        waitForPageTitleToContain(driver, "Account Entitlement | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Account Entitlement | Salesforce"), "Failed to navigate to Asset Line Items related list");
        loggerManager.getLogger().info("Navigated to Account Entitlement related list successfully");
    }

    /**
     * This method verifies the Account Entitlements on the Fulfillment record
     *
     * @param quoteData - Product details from the quote to be validated on the Account Entitlements
     */
    @Step("Verify that Account Entitlements are displayed on the Fulfillment")
    public void verifyAccountEntitlements(List<LinkedHashMap<String, String>> quoteData) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        List<String> actualStartDate = new ArrayList<>();
        List<String> actualEndDate = new ArrayList<>();
        List<String> actualStatus = new ArrayList<>();
        setScreenZoom(driver, 75);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Account Entitlement"));
        List<WebElement> accountEntitlements = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Account Entitlement"));
        for (WebElement accountEntitlement : accountEntitlements) {
            waitForElementToBeVisible(driver, accountEntitlement);
            String dataLabel = accountEntitlement.getAttribute("data-label");
            if (dataLabel != null)
                switch (dataLabel) {
                    case "Description":
                        actualProductNames.add(getElementText(driver, accountEntitlement));
                        break;
                    case "Status":
                        actualStatus.add(getElementText(driver, accountEntitlement));
                        break;
                    case "Permission Start Date":
                        actualStartDate.add(getElementText(driver, accountEntitlement));
                        break;
                    case "Permission Date":
                        actualEndDate.add(getElementText(driver, accountEntitlement));
                        break;
                    default:
                        break;
                }
        }

        // Get all product names including any option products from the quote data
        for (LinkedHashMap<String, String> data : quoteData) {
            expectedProductNames.add(data.get("ProductName"));
            if (data.get("ProductType").equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(",");
                expectedProductNames.addAll(Arrays.asList(optionProducts));
            }
        }
        Allure.step("Verify that Account Entitlement is created for all products" + expectedProductNames, step -> {
            softAssert.assertTrue(new HashSet<>(actualProductNames).containsAll(expectedProductNames) && new HashSet<>(expectedProductNames).containsAll(actualProductNames), "Account Entitlement is not created for all products");
        });
        Allure.step("Verify that Status is Active on Account Entitlement", step -> {
            softAssert.assertTrue(actualStatus.stream().allMatch(val -> val.equals("Active")), "Status is not displayed as expected");
        });
        Allure.step("Verify that Permission Start Date is " + expectedStartDate + " on Account Entitlement", step -> {
            softAssert.assertTrue(actualStartDate.stream().allMatch(val -> val.equals(expectedStartDate)), "Permission Start Date is not displayed as expected");
        });
        Allure.step("Verify that Permission End Date is " + expectedEndDate + " on Account Entitlement", step -> {
            softAssert.assertTrue(actualEndDate.stream().allMatch(val -> val.equals(expectedEndDate)), "Permission End Date is not displayed as expected");
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Account Entitlements are displayed correctly on the Fulfillment");
        setScreenZoom(driver, 100);
    }

    /**
     * This method verifies the Account Entitlements on the Fulfillment record for a change opportunity
     *
     * @param quoteDataFromChange - Product details from the change quote to be validated on the Account Entitlements
     * @param originalQuoteData - Product details from the original quote to be validated on the Account Entitlements
     */
    @Step("Verify that Account Entitlements are displayed on the Fulfillment")
    public void verifyAccountEntitlements_ChangeOppy(List<LinkedHashMap<String, String>> quoteDataFromChange,List<LinkedHashMap<String, String>> originalQuoteData) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        List<String> actualStartDate = new ArrayList<>();
        List<String> actualEndDate = new ArrayList<>();
        List<String> actualStatus = new ArrayList<>();
        setScreenZoom(driver, 75);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Account Entitlement"));
        List<WebElement> accountEntitlements = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Account Entitlement"));
        for (WebElement accountEntitlement : accountEntitlements) {
            waitForElementToBeVisible(driver, accountEntitlement);
            String dataLabel = accountEntitlement.getAttribute("data-label");
            if (dataLabel != null)
                switch (dataLabel) {
                    case "Description":
                        actualProductNames.add(getElementText(driver, accountEntitlement));
                        break;
                    case "Status":
                        actualStatus.add(getElementText(driver, accountEntitlement));
                        break;
                    case "Permission Start Date":
                        actualStartDate.add(getElementText(driver, accountEntitlement));
                        break;
                    case "Permission Date":
                        actualEndDate.add(getElementText(driver, accountEntitlement));
                        break;
                    default:
                        break;
                }
        }
        // Get all product names including any option products from both quote data lists
        //the expected product names include the quoteDataAfterTheChange and the original quote data
        List<List<LinkedHashMap<String, String>>> allQuoteData = Arrays.asList(quoteDataFromChange, originalQuoteData);

        for (List<LinkedHashMap<String, String>> quoteDataList : allQuoteData) {
            for (LinkedHashMap<String, String> data : quoteDataList) {
                expectedProductNames.add(data.get("ProductName"));
                if (data.get("ProductType").equals("Bundle")) {
                    String[] optionProducts = data.get("OptionProducts").split(",");
                    expectedProductNames.addAll(Arrays.asList(optionProducts));
                }
            }
        }

        Allure.step("Verify that Account Entitlement is created for all products" + expectedProductNames, step -> {
            softAssert.assertTrue(new HashSet<>(actualProductNames).containsAll(expectedProductNames) && new HashSet<>(expectedProductNames).containsAll(actualProductNames), "Account Entitlement is not created for all products");
        });
        Allure.step("Verify that Status is Active on Account Entitlement", step -> {
            softAssert.assertTrue(actualStatus.stream().allMatch(val -> val.equals("Active")), "Status is not displayed as expected");
        });
        Allure.step("Verify that Permission Start Date is " + expectedStartDate + " on Account Entitlement", step -> {
            softAssert.assertTrue(actualStartDate.stream().allMatch(val -> val.equals(expectedStartDate)), "Permission Start Date is not displayed as expected");
        });
        Allure.step("Verify that Permission End Date is " + expectedEndDate + " on Account Entitlement", step -> {
            softAssert.assertTrue(actualEndDate.stream().allMatch(val -> val.equals(expectedEndDate)), "Permission End Date is not displayed as expected");
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Account Entitlements are displayed correctly on the Fulfillment");
        setScreenZoom(driver, 100);
    }
    /**
     * This method verifies the Asset Line Items on the Fulfillment record for a change opportunity
     *
     *  @param quoteDataFromChange - Product details from the change quote to be validated on the Account Entitlements
     *  @param originalQuoteData - Product details from the original quote to be validated on the Account Entitlements
     */
    @Step("Verify that Asset Line Items are displayed on the Fulfillment")
    public void verifyAssetLineItems_ChangeOppy(List<LinkedHashMap<String, String>> quoteDataFromChange, List<LinkedHashMap<String, String>> originalQuoteData) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        List<String> actualStartDate = new ArrayList<>();
        List<String> actualEndDate = new ArrayList<>();
        setScreenZoom(driver, 75);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Asset Line Items"));
        List<WebElement> assetLineItems = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Asset Line Items"));
        for (WebElement assetLineItem : assetLineItems) {
            waitForElementToBeVisible(driver, assetLineItem);
            String dataLabel = assetLineItem.getAttribute("data-label");
            if (dataLabel != null)
                switch (dataLabel) {
                    case "Description":
                        actualProductNames.add(getElementText(driver, assetLineItem));
                        break;
                    case "Term Start Date":
                        actualStartDate.add(getElementText(driver, assetLineItem));
                        break;
                    case "End Date":
                        actualEndDate.add(getElementText(driver, assetLineItem));
                        break;
                    default:
                        break;
                }
        }

        // Get all product names including any option products from both quote data lists
        List<List<LinkedHashMap<String, String>>> allQuoteData = Arrays.asList(quoteDataFromChange, originalQuoteData);

        for (List<LinkedHashMap<String, String>> quoteDataList : allQuoteData) {
            for (LinkedHashMap<String, String> data : quoteDataList) {
                expectedProductNames.add(data.get("ProductName"));
                if (data.get("ProductType").equals("Bundle")) {
                    String[] optionProducts = data.get("OptionProducts").split(",");
                    expectedProductNames.addAll(Arrays.asList(optionProducts));
                }
            }
        }
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Description"));
        Allure.step("Verify that Asset Line Item is created for all products" + expectedProductNames, step -> {
            softAssert.assertTrue(new HashSet<>(actualProductNames).containsAll(expectedProductNames) && new HashSet<>(expectedProductNames).containsAll(actualProductNames), "Asset Line Item is not created for all products");
        });
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Description"));
        List<WebElement> assetLineItemsProductNames = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Description"));
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Sales Price"));
        List<WebElement> assetLineItemsPrice = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Asset Line Items", "Sales Price"));
        reusableBusinessLibrary.verifyLineItemsPrice(quoteDataFromChange, assetLineItemsProductNames, assetLineItemsPrice);

        Allure.step("Verify that Term Start Date is " + expectedStartDate + " on Asset Line Items ", step -> {
            softAssert.assertTrue(actualStartDate.stream().allMatch(val -> val.equals(expectedStartDate)), "Term Start Date is not displayed as expected");
        });
        Allure.step("Verify that End Date is " + expectedEndDate + " on Asset Line Items ", step -> {
            softAssert.assertTrue(actualEndDate.stream().allMatch(val -> val.equals(expectedEndDate)), "End Date is not displayed as expected");
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Asset Line Items are displayed correctly on the Fulfillment");
        setScreenZoom(driver, 100);
    }

    /**
     * This method Clicks on Change Opportunity from the fulfillment page
     */
    @Step("Navigate to ChangeOppy from the fulfillment page")
    public void clickCreateChangeOppy() {
        scrollToElement(driver, createChangeOpportunityBtn);
        elementClick(driver, createChangeOpportunityBtn);
        waitForPageTitleToContain(driver, "Change");
        takeScreenshot(TCName, driver);
        Assert.assertTrue(driver.getTitle().contains("Change: "), "Failed to navigate to Create Change Opportunity page");
        loggerManager.getLogger().info("Navigated to Change Opportunity Successfully from fulfillment page");
        changeOppyID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
    }
}
