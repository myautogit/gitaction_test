package com.crm.qa.base;

import com.crm.qa.util.LoggerManager;
import com.crm.qa.util.ReusableLibrary;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static com.crm.qa.util.AbstractDataLibrary.downloadPath;

// This is the base class for all the test classes.
// It contains common functionalities needed across all the test classes.
// Author: Sayon Das
// Last Modified By: Arshin Shaikh
// Date: 09/13/2024
// Comment: Removed implicit wait from initialization method
public class TestBase {
    
    public static WebDriver driver;
    
    public static  String env;
    
    public static  String browserName;

    public ReusableLibrary reusableLibrary;

    public Properties prop = reusableLibrary.initializeProperties();
    
    public static ThreadLocal<WebDriver> tdriver = new ThreadLocal<WebDriver>();
    protected static LoggerManager loggerManager;

    // This method reads the environment from the system property or from the config.properties file.
    public String getEnv() {
        if(env == null) {
            env = System.getProperty("Test_Env");
            if (env == null) {
                env = prop.getProperty("Test_Env");
            }
        }
        loggerManager.getLogger().info("Environment is " + env);
        return env;
    }
    
    public String getBrowser() {
        if(browserName == null) {
            browserName = System.getProperty("Browser");
            if (browserName == null) {
                browserName = prop.getProperty("Browser");
            }
        }
        loggerManager.getLogger().info("Browser name is " + browserName);
        return browserName;
    }

    // This method initializes the WebDriver based on the browser name provided in the config.properties file.
    public WebDriver initialization(){
        env=getEnv();
        browserName = getBrowser();
        if(browserName.equals("Edge")){
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
            }
            else if(browserName.equals("Chrome")){
                ChromeOptions options = new ChromeOptions();
                HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
                chromePrefs.put("download.default_directory", downloadPath);
                options.setExperimentalOption("prefs", chromePrefs);
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver(options);
            }
            else{
                loggerManager.getLogger().error("No browser set up configured in config.properties file. Please check the browser name.");
            }

            driver.manage().window().maximize();
            driver.manage().deleteAllCookies();
            driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration")), TimeUnit.SECONDS);
            tdriver.set(driver);
            loggerManager.getLogger().info(browserName + "driver initialized successfully");
            return getDriver();
    }
    
    // This method returns the synchronized WebDriver instance.
    public static synchronized WebDriver getDriver() {
        return tdriver.get();
    }
    
    @BeforeClass(alwaysRun = true)
    public void createLogger() {
        try{
            loggerManager = new LoggerManager(this.getClass().getSimpleName());
            loggerManager.getLogger().info("Logger object created successfully");
        }catch(Exception e){
            if(loggerManager!= null) {
                loggerManager.getLogger().error("Failed to create logger instance");
            } else {
                e.printStackTrace();
            }
            if (driver != null) {
                driver.quit();
            }
        }
    }


    // This method returns the URL of the current page.
    public String getUrl() {
        return driver.getCurrentUrl();
    }
    // This method waits for the page to load completely.
    public void waitForPageToLoad(Duration DEFAULT_WAIT_TIME) {
        try {
            new FluentWait<WebDriver>(driver)
                    .withTimeout(DEFAULT_WAIT_TIME)
                    .pollingEvery(Duration.ofSeconds(30))
                    .until(new ExpectedCondition<Boolean>() {
                        @Override
                        public Boolean apply(WebDriver driver) {
                            try {
                                JavascriptExecutor js = (JavascriptExecutor) driver;
                                if (js.executeScript("return document.readyState").equals("complete")) {
                                    if ((boolean) js.executeScript("return window.jQuery==undefined")) {
                                        return true;
                                    } else if ((boolean) js.executeScript("return jQuery.active==0")) {
                                        return true;
                                    } else {
                                        return false;
                                    }
                                }
                            } catch (Exception ex) {
                                return false;
                            }
                            return false;
                        }
                    });

        } catch (Exception e) {
            loggerManager.getLogger().error("Exception occured in waitForPageLoad: " + e.getMessage());
        }
    }

    
    @BeforeSuite
    public void cleanUp(){
        try {
            // Kill Chrome driver
            Runtime.getRuntime().exec("taskkill /F /IM chromedriver.exe /T");
            // Kill Edge driver
            Runtime.getRuntime().exec("taskkill /F /IM msedgedriver.exe /T");
            // Kill Excel
            Runtime.getRuntime().exec("taskkill /F /IM EXCEL.EXE /T");
        } catch (IOException e) {
            loggerManager.getLogger().error(e.getMessage());
            throw new RuntimeException(e);
        }
    }
}
