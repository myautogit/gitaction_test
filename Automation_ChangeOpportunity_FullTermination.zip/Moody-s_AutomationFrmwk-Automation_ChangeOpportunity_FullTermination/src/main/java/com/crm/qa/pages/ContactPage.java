package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import io.qameta.allure.Allure;
import org.openqa.selenium.JavascriptExecutor;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.*;
import java.util.LinkedHashMap;


/**
 * This class contains methods related to the Lead functionality.
 * Author: Bhagyashree Wani
 * Last Modified By: Rishi Saini
 * Date: 10/10/2024
 * Comment: Added methods for Create contact from Account.
 */
public class ContactPage extends TestBase {

    //Initializing the Page Objects:
    public ContactPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();
    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);

    //Page Factory - OR:

    @FindBy(xpath = "//span[text()='Phone']//following::lightning-formatted-phone[1]")
    WebElement contactPhoneValue ;

    @FindBy(xpath = "//span[text()='Function']")
    WebElement functionLabelOnContact;

    @FindBy(xpath = "(//span[text()='Primary Country']/following::lightning-formatted-text)[1]")
    WebElement contactPrimaryCountryText;

    public By contactAddressFieldText(String fieldName) {
        return By.xpath("(//span[text()='" + fieldName + "']/following::lightning-formatted-text)[1]");
    }

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//lightning-button-menu[contains(@class,'menu')]//button")
    WebElement showMoreActionsButton;

    @FindBy(xpath = "((//span[text()='Account Name']//following::a)[1]//slot)[last()]")
    WebElement accountNameOnContact;


    @FindBy(xpath = "//a[@id='detailTab__item']")
    WebElement detailsTabOnContact;

    @FindBy(xpath = "//span[text()='Name']//following::lightning-formatted-name")
    WebElement nameOnContactRecord;

    @FindBy(xpath = "//slot[contains(@class,'header__title')]//a")
    WebElement contactNameOnHeader;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'BusinessType')]//lightning-formatted-text")
    WebElement businessTypeOnContactRecord;

    @FindBy(xpath = "//span[text()='Phone']//following::span[4]")
    WebElement phoneOnContactRecord;

    @FindBy(xpath = "//span[text()='Email']//ancestor::dt//following-sibling::dd//a")
    WebElement emailOnContactRecord;


    @FindBy(xpath = "(//span[text()='Phone']//following::a)[1]")
    WebElement phoneOnContactRecord_hyperlink;

    @FindBy(xpath = "//input[contains(@placeholder,'Accounts')]")
    WebElement accountNameInputFieldOnContactCreation;



    //Action

    /**
     * Verifies that the address and phone details on the converted contact
     * match the address and phone details on the lead.
     * This method performs the following steps:
     * 1. Retrieves the address and phone details from the lead.
     * 2. Compares these details with the address and phone details on the converted contact.
     * 3. Asserts that the details match and logs the results.
     */
    @Step("Step: Verify that the converted Contact Address is same as the Lead Address")
    public void verifyAddressPhoneOnConvertedContact(){
        try{
            ReusableLibrary.pageRefresh(driver);
            ReusableLibrary.scrollToElement(driver,contactPhoneValue);
            softAssert.assertEquals(separateAddressInfo.get("Country"),ReusableLibrary.getElementText(driver,driver.findElement(contactAddressFieldText("Primary Country"))), "Country field on the Contact not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("Street"),ReusableLibrary.getElementText(driver,driver.findElement(contactAddressFieldText("Primary Street 1"))), "Street1 field on the Contact not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("City"),ReusableLibrary.getElementText(driver,driver.findElement(contactAddressFieldText("Primary City"))), "City field on the Contact not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("State"),ReusableLibrary.getElementText(driver,driver.findElement(contactAddressFieldText("Primary State"))), "State field on the Contact not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("Zip Code"),ReusableLibrary.getElementText(driver,driver.findElement(contactAddressFieldText("Primary Zip/Postal Code"))), "Postal Code field on the Contact not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("Phone"),ReusableLibrary.getElementText(driver,contactPhoneValue), "Phone field on the Contact not copied over from the Lead");
            softAssert.assertAll();
            loggerManager.getLogger().info("Lead's Address/Phone details are updated  successfully on Contact's Address/Phone details");
            ReusableLibrary.takeScreenshot("verifyAddressPhoneOnConvertedContact", driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Lead's Address/Phone details are not updated on Contact's Address/Phone details");
            Assert.assertTrue(false, "Lead's Address/Phone details are not updated on Contact's Address/Phone details");
        }
    }


    /**
     * This method gets the Contact Address details.
     *
     * @return LinkedHashMap<String, String> - The Contact Address details.
     */
    @Step("Get Contact Address Details")
    public LinkedHashMap<String, String> getContactAddressDetails(){
        LinkedHashMap<String, String> contactAddressDetails = new LinkedHashMap<>();
        waitForElementToBeVisible(driver, contactPrimaryCountryText);
        scrollToElement(driver, contactPrimaryCountryText);
        contactAddressDetails.put("Country", driver.findElement(contactAddressFieldText("Primary Country")).getText());
        contactAddressDetails.put("Street 1", driver.findElement(contactAddressFieldText("Primary Street 1")).getText());
        contactAddressDetails.put("City", driver.findElement(contactAddressFieldText("Primary City")).getText());
        contactAddressDetails.put("State", driver.findElement(contactAddressFieldText("Primary State")).getText());
        contactAddressDetails.put("Postal Code", driver.findElement(contactAddressFieldText("Primary Zip/Postal Code")).getText());
        takeScreenshot(TCName, driver);
        return contactAddressDetails;
    }

    /**
     * This method verifies that the converted Contact Address is same as the Lead Address.
     *
     * @param leadData LinkedHashMap<String, String> - The data of the lead that was converted.
     */
    @Step("Verify that the converted Contact Address is same as the Lead Address")
    public void verifyAddressOnConvertedContact(LinkedHashMap<String, String> leadData){
        waitForElementToBeVisible(driver, showMoreActionsButton);
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 900);");
        scrollToElement(driver, functionLabelOnContact);
        waitForElementToBePresent(driver, contactAddressFieldText("Primary Country"));
        waitForElementToBeVisible(driver, driver.findElement(contactAddressFieldText("Primary Country")));
        Allure.step("Validate that the Address fields are updated correctly on the Contact", step-> {
            softAssert.assertEquals(driver.findElement(contactAddressFieldText("Primary Country")).getText(), leadData.get("Primary Country"), "Country field on the Contact not copied over from the Lead");
            softAssert.assertEquals(driver.findElement(contactAddressFieldText("Primary Street 1")).getText(), leadData.get("Primary Street 1"), "Street1 field on the Contact not copied over from the Lead");
            softAssert.assertEquals(driver.findElement(contactAddressFieldText("Primary City")).getText(), leadData.get("Primary City"), "City field on the Contact not copied over from the Lead");
            softAssert.assertEquals(driver.findElement(contactAddressFieldText("Primary State")).getText(), leadData.get("Primary State"), "State field on the Contact not copied over from the Lead");
            softAssert.assertEquals(driver.findElement(contactAddressFieldText("Primary Zip/Postal Code")).getText(), leadData.get("Primary Zip/Postal Code"), "Postal Code field on the Contact not copied over from the Lead");
        });
        softAssert.assertAll();
        loggerManager.getLogger().info("Converted Contact Address is same as the Lead Address");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that lead is converted to Contact with existing Account.
     *
     * @param existingAccountName String - The name of the existing Account.
     */
    @Step("Verify that the Lead is converted to Contact with existing Account")
    public void verifyConvertedContactWithExistingAccount(String existingAccountName){
        Allure.step("Verify that the Lead is converted to Contact and linked with the existing Account" + existingAccountName + " used at the time of Lead Conversion", step -> {
            Assert.assertTrue(getUrl().contains("https://moodysanalytics--supportqa.sandbox.lightning.force.com/lightning/r/Contact")
                    && getElementText(driver, accountNameOnContact).equals(existingAccountName), "Failed to create Contact");
            loggerManager.getLogger().info("Lead is converted to Contact and linked with the existing Account" + existingAccountName + " used at the time of Lead Conversion");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method enters the necessary fields on a new contact created from an account.
     * It performs the following steps:
     * 1. Waits for the first name field to be visible.
     * 2. Reads the first name, last name, email, business type, and job title from an Excel file.
     * 3. Enters the first name, last name, email, business type, and job title into the respective fields.
     * 4. Logs the action and takes a screenshot of the entered details.
     */
    @Step("Enter necessary fields on the new contact created from Account")
    public void enterRequiredFieldsOnContactCreatedFromAccount(){
        waitForElementToBeVisible(driver, firstNameTextField);
        firstNameText = ReusableLibrary.readExcelData(contactsFilePath, TCName,"First Name");
        ReusableLibrary.sendKeysToElement(driver, firstNameTextField, firstNameText);
        lastNameText = ReusableLibrary.readExcelData(contactsFilePath, TCName,"Last Name")+ReusableLibrary.generateRandomString("_Auto");
        ReusableLibrary.sendKeysToElement(driver, lastNameTextField, lastNameText);
        sfdcLeadEmail = (generateRandomString("testuser") + "_" + generateRandomNumber(3) + "@automationtest.com").toLowerCase();
        ReusableLibrary.sendKeysToElement(driver, SFCDCEmailTextField, sfdcLeadEmail);
        ReusableLibrary.writeToExcel(contactsFilePath, TCName, "Email", sfdcLeadEmail);

        sendKeysToElement(driver, phoneTextField, readExcelData(contactsFilePath, TCName,"Phone"));
        ReusableLibrary.takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Entered necessary fields on the new contact created from Account");

    }


    /**
     * This method saves the contact record and ignores duplicates.
     * It performs the following steps:
     * 1. Waits for the Save button to be visible.
     * 2. Clicks on the Save button.
     * 3. Logs the action and takes a screenshot of the saved contact record.
     * 4. Switches back to the default content.
     * 5. Waits for the page to load and the details tab to be visible.
     * 6. Clicks on the details tab.
     * 7. Asserts that the contact name matches the expected name.
     * 8. Logs the successful navigation to the contact record and takes a screenshot.
     */
    @Step("Save the Contact record and navigate to contact record.")
    public void saveContactandNavigatetoNewContactRecord(){
        reusableBusinessLibrary.clickSaveBtn();
        elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
        Allure.step("Clicked on Save button successfully.", step -> {
            loggerManager.getLogger().info("Clicked on Save button successfully.");
            ReusableLibrary.takeScreenshot(TCName, driver);
        });
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, detailsTabOnContact);
        ReusableLibrary.elementClickByJS(driver, detailsTabOnContact);
        Assert.assertEquals(ReusableLibrary.getElementText(driver, nameOnContactRecord), firstNameText+" "+lastNameText);
        Allure.step("Contact record saved successfully.", step -> {
            loggerManager.getLogger().info("Navigated to Contact record.");
            ReusableLibrary.takeScreenshot("NewContactRecord", driver);
        });
    }

    /**
     * Validates the necessary fields on a contact created from an account.
     * This method performs the following steps:
     * 1. Refreshes the page and waits for it to load.
     * 2. Verifies that the contact's name, email, account name, phone, business type, job title, and address fields match the expected values from the Excel file.
     * 3. Asserts that the details match and logs the validation results.
     * 4. Takes a screenshot of the contact record.
     * Note: Commented the validate Business component line because of the on going issue with the Business Type field, It is not syncing down to contact from account.
     */
    @Step("Validate necessary fields on contact created from Account.")
    public void validateContactDetails(){
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, accountNameOnContact);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, contactNameOnHeader), firstNameText+" "+lastNameText);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, nameOnContactRecord), firstNameText+" "+lastNameText);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, emailOnContactRecord), sfdcLeadEmail);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, accountNameOnContact), ReusableLibrary.readExcelData(contactsFilePath, TCName, "Account Name"));
        switch (TCName){
            case "createContactFromAccount_BusinessAdmin":
                waitForElementToBeVisible(driver,phoneOnContactRecord);
                writeToExcel(contactsFilePath, TCName, "Phone", phoneOnContactRecord.getText());
                break;
            case "createContactFromAccount_SalesRep":
            case "createContactFromAccount_OperationalAnalyst":
            case "createContactFromAccount_DataManagement":
                waitForElementToBeVisible(driver,phoneOnContactRecord_hyperlink);
                writeToExcel(contactsFilePath, TCName, "Phone", phoneOnContactRecord_hyperlink.getText());
                break;
            default:
                loggerManager.getLogger().info("TCName does not exist for Account Phone number capture");
        }
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, businessTypeOnContactRecord), ReusableLibrary.readExcelData(contactsFilePath, TCName, "Business Type"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, driver.findElement(contactAddressFieldText("Primary Country"))), ReusableLibrary.readExcelData(contactsFilePath, TCName, "Primary Country"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, driver.findElement(contactAddressFieldText("Primary Street 1"))), ReusableLibrary.readExcelData(contactsFilePath, TCName, "Primary Street 1"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, driver.findElement(contactAddressFieldText("Primary City"))), ReusableLibrary.readExcelData(contactsFilePath, TCName, "Primary City"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, driver.findElement(contactAddressFieldText("Primary State"))), ReusableLibrary.readExcelData(contactsFilePath, TCName, "Primary State"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, driver.findElement(contactAddressFieldText("Primary Zip/Postal Code"))), ReusableLibrary.readExcelData(contactsFilePath, TCName, "Primary Zip/Postal Code"));
        softAssert.assertAll();
        ReusableLibrary.takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Validated Contact Name on Header, Name, Email, Account Name, Phone, Business Type, Job Title and Address fields on Contact record.");
        Allure.step("Validated name on header, contact name, email, account name, phone, business type, job title and address fields on Contact record.");
    }
}
