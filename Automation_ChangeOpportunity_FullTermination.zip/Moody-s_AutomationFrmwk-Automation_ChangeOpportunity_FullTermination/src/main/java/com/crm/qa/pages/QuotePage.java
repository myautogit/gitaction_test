package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.getSFDCRecordIDFromURL;
import static com.crm.qa.util.ReusableBusinessLibrary.openRecordBySFDCID;
import static com.crm.qa.util.ReusableLibrary.*;
import static com.crm.qa.util.ReusableLibrary.currentDatePlusDays;

/**
 * This class contains methods related to the Quoting functionality.
 * Author: Arshin Shaikh
 * Last Modified By: Arshin Shaikh
 * Date: 02/19/2025
 * Comment: Added new methods for Change Opportunity - Full Termination scenario.
 */
public class QuotePage extends TestBase {

    public QuotePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();
    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
    OpportunityPage opportunityPage = new OpportunityPage(driver);
    HomePage homePage = new HomePage(driver);

    //Page Factory - OR:

    @FindBy(xpath = "(//span[text()='Expected Start Date']/following::lightning-formatted-text)[1]")
    WebElement expectedStartDateOnQuote;

    @FindBy(xpath = "(//span[text()='Expected End Date']/following::lightning-formatted-text)[1]")
    WebElement expectedEndDateOnQuote;

    @FindBy(xpath = "//span[@class='proposal-summary__display']")
    WebElement proposalHeaderOnApttus;

    @FindBy(xpath = "//a[text()=' View ']")
    WebElement viewProposalLinkOnApttus;

    @FindBy(xpath = "//iframe[@scrolling='yes']")
    WebElement apttusCatalogIframe;

    @FindBy(xpath = "//span[text()='Total Base Extended Price']")
    WebElement totalBaseExtendedPriceLabel;

    @FindBy(xpath = "//input[@placeholder='Find Products']")
    WebElement findProductsSearchBoxOnApttus;

    @FindBy(xpath = "//button[contains(text(),'Configure')]")
    WebElement configureButtonOnApttusCatalog;

    public By searchProductResult(String productName) {
        return By.xpath("//a[text()=\"" + productName + "\" and @class]");
    }

    public By textFieldAttribute(String attributeName) {
        return By.xpath("(//label[text()[normalize-space()='" + attributeName + "']]//following::input)[1]");
    }

    public By dropdownAttribute(String attributeName) {
        return By.xpath("(//label[text()[normalize-space()='" + attributeName + "']]//following::a)[1]");
    }

    public By dropdownOption(String attributeName, String attributeValue) {
        return By.xpath("//label[text()[normalize-space()='" + attributeName + "']]//following::div[text()='" + attributeValue + "']");
    }

    public By multiSelectPicklistAttribute(String attributeName) {
        return By.xpath("(//label[text()[normalize-space()='" + attributeName + "']]//following::input)[1]");
    }

    public By multiselectAttributeOption(String attributeValue) {
        return By.xpath("//div[text()='" + attributeValue + "']");
    }

    @FindBy(xpath = "//button[text()[normalize-space()='Add More Products']]")
    WebElement addMoreProductsBtnOnApttus;

    @FindBy(xpath = "//button[text()[normalize-space()='Finalize']]")
    WebElement finalizeButtonOnApttusCart;

    @FindBy(xpath = "//md-icon[text()='shopping_cart']")
    WebElement cartIconOnApttus;

    @FindBy(xpath = "//button[text()[normalize-space()='View Cart']]")
    WebElement viewCartButtonOnApttus;

    @FindBy(xpath = "//div[contains(@class,'grid-canvas')]//div[contains(@class,'aptCurrency read-only')]")
    List<WebElement> cartLineItemsPrice;

    public By quoteActions(String actionName) {
        return By.xpath("//div[contains(@style,'center')]//lightning-icon[@title='" + actionName + "']");
    }

    @FindBy(xpath = "(//div[text()[normalize-space()='Grand Total']]/following::div[contains(@class,'read')])[1]")
    WebElement grandTotalValueOnApttus;

    @FindBy(xpath = "(//div[text()[normalize-space()='Total (Yearly)']]/following::div[contains(@class,'read')])[1]")
    WebElement totalYearlyValueOnApttus;

    @FindBy(xpath = "//span[text()='After finalizing the quote, wait a few minutes for quote total and locations to be updated and then refresh the page. Proceeding without locations will cause complications in further steps.']")
    WebElement quoteWarningMessage;

    public By contractSpecialistUser(String contractSpecialistName) {
        return By.xpath("//span[text()='" + contractSpecialistName + "']/ancestor::a[contains(@href,'User')]");
    }

    @FindBy(xpath = "//md-tab-item[text()[normalize-space()='Product Options']]")
    WebElement productOptionsTabOnApttus;

    public WebElement optionProductCheckbox(String optionProductName) {
        return driver.findElement(By.xpath("//span[text()=\""+optionProductName+"\"]//preceding::div[1]//input"));
    }
    public WebElement optionProductCheckboxLabel(String optionProductName) {
        return driver.findElement(By.xpath("//span[text()=\""+optionProductName+"\"]//preceding::div[1]//label"));
    }

    @FindBy(xpath = "//div[@style='overflow: hidden;']//following::dynamic-field[@field-type='STRING' and @is-editable='false']")
    List<WebElement> cartLineItemsProductNames;

    @FindBy(xpath = "//span[text()='Default Named Users']")
    WebElement defaultNamedUsersLabel;

    @FindBy(xpath = "//a[contains(@href,'ReadyforAgreement')]")
    WebElement readyForAgreementBtn;

    @FindBy(xpath = "//lightning-icon[@title='Create Agreement With Lines (Apttus)']")
    WebElement createAgreementWithLineItemsAction;

    @FindBy(xpath = "//lightning-icon[@title='Create Default Site Profile']")
    WebElement createDefaultSiteProfileAction;

    @FindBy(xpath = "//span[text()='Adjustment Difference']")
    WebElement adjustmentDifferenceLabel;

    By configureProductWrenchIconOnCart(String productName) {
        return By.xpath("(//span[text()=\"" + productName + "\"]//following::span[contains(@ui-sref,'lineItem.config')])[1]");
    }

    @FindBy(xpath = "//p[text()='1. “Trade Optimizer” cannot be sold standalone. It should be sold along with “67684 /CLO Management Module”.']")
    WebElement tradeOptimizerWarningMessage;

    By productNameOnApttusCart(String productName) {
        return By.xpath("//div[contains(@class,'grid-viewport')]//div[@ng-bind-html and text()='" + productName + "']");
    }

    @FindBy(xpath = "//button[text()[normalize-space()='OK'] and @ng-click='customAction.confirmFinalize()']")
    WebElement okButtonOnFinalizeConfirmation;

    @FindBy(xpath = "//button[text()[normalize-space()='Reprice']]")
    WebElement repriceButtonOnApttusCart;

    public @FindBy(xpath = "//button[normalize-space()='Mass Price Ramp']")
    WebElement massPriceRampButton;

    public @FindBy(xpath = "//th//span[@part='input-checkbox']")
    WebElement lineItemCheckBoxOnMassPriceRampPage;

    @FindBy(xpath = "//button[text()='Apply Price Ramps']")
    WebElement applyPriceRampsBtn;

    public By contractStartDateOnProposalLineItemPage() {
        return By.xpath("./following::td[@data-label='Term Start Date']");
    }
    public By contractEndDateOnProposalLineItemPage() {
        return By.xpath("./following::td[@data-label='End Date']");
    }

    public By productNameOnProposalLineItemPage(String productName){
        return By.xpath("//span[@text()=\""+productName+"\"]");
    }

    public By productFrame(String oppyName) {
        return By.xpath("//iframe[@title=\"" + oppyName + "\"]");
    }

    public By cartLineMoreActionIcon(String productName,int index) {
        return By.xpath("(//span[text()='" + productName + "'])["+index+"]//following::md-icon[text()='more_vert'][1]");
    }

    public By cartLineMoreActionHoverArea(String productName,int index) {
        return By.xpath("((//span[text()='" + productName + "'])["+index+"]//following::div[@ng-mouseenter])[1]");
    }

    public By cartLineActionBtn(String actionName) {
        return By.xpath("(//div[@aria-hidden='false']//button[text()='" + actionName + "'])");
    }

    @FindBy(xpath = "//label[text()='To']//following::input[2]")
    WebElement noOfCommittedUsersOnTier1;

    @FindBy(xpath = "//button[contains(@ng-click,'saveUsage')]")
    WebElement saveUsagePriceTierBtn;

    @FindBy(xpath = "//button[text()[normalize-space()='Validate']]")
    WebElement validateButtonOnProductConfig;

    By attributeNameOnProductConfig(String attributeName){
        return By.xpath("//label[text()[normalize-space()='" + attributeName + "']]//following::div[2]//li//span");
    }

    @FindBy(xpath = "//i[contains(@ng-click,'toggleCartSubtotals')]")
    WebElement grandTotalIconOnApttusCart;

    @FindBy(xpath = "(//dynamic-field[contains(@model,'AdjustmentType')]//md-select[@id='picklistSelectMaterialDesign'])[1]")
    WebElement adjustmentTypeDropdownOnCartTotal;

    public By adjustmentTypeDropdownOption(String option) {
        return By.xpath("(//div[text()[normalize-space()='"+ option +"']])[last()]");
    }

    @FindBy(xpath = "(//dynamic-field[contains(@properties,'AdjustmentAmount')]//input)[1]")
    WebElement adjustmentAmountInputOnCartTotal;

    @FindBy(xpath = "//button[text()[normalize-space()='Submit for Approval']]")
    WebElement submitForApprovalBtn;

    @FindBy(xpath = "//table[contains(@id,'Approvals')]")
    WebElement approvalsTable;

    public By approvalTableColumnValue(int columnNumber)
    {
        return By.xpath("//table[contains(@id,'idStepRequestsTable')]//tbody//td[" + columnNumber + "]//span");
    }

    public By apttusApprovalPageBtn(String buttonName) {
        return By.xpath("//input[@value='" + buttonName + "']");
    }

    @FindBy(xpath = "//span[@class='menu-toggle']")
    WebElement apttusMoreActionsMenuBtn;

    @FindBy(xpath = "//button[text()[normalize-space()='Save'] and @buttonid]")
    WebElement saveCartBtn;

    public By existingMultiselectPicklistOptions(String multiselectAttributeName)
    {
        return By.xpath("//label[text()[normalize-space()='" + multiselectAttributeName + "']]/following::dynamic-field[1]//a[contains(@ng-click,'remove')]");
    }

    @FindBy(xpath = "//div[contains(@class,'PERCENT')]//div[contains(@class,'aptPercentage')]")
    List<WebElement> netAdjustmentPercentOnCartLines;

    @FindBy(xpath = "(//div[contains(@class,'AdjustmentType')]//md-select)[1]")
    WebElement adjustmentTypeDropdownOnCartLine;

    @FindBy(xpath = "(//div[contains(@class,'Adjustment')]//input)[1]")
    WebElement adjustmentAmountTextfieldOnCartLine;

    public By productName(String productName) {
        return By.xpath("//span[text()=\""+productName+"\" and @class]");
    }

    @FindBy(xpath = "//div[@id='progress-bar-container']//following::div[@id='ngProgress-container' and contains(@style,'background')]")
    WebElement repriceCartProgressBar;

    @FindBy(xpath = "//button[text()='Clone with Line Items']")
    WebElement cloneWithLineItemsBtn;

    @FindBy(xpath = "//input[@name='Trial__c']")
    WebElement trialCheckbox;

    @FindBy(xpath = "//input[@name='Apttus_Proposal__Primary__c']")
    WebElement primaryCheckbox;

    @FindBy(xpath = "//img[@alt='Configure Products']")
    WebElement configureProductsBtn;

    @FindBy(xpath = "//a[contains(@href,'Opportunity') and @data-navigation='enable']//following::span[string-length(text())>0][1]")
    WebElement getOpportunityName;

    @FindBy(xpath = "//div[contains(@style,'block')]//span[contains(text(),'Previewing Approvals')]")
    WebElement previewingApprovalsDialog;

    @FindBy(xpath = "//div[text()='Your request(s) have been submitted for approval. You will be notified when approvals are complete.']")
    WebElement approvalsSubmittedMessage;

    public By approvalPageBtn(String btnName)
    {
        return By.xpath("//input[@value='" + btnName + "']");
    }

    @FindBy(xpath = "//span[text()='Approved' and @class='approvalStatusValueGreen']")
    WebElement approvedStatusOnApprovalPage;

    @FindBy(xpath = "//div[@class='ui-grid-viewport']//following::div[@class='grid-checkbox']")
    WebElement productCheckboxOnCartPage;

    @FindBy(xpath = "//p[@pikaday='dynamicField.tempDate']//input")
    WebElement contractDatesOnCartPage;

    @FindBy(xpath = "//li[contains(@ng-repeat,'pageWarnings')]")
    WebElement warningMsgOnCartPage;

    @FindBy(xpath = "//button[@aria-label='Copy']")
    WebElement copyButtonOnCart;

    @FindBy(xpath = "//button[@title='Edit Default Category']")
    WebElement editDefaultCategoryBtn;

    @FindBy(xpath = "//button[@aria-label='Default Category']")
    WebElement defaultCategoryDropdown;

    @FindBy(xpath = "(//span[text()='Default Category']/following::lightning-formatted-text)[1]")
    WebElement defaultCategoryValidationField;

    @FindBy(xpath = "(//span[text()='Default Reason']/following::lightning-formatted-text)[1]")
    WebElement defaultReasonValidationField;

    @FindBy(xpath = "//button[@buttonid='id_task_left_catalogproducts']")
    WebElement catalogProductsBtn;

    @FindBy(xpath = "//button[@aria-label='Mass Update']")
    WebElement massUpdateBtn;

    @FindBy(xpath = "//md-dialog-content//label[text()='Start Date']/../following-sibling::td//p/input")
    WebElement massUpdateStartDate;

    @FindBy(xpath = "//md-dialog-content//label[text()='End Date']/../following-sibling::td//p/input")
    WebElement massUpdateEndDate;

    @FindBy(xpath = "//md-dialog//button[contains(text(),'Apply')]")
    WebElement massUpdateApplyBtn;

    public By productCheckboxonCart(String productName,int index) {
        return By.xpath("(//span[@title=\""+productName+"\"]/preceding::div[@class='grid-checkbox'][1])["+index+"]");
    }

    public By defaultReasonPicklistOption(String optionName) {
        return By.xpath("//button[@aria-label='Default Reason']/following::lightning-base-combobox-item[@data-value='"+optionName+"']");
    }

    @FindBy(xpath = "(//div[@role='columnheader']//following::label[@for])[1]")
    WebElement firstProductCheckboxOnInstalledProducts;

    @FindBy(xpath = "//button[text()='Terminate']")
    WebElement terminateBtnOnInstalledProducts;

    @FindBy(id = "terminateDate")
    WebElement terminationDateInput;

    @FindBy(xpath = "//button[normalize-space()='Calculate']")
    WebElement calculateBtnOnInstalledProducts;

    @FindBy(xpath = "//div[@class='loading']")
    WebElement loadingSpinnerOnTerminationPage;

    @FindBy(xpath = "//button[text()='Confirm']")
    WebElement confirmBtnOnTerminationPage;

    @FindBy(xpath = "//button[normalize-space()='Go to Pricing']")
    WebElement goToPricingBtn;

    public By cartLineColumnValue(int cartLineRowNo, int columnNo){
        return By.xpath("((//div[contains(@style,'hidden auto')]//following::div[contains(@ng-repeat,'row')])[" + cartLineRowNo + "]//div[contains(@class,'read')])[" + columnNo + "]");
    }

    @FindBy(xpath = "(//span[contains(@class,'line-item--name')])[1]")
    WebElement firstProductNameOnInstalledProducts;

    @FindBy(xpath = "(//dynamic-field[contains(@properties,'Sales_Price')]//div)[1]")
    WebElement firstProductPriceOnInstalledProducts;

    @FindBy(xpath = "//div[contains(@class,'right')]//span[contains(@class,'grid-header-text')]")
    List<WebElement> cartLineItemsRightTableHeaders;

    //Actions:

    /**
     * This method verifies that expected start and end dates are updated on the Quote as per the Opportunity.
     *
     * @param expectedStartDate - The expected start date on the Quote
     * @param expectedEndDate   - The expected end date on the Quote
     */
    @Step("Verify that expected start and end dates are updated on the Quote as per the Opportunity")
    public void verifyQuoteDates(String expectedStartDate, String expectedEndDate) {
        waitForElementToBeVisible(driver, totalBaseExtendedPriceLabel);
        scrollToElement(driver, totalBaseExtendedPriceLabel);
        waitForElementToBeVisible(driver, expectedStartDateOnQuote);

        if (getElementText(driver, expectedStartDateOnQuote).equals(expectedStartDate)
                && getElementText(driver, expectedEndDateOnQuote).equals(expectedEndDate)) {
            loggerManager.getLogger().info("Expected Start and End Dates are updated on the Quote as per the Opportunity");
        } else {
            loggerManager.getLogger().error("Expected Start and End Dates are not updated on the Quote");
        }
        takeScreenshot(TCName, driver);
        Assert.assertTrue(getElementText(driver, expectedStartDateOnQuote).equals(expectedStartDate)
                && getElementText(driver, expectedEndDateOnQuote).equals(expectedEndDate), "Expected Start and End Dates are not updated on the Quote");
    }

    /**
     * This method navigates to Quote/Proposal record from Apttus.
     */
    @Step("Navigate to Quote/Proposal record from Apttus")
    public void navigateToQuoteFromApttus() {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, proposalHeaderOnApttus);
        elementClick(driver, proposalHeaderOnApttus);
        waitForElementToBeVisible(driver, viewProposalLinkOnApttus);
        elementClick(driver, viewProposalLinkOnApttus);
        waitForPageTitleToContain(driver, "Quote/Proposal | Salesforce");
        takeScreenshot(TCName, driver);
        Assert.assertTrue(driver.getTitle().contains("Quote/Proposal | Salesforce"), "Failed to navigate to Quote/Proposal from Apttus");
        loggerManager.getLogger().info("Successfully navigated to Quote/Proposal from Apttus");
        switchToDefaultContent(driver);
    }

    /**
     * This method searches for a product by product code on Apttus Catalog
     *
     * @param productCode - The product code to search for
     * @param productName - The product name associated with the product code
     */
    @Step("Search product by product code {productCode} on Apttus")
    public void searchProductByProductCode(String productCode, String productName) {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, findProductsSearchBoxOnApttus);
        sendKeysToElement(driver, findProductsSearchBoxOnApttus, productCode + Keys.ENTER);
        waitForElementToBePresent(driver, searchProductResult(productName));
        waitForElementToBeVisible(driver, driver.findElement(searchProductResult(productName)));
        Assert.assertTrue(isElementDisplayed(driver, driver.findElement(searchProductResult(productName))), "Product " + productName + " not found in the search results");
        loggerManager.getLogger().info("Product " + productName + " found in the search results");
        setScreenZoom(driver, 75);
        takeScreenshot(TCName, driver);
        waitForElementToBeVisible(driver, configureButtonOnApttusCatalog);
        elementClickByJS(driver, configureButtonOnApttusCatalog);
        loggerManager.getLogger().info("Product " + productName + " added to the cart");
        switchToDefaultContent(driver);
    }

    /**
     * This method configures product attributes on Apttus
     *
     * @param productAttributes - The product attributes to configure
     */
    @Step("Configure product attributes on Apttus")
    public void configureProductAttributes(Map<String, String> productAttributes) {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        for (Map.Entry<String, String> entry : productAttributes.entrySet()) {
            String attributeName = entry.getKey();
            String attributeValue = entry.getValue();
            String attributeType = getAttributeType(attributeName);
            attributeName = attributeName.split("_")[0];
            WebElement element;
            if (attributeValue != null && !attributeValue.isEmpty()) {
                switch (attributeType) {
                    case "txt":
                        waitForElementToBePresent(driver, textFieldAttribute(attributeName));
                        element = driver.findElement(textFieldAttribute(attributeName));
                        element.clear();
                        sendKeysToElement(driver, element, attributeValue);
                        driver.findElement(textFieldAttribute(attributeName)).sendKeys(Keys.TAB);
                        loggerManager.getLogger().info("Entered value: " + attributeValue + " for attribute: " + attributeName);
                        break;
                    case "drp":
                        waitForElementToBePresent(driver, dropdownAttribute(attributeName));
                        element = driver.findElement(dropdownAttribute(attributeName));
                        elementClickByJS(driver, element);
                        elementClickByJS(driver, driver.findElement(dropdownOption(attributeName, attributeValue)));
                        loggerManager.getLogger().info("Selected value: " + attributeValue + " for attribute: " + attributeName);
                        break;
                    case "lst":
                        waitForElementToBePresent(driver, multiSelectPicklistAttribute(attributeName));
                        element = driver.findElement(multiSelectPicklistAttribute(attributeName));
                        scrollToBottom(driver);
                        //Clear already selected values if any
                        waitForElementToBePresent(driver, existingMultiselectPicklistOptions(attributeName));
                        if(isElementPresent(driver, existingMultiselectPicklistOptions(attributeName))){
                            List<WebElement> existingOptions = driver.findElements(existingMultiselectPicklistOptions(attributeName));
                            for(WebElement option : existingOptions){
                                elementClickByJS(driver, option);
                            }
                        }
                        elementClickByJS(driver, element);
                        if (attributeValue.contains(",")) {
                            String[] values = attributeValue.split(",");
                            for (String value : values) {
                                waitForElementToBePresent(driver, multiselectAttributeOption(value));
                                elementClickByJS(driver, driver.findElement(multiselectAttributeOption(value)));
                            }
                        } else {
                            waitForElementToBePresent(driver, multiselectAttributeOption(attributeValue));
                            elementClickByJS(driver, driver.findElement(multiselectAttributeOption(attributeValue)));
                        }
                        elementClickByJS(driver, driver.findElement(productName(productAttributes.get("ProductName"))));
                        loggerManager.getLogger().info("Selected value: " + attributeValue + " for attribute: " + attributeName);
                        break;
                    default:
                        loggerManager.getLogger().warn("Unknown attribute type for: " + attributeName);
                        break;
                }
            }
        }
        takeScreenshot(TCName, driver);
        switchToDefaultContent(driver);
    }

    /**
     * This method returns the attribute type based on the attribute name
     *
     * @param attributeName - The attribute name
     * @return - The attribute type - txt for a text field, drp for a dropdown and lst for a multiselect picklist
     */
    private String getAttributeType(String attributeName) {
        if (attributeName.endsWith("_txt")) {
            return "txt";
        } else if (attributeName.endsWith("_drp")) {
            return "drp";
        } else if (attributeName.endsWith("_lst")) {
            return "lst";
        } else {
            return "unknown";
        }
    }

    /**
     * This method verifies that cart line items price is non-zero
     *
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify that cart line items price is non-zero")
    public void verifyCartLineItemsPrice(List<LinkedHashMap<String, String>> quoteData) {
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        Map<String, Integer> productIndexMap = new HashMap<>();
        for (int i = 0; i < cartLineItemsProductNames.size(); i++) {
            scrollToElement(driver, cartLineItemsProductNames.get(i));
            String productName;
            if (getElementText(driver, cartLineItemsProductNames.get(i)).contains(("AXIS User Keys")))// handle additional text for Axis product.
            {
                productName = "AXIS User Keys";
            } else {
                productName = getElementText(driver, cartLineItemsProductNames.get(i));
            }
            productIndexMap.put(productName, i);
        }

        for (LinkedHashMap<String, String> data : quoteData) {
            String productName = data.get("ProductName");
            int index = productIndexMap.get(productName);
            String[] actualPrice = getElementText(driver, cartLineItemsPrice.get(index)).split(" ");
            String productType = data.get("ProductType");
            String pricingAtBundleHeader = data.get("PricingAtBundleHeader");

            if (productType.equals("Standalone")) {
                if (data.get("ZeroDollarProduct").equals("Y")) {
                    Assert.assertEquals(actualPrice[1], "0.00", "Product price is not zero for " + productName);
                    loggerManager.getLogger().info("Product price is zero for " + productName + ". Actual Price: " + cartLineItemsPrice.get(index).getText());
                } else {
                    Assert.assertNotEquals(actualPrice[1], "0.00", "Product price is zero for " + productName);
                    loggerManager.getLogger().info("Product price is non-zero for " + productName + ". Actual Price: " + cartLineItemsPrice.get(index).getText());
                }
            } else if (productType.equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(","); // replace earlier if condition with this line, it handles both single and multiple option products.
                if (pricingAtBundleHeader.equals("Y")) {
                    softAssert.assertNotEquals(actualPrice[1], "0.00", "Bundle header price is zero for " + productName);
                    loggerManager.getLogger().info("Bundle header price is non-zero for " + productName + ". Actual Price: " + cartLineItemsPrice.get(index).getText());
                    verifyOptionProductsPrice(optionProducts, productIndexMap, true, cartLineItemsPrice);
                } else if (pricingAtBundleHeader.equals("N")) {
                    softAssert.assertEquals(actualPrice[1], "0.00", "Bundle header price is not zero for " + productName);
                    loggerManager.getLogger().info("Bundle header price is zero for " + productName + ". Actual Price: " + cartLineItemsPrice.get(index).getText());
                    verifyOptionProductsPrice(optionProducts, productIndexMap, false, cartLineItemsPrice);
                }
            } else {
                loggerManager.getLogger().error("Product name not found in the productIndexMap: " + productName);
            }
        }
        softAssert.assertAll();
    }

    /**
     * This method verifies option products price
     *
     * @param optionProducts         - The option products to verify
     * @param productIndexMap        - The product index map with product name and its index in the cart
     * @param isPricingAtBundleHeader - The pricing at bundle header flag
     * @param lineItemsPrice         - The line items price
     */
    @Step("Verify option products price")
    private void verifyOptionProductsPrice(String[] optionProducts, Map<String, Integer> productIndexMap, boolean isPricingAtBundleHeader, List<WebElement> lineItemsPrice) {
        for (String optionProduct : optionProducts) {
            int index = productIndexMap.get(optionProduct);
            String[] optionPrice = getElementText(driver, lineItemsPrice.get(index)).split(" ");
            if (isPricingAtBundleHeader) {
                Assert.assertEquals(optionPrice[1], "0.00", "Option Product price is not zero where pricing is at bundle header");
                loggerManager.getLogger().info("Option Product price is zero where pricing is at bundle header. Actual Price: " + lineItemsPrice.get(index).getText());
            } else {
                Assert.assertNotEquals(optionPrice[1], "0.00", "Option Product price is zero where pricing is not at bundle header");
                loggerManager.getLogger().info("Option Product price is non-zero where pricing is not at bundle header. Actual Price: " + lineItemsPrice.get(index).getText());
            }
        }
    }

    /**
     * This method verifies fields on the Quote post finalization
     *
     * @param opportunityData - The opportunity data to be validated on the Quote
     */
    @Step("Verify fields on the Quote post finalization")
    public void verifyNewSaleQuoteDetails(LinkedHashMap<String, String> opportunityData) {
        for (int i = 0; i < 3; i++) {
            pageRefresh(driver);
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
            if (!isElementDisplayed(driver, quoteWarningMessage)) {
                break;
            }
            try {
                Thread.sleep(4000);
            } catch (InterruptedException e) {
                loggerManager.getLogger().error(e.getMessage());
            }
        }
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Proposal Name"));
        waitForElementToBeVisible(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Proposal Name")));
        Allure.step("Verify that value of Proposal Name is " + oppyName, step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Proposal Name"))), oppyName, "Proposal Name is not displayed as expected.");
        });
        Allure.step("Verify that value of ABO Type is New", step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("ABO Type"))), "New", "ABO Type is not displayed as expected.");
        });
        Allure.step("Verify that value of Approval Stage is Approved", step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Approval Stage"))), "Approved", "Approval Stage is not displayed as expected.");
        });
        Allure.step("Verify that value of Quote Total is not zero: ", step -> {
            softAssert.assertNotEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Quote Total"))).split(" ")[1], quoteAndAgreementTotal, "Quote Total is not displayed as expected.");
        });
        if(TCName.contains("Trial")){
            Allure.step("Verify that value of Default Category is empty", step -> {
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Default Category"))), "","Default Category is not displayed as expected.");
            });
            Allure.step("Verify that value of Expected End Date is " + trialEndDate, step -> {
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Expected End Date"))), trialEndDate, "Expected End Date is not displayed as expected.");
            });
        }else{
            Allure.step("Verify that value of Default Category is New Sale", step -> {
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Default Category"))), "New Sale", "Default Category is not displayed as expected.");
            });
            Allure.step("Verify that value of Expected End Date is " + expectedEndDate, step -> {
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Expected End Date"))), expectedEndDate, "Expected End Date is not displayed as expected.");
            });
        }
        Allure.step("Verify that value of Expected Start Date is " + expectedStartDate, step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Expected Start Date"))), expectedStartDate, "Expected Start Date is not displayed as expected.");
        });
        Allure.step("Verify that value of Account is " + opportunityData.get("AccountName"), step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.linkFieldValue("Account"))), opportunityData.get("AccountName"), "Account is not displayed as expected.");
        });
        Allure.step("Verify that value of Opportunity " + oppyName, step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.linkFieldValue("Opportunity"))), oppyName, "Opportunity is not displayed as expected.");
        });
        takeScreenshot(TCName, driver);
        waitForElementToBePresent(driver, reusableBusinessLibrary.subTabName("Details"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.subTabName("Details")));
        Allure.step("Verify that value of Primary Contact " + opportunityData.get("SoldToContactName"), step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.linkFieldValue("Primary Contact"))), opportunityData.get("SoldToContactName"), "Primary Contact is not displayed as expected.");
        });
        takeScreenshot(TCName, driver);
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Account"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Account")));
        Allure.step("Verify that value of Contract Specialist is " + opportunityData.get("ContractSpecialistName"), step -> {
            waitForElementToBePresent(driver, contractSpecialistUser(opportunityData.get("ContractSpecialistName")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(contractSpecialistUser(opportunityData.get("ContractSpecialistName")))), "Contract Specialist is not displayed as expected.");
        });
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Quote Details are validated successfully post finalization");
    }

    /**
     * This method verifies that Quote Actions are displayed on the Quote/Proposal
     */
    @Step("Verify Quote Actions on the Quote/Proposal")
    public void verifyQuoteActions() {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.quickAction("Configure Products"));
        waitForElementToBeVisible(driver, driver.findElement(quoteActions("Configure Products")));
        Allure.step("Verify that Configure Products action is displayed on the Quote", step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(quoteActions("Configure Products"))), "Configure Products action is not displayed as expected.");
        });
        Allure.step("Verify that Sync to Opportunity action is displayed on the Quote", step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.quickAction("Sync to Opportunity"))), "Sync to Opportunity action is not displayed as expected.");
        });
        Allure.step("Verify that My Approval action is displayed on the Quote", step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.quickAction("My Approval"))), "My Approval action is not displayed as expected.");
        });
        Allure.step("Verify that Generate action is displayed on the Quote", step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.quickAction("Generate"))), "Generate action is not displayed as expected.");
        });
        Allure.step("Verify that Present action is displayed on the Quote", step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.quickAction("Present"))), "Present action is not displayed as expected.");
        });
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Quote Actions are displayed correctly on the Quote?/Proposal");
        if (isElementDisplayed(driver, createDefaultSiteProfileAction)) {
            elementClickByJS(driver, createDefaultSiteProfileAction);
            waitForAlertAndAccept(driver, Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration")));
            loggerManager.getLogger().info("Clicked on Create Default Site Profile action");
        }
    }

    /**
     * This method verifies that cart total is non-zero
     */
    @Step("Verify that Cart Total is not zero")
    public void verifyCartTotalValues() {
        String totalYearly = getElementText(driver, totalYearlyValueOnApttus).split(" ")[1];
        String grandTotal = getElementText(driver, grandTotalValueOnApttus).split(" ")[1];
        if(TCName.contains("Trial")){
            Assert.assertEquals(totalYearly, "0.00", "Product price is not zero");
            loggerManager.getLogger().info("Total Yearly Price is zero: " + totalYearly);
            Assert.assertEquals(grandTotal, "0.00", "Product price is not zero");
            loggerManager.getLogger().info("Grand Total Price is zero: " + totalYearly);
        }else {
            Assert.assertNotEquals(totalYearly, "0.00", "Product price is zero");
            loggerManager.getLogger().info("Total Yearly Price is non-zero: " + totalYearly);
            Assert.assertNotEquals(grandTotal, "0.00", "Product price is zero");
            loggerManager.getLogger().info("Grand Total Price is non-zero: " + totalYearly);
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method navigates to Proposal Line Items related list on the Quote
     */
    @Step("Navigate to Proposal Line Items related list")
    public void navigateToProposalLineItemsRelatedList() {
        scrollToTop(driver);
        scrollToElement(driver, adjustmentDifferenceLabel);
        reusableBusinessLibrary.clickOnRelatedList("Line Items");
        waitForPageTitleToContain(driver, "Proposal Line Items");
        Assert.assertTrue(driver.getTitle().contains("Proposal Line Items"), "Failed to navigate to Proposal Line Items related list");
        loggerManager.getLogger().info("Successfully navigated to Proposal Line Items related list");
    }

    /**
     * This method verifies the Proposal Line Items on the Quote
     *
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify that Proposal Line Items are displayed on the Quote")
    public void verifyProposalLineItems(List<LinkedHashMap<String, String>> quoteData) {
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        List<String> actualStartDates = new ArrayList<>();
        List<String> actualEndDates = new ArrayList<>();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Line Items"));

        pageRefresh(driver);
        setScreenZoom(driver, 50);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Line Items"));

        List<WebElement> proposalLineItems = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Line Items"));
        for (WebElement proposalLineItem : proposalLineItems) {
            waitForElementToBeVisible(driver, proposalLineItem);
            String dataLabel = proposalLineItem.getAttribute("data-label");
            if (dataLabel != null)
                switch (dataLabel) {
                    case "Description":
                        if (getElementText(driver,proposalLineItem).contains(("AXIS User Keys")))// handle additional text for Axis product.
                        {
                            actualProductNames.add("AXIS User Keys");
                            break;
                        }
                        actualProductNames.add(getElementText(driver, proposalLineItem));
                        break;
                    case "Term Start Date":
                        actualStartDates.add(getElementText(driver, proposalLineItem));
                        break;
                    case "End Date":
                        actualEndDates.add(getElementText(driver, proposalLineItem));
                        break;
                    default:
                        break;
                }
        }

        // Get all product names including any option products from the quote data
        for (LinkedHashMap<String, String> data : quoteData) {
            expectedProductNames.add(data.get("ProductName"));
            if (data.get("ProductType").equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(",");
                expectedProductNames.addAll(Arrays.asList(optionProducts));
            }
        }

        //verifies proposal line items for multi year quotes
        if (readExcelData(opportunitiesFilePath,TCName,"ContractLength") != null && readExcelData(opportunitiesFilePath,TCName,"ContractLength").equals("Multi-Year")) {

            for (String productName : expectedProductNames) {
                List<WebElement> productElements = driver.findElements(productNameOnProposalLineItemPage(productName));
                String currentStartDate = expectedStartDate;

                for (int i = 0; i < productElements.size(); i++) {
                    scrollToElement(driver, productElements.get(i));
                    WebElement productElement = productElements.get(i);
                    WebElement startDateElement = productElement.findElement(contractStartDateOnProposalLineItemPage());
                    WebElement endDateElement = productElement.findElement(contractEndDateOnProposalLineItemPage());

                    softAssert.assertEquals(startDateElement.getText(), currentStartDate, "The start date for the line item does not match the expected start date.");

                    if (i == productElements.size() - 1) {

                        softAssert.assertEquals(endDateElement.getText(), expectedEndDate, "The end date for the last line item does not match the expected end date.");
                    } else {
                        softAssert.assertEquals(endDateElement.getText(), subtractDays(customDatePlusYears(1,currentStartDate),1), "The end date for the line item does not match the expected end date.");
                    }
                    currentStartDate = customDatePlusYears(1,currentStartDate);
                }
            }
            //For Axis manual price ramp, number of products will be configured on datafile for each year.
            int numberOfExpectedItems;
            if (!manualPriceRamp) {
                numberOfExpectedItems = (expectedProductNames.size() * reusableBusinessLibrary.getMultiYearNumber());
            } else {
                numberOfExpectedItems = expectedProductNames.size();
            }
            Allure.step("Verify that proposal line items are of the correct amount based on how many years the quote is for and how many products were configured" + expectedProductNames, step -> {
                softAssert.assertEquals(actualProductNames.size(), numberOfExpectedItems, "Proposal Line Items are not created for all products and years that were configured and finalized on Apttus");
            });
        }
        else if(TCName.contains("ChangeOppyFullTerminationOnOneLine")) {
            Allure.step("Verify that proposal line item is created for the terminated product: " + terminatedProductName, step -> {
                softAssert.assertTrue(new HashSet<>(actualProductNames).contains(terminatedProductName) && actualProductNames.size() == 1, "Proposal Line Item is not created for the terminated product");
            });

            waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Line Items","Sales Price"));
            List<WebElement> proposalLineItemsPrice = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Line Items","Sales Price"));
            softAssert.assertTrue(getElementText(driver, proposalLineItemsPrice.get(0)).contains("0.00"), "Terminated Product Price is not displayed as 0");

            Allure.step("Verify that Term Start Date is " + expectedStartDate + " on Proposal Line Items ", step -> {
                softAssert.assertTrue(actualStartDates.stream().allMatch(val -> val.equals(expectedStartDate)), "Start Date is not displayed as expected");
            });

            Allure.step("Verify that End Date is " + subtractDays(expectedStartDate, 1) + " on Proposal Line Items ", step -> {
                softAssert.assertTrue(actualEndDates.stream().allMatch(val -> val.equals(subtractDays(expectedStartDate, 1))), "End Date is not displayed as expected");
            });
        }
        else{
            Allure.step("Verify that proposal line item is created for all products that were configured and finalized on Apttus" + expectedProductNames, step -> {
                softAssert.assertTrue(new HashSet<>(actualProductNames).containsAll(expectedProductNames) && new HashSet<>(expectedProductNames).containsAll(actualProductNames), "Proposal Line Item is not created for all products that were configured and finalized on Apttus");
            });

            waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Line Items","Description"));
            List<WebElement> proposalLineItemsProductNames = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Line Items","Description"));
            waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Line Items","Sales Price"));
            List<WebElement> proposalLineItemsPrice = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Line Items","Sales Price"));
            reusableBusinessLibrary.verifyLineItemsPrice(quoteData, proposalLineItemsProductNames, proposalLineItemsPrice);

            Allure.step("Verify that Term Start Date is " + expectedStartDate + " on Proposal Line Items ", step -> {
                softAssert.assertTrue(actualStartDates.stream().allMatch(val -> val.equals(expectedStartDate)), "Start Date is not displayed as expected");
            });

            Allure.step("Verify that End Date is " + expectedEndDate + " on Proposal Line Items ", step -> {
                    softAssert.assertTrue(actualEndDates.stream().allMatch(val -> val.equals(expectedEndDate)), "End Date is not displayed as expected");
            });
        }

        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Proposal Line Items are displayed correctly on the Quote");
        setScreenZoom(driver, 100);
    }
    /**
     * This method adds and configures products on Apttus
     *
     * @param quoteData - The products details to be validated on the Quote
     */
    @Step("Add and configure products on Apttus")
    public void addAndConfigureProductsOnApttus(List<LinkedHashMap<String, String>> quoteData) {
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error("Error occurred while waiting for the page to load" + e.getMessage());
        }
        for (Map<String, String> productData : quoteData) {
            if (!productData.get("ProductType").equals("AutoInclusion")) {
                searchProductByProductCode(productData.get("ProductCode"), productData.get("ProductName"));
                configureProductAttributes(productData);
                waitForElementToBePresent(driver, productFrame(oppyName));
                waitforFrametoLoad(driver, driver.findElement(productFrame(oppyName)));
                if (productData.get("ProductType").equals("RMS")){
                    verifyRMSProductAttributes(productData);
                    updateRMSProductAttribute(); //Added this method temporarily to update the attribute value for the RMS Package product in order to calculate pricing.
                }
                if (productData.get("ProductType").equals("Kompany")){
                    updateKompanyProductAttribute(); //Added this method temporarily to update the attribute value for the Kompany product in order to calculate pricing.
                }
                if (productData.get("ProductType") != null && productData.get("ProductType").equals("Bundle")) {
                    waitForElementToBeVisible(driver, productOptionsTabOnApttus);
                    elementClick(driver, productOptionsTabOnApttus);
                    verifyOptionProductsOnApttusConfigPage(productData);
                }
                if (productData.get("ProductName").equals("Trade Optimizer")) {
                    verifyTradeOptimizerWarningMessageOnApttus();
                }
                if (productData != quoteData.get(quoteData.size() - 1)) {
                    waitForElementToBeVisible(driver, addMoreProductsBtnOnApttus);
                    elementClickByJS(driver, addMoreProductsBtnOnApttus);
                }
                driver.switchTo().defaultContent();
            }
        }
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, cartIconOnApttus);
        elementClickByJS(driver, cartIconOnApttus);
        waitForElementToBeVisible(driver, viewCartButtonOnApttus);
        elementClickByJS(driver, viewCartButtonOnApttus);
        driver.switchTo().defaultContent();
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error("Error occurred while waiting for the page to load");
        }
        configureAutoInclusionProducts(quoteData);
    }

    /**
     * This method configures the mass price ramp for the products listed in the quote data.
     * It navigates to the Price Ramp page, selects the checkboxes for each product, and applies the price ramps.
     */
    @Step("Perform Mass Price Ramp")
    public void configurePriceRamp()
    {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        elementClick(driver, massPriceRampButton);
        driver.switchTo().defaultContent();
        waitForPageTitleToContain(driver, "PriceRampPage");
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, applyPriceRampsBtn);
        elementClick(driver, lineItemCheckBoxOnMassPriceRampPage);
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Successfully configured mass price ramp");
        elementClick(driver, applyPriceRampsBtn);
        driver.switchTo().defaultContent();
    }

    /**
     * This method finalizes the Quote
     */
    @Step("Finalize Quote")
    public void finalizeQuote() {
        try {
            Thread.sleep(12000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error("Error occurred while waiting for the page to load");
        }
        waitForPageTitleToContain(driver, "Salesforce");
        waitForPageTitleToContain(driver, oppyName);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToDisappear(driver, repriceCartProgressBar);
        if (isElementDisplayed(driver, repriceButtonOnApttusCart))
            elementClickByJS(driver, repriceButtonOnApttusCart);
        waitForElementToBeClickable(driver, finalizeButtonOnApttusCart);
        setScreenZoom(driver, 75);
        takeScreenshot(TCName, driver);
        elementClick(driver, finalizeButtonOnApttusCart);
        elementClickByJS(driver, finalizeButtonOnApttusCart); // Click Finalize button again when Quote is reconfigured, first time configuration and finalization will not be affected as we are using JS for the second click
        if (isElementDisplayed(driver, okButtonOnFinalizeConfirmation)) {
            elementClickByJS(driver, okButtonOnFinalizeConfirmation);
            loggerManager.getLogger().info("Clicked on OK button on Finalize Confirmation pop up window");
        }
        switchToDefaultContent(driver);
        waitForUrlToContain(driver, "Apttus_Proposal__Proposal__c");
        waitForPageTitleToContain(driver, "Quote/Proposal");
        Assert.assertTrue(driver.getTitle().contains("Quote/Proposal"), "Failed to finalize the Quote");
        loggerManager.getLogger().info("Quote finalized successfully");
        proposalRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
        loggerManager.getLogger().info("Proposal Record ID: " + proposalRecordID + " is written to the Excel sheet");
    }

    /**
     * This method verifies that option products are displayed as expected with the bundle product on the Apttus configuration page.
     * It checks if each option product is displayed and selects the product if it is not already selected.
     *
     * @param productData - A map containing product data, including option products to be verified.
     */
    @Step("Verify that option products are displayed as expected with the bundle product on Apttus configuration page")
    public void verifyOptionProductsOnApttusConfigPage(Map<String, String> productData) {
        List<String> optionProducts = Arrays.asList(productData.get("OptionProducts").split(","));

        for (String optionProduct : optionProducts) {
            //check that option product is displayed
            waitForElementToBeVisible(driver, optionProductCheckboxLabel(optionProduct));
            Assert.assertTrue(isElementDisplayed(driver, optionProductCheckboxLabel(optionProduct)), "Option Product " + optionProduct + " is not displayed on the Apttus configuration page");
            //if the option product is not checked then check the product
            try{
                if(optionProductCheckbox(optionProduct).getAttribute("checked") == null){
                    elementClickByJS(driver, optionProductCheckboxLabel(optionProduct));
                }
            }
            catch (Exception e){
                loggerManager.getLogger().error("Not able to check the option product: " + optionProduct);
            }

        }

        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Option Products are displayed and checked as expected on the Apttus configuration page");

    }

    /**
     * This method verifies that Ready for Agreement button is displayed on the Quote
     *
     */
    @Step("Verify that Ready for Agreement button is displayed on the Quote")
    public void verifyReadyForAgreementButton(){
        scrollToElement(driver, defaultNamedUsersLabel);
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedList("Orders"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.relatedList("Orders")));
        if (isElementDisplayed(driver, readyForAgreementBtn)) {
            Assert.assertTrue(isElementDisplayed(driver, readyForAgreementBtn), "Ready for Agreement button is not displayed on the Quote");
            loggerManager.getLogger().info("Ready for Agreement button is displayed on the Quote");
        } else {
            Assert.fail("Ready for Agreement button is not displayed on the Quote");
            loggerManager.getLogger().error("Ready for Agreement button is not displayed on the Quote");
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks on Create Agreement with Line Items button on the Quote
     */
    @Step("Click on Create Agreement with Line Items button")
    public void clickOnCreateAgreementWithLineItemsBtn(){
        waitForElementToBeVisible(driver, createAgreementWithLineItemsAction);
        elementClickByJS(driver, createAgreementWithLineItemsAction);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, "Agreement | Salesforce");
        waitForUrlToContain(driver, "Apttus__APTS_Agreement__c");
        Assert.assertEquals(driver.getTitle(), "Agreement | Salesforce", "Failed to navigate to Agreement record");
        loggerManager.getLogger().info("Successfully clicked on Create Agreement with Line Items button");
    }

    /**
     * This method gets the value of Quote Total
     *
     * @return - The value of Quote Total
     */
    @Step("Get the value of Quote Total")
    public String getQuoteTotal(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Quote Total"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Quote Total")));
    }

    /**
     * This method gets the value of Proposal ID field on the Quote
     *
     * @return - The value of Proposal ID
     */
    @Step("Get the value of Proposal ID")
    public String getProposalID(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Proposal ID"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Proposal ID")));
    }

    /**
     * This method gets the value of Opportunity Name on the Quote
     *
     * @return - The value of Opportunity Name
     */
    @Step("Get the value of Opportunity Name")
    public String getOpportunityName(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.linkFieldValue("Opportunity"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.linkFieldValue("Opportunity")));
    }

    /**
     * This method configures the auto inclusion products on the Quote
     *
     * @param - The product details from the quote data
     */
    public void configureAutoInclusionProducts(List<LinkedHashMap<String, String>> quoteData){
        for (Map<String, String> productData : quoteData) {
            waitforFrametoLoad(driver, apttusCatalogIframe);
            if (productData.get("ProductType").equals("AutoInclusion"))
            {
                waitForElementToBePresent(driver, productNameOnApttusCart(productData.get("ProductName")));
                for (int i = 0; i < cartLineItemsProductNames.size(); i++) {
                    scrollToElement(driver, cartLineItemsProductNames.get(i));
                    if (getElementText(driver, cartLineItemsProductNames.get(i)).equals(productData.get("ProductName"))) {
                        break;
                    }
                }
                waitForElementToBePresent(driver, configureProductWrenchIconOnCart(productData.get("ProductName")));
                elementClickByJS(driver, driver.findElement(configureProductWrenchIconOnCart(productData.get("ProductName"))));
                switchToDefaultContent(driver);
                configureProductAttributes(productData);
                switch (TCName){
                    case "verifySingleYearQuoteCreation_RMSPackageProducts":
                        verifyRMSProductAttributes(productData);
                        break;
                    default:
                        break;
                }
                waitforFrametoLoad(driver, apttusCatalogIframe);
                waitForElementToBeVisible(driver, cartIconOnApttus);
                elementClickByJS(driver, cartIconOnApttus);
                waitForElementToBeVisible(driver, viewCartButtonOnApttus);
                elementClickByJS(driver, viewCartButtonOnApttus);
                switchToDefaultContent(driver);
                try {
                    Thread.sleep(15000);
                } catch (InterruptedException e) {
                    loggerManager.getLogger().error("Error occurred while waiting for the page to load");
                }
                loggerManager.getLogger().info("Configured auto inclusion product: " + productData.get("ProductName"));
            }
            switchToDefaultContent(driver);
        }
    }

    /**
     * This method verifies that warning message is displayed for Trade Optimizer product on Apttus
     */
    @Step("Verify warning message for Trade Optimizer product on Apttus")
    public void verifyTradeOptimizerWarningMessageOnApttus(){
        waitForElementToBeVisible(driver, tradeOptimizerWarningMessage);
        Assert.assertTrue(isElementDisplayed(driver, tradeOptimizerWarningMessage), "Warning message for Trade Optimizer product is not displayed on Apttus");
        loggerManager.getLogger().info("Warning message for Trade Optimizer product warning message is displayed on the Quote");
    }

    /**
     * This method navigates to the Transaction Locations related list on the Quote
     */
    @Step("Navigate to Transaction Locations related list")
    public void navigateToTransactionLocationsRelatedList(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        for (int i = 0; i < 3; i++) {
            pageRefresh(driver);
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
            if (!isElementDisplayed(driver, quoteWarningMessage)) {
                break;
            }
            try {
                Thread.sleep(4000);
            } catch (InterruptedException e) {
                loggerManager.getLogger().error(e.getMessage());
            }
        }
        reusableBusinessLibrary.openSFDCSubTab("Related");
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedList("Line Items"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.relatedList("Line Items")));
        reusableBusinessLibrary.clickOnRelatedList("Locations");
        waitForPageTitle(driver, "Locations | Salesforce");
        Assert.assertEquals(driver.getTitle(),"Locations | Salesforce", "Failed to navigate to Locations related list");
        loggerManager.getLogger().info("Successfully navigated to Locations related list");
    }

    /**
     * This method verifies the Transaction Locations on the Quote
     *
     * @param quoteData - The product details from the quote data
     */
    public void verifyTransactionLocations(List<LinkedHashMap<String, String>> quoteData) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        setScreenZoom(driver, 75);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Locations"));
        List<WebElement> transactionLocations = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Locations"));
        for (WebElement transactionLocation : transactionLocations) {
            waitForElementToBeVisible(driver, transactionLocation);
            String dataLabel = transactionLocation.getAttribute("data-label");
            if (dataLabel != null)
                if (dataLabel.equals("Product")) {
                    actualProductNames.add(getElementText(driver, transactionLocation));
                }
        }
        // Get all product names including any option products from the quote data
        for (LinkedHashMap<String, String> data : quoteData) {
            expectedProductNames.add(data.get("ProductName"));
            if (data.get("ProductType").equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(",");
                expectedProductNames.addAll(Arrays.asList(optionProducts));
            }
        }
        Allure.step("Verify that transaction locations are created for all products that were configured and finalized on Apttus" + expectedProductNames, step -> {
            takeScreenshot(TCName, driver);
            Assert.assertTrue(new HashSet<>(actualProductNames).containsAll(expectedProductNames), "Transaction Locations are not created for all products that were configured and finalized on Apttus. Actual: " + actualProductNames + " Expected: " + expectedProductNames);
            loggerManager.getLogger().info("Transaction Locations are displayed correctly on the Quote");
        });
        setScreenZoom(driver, 100);
    }

    /**
     * This method verifies the value of Approval Stage on the Quote
     */
    @Step("Verify that value of Approval Stage is {expectedStage}")
    public void verifyQuoteStage(String expectedStage){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Approval Stage"));
        takeScreenshot(TCName, driver);
        Assert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Approval Stage"))), expectedStage, "Approval Stage is not displayed as expected.");
        loggerManager.getLogger().info("Approval Stage is displayed as " + expectedStage);
    }

    /**
     * This method adjusts the first usage tier for overage line
     * Hemal Shah: updated method to handle multiple year entries
     */
    @Step("Adjust first usage tier for overage line")
    public void adjustFirstUsageTierForOverageLine(List<LinkedHashMap<String, String>> quoteData){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToDisappear(driver, repriceCartProgressBar);
        waitForElementToBeClickable(driver, finalizeButtonOnApttusCart);
        int multiYear = 1;
        for (Map<String, String> productData : quoteData) {
            if (productData.get("ProductType").equals("Bundle")) {
                waitForElementToBePresent(driver,cartLineMoreActionHoverArea(productData.get("OptionProducts"),multiYear));
                scrollToElement(driver, driver.findElement(cartLineMoreActionHoverArea(productData.get("OptionProducts"),multiYear)));
                moveToElement(driver, driver.findElement(cartLineMoreActionHoverArea(productData.get("OptionProducts"),multiYear)));
                elementClickByJS(driver, driver.findElement(cartLineMoreActionIcon(productData.get("OptionProducts"),multiYear)));
                waitForElementToBePresent(driver, cartLineActionBtn("Usage Price Tiers"));
                elementClickByJS(driver, driver.findElement(cartLineActionBtn("Usage Price Tiers")));
                multiYear = multiYear + 1;
                waitForElementToBeVisible(driver, noOfCommittedUsersOnTier1);
                noOfCommittedUsersOnTier1.click();
                noOfCommittedUsersOnTier1.clear();
                Actions actions = new Actions(driver);
                actions.moveToElement(noOfCommittedUsersOnTier1).click().keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).sendKeys(Keys.BACK_SPACE).build().perform();
                actions.moveToElement(noOfCommittedUsersOnTier1).click().sendKeys(productData.get("Number of Users_txt")).build().perform();
                waitForElementToBeVisible(driver, saveUsagePriceTierBtn);
                takeScreenshot(TCName, driver);
                elementClick(driver, saveUsagePriceTierBtn);
                loggerManager.getLogger().info("Adjusted usage tier for overage line: " + productData.get("OptionProducts"));
            }
        }
    }

    /**
     * This method validates the cart page
     * @param quoteData - The product details from the quote data
     */
    @Step("Validate Cart Page")
    public void validateCartPage(List<LinkedHashMap<String, String>> quoteData){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, finalizeButtonOnApttusCart);
        setScreenZoom(driver, 75);
        verifyCartLineItemsPrice(quoteData);
        verifyCartTotalValues();
        switchToDefaultContent(driver);
    }

    /**
     * This method verifies the auto populated attribute values for RMS Package products
     *
     * @param productData - The product details from the quote data
     */
    @Step("Extract and validate auto-populated product attributes")
    public void verifyRMSProductAttributes(Map<String, String> productData) {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, validateButtonOnProductConfig);
        elementClick(driver, validateButtonOnProductConfig);

        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, addMoreProductsBtnOnApttus);

        // Initialize an ArrayList to store the text values
        List<String> attributeValuesList = new ArrayList<>();

        String mandatoryAttributes = productData.get("Mandatory Attributes");
        if (mandatoryAttributes != null && !mandatoryAttributes.isEmpty()) {
            String[] attributes = mandatoryAttributes.split(",");
            for (String attributeName : attributes) {
                attributeName = attributeName.trim();
                By attributeLocator = attributeNameOnProductConfig(attributeName);
                List<WebElement> attributeElements = driver.findElements(attributeLocator);

                // Log the number of elements found
                loggerManager.getLogger().info("Found " + attributeElements.size() + " elements for attribute: " + attributeName);

                // Iterate through the web elements and add their text values to the list
                for (WebElement element : attributeElements) {
                    String text = element.getText();
                    attributeValuesList.add(text);
                    loggerManager.getLogger().info("Added attribute value: " + text + " for attribute: " + attributeName);
                }
            }
        } else {
            loggerManager.getLogger().warn("No mandatory attributes found for product data: " + productData);
        }

        // Assert that attributeValuesList is not empty
        softAssert.assertFalse(attributeValuesList.isEmpty(), "Attribute values list is empty.");

        // Compare the values in attributeValuesList with the values in the productData
        if (mandatoryAttributes != null && !mandatoryAttributes.isEmpty()) {
            String[] attributes = mandatoryAttributes.split(",");
            for (String attributeName : attributes) {
                attributeName = attributeName.trim();
                String[] expectedValues = productData.get(attributeName).split(",");
                for (String expectedValue : expectedValues) {
                    boolean isPresent = attributeValuesList.contains(expectedValue.trim());
                    loggerManager.getLogger().info("Attribute value " + expectedValue + " is " + (isPresent ? "present" : "not present") + " in the list.");
                    // Assert that the expected value is present in the list
                    softAssert.assertTrue(isPresent, "Attribute value " + expectedValue + " is not present in the list.");
                }
            }
        }
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
    }

    /**
     * This method updates the attribute value for Calculation of RMS Package Products
     */
    @Step("Update the attribute value for Calculation of RMS Package Products.")
    public void updateRMSProductAttribute(){
        WebElement element;
        waitForElementToBePresent(driver, dropdownAttribute("Size"));
        element = driver.findElement(dropdownAttribute("Size"));
        elementClickByJS(driver, element);
        elementClickByJS(driver, driver.findElement(dropdownOption("Size","Large")));
        loggerManager.getLogger().info("Attribute values udpdated after validation");
        waitForElementToBeVisible(driver, validateButtonOnProductConfig);
        elementClick(driver, validateButtonOnProductConfig);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        setScreenZoom(driver, 50);
        takeScreenshot(TCName, driver);
        if(isPageVerticallyScrollable(driver)){
            scrollToBottom(driver);
            takeScreenshot(TCName, driver);
        }
        setScreenZoom(driver, 75);
    }

    /**
     * This method validates the Level 1 Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify Approval Level 1")
    public void verifyLevel1ApprovalOnNewSaleQuote(List<LinkedHashMap<String, String>> quoteData){
        verifyApprovalLevel1A(quoteData);
        verifyApprovalLevel1B(quoteData);
        verifyApprovalLevel1C(quoteData);
    }

    /**
     * This method validates the Level 1A Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify Approval Level 1A")
    public void verifyApprovalLevel1A(List<LinkedHashMap<String, String>> quoteData) {
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        applyAdjustmentOnAllProducts(quoteData.get(0).get("AdjustmentType"), quoteData.get(0).get("AdjustmentAmount"));
        validateCartPage(quoteData);
        finalizeQuote();
        loggerManager.getLogger().info("New Sale Approval Level 1A validation is successful");
    }

    /**
     * This method validates the Level 1B Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify Approval Level 1B")
    public void verifyApprovalLevel1B(List<LinkedHashMap<String, String>> quoteData) {
        openRecordBySFDCID(oppyID);
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        applyAdjustmentOnAllProducts(quoteData.get(1).get("AdjustmentType"), quoteData.get(1).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "LineManager"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level1B"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 1B validation is successful");
        proposalRecordID = proposalRecordID + "," + getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method validates the Level 1C Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify Approval Level 1B")
    public void verifyApprovalLevel1C(List<LinkedHashMap<String, String>> quoteData) {
        openRecordBySFDCID(oppyID);
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        applyAdjustmentOnAllProducts(quoteData.get(2).get("AdjustmentType"), quoteData.get(2).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Segment Lead / MD"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level1C"));
        clickOnReturnToCartBtn();
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 1C validation is successful");
        proposalRecordID = proposalRecordID + "," + getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method clicks on Submit for Approval button on the cart
     */
    @Step("Click on Submit for Approval button")
    public void clickOnSubmitForApprovalBtn(){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, submitForApprovalBtn);
        elementClickByJS(driver, submitForApprovalBtn);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToDisappear(driver, previewingApprovalsDialog);
        if(TCName.contains("ChangeOppy")) {
            waitForPageTitleToContain(driver, "Quote/Proposal");
            Assert.assertTrue(driver.getTitle().contains("Quote/Proposal"), "Failed to navigate to Cart Approvals page");
        }
        else {
            waitForPageTitle(driver, "Apttus_CQApprov__CartApprovals | Salesforce");
            Assert.assertEquals(driver.getTitle(), "Apttus_CQApprov__CartApprovals | Salesforce", "Failed to navigate to Cart Approvals page");
        }
        loggerManager.getLogger().info("Clicked on Submit for Approval button");
        switchToDefaultContent(driver);
    }

    /**
     * This method validates the Approval Page
     * @param expectedApprover - The expected approver for the approval request
     * @param expectedApprovalDetails - The expected approval details
     */
    @Step("Verify details on the Approval Page")
    public void validateApprovalDetails(String expectedApprover, String expectedApprovalDetails){
        try {
            Thread.sleep(15000);
        }
        catch (InterruptedException e){
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForElementToDisappear(driver, previewingApprovalsDialog);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        Allure.step("Verify that Approval Request is assigned to the correct approver: " + expectedApprover, step->{
            waitForElementToBePresent(driver, approvalTableColumnValue(getColumnNumber(driver, approvalsTable, "Assigned To")));
            String assignedTo = getElementText(driver, driver.findElement(approvalTableColumnValue(getColumnNumber(driver, approvalsTable, "Assigned To"))));
            softAssert.assertEquals(assignedTo, expectedApprover, "Approval request is not assigned to the expected approver");
            loggerManager.getLogger().info("Approval request is assigned to the expected approver " + assignedTo);
        });
        Allure.step("Verify that Approval Details column value is displayed as expected: " + expectedApprovalDetails, step->{
            waitForElementToBePresent(driver, approvalTableColumnValue(getColumnNumber(driver, approvalsTable, "Approval Details")));
            String approvalDetails = null;
            approvalDetails = getElementText(driver, driver.findElement(approvalTableColumnValue(getColumnNumber(driver, approvalsTable, "Approval Details"))));
            softAssert.assertEquals(approvalDetails, expectedApprovalDetails, "Approval details are not displayed as expected");
            loggerManager.getLogger().info("Approval details are displayed as expected");
        });
        switchToDefaultContent(driver);
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
    }

    /**
     * This method clicks on Return to Cart button on the Approval page
     */
    @Step("Click on Return to Cart button")
    public void clickOnReturnToCartBtn(){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBePresent(driver, apttusApprovalPageBtn("Return to Cart"));
        elementClickByJS(driver, driver.findElement(apttusApprovalPageBtn("Return to Cart")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForPageTitle(driver, oppyName + " | Salesforce");
        Assert.assertEquals(driver.getTitle(), oppyName + " | Salesforce", "Failed to navigate to click on Return to Cart button");
        loggerManager.getLogger().info("Clicked on Return to Cart button successfully");
        switchToDefaultContent(driver);
    }

    /**
     * This method saves the cart
     */
    @Step("Save the Cart")
    public void saveCart(){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, apttusMoreActionsMenuBtn);
        elementClickByJS(driver, apttusMoreActionsMenuBtn);
        waitForElementToBeVisible(driver, saveCartBtn);
        elementClickByJS(driver, saveCartBtn);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, "Quote/Proposal | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Quote/Proposal | Salesforce"), "Failed to save the cart");
        switchToDefaultContent(driver);
        loggerManager.getLogger().info("Cart saved successfully");
    }

    /**
     * This method validates the Level 2A Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 2A")
    public void verifyApprovalLevel2A(List<LinkedHashMap<String, String>> quoteData) {
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        switchToDefaultContent(driver);
        applyAdjustmentOnAllProducts(quoteData.get(0).get("AdjustmentType"),quoteData.get(0).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "LineManager"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level2A"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 2A validation is successful");
        proposalRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method validates the Level 2B Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 2B")
    public void verifyApprovalLevel2B(List<LinkedHashMap<String, String>> quoteData) {
        openRecordBySFDCID(oppyID);
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        applyAdjustmentOnAllProducts(quoteData.get(1).get("AdjustmentType"), quoteData.get(1).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Segment Lead / MD"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level2B"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 2B validation is successful");
        proposalRecordID = proposalRecordID + "," +getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method verifies the Level 2 Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 2")
    public void verifyLevel2ApprovalOnNewSaleQuote(List<LinkedHashMap<String, String>> quoteData){
        verifyApprovalLevel2A(quoteData);
        verifyApprovalLevel2B(quoteData);
    }

    /**
     * This method applies adjustment on all products
     * @param adjustmentType - The type of adjustment to be applied
     * @param adjustmentAmount - The amount of adjustment to be applied
     *
     */
    @Step("Apply {adjustmentType} of {adjustmentAmount} on all products")
    public void applyAdjustmentOnAllProducts(String adjustmentType, String adjustmentAmount){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, grandTotalIconOnApttusCart);
        elementClickByJS(driver, grandTotalIconOnApttusCart);
        switchToDefaultContent(driver);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, adjustmentAmountInputOnCartTotal);
        sendKeysToElement(driver, adjustmentAmountInputOnCartTotal, adjustmentAmount);
        try {
            Thread.sleep(3000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForElementToBeVisible(driver, adjustmentTypeDropdownOnCartTotal);
        elementClickByJS(driver, adjustmentTypeDropdownOnCartTotal);
        waitForElementToBePresent(driver, adjustmentTypeDropdownOption(adjustmentType));
        elementClickByJS(driver, driver.findElement(adjustmentTypeDropdownOption(adjustmentType)));
        try {
            Thread.sleep(3000);
        }
        catch (InterruptedException e){
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForElementToBeVisible(driver, repriceButtonOnApttusCart);
        elementClickByJS(driver, repriceButtonOnApttusCart);
        waitForElementToBeVisible(driver, grandTotalIconOnApttusCart);
        elementClickByJS(driver, grandTotalIconOnApttusCart);
        switchToDefaultContent(driver);
        verifyNetAdjustmentPercentOnCartLines();
        loggerManager.getLogger().info("Applied " + adjustmentType + " of " + adjustmentAmount + " on all products");
    }

    /**
     * This method verifies the Level 3 Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 3")
    public void verifyLevel3ApprovalOnNewSaleQuote(List<LinkedHashMap<String, String>> quoteData){
        verifyApprovalLevel3A(quoteData);
        verifyApprovalLevel3B(quoteData);
    }

    /**
     * This method verifies the Level 3A Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 3A")
    public void verifyApprovalLevel3A(List<LinkedHashMap<String, String>> quoteData) {
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        switchToDefaultContent(driver);
        applyAdjustmentOnAllProducts(quoteData.get(0).get("AdjustmentType"),quoteData.get(0).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Segment Lead / MD"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level3A"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 3A validation is successful");
        proposalRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method verifies the Level 3B Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 3B")
    public void verifyApprovalLevel3B(List<LinkedHashMap<String, String>> quoteData) {
        openRecordBySFDCID(oppyID);
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        applyAdjustmentOnAllProducts(quoteData.get(1).get("AdjustmentType"), quoteData.get(1).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Regional GM"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level3B"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 3B validation is successful");
        proposalRecordID = proposalRecordID + "," +getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method verifies the Net Adjustment Percent on all cart lines
     */
    @Step("Verify that adjustment is applied successfully on all lines")
    public void verifyNetAdjustmentPercentOnCartLines(){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, submitForApprovalBtn);
        for (WebElement netAdjustmentPercent : netAdjustmentPercentOnCartLines) {
            waitForElementToBeVisible(driver, netAdjustmentPercent);
            softAssert.assertNotEquals(getElementText(driver, netAdjustmentPercent), "0.00%", "Net Adjustment Percent is displayed as 0");
        }
        switchToDefaultContent(driver);
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Adjustment is applied successfully on all lines");
    }

    /**
     * This method applies adjustment on first product in the cart
     * @param adjustmentType - The type of adjustment to be applied
     * @param adjustmentAmount - The amount of adjustment to be applied
     */
    @Step("Apply {adjustmentType} of {adjustmentAmount} on first product")
    public void applyAdjustmentOnFirstProduct(String adjustmentType, String adjustmentAmount){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, adjustmentTypeDropdownOnCartLine);
        elementClickByJS(driver, adjustmentTypeDropdownOnCartLine);
        waitForElementToBeVisible(driver, adjustmentAmountTextfieldOnCartLine);
        sendKeysToElement(driver, adjustmentAmountTextfieldOnCartLine, adjustmentAmount);
        waitForElementToBePresent(driver, adjustmentTypeDropdownOption(adjustmentType));
        elementClickByJS(driver, driver.findElement(adjustmentTypeDropdownOption(adjustmentType)));
        waitForElementToDisappear(driver, repriceCartProgressBar);
        waitForElementToBeVisible(driver, repriceButtonOnApttusCart);
        elementClick(driver, repriceButtonOnApttusCart);
        switchToDefaultContent(driver);
        loggerManager.getLogger().info("Applied {} of {} on first product", adjustmentType, adjustmentAmount);
    }

    /**
     * This method verifies the Level 4 Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 4")
    public void verifyLevel4ApprovalOnNewSaleQuote(List<LinkedHashMap<String, String>> quoteData){
        verifyApprovalLevel4A(quoteData);
        verifyApprovalLevel4B(quoteData);
    }

    /**
     * This method verifies the Level 4A Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 4A")
    public void verifyApprovalLevel4A(List<LinkedHashMap<String, String>> quoteData) {
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        switchToDefaultContent(driver);
        applyAdjustmentOnFirstProduct(quoteData.get(0).get("AdjustmentType"),quoteData.get(0).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Regional GM"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level4A"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 4A validation is successful");
        proposalRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method verifies the Level 4B Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 4B")
    public void verifyApprovalLevel4B(List<LinkedHashMap<String, String>> quoteData) {
        openRecordBySFDCID(oppyID);
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        applyAdjustmentOnFirstProduct(quoteData.get(1).get("AdjustmentType"), quoteData.get(1).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Global Head of Sales"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level4B"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 4B validation is successful");
        proposalRecordID = proposalRecordID + "," +getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method verifies the Level 5 Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 5")
    public void verifyLevel5ApprovalOnNewSaleQuote(List<LinkedHashMap<String, String>> quoteData){
        verifyApprovalLevel5A(quoteData);
        verifyApprovalLevel5B(quoteData);
    }

    /**
     * This method verifies the Level 5A Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 5A")
    public void verifyApprovalLevel5A(List<LinkedHashMap<String, String>> quoteData) {
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        switchToDefaultContent(driver);
        applyAdjustmentOnFirstProduct(quoteData.get(0).get("AdjustmentType"),quoteData.get(0).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Regional GM"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level5A"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 5A validation is successful");
        proposalRecordID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    /**
     * This method verifies the Level 5B Approval on New Sale Quote
     * @param quoteData - The product details from the quote data
     */
    @Step("Verify New Sale Quote Approval for Level 5B")
    public void verifyApprovalLevel5B(List<LinkedHashMap<String, String>> quoteData) {
        openRecordBySFDCID(oppyID);
        opportunityPage.createQuoteFromOpportunity();
        addAndConfigureProductsOnApttus(quoteData);
        applyAdjustmentOnFirstProduct(quoteData.get(1).get("AdjustmentType"), quoteData.get(1).get("AdjustmentAmount"));
        clickOnSubmitForApprovalBtn();
        validateApprovalDetails(readExcelData(quotesFilePath, TCName, "Global Head of Sales"),readExcelData(quotesFilePath, TCName, "ExpectedApprovalDetails_Level5B"));
        clickOnReturnToCartBtn();
        validateCartPage(quoteData);
        saveCart();
        loggerManager.getLogger().info("New Sale Approval Level 5B validation is successful");
        proposalRecordID = proposalRecordID + "," +getSFDCRecordIDFromURL(driver.getCurrentUrl());
        writeToExcel(quotesFilePath,TCName,"SFDCRecordID", proposalRecordID);
    }

    @Step("Update the attribute value for Calculation of Kompany Products.")
    public void updateKompanyProductAttribute() {
        WebElement element;
        waitForElementToBeVisible(driver, validateButtonOnProductConfig);
        elementClick(driver, validateButtonOnProductConfig);

        if (isElementPresent(driver, dropdownAttribute("Subscription Type"))) {
            element = driver.findElement(dropdownAttribute("Subscription Type"));
            elementClickByJS(driver, element);
            elementClickByJS(driver, driver.findElement(dropdownOption("Subscription Type", "Renewable")));
            loggerManager.getLogger().info("Attribute values updated after validation");
            waitForElementToBeVisible(driver, validateButtonOnProductConfig);
            elementClick(driver, validateButtonOnProductConfig);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            takeScreenshot(TCName, driver);
        } else {
            loggerManager.getLogger().info("Dropdown attribute 'Subscription Type' is not available, skipping attribute update.");
        }
    }

    @Step("Click on Clone with Line Items button")
    public void clickCloneLineItem() {
        waitForElementToBeClickable(driver, cloneWithLineItemsBtn);
        elementClick(driver, cloneWithLineItemsBtn);
        loggerManager.getLogger().info("Clicked on Clone with Line Items button");
    }

    @Step("Validate Clone Quote Info")
    public void validateCloneQuote() {
        pageRefresh(driver);
        waitForElementToBeVisible(driver, configureProductsBtn);
        softAssert.assertFalse(trialCheckbox.isSelected(), "Trial checkbox is selected");
        softAssert.assertTrue(primaryCheckbox.isSelected(), "Primary checkbox is not selected");
        oppyName= getElementText(driver, getOpportunityName);
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
    }

    @Step("Click on Configure Products button")
    public void clickConfigureProduct() {
        waitForElementToBeClickable(driver, configureProductsBtn);
        elementClick(driver, configureProductsBtn);
        loggerManager.getLogger().info("Clicked on Configure Products button");
    }

    @Step("Verify Cart Total is not zero")
    public void validateCartTotal() {
        waitForPageTitleToContain(driver, oppyName);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeClickable(driver, repriceButtonOnApttusCart);
        if (isElementDisplayed(driver, repriceButtonOnApttusCart)) {
            elementClick(driver, repriceButtonOnApttusCart);
        }
        waitForElementToBeClickable(driver, finalizeButtonOnApttusCart);
        setScreenZoom(driver, 75);
        verifyCartTotalValues();
        switchToDefaultContent(driver);
    }

    /**
     * This method reconfigures the Quote and submits it for Approval
     */
    @Step("Reconfigure the Quote and submit for Approval")
    public void reconfigureAndSubmitQuoteForApproval(){
        clickQuoteAction("Configure Products");
        waitForPageTitleToContain(driver, readExcelData(opportunitiesFilePath, TCDependency, "OpportunityName"));
        clickOnSubmitForApprovalBtn();
        submitQuoteForApproval();
    }

    /**
     * This method approves the Quote and verifies that the Approval Stage is set to Approved
     */
    @Step("Approve the Quote")
    public void approveQuote(){
        clickQuoteAction("My Approval");
        waitForPageTitle(driver, "My Approvals | Salesforce");
        waitforFrametoLoad(driver, apttusCatalogIframe);
        takeScreenshot(TCName, driver);
        waitForElementToBePresent(driver, approvalPageBtn("Approve"));
        elementClick(driver, driver.findElement(approvalPageBtn("Approve")));
        waitForElementToBePresent(driver, approvalPageBtn("Save"));
        elementClick(driver, driver.findElement(approvalPageBtn("Save")));
        waitForElementToBeVisible(driver, approvedStatusOnApprovalPage);
        takeScreenshot(TCName, driver);
        softAssert.assertTrue(isElementDisplayed(driver, approvedStatusOnApprovalPage), "Failed to approve the Quote");
        loggerManager.getLogger().info("Quote approved successfully");
        waitForElementToBePresent(driver, approvalPageBtn("Return"));
        elementClick(driver, driver.findElement(approvalPageBtn("Return")));
        switchToDefaultContent(driver);
        waitForPageTitleToContain(driver, "Quote/Proposal | Salesforce");
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        Allure.step("Verify that value of Approval Stage is Approved", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Approval Stage"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Approval Stage"))), "Approved", "Approval Stage is not displayed as expected.");
        });
        softAssert.assertAll();
    }

    /**
     * This method clicks on the Quick Action on the Quote
     * @param actionName - The name of the Quick Action to be clicked
     */
    @Step("Click on Quote Action {actionName}")
    public void clickQuoteAction(String actionName) {
        waitForElementToBePresent(driver, reusableBusinessLibrary.quickAction(actionName));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.quickAction(actionName)));
        loggerManager.getLogger().info("Clicked on {} Quote Action", actionName);
    }

    /**
     * This method gets the value of the Expected Start Date on the Quote Record
     *
     * @return - The value of the Expected Start Date on the Quote Record
     */
    @Step("Get the value of Expected Start Date on the Quote Record")
    public String getQuoteExpectedStartDate(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Expected Start Date"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Expected Start Date")));
    }

    /**
     * This method gets the value of the Expected End Date on the Quote Record
     *
     * @return - The value of the Expected End Date on the Quote record
     */
    @Step("Get the value of Expected End Date on the Quote Record")
    public String getQuoteExpectedEndDate(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Expected End Date"));
        return getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Expected End Date")));
    }

    /**
     * This method submits the Quote for Approval
     * @param  quoteRecordID - The Quote Record ID to be submitted for Approval
     *
     */
    @Step("Submit Quote for Approval {approvalLevel}")
    public void submitQuoteForApproval(String quoteRecordID, String approvalLevel) {
        openRecordBySFDCID(quoteRecordID);
        oppyName = getOpportunityName();
        expectedStartDate = getQuoteExpectedStartDate();
        expectedEndDate = getQuoteExpectedEndDate();
        reconfigureAndSubmitQuoteForApproval();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
    }

    /**
     * This method approves the Approval Request on the Quote
     * @param profile - The profile of the user who is approving the request
     * @param quoteRecordID - The Quote Record ID to be approved
     */
    @Step("Approve the Approval Request on the Quote Record {quoteRecordID} as {profile} for {approvalLevel}")
    public void completeApproval(String profile, String quoteRecordID, String approvalLevel) {
        homePage.loginAs(profile);
        homePage.checkMoodysApp();
        openRecordBySFDCID(quoteRecordID);
        approveQuote();
        homePage.logoutFromProxyProfile();
        reusableBusinessLibrary.switchtoMoodysApp();
    }

    /**
     * This method validates the Quote and PLI Details
     * @param quoteRecordID - The Quote Record ID
     * @param opportunityData - The Opportunity Data
     * @param quoteData - The Quote Data
     */
    @Step("Validate Quote and PLI Details")
    public void validateQuoteAndPLIDetails(String quoteRecordID, LinkedHashMap<String, String> opportunityData, List<LinkedHashMap<String, String>> quoteData) {
        homePage.loginAs("Sales Rep");
        homePage.checkMoodysApp();
        openRecordBySFDCID(quoteRecordID);
        verifyNewSaleQuoteDetails(opportunityData);
        verifyReadyForAgreementButton();
        navigateToProposalLineItemsRelatedList();
        verifyProposalLineItems(quoteData);
    }
    /**
     * This method edits and enters the Default Category and Default Reason fields on a Quote.
     */
    @Step("Edits and enters the Default Category field as {defaultCategory} and Default Reason field as {defaultReason} a Quote")
    public void enterDefaultCategoryAndDefaultReasonFieldOnQuote(String defaultCategory, String defaultReason) {
        pageRefresh(driver);
        elementClick(driver, editDefaultCategoryBtn);
        waitForElementToBeVisible(driver, defaultCategoryDropdown);
        elementClick(driver, defaultCategoryDropdown);
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement(defaultCategory)));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("Default Reason")));
        elementClick(driver, driver.findElement(defaultReasonPicklistOption(defaultReason)));
        loggerManager.getLogger().info("Default Category and default reason fields have been entered into proposal");
    }
    /**
     * This method validates the Default Category and Default Reason fields on a Quote.
     */
    @Step("Validate Default Category and Default Reason field on Quote")
    public void validateDefaultCategoryAndDefaultReasonFieldOnQuote(String defaultCategory, String defaultReason) {
        pageRefresh(driver);
        waitForElementToBeVisible(driver, defaultCategoryValidationField);
        Assert.assertEquals(getElementText(driver, defaultCategoryValidationField),defaultCategory , "Default Category field is not displayed as expected");
        Assert.assertEquals(getElementText(driver, defaultReasonValidationField), defaultReason, "Default Reason field is not displayed as expected");
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Default Category and default reason fields are validated successfully");
    }
    /**
     * This method clicks on "Configure Products" Button on the quote page
     */
    @Step("Click 'Configure Products' Button on Quote Page")
    public void clickConfigureProductsOnQuote() {
        pageRefresh(driver);
        waitForElementToBeVisible(driver, configureProductsBtn);
        scrollToElement(driver, configureProductsBtn);
        elementClick(driver, configureProductsBtn);
        waitForElementToBeVisible(driver, cartIconOnApttus);
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Successfully clicked on configure products on Proposal page and navigated to Apptus CPQ page");
    }

    /**
     * This method clicks on "Catalog Products" Button in Apptus CPQ
     */
    @Step("Click on 'Catalog Products' Button in Apptus CPQ")
    public void clickCatalogProducts() {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, catalogProductsBtn);
        elementClick(driver, catalogProductsBtn);
        waitForElementToBeVisible(driver, findProductsSearchBoxOnApttus);
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Successfully navigated to Catalog Products page on Apptus CPQ");
    }

    /**
     * This method copies the line items in the cart based on the number of years and products.
     * It reads the number of years from the Excel sheet and calculates the number of products
     * from the provided quote data. The method then performs the necessary actions to copy
     * the line items accordingly.
     *
     * @param quoteData - The list of quote data containing product details.
     */
    @Step("Manually copy the Line items in the Cart as per the number of years and products")
    public void copyLineItemsAsPerNumberOfYear(List<LinkedHashMap<String, String>> quoteData) {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToDisappear(driver, repriceCartProgressBar);

        // Read number of products and number of years from Excel sheet
        int numberOfYears = reusableBusinessLibrary.getMultiYearNumber();
        int numberOfProducts = quoteData.size();
        loggerManager.getLogger().info("Number of products: " + numberOfProducts + ", Number of years: " + numberOfYears);

        waitForElementToBeClickable(driver, productCheckboxOnCartPage);

        // Find all elements once and limit to numberOfProducts
        List<WebElement> elements = driver.findElements(By.xpath("//div[@class='ui-grid-viewport']//following::div[@class='grid-checkbox']"))
                .stream().limit(numberOfProducts).collect(Collectors.toList());

        for (int year = 1; year < numberOfYears; year++) {
            // Click on each element in the list
            elements.forEach(WebElement::click);
            // Click on the copy button
            copyButtonOnCart.click();
            loggerManager.getLogger().info("Product added for year: " + year);

            waitForElementToBeVisible(driver, repriceCartProgressBar);
            waitForElementToDisappear(driver, repriceCartProgressBar);
        }

        try {
            if(repriceButtonOnApttusCart.isDisplayed()){
                elementClick(driver, repriceButtonOnApttusCart);
            }
        } catch (Exception e) {
            loggerManager.getLogger().error("Error while clicking the reprice button on Apttus cart: ", e);
        }
        waitForElementToDisappear(driver, repriceCartProgressBar);
        waitForElementToBeVisible(driver, finalizeButtonOnApttusCart);
        takeScreenshot(TCName, driver);
        switchToDefaultContent(driver);
        loggerManager.getLogger().info("Line items copied successfully for " + numberOfYears + " years.");
    }

    /**
     * This method updates the Start and End Date on the cart page for multi-year RMS products.
     * It navigates to the cart page, waits for the elements to be clickable, and then updates
     * the start and end dates for each product in the quote data.
     *
     * @param quoteData - The list of quote data containing product details.
     */
    @Step("Update the Start and End Date on cart page for multi-year RMS products")
    public void updateMultiYearDatesOnRMSCart(List<LinkedHashMap<String, String>> quoteData) {
        waitforFrametoLoad(driver, apttusCatalogIframe);

        try {
            if(repriceCartProgressBar.isDisplayed()){
                waitForElementToDisappear(driver, repriceCartProgressBar);
            }
        } catch (Exception e) {
            loggerManager.getLogger().error("Error while waiting for reprice cart progress bar to disappear");
        }

        waitForElementToBeClickable(driver, contractDatesOnCartPage);

        List<WebElement> elements = driver.findElements(By.xpath("//p[@pikaday='dynamicField.tempDate']//input"));

        // Read number of years and number of products from Excel sheet
        int numberOfYears = reusableBusinessLibrary.getMultiYearNumber();
        int numberOfProducts = quoteData.size();

        List<String> startDates = new ArrayList<>();
        List<String> endDates = new ArrayList<>();

        for (int i = 0; i < numberOfYears; i++) {
            String startDate = currentDatePlusYears(i);
            String endDate = subtractDays(currentDatePlusYears(i + 1), 1);
            startDates.add(startDate);
            endDates.add(endDate);
        }

        for (int i = 0; i < elements.size(); i++) {
            WebElement element = elements.get(i);
            element.clear();

            int yearIndex = (i / (numberOfProducts * 2)) % numberOfYears;
            boolean isStartDate = (i % 2) == 0;

            String dateToEnter = isStartDate ? startDates.get(yearIndex) : endDates.get(yearIndex);
            element.sendKeys(dateToEnter);

            softAssert.assertEquals(element.getAttribute("value"), dateToEnter,
                    (isStartDate ? "Start Date" : "End Date") + " mismatch at index " + i);
            loggerManager.getLogger().info("Set " + (isStartDate ? "Start Date" : "End Date") + " for element at index " + i);

            elementClick(driver, warningMsgOnCartPage);
        }

        waitForElementToBeVisible(driver, repriceButtonOnApttusCart);
        elementClick(driver, repriceButtonOnApttusCart);
        waitForElementToDisappear(driver, repriceCartProgressBar);
        waitForElementToBeVisible(driver, finalizeButtonOnApttusCart);
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Completed updating multi-year dates on RMS Cart.");
    }


    // WIP method which will be incorporated to future tests.
    /* Method to perform manual price ramp
     * @param quoteData - The product details from the quote data
     */
    @Step("Manual update of multi-year dates on cart")
    public void manualPriceRamp(List<LinkedHashMap<String,String>> quoteData) {
        //manualPriceRamp = true;
        waitforFrametoLoad(driver, apttusCatalogIframe);
        updateMultiYrDatesonCart(getManualPriceRampProd(quoteData), getMultiYearProdDates());
    }

    /* Method to get manual price ramp products from quote data, it returns unique products list
        * @param quoteData - The product details from the quote data
     */
    public List<String> getManualPriceRampProd(List<LinkedHashMap<String,String>> quoteData) {
        List<String> multiYearsProducts = new ArrayList<>();
        for (LinkedHashMap<String, String> data : quoteData) {
            String productName = data.get("ProductName");
            if (!multiYearsProducts.contains(productName)) {
                multiYearsProducts.add(productName);
            }
        }
        return multiYearsProducts;
    }

    /* Method to get multi-year product dates
        * @return multiYrProdsDates - List of multi-year product dates
     */
    public List<Map<String, String>> getMultiYearProdDates() {
        int multiYearNumber = reusableBusinessLibrary.getMultiYearNumber();
        List<Map<String, String>> multiYrProdsDates = new ArrayList<>();
        for (int i = 0; i < multiYearNumber; i++) {
            Map<String, String> dateMap = new HashMap<>();
            if (i == 0) {
                newStartDate = expectedStartDate;
                newEndDate = currentDatePlusDays(364);
            } else {
                newStartDate = customDatePlusDays(1,newEndDate);
                newEndDate = customDatePlusDays(365,newEndDate);
            }
            dateMap.put("newStartDate", newStartDate);
            dateMap.put("newEndDate", newEndDate);
            multiYrProdsDates.add(dateMap);
        }
        return multiYrProdsDates;
    }

    /* Method to update multi-year dates on cart
        * @param multiYearsProducts - List of multi-year products
        * @param multiYrProdsDates - List of multi-year product dates
     */
    public void updateMultiYrDatesonCart(List<String> multiYearsProducts, List<Map<String, String>> multiYrProdsDates) {
        for (int i = 0; i < reusableBusinessLibrary.getMultiYearNumber(); i++) {
            Map<String, String> dates = multiYrProdsDates.get(i);
            for (String productName : multiYearsProducts) {
                elementClick(driver, driver.findElement(productCheckboxonCart(productName, i+1)));
                waitForElementToBeVisible(driver, massUpdateBtn);
                elementClickByJS(driver, massUpdateBtn);
                waitForElementToBeVisible(driver, massUpdateStartDate);
                waitForElementToBeClickable(driver, massUpdateStartDate);
                sendKeysToElement(driver, massUpdateStartDate, dates.get("newStartDate"));
                sendKeysToElement(driver, massUpdateEndDate, dates.get("newEndDate"));
                elementClick(driver, massUpdateApplyBtn);
                switchToDefaultContent(driver);
                waitForElementToBePresent(driver, productFrame(oppyName));
                waitforFrametoLoad(driver, driver.findElement(productFrame(oppyName)));
            }
            takeScreenshot(TCName, driver);
        }
        Allure.step("Manually updated multi-year dates on cart");
        loggerManager.getLogger().info("Manually updated multi-year dates on cart");
    }

    /**
     * This method enters the Default Category and Default Reason fields on the Quote.
     */
    @Step("Edits and enters the default category field on a proposal that has been created")
    public void enterDefaultCategoryAndDefaultReasonFieldOnProposal() {
        pageRefresh(driver);
        elementClick(driver, editDefaultCategoryBtn);
        waitForElementToBeVisible(driver, defaultCategoryDropdown);
        elementClick(driver, defaultCategoryDropdown);
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistOptionElement("Midterm Cancel or Downgrade")));
        elementClick(driver, driver.findElement(reusableBusinessLibrary.picklistListElement("Default Reason")));
        elementClick(driver, driver.findElement(defaultReasonPicklistOption("Price")));
        loggerManager.getLogger().info("Default Category and Default reason fields have been entered into proposal");
        reusableBusinessLibrary.clickSaveBtn();
        validateDefaultCategoryAndDefaultReasonFieldOnProposal();
    }

    @Step("Edits and enters the default category field on a proposal that has been created")
    public void validateDefaultCategoryAndDefaultReasonFieldOnProposal() {
        pageRefresh(driver);
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Primary"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Primary")));
        waitForElementToBeVisible(driver, defaultCategoryValidationField);
        takeScreenshot(TCName, driver);
        Assert.assertEquals(getElementText(driver, defaultCategoryValidationField), "Midterm Cancel or Downgrade", "Default Category field is not displayed as expected");
        Assert.assertEquals(getElementText(driver, defaultReasonValidationField), "Price", "Default Reason field is not displayed as expected");
        loggerManager.getLogger().info("Default Category and Reason fields are displayed as expected");
    }

    /**
     * This method terminates the first product in the cart
     * It selects the first product on the Installed Products page, enters the termination date, clicks on calculate and confirm buttons, and then navigates to the cart page.
     * It also stores the name and price of the terminated product.
     */
    public void performFullTerminationOnFirstLine(){
        waitForPageTitleToContain(driver, "Change: ");
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, firstProductCheckboxOnInstalledProducts);
        elementClickByJS(driver, firstProductCheckboxOnInstalledProducts);
        terminatedProductName = firstProductNameOnInstalledProducts.getText().trim();
        terminatedProductPrice = firstProductPriceOnInstalledProducts.getText().trim();
        waitForElementToBeVisible(driver, terminateBtnOnInstalledProducts);
        elementClickByJS(driver, terminateBtnOnInstalledProducts);
        switchToDefaultContent(driver);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, terminationDateInput);
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        terminationDateInput.clear();
        sendKeysToElement(driver, terminationDateInput, subtractDays(expectedStartDate, 1));
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        terminationDateInput.sendKeys(Keys.TAB);
        elementClickByJS(driver, calculateBtnOnInstalledProducts);
        takeScreenshot(TCName, driver);
        waitForElementToDisappear(driver, loadingSpinnerOnTerminationPage);
        scrollToBottom(driver);
        elementClickByJS(driver, confirmBtnOnTerminationPage);
        waitForElementToDisappear(driver, loadingSpinnerOnTerminationPage);
        switchToDefaultContent(driver);
        takeScreenshot(TCName, driver);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        elementClickByJS(driver, goToPricingBtn);
        switchToDefaultContent(driver);
        waitforFrametoLoad(driver, apttusCatalogIframe);
    }

    /**
     * This method verifies the details of the terminated products in the cart
     */
    @Step("Verify the details of the terminated products in the cart")
    public void verifyCartLineDetailsPostFullTermination() {
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitforFrametoLoad(driver, apttusCatalogIframe);
        Map<String, Integer> productIndexMap = new HashMap<>();
        for (int i = 0; i < cartLineItemsProductNames.size(); i++) {
            scrollToElement(driver, cartLineItemsProductNames.get(i));
            String productName;
            if (getElementText(driver, cartLineItemsProductNames.get(i)).contains(("AXIS User Keys")))// handle additional text for Axis product.
            {
                productName = "AXIS User Keys";
            } else {
                productName = getElementText(driver, cartLineItemsProductNames.get(i));
            }
            productIndexMap.put(productName, i);
        }

        for (int i = 0; i < productIndexMap.size(); i++) {
            String productName = productIndexMap.keySet().toArray()[i].toString();
            int cartLineRowNo = productIndexMap.get(productName);
            waitForElementToBePresent(driver, cartLineColumnValue(cartLineRowNo, getElementIndexByText(cartLineItemsRightTableHeaders, "Category")));
            String actualDefaultCategory = getElementText(driver, driver.findElement(cartLineColumnValue(cartLineRowNo + 1, getElementIndexByText(cartLineItemsRightTableHeaders, "Category"))));
            String actualDefaultReason = getElementText(driver, driver.findElement(cartLineColumnValue(cartLineRowNo + 1, getElementIndexByText(cartLineItemsRightTableHeaders, "Reason"))));
            String actualSalesPrice = getElementText(driver, driver.findElement(cartLineColumnValue(cartLineRowNo + 1, getElementIndexByText(cartLineItemsRightTableHeaders, "Sales Price"))));
            String actualNetPrice = getElementText(driver, driver.findElement(cartLineColumnValue(cartLineRowNo + 1, getElementIndexByText(cartLineItemsRightTableHeaders, "Net Price"))));
            String actualDeltaPrice = getElementText(driver, driver.findElement(cartLineColumnValue(cartLineRowNo + 1, getElementIndexByText(cartLineItemsRightTableHeaders, "Delta Price"))));
            softAssert.assertEquals(actualDefaultCategory, "Midterm Cancel or Downgrade", "Default Category is not as expected for product: " + productName);
            softAssert.assertEquals(actualDefaultReason, "Price", "Default Reason is not as expected for product: " + productName);
            softAssert.assertEquals(actualSalesPrice.split(" ")[1], "0.00", "Sales Price is not as expected for product: " + productName);
            softAssert.assertEquals(actualNetPrice, "("+terminatedProductPrice+")", "Net Price is not as expected for product: " + productName);
            softAssert.assertEquals(actualDeltaPrice, "("+terminatedProductPrice+")", "Delta Price is not as expected for product: " + productName);
        }
        takeScreenshot(TCName, driver);
        softAssert.assertAll();
        loggerManager.getLogger().info("Default Category, Default Reason, Sales Price, Net Price and Delta Price are displayed as expected for the products");
        switchToDefaultContent(driver);
    }

    /**
     * This method fetches the list of approvers for the Quote from the Approval Details page
     */
    @Step("Get the list of approvers for the Quote")
    public void getApproverNames(){
        waitforFrametoLoad(driver, apttusCatalogIframe);
        approverNamesList = new ArrayList<>();
        List<WebElement> approverNames = driver.findElements(approvalTableColumnValue(getColumnNumber(driver, approvalsTable, "Assigned To")));
        for (WebElement approverName : approverNames) {
            approverNamesList.add(getElementText(driver, approverName));
        }
    }

    /**
     * This method submits the Quote for Approval
     */
    @Step("Submit the Quote for Approval")
    public void submitQuoteForApproval() {
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToDisappear(driver, previewingApprovalsDialog);
        switchToDefaultContent(driver);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        takeScreenshot(TCName, driver);
        getApproverNames();
        waitForElementToBePresent(driver, approvalPageBtn("Submit"));
        elementClick(driver, driver.findElement(approvalPageBtn("Submit")));
        if(TCName.contains("ChangeOppy"))
            waitForPageTitleToContain(driver, "Quote/Proposal");
        else
            waitForPageTitle(driver, "Apttus_Approval__Approval_Request__c | Salesforce");
        switchToDefaultContent(driver);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        takeScreenshot(TCName, driver);
        waitForElementToBePresent(driver, approvalPageBtn("Submit"));
        elementClick(driver, driver.findElement(approvalPageBtn("Submit")));
        switchToDefaultContent(driver);
        waitforFrametoLoad(driver, apttusCatalogIframe);
        waitForElementToBeVisible(driver, approvalsSubmittedMessage);
        takeScreenshot(TCName, driver);
        softAssert.assertTrue(isElementDisplayed(driver, approvalsSubmittedMessage), "Failed to submit Quote for Approval");
        loggerManager.getLogger().info("Quote submitted for Approval successfully");
        waitForElementToBePresent(driver, approvalPageBtn("Return"));
        elementClick(driver, driver.findElement(approvalPageBtn("Return")));
        switchToDefaultContent(driver);
        waitForPageTitleToContain(driver, "Quote/Proposal | Salesforce");
        Allure.step("Verify that value of Approval Stage is In Review", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Approval Stage"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Approval Stage"))), "In Review", "Approval Stage is not displayed as expected.");
        });
        softAssert.assertAll();
    }

    /**
     * This method approves the Change Quote with multiple approvers
     */
    @Step("Approve the Change Quote")
    public void approveQuoteWithMultipleApprovers(){
        for (String approver : approverNamesList) {
            homePage.loginAsUser(approver);
            homePage.checkMoodysApp();
            openRecordBySFDCID(proposalRecordID);
            approveQuote();
            homePage.logoutFromProxyProfile();
            reusableBusinessLibrary.switchtoMoodysApp();
        }
    }
}