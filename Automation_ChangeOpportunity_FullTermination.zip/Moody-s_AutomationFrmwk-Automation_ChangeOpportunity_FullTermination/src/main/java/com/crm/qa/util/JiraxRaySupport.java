package com.crm.qa.util;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static io.restassured.RestAssured.given;

// This class contains JIRA XRay integration methods.
// Author: Sayon Das
// Last Modified By: Sayon Das
// Date: 07/23/2024
// Comment: Added methods to generate authentication token and upload test results to Jira XRay. Added UploadTestResult method to upload test results.
public class JiraxRaySupport extends ReusableLibrary {
	
	/**
	 * This method generates an authentication token for the Jira XRay API.
	 * It reads the client information from a JSON file and replaces the placeholders with actual client ID and secret.
	 * The updated client information is then sent as a POST request to the XRayAuthURL to generate the token.
	 * The response of this request, which is the token, is then returned as a string.
	 *
	 * @return String - The authentication token as a string.
	 */
	public String generateAuthToken(){
		String authReq=readJSONFileByKey(jsonFilePath,"xRay-JIRAClientInfo");
		authReq=authReq.replace("$clientId", jiraClientId)
				.replace("$clientSecret", jiraClientSecret);
		authResponse=given().contentType("application/json")
				.body(authReq)
				.when().post(prop.getProperty("xRayAuthURL")).then().log().all().extract().response();
		return authResponse.asString();
	}
	
	/**
	 * This method uploads the test results to the Jira XRay.
	 * It first checks if the flag parameter is set to "true". If it is, it reads the TestNG report file and generates an authentication token.
	 * The token is then used to authenticate a POST request to the XRayJiraResultParserURL, along with the test execution key and the test results as the request body.
	 * If the response status code is 200, it logs that the test results were uploaded successfully. Otherwise, it logs that the test results upload failed.
	 * If the flag parameter is not set to "true", it skips the test results upload step and logs this action.
	 */
	public void uploadTestResult() {
			try {
				Thread.sleep(5000);
				String jiraResultParserReq=readXMLFile(testNGReoportPath);
				if (jiraResultParserReq!=null) {
					String token = generateAuthToken();
					token = token.replace("\"", "");
					jiraResultParserResp = given().contentType("text/xml")
							.header("Authorization", "Bearer " + token)
							.queryParam("testExecKey", prop.getProperty("xRayTestExecKey"))
							.body(jiraResultParserReq)
							.when().post(prop.getProperty("xRayJiraResultParserURL")).then().log().all().extract().response();
					if (jiraResultParserResp.getStatusCode() == 200) {
						loggerManager.getLogger().info("Test results uploaded successfully");
					} else {
						loggerManager.getLogger().info("Test results upload failed");
					}
				}else{
					loggerManager.getLogger().error("TestNG xml content is empty");
				}
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
		}
}

