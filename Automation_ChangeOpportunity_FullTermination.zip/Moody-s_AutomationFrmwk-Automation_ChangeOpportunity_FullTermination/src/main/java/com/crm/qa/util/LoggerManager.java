package com.crm.qa.util;

import java.util.Properties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

//This class is used to create the logger object
//The logger object is used to log messages to the log file
public  class LoggerManager {
    private static ReusableLibrary reusableLibrary = new ReusableLibrary();
    private static Properties prop = reusableLibrary.initializeProperties();
    private Logger logger;
    static {
        //Set the system property to the log4j2 configuration file
        System.setProperty("log4j2.configurationFile",prop.getProperty("env.logging.log4j.configurationFile")) ;
    }
    //Constructor to create the logger object
    public LoggerManager(String className) throws Exception {
        try {
            this.logger = generateLogger(className);
        } catch (Exception e) {
            throw new Exception("Error in creating logger object");
        }
    }
    public Logger getLogger() {
        return this.logger;
    }
    public static Logger generateLogger(String className) {
            return LogManager.getLogger(className);
    }

}


