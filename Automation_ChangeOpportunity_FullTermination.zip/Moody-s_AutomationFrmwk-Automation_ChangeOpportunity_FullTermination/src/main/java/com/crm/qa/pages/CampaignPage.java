package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;
import static com.crm.qa.util.ReusableLibrary.waitForElementToBeVisible;

public class CampaignPage extends TestBase {

    public CampaignPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    //Page Factory - OR:
    @FindBy(xpath = "//div[@title='New']")
    WebElement newCampaignBtn;
    @FindBy(xpath = "//span[text()='Campaign Details']")
    WebElement campaignDetailsTab;
    @FindBy(xpath = "//a[@title='Add Leads']")
    WebElement addLeadsBtn;

    WebElement leadToSelect() {
        return driver.findElement(By.xpath("//div[@title='"+firstNameText+" "+lastNameText+"']"));
    }
    @FindBy(xpath = "//input[contains(@aria-describedby,'lookupSelectionAssistiveText')]")
    WebElement searchBarOnAddLeadToCampaignPage;
    @FindBy(xpath = "//div[contains(text(),'Current Selection')]")
    WebElement leadSelected;

    @FindBy(xpath = "//button[text()='Next']")
    WebElement nextBtnOnAddLeadToCampaignPage;
    @FindBy(xpath = "//button[text()='Submit']")
    WebElement submitBtnOnAddLeadToCampaignPage;

    @FindBy(xpath = "//a[text()='Lead']")
    WebElement newLeadHyperLink;
    @FindBy(xpath = "//span[text()='Next']")
    WebElement nextOnNewCampaignPage;
    @FindBy(xpath = "(//label//span[text()='Campaign Name']/following::input) [1]")
    WebElement campaignNameTextBox;
    @FindBy(xpath = "(//span[text()='Type' and contains(@id, 'label')]/following::a) [1]")
    WebElement campaignTypePicklist;

    @FindBy(xpath = "(//span[contains(@id,'label') and text()='Business']/following::a) [1]")
    WebElement businessTypePicklist;
    @FindBy(xpath = "(//span[contains(@id,'label') and text()='Region']/following::a) [1]")
    WebElement regionTypePicklist;

    @FindBy(xpath = "(//label//span[text()='Start Date']/following::input) [1]")
    WebElement startDateTextBox;
    @FindBy(xpath = "(//span[text()='Start Date']/following::span[text()='Date Picker']) [1]")
    WebElement calendarIcon;
    @FindBy(xpath = "//button[@title='Save']")
    WebElement saveBtnOnNewCampaignPage;



    //Actions:
    /**
     * This method clicks on the "Campaign Details" tab on the campaign page.
     * It waits for the tab to be visible, then clicks on it and logs the action.
     * If any exception occurs during the process, it logs an error message and fails the test.
     * Finally, it takes a screenshot of the page after attempting to click the tab.
     */
    @Step("Click on Campaign Details tab")
    public void clickCampaignDetails()  {
        try{
            waitForElementToBeVisible(driver, campaignDetailsTab);
            elementClick(driver, campaignDetailsTab);
            loggerManager.getLogger().info("Clicked on Campaign Details tab");
        }catch(Exception e){
            Assert.fail("Could not click on Campaign Details tab");
            loggerManager.getLogger().error("Could not click on Campaign Details tab");
        }
        ReusableLibrary.takeScreenshot("ClickCampaignDetails", driver);
    }
    /**
     * This method adds a lead to the campaign.
     * It performs the following steps:
     * 1. Waits for the "Add Leads" button to be visible.
     * 2. Clicks the "Add Leads" button.
     * 3. Enters the lead's name in the search bar.
     * 4. Waits for the lead to be visible in the search results.
     * 5. Selects the lead from the search results.
     * 6. Verifies that the lead has been selected.
     * 7. Clicks the "Next" button using JavaScript.
     * 8. Waits for the "Submit" button to be visible.
     * 9. Clicks the "Submit" button using JavaScript.
     */
    @Step("Add a lead to the campaign")
    public void addLeadToCampaign() {
        try{
            waitForElementToBeVisible(driver, addLeadsBtn);
            elementClick(driver, addLeadsBtn);
            sendKeysTypeAheadField( searchBarOnAddLeadToCampaignPage,  firstNameText+" "+lastNameText);
            waitForElementToBeVisible(driver, leadToSelect());
            elementClick(driver, leadToSelect());
            //verify that a lead has been selected
            Assert.assertTrue(leadSelected.isDisplayed(), "Lead has not been selected");
            elementClickByJS(driver, nextBtnOnAddLeadToCampaignPage);
            waitForElementToBeVisible(driver, submitBtnOnAddLeadToCampaignPage);
            elementClickByJS(driver, submitBtnOnAddLeadToCampaignPage);
            loggerManager.getLogger().info("Lead has been added to the campaign");
        }
        catch(Exception e){
            Assert.fail("Could not add lead to the campaign");
            loggerManager.getLogger().error("Could not add lead to the campaign");
        }
        wait.until(ExpectedConditions.invisibilityOf(submitBtnOnAddLeadToCampaignPage));
        ReusableLibrary.takeScreenshot("AddLeadToCampaign", driver);
    }
    /**
     * This method refreshes the current page, navigates to the "Campaign Details" tab,
     * and then clicks on a hyperlink to navigate to a specific lead that has been added to the campaign.
     * It logs the navigation process and takes a screenshot of the page.
     * If any exception occurs during the process, it logs an error message and fails the test.
     */
    @Step("Navigate to the lead which has been added to the campaign")
    public void navigateToLead() {

            ReusableLibrary.pageRefresh(driver);
            clickCampaignDetails();
            waitForElementToBeVisible(driver, newLeadHyperLink);
            Assert.assertTrue(newLeadHyperLink.isDisplayed(), "No lead has been added to the campaign");
            elementClickByJS(driver, newLeadHyperLink);
            loggerManager.getLogger().info("Navigated to the lead");

        ReusableLibrary.takeScreenshot("NavigateToLead", driver);
    }
    /**
     * This method fills out the mandatory fields for creating a new campaign.
     * It performs the following steps:
     * 1. Clicks the "Next" button on the new campaign page.
     * 2. Selects the specified region from the region picklist.
     * 3. Enters the campaign name with a suffix "_Automation_Campaign".
     * 4. Selects the specified campaign type from the campaign type picklist.
     * 5. Selects the specified business type from the business type picklist.
     * 6. Scrolls to the start date text box.
     * 7. Enters the current date in MM/dd/yyyy format as the start date.
     * 8. Clicks the calendar icon.
     * 9. Clicks the "Save" button to save the new campaign.
     *
     * @param region The region to be selected.
     * @param campaignName The name of the campaign.
     * @param campaignType The type of the campaign to be selected.
     * @param businessType The business type to be selected.
     */
    @Step("Fill out New Campaign Mandatory Fields")
    public void fillOutNewCampaignMandatoryFields(String region, String campaignName,String campaignType, String businessType){
        try{
            elementClick(driver, nextOnNewCampaignPage);
            selectPicklistOption(regionTypePicklist, region);
            sendKeysToElement(driver, campaignNameTextBox, campaignName+ReusableLibrary.generateRandomString("_Automation_Campaign"));
            selectPicklistOption(campaignTypePicklist, campaignType);
            selectPicklistOption(businessTypePicklist, businessType);
            scrollToElement(driver, startDateTextBox);
            sendKeysToElement(driver, startDateTextBox, getCurrentDateInMMddyyyyFormat());
            elementClickByJS(driver, calendarIcon);
            elementClickByJS(driver, saveBtnOnNewCampaignPage);
            loggerManager.getLogger().info("Filled out New Campaign Mandatory Fields");
        }
        catch (Exception e){
            loggerManager.getLogger().error("Failed to fill out New Campaign Mandatory Fields");
            Assert.fail("Failed to fill out New Campaign Mandatory Fields", e);
        }
        takeScreenshot("fillOutNewCampaignMandatoryFields", driver);

    }
    @Step("Click New Campaign Button")
    public void clickNewCampaign(){
        try{
            elementClick(driver, newCampaignBtn);
            loggerManager.getLogger().info("Clicked New Campaign Button");
        }
        catch (Exception e){
            loggerManager.getLogger().error("Failed to click new campaign button");
            Assert.fail("Failed to click new campaign Button", e);
        }
        wait.until(ExpectedConditions.visibilityOf(nextOnNewCampaignPage));
        takeScreenshot("clickNewCampaignButton", driver);

    }


}
