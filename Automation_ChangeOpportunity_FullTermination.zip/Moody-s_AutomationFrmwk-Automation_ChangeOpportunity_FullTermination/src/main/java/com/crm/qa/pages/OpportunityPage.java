package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.OutlookSupport;
import com.crm.qa.util.ReusableBusinessLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.*;

import java.util.stream.Collectors;


import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.getSFDCRecordIDFromURL;
import static com.crm.qa.util.ReusableBusinessLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;
import com.crm.qa.util.ReusableLibrary;
import org.openqa.selenium.support.FindAll;

/**
 * This class contains methods related to the Opportunity functionality.
 * Author: Arshin Shaikh
 * Last Modified By: Arshin Shaikh
 * Date: 12/05/2024
 * Comment: Added new methods for validating warning message on Opportunity post Sold To Contact change and validating Product Forecast field placement on the Opportunity Product.
 * Last Modified By: Hemal Shah
 * Date: 12/06/2024
 * Comment: Added changes related to Opportunity site profiles.
 */

public class OpportunityPage extends TestBase {

    public OpportunityPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();
    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
    OutlookSupport outlookSupport = new OutlookSupport();

    //Page Factory - OR:

    @FindBy(xpath = "//div[contains(@class,'recordTypeName')]/span")
    WebElement opportunityRecordTypeText;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Person')]//slot[@lwc-47ngqe6rvah]")
    WebElement soldToContactNameOnOpportunity;

    @FindBy(xpath = "//label[text()='Opportunity Name']//following::input[1]")
    WebElement opportunityNameTextField;

    @FindBy(xpath = "//label[text()='Sold to Contact']//following::input[1]")
    WebElement soldToContactTextField;

    public By soldToContactOption(String contactName) {
        return By.xpath("//lightning-base-combobox-formatted-text[@title='"+contactName+"']");
    }

    @FindBy(xpath = "//label[text()='Contract Specialist']//following::input[1]")
    WebElement contractSpecialistTextField;

    public By contractSpecialistOption(String contractSpecialist) {
        return By.xpath("//lightning-base-combobox-formatted-text[@title='"+contractSpecialist+"']");
    }

    @FindBy(xpath = "//label[text()='Stage']//following::button[2]")
    WebElement stageDropdown;

    public By selectDropDownOption(String option) {
        return By.xpath("//span[@title='"+option+"']");
    }

    @FindBy(xpath = "//label[text()='Lead Source']//following::button[1]")
    WebElement leadSourceDropdown;

    @FindBy(xpath = "//label[text()='First Appt Date']//following::input[1]")
    WebElement firstAppointmentDateTextField;

    @FindBy(xpath = "//label[text()='Close Date']//following::input[1]")
    WebElement closeDateTextField;

    @FindBy(xpath = "//label[text()='Renewal Type']//following::button[1]")
    WebElement renewalTypeDropdown;

    @FindBy(xpath = "//label[text()='Related to Third Party']//following::button[2]")
    WebElement relatedToThirdPartyDropdown;

    @FindBy(xpath = "//h2[text()='We hit a snag.']")
    WebElement errorHeader;

    @FindBy(xpath = "//ul[contains(@class,'errorsList')]//li")
    WebElement errorText;

    public By newOpportunityHeader(){
        return By.xpath("//h2[contains(text(),'New Opportunity')]");
    }

    public By accountNameOption(String accountName) {
        return By.xpath("//lightning-base-combobox-formatted-text[@title='"+accountName+"']");
    }

    @FindBy(xpath = "//label[text()='Affiliate Sale']//following::button[@aria-label='Affiliate Sale']")
    WebElement affiliateSaleDropDown;

    @FindBy(xpath = "//span[text()='Affiliate Sale']//following::lightning-formatted-text[text()='Yes']")
    WebElement affiliateSaleText;

    public  By dropDownBtnElementOption(String drpDownListTitle , String optionName) {
        return By.xpath("//button[@aria-label ='" + drpDownListTitle + "']/following::span[text()='" + optionName + "']");
    }
    @FindBy(xpath = "//span[text()='Opportunity Currency']//following::lightning-formatted-text[text()='USD - U.S. Dollar']")
    WebElement opportunityCurrencyText;

    @FindBy(xpath = "//h2[text()='New Opportunity']")
    WebElement opportunityRecordPageHeader;

    @FindBy(xpath = "//span[text()='Forecast']")
    WebElement forecastInformationSection;

    @FindBy(xpath = "//span[text()='Multi-Year Information']")
    WebElement multiYearInformationSection;

   @FindBy(xpath = "//span[text()='Probability (%)' and @class='test-id__field-label']//following::lightning-formatted-number[1]")
    WebElement probabilityPercentageText;

    @FindBy(xpath = "//span[text()='Renewal Type']//following::lightning-formatted-text[1]")
    WebElement renewalTypeText;

    @FindBy(xpath = "//span[text()='Stage' and @class='test-id__field-label']//following::lightning-formatted-text[1]")
    WebElement oppyStageText;

    @FindBy(xpath = "//span[text()='Category']//following::lightning-formatted-text[1]")
    WebElement oppyCategoryText;

    @FindBy(xpath = "//span[text()='Contract Information']")
    WebElement contractInformationSection;

    @FindBy(xpath = "//span[text()='Related to Third Party']//following::lightning-formatted-text[1]")
    WebElement relatedToThirdPartyText;

    @FindBy(xpath = "//span[text()='Contract Start Date' and @class='test-id__field-label']//following::lightning-formatted-text[1]")
    WebElement contractStartDateText;

    @FindBy(xpath = "//span[text()='Contract End Date' and @class='test-id__field-label']//following::lightning-formatted-text[1]")
    WebElement contractEndDateText;

    @FindBy(xpath = "//h2[text()='Related List Quick Links']")
    WebElement relatedListQuickLinks;

    public By opportunityValidationTextFieldLinks(String fieldName) {
        return By.xpath("(//span[text()='"+fieldName+"']//following::a[1]/span//slot)[2]");
    }

    public By opportunityValidationTextField(String fieldName) {
        return By.xpath("(//span[text()='" + fieldName + "']/following::lightning-formatted-text) [1]");
    }

    public By opportunityNameHeader(String opportunityName) {
        return By.xpath("(//records-entity-label[text()='Opportunity']/following::lightning-formatted-text[text()='" + opportunityName + "']) [1]");
    }

    public By opportunityValidationNumberField(String fieldName) {
        return By.xpath("(//span[text()='"+fieldName+"']/following::lightning-formatted-number) [1]");
    }
    @FindBy(xpath = "//span[text()='Services Owner']//following::a[1]//following::button[1]")
    WebElement servicesOwnerValidationField;


    @FindBy(xpath = "//div[@class='slds-modal__header']//h2/following::span[text()='Probability Override']")
    WebElement probabilityOverrideCheckBox;

    public By filledFormDropDownField(String textfieldName, String expectedValue) {
        return By.xpath("(//label[text()='"+textfieldName+"']/following::button[@data-value='"+expectedValue+"']) [1]");
    }

    public By partnershipSalesTypeOption(String option){
        return By.xpath("//div[contains(@class,'windowViewMode-normal')]//div[@data-value='" + option + "']");
    }

    @FindBy(xpath = "//div[text()='Partnership / Alliance: Sales Type']")
    WebElement partnershipAllianceSalesTypeLabel;

    @FindBy(xpath = "//div[text()='Partnership / Alliance: Sales Type']/following::button[@title='Move to Chosen']")
    WebElement partnershipAllianceMoveToChosenBtn;

    @FindBy(xpath = "//div[contains(@data-target-selection-name, 'Partner_Account__c')]//input")
    WebElement partnerAccountTextField;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//div[contains(@data-target-selection-name, 'AccountId')]//input")
    WebElement accountNameTextField;

    public By opportunityPagePicklistOption(String recordName){
        return By.xpath("//lightning-base-combobox-formatted-text[@title='" + recordName + "']");
    }

    @FindBy(xpath = "//span[text()='Third Party']")
    WebElement thirdPartySectionLabel;

    @FindBy(xpath = "(//span[text()='Partnership / Alliance: Sales Type']/following::lightning-formatted-text)[1]")
    WebElement partnershipAllianceSalesTypeValue;

    @FindBy(xpath = "(//div[text()='Partnership / Alliance: Sales Type']//following::div[contains(@class,'list__options')])[1]")
    WebElement partnershipAllianceSalesTypeMultiselectPicklist;

    @FindBy(xpath = "//span[text()='Contract Term (m)']")
    WebElement contractTermLabel;

    @FindBy(xpath ="//label[text()='Partner Account']/following::input[@data-value!='' and @data-value!='Standard Price Book']")
    WebElement selectedPartnerAccount;

    @FindBy(xpath ="(//label[text()='Partner Account']/following::button[@title='Clear Selection'])[1]")
    WebElement partnerAccountClearBtn;

    @FindBy(xpath = "//button[@name='CancelEdit']")
    WebElement opportunityCancelBtn;

    @FindBy(xpath = "//lightning-icon[@icon-name='utility:arrow_right' and @title='Renewal Source']")
    WebElement renewalSourceRightArrowIcon;

    @FindBy(xpath = "//lightning-icon[@icon-name='utility:arrow_right']/following::p[text()='Renewal Source']")
    WebElement renewalSourceLabel;

    @FindBy(xpath = "//lightning-icon[@icon-name='utility:arrow_left' and @title='Renewal Opportunity']")
    WebElement renewalSourceLeftArrowIcon;

    @FindBy(xpath = "//lightning-icon[@icon-name='utility:arrow_left']/following::p[text()='Renewal Opportunity']")
    WebElement renewalOpportunityLabel;

    @FindBy(xpath = "//button[contains(@class,'stepAction')]")
    WebElement stageStepActionButton;

    public By opportunityProductsListViewColumnHeaders =  By.xpath("//div[contains(@class,'windowViewMode-normal')]//th[@title]");

    @FindBy(xpath = "//a[text()='Products']")
    WebElement productsTab;

    @FindBy(xpath = "//span[@title='Products']")
    WebElement productsRelatedList;

    @FindBy(xpath = "//a[text()='Contacts']")
    WebElement contactsTab;

    @FindBy(xpath = "//span[text()='Contact Roles']")
    WebElement contactRolesRelatedList;

    public By  contactRolesListViewColumnHeaders =  By.xpath("//thead//a/span[@title]");

    public By contactRoleRecordFields = By.xpath("//div[@class='record-layout-container']//span[contains(@class,'field-label')]");

    @FindBy(xpath = "(//td[@data-label='Contact Role Number']//a)[1]")
    WebElement contactRoleRecord;

    public By servicesDataSectionFields = By.xpath("//span[text()='Services Data']/following::div[contains(@class,'horizontal_small')][1]//span[contains(@class,'field-label')]");

    @FindBy(xpath = "//span[text()='Commit Amount']")
    WebElement commitAmountField;

    @FindBy(xpath = "//span[text()='Manager Notes']")
    WebElement managerNotesField;

    @FindBy(xpath = "//span[text()='Forecast']")
    WebElement forecastSectionLabel;

    @FindBy(xpath = "//span[text()='Quip']")
    WebElement quipTabUnderMore;

    @FindBy(xpath = "(//button[text()='More'])[1]")
    WebElement moreTab;

    @FindBy(xpath = "//span[text()='Segment']")
    WebElement segmentField;

    @FindBy(xpath = "//span[text()='Business Sector']")
    WebElement businessSectorField;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//span[text()='Cancel']")
    WebElement oppyRecordPageCancelBtn;

    @FindBy(xpath = "//a[contains(@href,'Contracts')]")
    WebElement fulfillmentQuickLink;

    @FindBy(xpath = "//span[text()='ERS DOA']")
    WebElement ERSDOAField;

    @FindBy(xpath = "//lightning-icon[@title='Key Attributes - Crediting']")
    WebElement keyAttributesCreditingReportIcon;

    @FindBy(xpath = "//button[@aria-label='Regulatory']")
    WebElement regulatoryPicklist;

    @FindBy(xpath = "//div[@aria-label='Regulatory']/lightning-base-combobox-item")
    List<WebElement> regulatoryPicklistOptions;

    @FindBy(xpath = "//button[text()='Create Quote/Proposal']")
    WebElement createQuoteBtn;

    public By proposalNameOnApttus(String proposalName){
        return By.xpath("//span[@title='" + proposalName + "']");

    }

    @FindBy(xpath = "//article[@aria-label='Proposals']//dt")
    List<WebElement> fieldsUnderProposalsRelatedList;

    @FindBy(xpath = "//span[text()='Proposals' and contains(@class,'right')]")
    WebElement proposalsRelatedList;

    @FindBy(xpath = "//div[contains(@data-target-selection-name, 'Multi_Year__c')]//lightning-input")
    WebElement multiyearCheckbox;

    @FindBy(xpath = "//span[text()='Description']")
    WebElement descriptionLabel;

    @FindBy(xpath = "//button[@aria-label='Usage Type']")
    WebElement usageTypePicklist;

    @FindBy(xpath = "//div[@aria-label='Usage Type']/lightning-base-combobox-item")
    List<WebElement> usageTypePicklistOptions;

    @FindBy(xpath = "//input[contains(@placeholder,'Search Campaigns')]")
    WebElement searchCampaignsTextField;

    @FindBy(xpath = "//span[text()='Renewal Source']")
    WebElement renewalSourceFieldLabel;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Campaign')]//a")
    WebElement campaignNameLink;

    @FindBy(xpath = "(//label[text()='Primary Campaign Source']/following::button[@title='Clear Selection'])[1]")
    WebElement clearPrimaryCampaignSourceBtn;

    @FindBy(xpath = "//span[text()='Mismatched Allocation']")
    WebElement mismatchedAllocationField;

    @FindBy(xpath = "//span[text()='Custom Links']")
    WebElement customLinksSection;

    @FindBy(xpath = "//a[text()='My Renewal Sales Opportunities']")
    WebElement myRenewalSalesOpportunitiesLink;

    @FindBy(xpath = "//a[text()='SRB Detail']")
    WebElement srbDetailLink;

    @FindBy(xpath = "//span[text()='My Renewal Sales Opportunities']")
    WebElement myRenewalSalesOpportunitiesListViewText;

    @FindBy(xpath = "//span[text()='SRB Detail (For Link)']")
    WebElement srbDetailReportHeaderText;

    @FindBy(xpath = "//iframe[@title='Report Viewer']")
    WebElement srbDetailReportFrame;

    @FindBy(xpath = "//div[contains(@class,'right')]//span[contains(@class,'truncate') and contains(@class,'right')]")
    List<WebElement> rightPanelRelatedListsOnOpportunity;

    @FindBy(xpath = "//span[text()='Quick Links']")
    WebElement quickLinksWidgetLabel;

    @FindBy(xpath = "//span[text()='Fulfillments']")
    WebElement fulfillmentsRelatedListLabel;

    @FindBy(xpath = "(//label//span[text()='Owner Assigned Manually'])[last()]")
    WebElement ownerAssignedManuallyCheckboxOnEditPage;

    @FindBy(xpath = "//input[@name='Owner_Assigned_Manually__c']")
    WebElement ownerAssignedManuallyCheckboxOnViewPage;

    @FindBy(xpath = "//a[contains(text(),'Show All')]")
    WebElement showAllQuickLinks;

    @FindBy(xpath = "//span[text()='Orders']")
    WebElement ordersRelatedList;

    @FindBy(xpath = "//a[text()='Activity']")
    WebElement activityTab;

    @FindBy(xpath = "//button[@value='SendEmail']")
    WebElement sendEmailBtn;

    @FindBy(xpath = "//div[contains(@data-aura-class,'ToInputEmailRecipients ')]//input")
    WebElement emailToTextField;

    @FindBy(xpath = "//input[contains(@placeholder,'Enter Subject')]")
    WebElement emailSubjectTextField;

    @FindBy(xpath = "//span[text()='Attach file']/parent::button[contains(@class,'Attachment')]")
    WebElement emailAttachmentBtn;

    @FindBy(xpath = "//button[contains(@class,'send') and @type='button']")
    WebElement emailSendBtn;

    @FindBy(xpath = "//span[text()='Insert merge field']/parent::button[contains(@class,'Attachment')]")
    WebElement insertMergeFieldBtn;

    @FindBy(xpath = "//input[contains(@class,'searchInput')]")
    WebElement searchMergeFieldTextField;

    public By mergeFieldOption(String mergeField){
        return By.xpath("//span[text()='" + mergeField + "' and contains(@class,'element')]");
    }

    @FindBy(xpath = "//span[text()='Insert']")
    WebElement insertBtn;

    @FindBy(xpath = "//button[text()='Attach and Send']")
    WebElement attachAndSendBtn;

    @FindBy(xpath = "//span[text()='Opportunity']")
    WebElement opportunitySectionLabelOnMergeFieldPage;

    public By emailRecordLinkUnderActivityTab(String emailSubject){
        return By.xpath("//a[text()='" + emailSubject + "']");
    }

    @FindBy(xpath = "//span[text()='Opportunity Owner']")
    WebElement opportunityOwnerFieldLabel;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Sold_To_Contact_Address')]//span[contains(@part,'text')]")
    WebElement soldToContactAddressFieldValue;

    @FindBy(xpath = "//button[contains(@class,'attachButton')]")
    WebElement uploadFilesBtn;

    public By emailBodyFrame = By.xpath("//iframe[@title='Email Body']");

    public By emailEditorFrame = By.xpath("//iframe[@title='CK Editor Container']");

    public By emailBodyTextField = By.xpath("//body[contains(@aria-label,'Email Body')]/br[1]");

    @FindBy(xpath = "//button[@aria-label='Opportunity Currency']")
    WebElement opportunityCurrencyDrpDown;

    public By oppyCurrencyValue(String currencyName) {
        return By.xpath("//span[@title='"+currencyName+"']");
    }

    @FindBy(xpath = "//span[text()='Update Currency']")
    WebElement updateCurrencyLink;

    @FindBy(xpath = "//label[text()='Choose New Currency']//following::button[@name='CurrencyIsoCode']")
    WebElement chooseNewCurrencyDrpDown;

    @FindBy(xpath = "//a[text()='Quip']")
    WebElement quipTab;

    @FindBy(xpath ="//label[text()='Services Owner']/following::button[@title='Clear Selection'] [1]")
    WebElement clearServicesOwnerBtn;

    @FindBy (xpath = "//span[text()='Quick Links']")
    WebElement quickLinksHeader;

    @FindBy (xpath = "(//span[text()='Quick Links']/following::lightning-layout-item)[1]")
    WebElement quickLink;

    @FindBy(xpath = "(//span[text()='Opportunity']/following::span[contains(@class,'field-label')])[1]")
    WebElement fieldNameNextToOpportunityField;

    @FindBy(xpath = "(//div[contains(@class,'windowViewMode-normal')]//table[@aria-label='Products']//tbody//th//a)[1]")
    WebElement firstOppyProductLink;

    @FindBy(xpath = "//span[text()='Warning: The Sold to Contact has changed on this Opportunity. The Ship to and Bill to Contacts have not changed. Please open and save the Location grid to confirm the Locations are correctly assigned.']")
    WebElement soldToContactChangeWarningMessage;

    @FindBy(xpath = "//span[text()='Add/Update Site Profiles']")
    WebElement addUpdateSiteProfiles;

    @FindBy(xpath = "//h4[text()='Site Profiles Details']")
    WebElement siteProfilesDetailsPage;

    @FindAll(@FindBy(xpath = "//c-add-many-locations//tbody//tr"))
    List<WebElement> siteProfilesList;

    @FindBy(xpath = "//c-add-many-locations//tbody//tr[1]//input[@type='checkbox']")
    WebElement firstSiteNameCheckbox;

    @FindBy(xpath = "(//th//button[@name='LocationType'])[1]")
    WebElement firstSiteType;

    @FindBy(xpath = "//lightning-base-combobox-item[@data-value='Deliver To']")
    WebElement firstDeliveryTo;

    @FindBy(xpath = "(//button[@name='FulfilmentMethod'])[1]")
    WebElement firstFulfilmentMethod;

    @FindBy(xpath = "//lightning-base-combobox-item[@data-value='Hosted']")
    WebElement firstHostedFulfillmentMethod;

    @FindBy(css = "[class*='toastContent']")
    WebElement siteProfileSuccesstoast;

    @FindBy(xpath = "//span[text()='Contract Specialist']//following::a[1]//following::button[1]")
    WebElement contractSpecialistValidationField;

    @FindBy(xpath = "//img[@alt='Create Trial']")
    WebElement createTrailButton;

    @FindBy(xpath = "//span[text()='Contract Information']")
    WebElement scrollToContactInfo;

    @FindBy(xpath = "//input[@name='Multi_Year__c']")
    WebElement multiYearCheckbox;

    @FindBy(xpath = "//span[text()='Intercompany Sale']")
    WebElement intercompanySaleLabel;

    public By yearValidation(String year) {
        return By.xpath("(//span[text()='"+year+"']/following::lightning-formatted-text) [1]");
    }
    @FindBy(xpath = " (//span[text()='Contract Start Date']/following::lightning-formatted-text) [1]")
    WebElement contractStartDateValidationField;

    @FindBy(xpath = " (//span[text()='Contract End Date']/following::lightning-formatted-text) [1]")
    WebElement contractEndDateValidationField;

    public By oppySavedSuccessBanner = By.xpath("//div[@data-key='success']");

    @FindBy(xpath = "(//span[@title='Proposals']/following::records-hoverable-link) [1]")
    WebElement proposalLink;

    //Actions:

    /**
     * This method verifies that the record type of the Opportunity created as part of Lead Conversion is New Sales.
     *
     */
    @Step("Verify the Record Type of the Opportunity created as part of Lead Conversion process")
    public void verifyOpportunityRecordType() {
        driver.navigate().refresh();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, opportunityRecordTypeText);
        Allure.step("Validate that Opportunity converted from Lead has Record Type as New Sales", step-> {
            if (opportunityRecordTypeText.getText().equals("New Sales"))
                loggerManager.getLogger().info("Opportunity converted from Lead has Record Type as New Sales");
            else
                loggerManager.getLogger().error("Opportunity converted from Lead does not have Record Type as New Sales");
            Assert.assertEquals(opportunityRecordTypeText.getText(), "New Sales", "Opportunity converted from Lead does not have Record Type as New Sales");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the Sold To Contact on the Opportunity is auto updated by the System.
     *
     * @param expectedContact String - The expected Sold To Contact on the Opportunity.
     */
    @Step("Verify that Sold To Contact on Opportunity is auto updated by the System to {expectedContact}")
    public void verifySoldToContactOnOpportunity(String expectedContact){
        Allure.step("Validate that Sold To Contact on Opportunity is auto updated by the System to " + expectedContact, step-> {
            if(soldToContactNameOnOpportunity.getText().equals(expectedContact))
                loggerManager.getLogger().info("Sold To Contact on Opportunity is auto updated by the System to " + expectedContact);
            else
                loggerManager.getLogger().error("Sold To Contact on Opportunity is not auto updated by the System to " + expectedContact);

            Assert.assertEquals(soldToContactNameOnOpportunity.getText(), expectedContact, "Sold To Contact on Opportunity is not updated to " + expectedContact);
        });
        takeScreenshot(TCName, driver);
    }

    @Step("validate the error message displayed on the Opportunity page when Account Company status is unknown")
    public void validateErrorInfo(){
        waitForElementToBeVisible(driver, errorHeader);
        softAssert.assertTrue(errorHeader.isDisplayed());
        Allure.step("Validate the error message displayed on the Opportunity page when Account Company status is unknown", step->{
            softAssert.assertEquals(getElementText(driver, errorText),readExcelData(opportunitiesFilePath, TCName, "ErrorMessage"));
            loggerManager.getLogger().info("Error message displayed on the Opportunity page when Account Company status is unknown");
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
    }

    @Step("Verify that the opportunity has been saved successfully")
    public void verifyOpportunityIsSaved() {
        waitForElementToBePresent(driver, opportunityNameHeader(oppyName));
        if (isElementDisplayed(driver, driver.findElement(opportunityNameHeader(oppyName)))) {
            loggerManager.getLogger().info("Opportunity has been saved successfully");
        } else {
            loggerManager.getLogger().error("Opportunity has not been saved successfully");
            Assert.fail("Opportunity not saved successfully");
        }
        takeScreenshot(TCName, driver);
    }
    /**
     * This method validates the Contract Specialist field on the Opportunity.
     * It checks if the Contract Specialist field contains the expected value from the provided data.
     * @param oppData A LinkedHashMap containing the expected values for the Opportunity fields.
     */
    private void validateContractSpecialistField(LinkedHashMap<String, String> oppData)
    {
        if (contractSpecialistValidationField.getAttribute("title").contains(oppData.get("ContractSpecialistName"))) {
            loggerManager.getLogger().info("Contract Specialist field saved on the Opportunity");
        } else {
            loggerManager.getLogger().error("Contract Specialist field not saved on the Opportunity");
            Assert.fail("Contract Specialist field not saved on the Opportunity");
        }
    }

    public void validateContractDates(LinkedHashMap<String, String> oppData)
    {
        if ("Multi-Year".equalsIgnoreCase(oppData.get("ContractLength"))) {

            softAssert.assertTrue(multiYearCheckbox.isSelected(), "Multi Year checkbox is not selected when it should be");
            String monthsBetween = readExcelData(opportunitiesFilePath, TCName, "ContractTerm_Months");
            double yearsBetween =Math.ceil(Double.parseDouble(monthsBetween) / 12);

            for (int i = 1; i <= 5; i++) {
                String year = "Year " + i + " Amount";

                if (i <= yearsBetween) {
                    softAssert.assertFalse(getElementText(driver, driver.findElement(yearValidation(year))).isEmpty(), "Year validation failed for: " + year);
                } else {
                    softAssert.assertTrue(getElementText(driver, driver.findElement(yearValidation(year))).contains("0.00"), "Year validation failed for: " + year);
                }
            }
            loggerManager.getLogger().info("Contract is Multi Year as intended");
        }
            softAssert.assertEquals(getElementText(driver, contractStartDateValidationField), expectedStartDate, "Contract Start Date is not displayed as expected");
            softAssert.assertEquals(getElementText(driver, contractEndDateValidationField), expectedEndDate, "Contract End Date is not displayed as expected");

            loggerManager.getLogger().info("Contract Dates have been validated successfully");

    }
    /**
     * This method validates that the mandatory fields on the newly created opportunity match the values from the test data sheet.
     */
    @Step("Verify that the fields filled out on the newly created opportunity match the entered values from the test data sheet")
    public void validateMandatoryOpportunityInfo(LinkedHashMap<String, String> oppData) {
        pageRefresh(driver);
        waitForElementToBePresent(driver, opportunityNameHeader(oppyName));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.subTabName("Details")));
        takeScreenshot(TCName, driver);
        Allure.step("Verify the Opportunity Details", step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Opportunity Name"))), oppyName, "Opportunity Name field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Stage"))), oppData.get("OppyStage"), "Opportunity stage field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Lead Source"))), oppData.get("OppyLeadSource"), "Opportunity lead source field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Renewal Type"))), oppData.get("OppyRenewalOption"), "Opportunity Renewal field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Related to Third Party"))), oppData.get("OppyThirdPartyOption"), "Opportunity third party field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Category"))), oppData.get("OppyCategory"), "Opportunity Category field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Opportunity Currency"))), oppData.get("OppyCurrency"), "Opportunity Currency field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextFieldLinks("Account Name"))), oppData.get("AccountName"), "Account Name field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextFieldLinks("Sold to Contact"))), oppData.get("SoldToContactName"), "Sold to Contact field not saved on the Opportunity");
            softAssert.assertEquals(opportunityRecordTypeText.getText(), oppData.get("OpportunityRecordType"), "Opportunity Record Type not saved on the Opportunity");
            if(oppData.get("OppyProbabilityOverridePercent") != null) {
                String actualProbabilityPercent = getElementText(driver, driver.findElement(opportunityValidationNumberField("Probability (%)")));
                Assert.assertEquals(actualProbabilityPercent.replaceAll("[^0-9]", ""), readExcelData(opportunitiesFilePath, TCName, "OppyProbabilityOverridePercent"),
                        "Opportunity Probability has not been overriden");
                reusableLibrary.writeToExcel(opportunitiesFilePath, TCName, "OppyProbabilityOverridePercent",null );
            }
            validateContractSpecialistField(oppData);

            scrollToElement(driver,intercompanySaleLabel);
            validateContractDates(oppData);

        });

        Allure.step("Validate that mandatory opportunity details are populated correctly on the created Opportunity", step -> {
            softAssert.assertAll();
            loggerManager.getLogger().info("Mandatory details validated successfully on the created opportunity.");
        });
        takeScreenshot(TCName, driver);
    }
    /**
     * This method verifies successful navigation to the opportunity creation form.It only works when creating an opportunity and not when creating an opportunity from account
     */
    @Step("Verify successful navigation to opportunity creation form")
    public void verifyOpportunityCreationFormIsVisible() {
        waitForPageTitleToContain(driver, "New Opportunity");
        waitForElementToBePresent(driver, newOpportunityHeader());
        if (isElementPresent(driver, newOpportunityHeader())) {
            loggerManager.getLogger().info("Navigated Successfully to new opportunity creation form");
        } else {
            loggerManager.getLogger().error("Not able to navigate to opportunity creation form");
        }
        takeScreenshot(TCName, driver);
    }
    /**
     * This method creates a new Opportunity from the Account Record with mandatory fields.
     * It then fills in the mandatory fields such as Sold to Contact, Contract Specialist, Stage, Lead Source,
     * @param opportunityData A LinkedHashMap containing the expected values for the Opportunity fields.
     */
    @Step("Create a new Opportunity from Account Record with Mandatory fields")
    public void enterNewSalesOpportunityFromAccountRecord(LinkedHashMap<String, String> opportunityData) {
        oppyName = opportunityData.get("OpportunityName") + generateRandomString("_Automation");
        sendKeysToElement(driver, opportunityNameTextField, oppyName);

        //send keys and select record to Sold to Contact text fields

        sendKeysTypeAheadField(formTextField("Sold to Contact"), opportunityData.get("SoldToContactName"));
        waitForElementToBePresent(driver, recordToSelectAfterSendingKeys( opportunityData.get("SoldToContactName")));
        elementClick(driver, driver.findElement(recordToSelectAfterSendingKeys( opportunityData.get("SoldToContactName"))));
        isElementPresent(driver,filledFormTextField("Sold to Contact", opportunityData.get("SoldToContactName")));


        //send keys and select record to Contract Specialist text field
        sendKeysTypeAheadField( formTextField("Contract Specialist"), opportunityData.get("ContractSpecialistName"));
        waitForElementToBePresent(driver, recordToSelectAfterSendingKeys(opportunityData.get("ContractSpecialistName")));
        elementClick(driver, driver.findElement(recordToSelectAfterSendingKeys(opportunityData.get("ContractSpecialistName"))));
        isElementPresent(driver, filledFormTextField("Contract Specialist", opportunityData.get("ContractSpecialistName")));


        scrollToElement(driver,driver.findElement(picklistButtonElement("Stage") ));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Stage")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Stage",opportunityData.get("OppyStage"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Stage",opportunityData.get("OppyStage"))));

        scrollToElement(driver, driver.findElement(picklistButtonElement("Lead Source")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Lead Source")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Lead Source", opportunityData.get("OppyLeadSource"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Lead Source", opportunityData.get("OppyLeadSource"))));

        if (TCName.contains("EMEARegion") || TCName.contains("APACRegion"))
        {
            sendKeysToElement(driver, formTextField("First Appt Date"), convertDateFormat(getCurrentDateInMMddyyyyFormat(), "M/d/yyyy", "d/M/yyyy"));
            sendKeysToElement(driver, formTextField("Close Date"), convertDateFormat(currentDatePlusMonths(6), "M/d/yyyy", "d/M/yyyy"));
        }
        else {
            sendKeysToElement(driver, formTextField("First Appt Date"), getCurrentDateInMMddyyyyFormat());
            sendKeysToElement(driver, formTextField("Close Date"), currentDatePlusMonths(6));
        }

        String contractLength = opportunityData.get("ContractLength");
        if ("Multi-Year".equalsIgnoreCase(contractLength)) {
            expectedStartDate = getCurrentDateInMMddyyyyFormat();
            expectedEndDate =  subtractDays(currentDatePlusMonths(Integer.parseInt(opportunityData.get("ContractTerm_Months"))),1);
        }
        else if(TCName.contains("EMEARegion") || TCName.contains("APACRegion")){
            expectedStartDate = convertDateFormat(getCurrentDateInMMddyyyyFormat(), "M/d/yyyy", "d/M/yyyy");
            expectedEndDate = convertDateFormat(currentDatePlusMonths(6), "M/d/yyyy", "d/M/yyyy");
        }
        else {
            expectedStartDate = getCurrentDateInMMddyyyyFormat();
            expectedEndDate = subtractDays(currentDatePlusYears(1),1);
        }
        sendKeysToElement(driver, formTextField("Contract Start Date"), expectedStartDate);
        sendKeysToElement(driver, formTextField("Contract End Date"), expectedEndDate);

        scrollToElement(driver, driver.findElement(picklistButtonElement("Renewal Type")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Renewal Type")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Renewal Type", opportunityData.get("OppyRenewalOption"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Renewal Type", opportunityData.get("OppyRenewalOption"))));

        if(!TCName.contains("ProductSpecialistAccountManager")) {
            scrollToElement(driver, driver.findElement(picklistButtonElement("Related to Third Party")));
            elementClickByJS(driver, driver.findElement(picklistButtonElement("Related to Third Party")));
            scrollToElement(driver, driver.findElement(picklistButtonElementOption("Related to Third Party", opportunityData.get("OppyThirdPartyOption"))));
            elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Related to Third Party", opportunityData.get("OppyThirdPartyOption"))));
        }
        loggerManager.getLogger().info("All the mandatory fields are entered for the Opportunity creation");
        takeScreenshot(TCName, driver);
    }
    /**
     * This method creates a new Opportunity from the Opportunity Page with mandatory fields.
     * It first selects the Account Name in the form text field.
     * Then, it calls another method to enter the remaining mandatory fields for the Opportunity creation.
     * @param opportunityData A LinkedHashMap containing the expected values for the Opportunity fields.
     */
    @Step("Create a new Opportunity from Opportunity Page with Mandatory fields")
    public void enterNewSalesOpportunity(LinkedHashMap<String, String> opportunityData) {

        selectAccountNameOnOpportunity(opportunityData.get("AccountName"));
        enterNewSalesOpportunityFromAccountRecord(opportunityData);
    }

    /**
     * This method creates a new Affiliate Sales Opportunity from the Opportunity Page.
     * It fills in all the mandatory fields required for the creation of the opportunity.
     * The method reads data from an Excel file and uses it to populate the fields.
     * It also handles the selection of dropdown options and waits for elements to be present before interacting with them.
     * Finally, it logs the completion of the mandatory fields entry for the Affiliate Sales Opportunity creation.
     */
    @Step("Create a New Affiliate Sales Opportunity from Opportunity Page")
    public void enterAffiliateSalesOpportunityDetails() {
        try{
        waitForPageTitleToContain(driver,"New Sales");
        waitForElementToBePresent(driver, newOpportunityHeader());
        takeScreenshot(TCName, driver);
        sendKeysToElement(driver, accountNameTextField, readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        try{
            Thread.sleep(6000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        elementClick(driver, driver.findElement(accountNameOption(readExcelData(opportunitiesFilePath, TCName, "AccountName"))));
        oppyName= readExcelData(opportunitiesFilePath, TCName, "OpportunityName")+generateRandomString("_Automation");
        sendKeysToElement(driver, opportunityNameTextField, oppyName);
        sendKeysToElement(driver, soldToContactTextField, readExcelData(opportunitiesFilePath, TCName, "SoldToContactName"));
        try{
            Thread.sleep(6000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        elementClick(driver, driver.findElement(soldToContactOption(readExcelData(opportunitiesFilePath, TCName, "SoldToContactName"))));
        sendKeysToElement(driver, contractSpecialistTextField, readExcelData(opportunitiesFilePath, TCName, "ContractSpecialistName"));
        try{
            Thread.sleep(6000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }
        elementClick(driver, driver.findElement(contractSpecialistOption(readExcelData(opportunitiesFilePath, TCName, "ContractSpecialistName"))));
        elementClick(driver, stageDropdown);
        elementClick(driver, driver.findElement(dropDownBtnElementOption("Stage", readExcelData(opportunitiesFilePath, TCName, "OppyStage"))));
        takeScreenshot(TCName, driver);
        scrollToElement(driver, leadSourceDropdown);
        elementClick(driver, leadSourceDropdown);
        elementClick(driver, driver.findElement(dropDownBtnElementOption("Lead Source", readExcelData(opportunitiesFilePath, TCName, "OppyLeadSource"))));
        // Affiliate Sales Dropdown Code is added
        elementClick(driver, affiliateSaleDropDown);
        elementClick(driver, driver.findElement(dropDownBtnElementOption("Affiliate Sale", readExcelData(opportunitiesFilePath, TCName, "AffiliateSaleOption"))));
        takeScreenshot(TCName, driver);
        sendKeysToElement(driver, firstAppointmentDateTextField, getCurrentDateInMMddyyyyFormat());
        sendKeysToElement(driver, closeDateTextField, currentDatePlusMonths(1));
        expectedStartDate = getCurrentDateInMMddyyyyFormat();
        expectedEndDate = subtractDays(currentDatePlusMonths(7), 1);
        sendKeysToElement(driver, formTextField("Contract Start Date"), expectedStartDate);
        // Contract End Date is set to 7 months from the current date for the Affiliate Sales Opportunity Creation as per the requirement.
        sendKeysToElement(driver, formTextField("Contract End Date"), expectedEndDate);
        // Renewal Type selected is 'One-Time' as we do not renew the Affiliate Sales Contract as it is 0 $ contract as per the requirement.
        elementClick(driver, renewalTypeDropdown);
        elementClick(driver, driver.findElement(dropDownBtnElementOption("Renewal Type", readExcelData(opportunitiesFilePath, TCName, "OppyRenewalOption"))));
        takeScreenshot(TCName, driver);
        scrollToElement(driver, relatedToThirdPartyDropdown);
        elementClick(driver, relatedToThirdPartyDropdown);
        elementClickByJS(driver, driver.findElement(dropDownBtnElementOption("Related to Third Party", readExcelData(opportunitiesFilePath, TCName, "OppyThirdPartyOption"))));
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("All the mandatory fields are entered for the  Affiliate Sales Opportunity Creation");

        }
        catch (Exception e){
            loggerManager.getLogger().error("Error occurred while entering the mandatory fields for the Affiliate Sales Opportunity Creation");
            Assert.assertTrue(false, "Error occurred while entering the mandatory fields for the Affiliate Sales Opportunity Creation");
        }
    }

    /**
     * This method validates that the created Opportunity is an Affiliate Sales Opportunity.
     * It scrolls to the Opportunity Currency text element and waits for it to be visible.
     * It then compares the actual value of the Affiliate Sale field with the expected value from the Excel data.
     * If the values match, it logs a success message and takes a screenshot.
     * If the values do not match, it logs an error message and asserts a failure.
     */
    @Step("Validate the Affiliate Sales Opportunity Details")
    public void validateAffiliateSalesOpportunityDetails() {
        try {
            scrollToElement(driver, relatedListQuickLinks);
            waitForElementToBeVisible(driver, relatedListQuickLinks);
            Allure.step("Validate that Stage is set to 'Opportunity Identification' for the Affiliate Sales Opportunity", step -> {
                waitForElementToBeVisible(driver, oppyStageText);
                softAssert.assertEquals(getElementText(driver, oppyStageText), readExcelData(opportunitiesFilePath, TCName, "OppyStage"), "Stage is not set to 'Opportunity Identification' for the Affiliate Sales Opportunity");
                loggerManager.getLogger().info("Stage is set to 'Opportunity Identification' for the Affiliate Sales Opportunity");
            });
            scrollToElement(driver, opportunityCurrencyText);
            waitForElementToBeVisible(driver, opportunityCurrencyText);
            Allure.step("Validate that Affiliate Sale is set to 'Yes' for Affiliate Sales Opportunity", step -> {
                softAssert.assertEquals(getElementText(driver, affiliateSaleText), readExcelData(opportunitiesFilePath, TCName, "AffiliateSaleOption"), "Affiliate Sale is not set to 'Yes' for Affiliate Sales Opportunity");
                loggerManager.getLogger().info("Affiliate Sale is set to 'Yes' for Affiliate Sales Opportunity");
            });
            scrollToElement(driver, multiYearInformationSection);
            waitForElementToBeVisible(driver, multiYearInformationSection);
            Allure.step("Validate that Probability (%) is correctly set for the Affiliate Sales Opportunity as per Oppy Stage", step -> {
                softAssert.assertEquals(getElementText(driver, probabilityPercentageText), readExcelData(opportunitiesFilePath, TCName, "Probability"), "Probability (%) is not correctly set for the Affiliate Sales Opportunity as per the Oppy Stage");
                loggerManager.getLogger().info("Probability (%) is correctly set for the Affiliate Sales Opportunity as per Oppy Stage");
            });
            scrollToElement(driver, forecastInformationSection);
            waitForElementToBeVisible(driver, forecastInformationSection);
            Allure.step("Validate that Renewal Type is set to 'One-Time' for the Affiliate Sales Opportunity", step -> {
                softAssert.assertEquals(getElementText(driver, renewalTypeText), readExcelData(opportunitiesFilePath, TCName, "OppyRenewalOption"), "Renewal Type is not set to 'One-Time' for the Affiliate Sales Opportunity");
                loggerManager.getLogger().info("Renewal Type is set to 'One-Time' for the Affiliate Sales Opportunity");
            });
            Allure.step("Validate that Category is set to 'New Sale' for the Affiliate Sales Opportunity", step -> {
                softAssert.assertEquals(getElementText(driver,oppyCategoryText), readExcelData(opportunitiesFilePath,TCName,"OppyCategory"), "Category is not set to 'New Sale' for the Affiliate Sales Opportunity");
                loggerManager.getLogger().info("Category is set to 'New Sale' for the Affiliate Sales Opportunity");
            });
            Allure.step("Validate that Contract Start Date is set to current date for the Affiliate Sales Opportunity", step -> {
                softAssert.assertEquals(getElementText(driver,contractStartDateText), expectedStartDate, "Contract Start Date is not set to current date for the Affiliate Sales Opportunity");
                loggerManager.getLogger().info("Contract Start Date is set to current date for the Affiliate Sales Opportunity");
            });
            Allure.step("Validate that Contract End Date is set to 7 months from the current date for the Affiliate Sales Opportunity", step -> {
                softAssert.assertEquals(getElementText(driver,contractEndDateText), expectedEndDate, "Contract End Date is not set to 7 months from the current date for the Affiliate Sales Opportunity");
                loggerManager.getLogger().info("Contract End Date is set to 7 months from the current date for the Affiliate Sales Opportunity");
            });
            scrollToElement(driver, contractInformationSection);
            waitForElementToBeVisible(driver, contractInformationSection);
            Allure.step("Validate that Related to Third Party is set to 'No' for the Affiliate Sales Opportunity", step -> {
                softAssert.assertEquals(getElementText(driver, relatedToThirdPartyText), readExcelData(opportunitiesFilePath, TCName, "OppyThirdPartyOption"), "Related to Third Party is not set to 'No' for the Affiliate Sales Opportunity");
                loggerManager.getLogger().info("Related to Third Party is set to 'No' for the Affiliate Sales Opportunity");
            });
            takeScreenshot(TCName, driver);
            softAssert.assertAll();
            loggerManager.getLogger().info("Affiliate Sales Opportunity details are validated successfully");
        } catch (Exception e) {
            loggerManager.getLogger().error("Error occurred while validating the Affiliate Sales Opportunity details");
            Assert.fail("Error occurred while validating the Affiliate Sales Opportunity details");
        }
    }

    /**
     * This method cancels the Opportunity Record Page after the user clicks on the Save and New button.
     * It waits for the Opportunity Record Page header to be visible and then clicks the cancel button.
     * If an error occurs during this process, it logs an error message and asserts a failure.
     */
    @Step("Cancel the Opportunity Record Page after user clicks on Save and New button")
    public void cancelOpportunityRecordPage(){
        try{
            waitForElementToBeVisible(driver, opportunityRecordPageHeader);
            takeScreenshot(TCName, driver);
            elementClick(driver, oppyRecordPageCancelBtn);
            loggerManager.getLogger().info("Opportunity Creation Page is cancelled after user clicks on Save and New button");
        }
        catch (Exception e){
            loggerManager.getLogger().error("Error occurred while cancelling the Opportunity Creation Page after user clicks on Save and New button");
            Assert.assertTrue(false, "Error occurred while cancelling the Opportunity Creation Page after user clicks on Save and New button");
        }

    }

    /**
     * This method creates a new Opportunity with mandatory fields and saves it.
     * @param opportunityData A LinkedHashMap containing the mandatory fields and their values for the Opportunity.
     */
    @Step("Create New Opportunity with mandatory fields and save")
    public void createNewSalesOpportunityWithMandatoryFieldsAndSave(LinkedHashMap<String, String> opportunityData) {
        reusableBusinessLibrary.openSFDCTab("Opportunities");
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        verifyOpportunityCreationFormIsVisible();
        enterNewSalesOpportunity(opportunityData);
        reusableBusinessLibrary.clickSaveBtn();
        verifyOpportunityIsSaved();
    }
    /**
     * Edits specific fields on an existing Opportunity.
     * @param opportunityData A LinkedHashMap containing the fields to be updated and their new values.
     */
    @Step("Edit specific fields on Opportunity")
    public void editFieldsOnNewSalesOpportunity(LinkedHashMap<String, String> opportunityData) {
        reusableBusinessLibrary.clickEditBtn();

        waitForElementToBePresent(driver, picklistButtonElement("Stage"));

        oppyName = opportunityData.get("OpportunityName") + generateRandomString("_Automation");
        formTextField("Opportunity Name").clear();
        sendKeysToElement(driver, formTextField("Opportunity Name"), oppyName);

        scrollToElement(driver,driver.findElement(picklistButtonElement("Stage") ));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Stage")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Stage",opportunityData.get("UpdatedStage"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Stage",opportunityData.get("UpdatedStage"))));

        scrollToElement(driver,driver.findElement(picklistButtonElement("Opportunity Currency") ));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Opportunity Currency")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Opportunity Currency",opportunityData.get("UpdatedCurrency"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Opportunity Currency",opportunityData.get("UpdatedCurrency"))));

        formTextField("Close Date").clear();
        sendKeysToElement(driver, formTextField("Close Date"), opportunityData.get("OppyCloseDate"));

        scrollToElement(driver, driver.findElement(picklistButtonElement("Lead Source")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Lead Source")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Lead Source", opportunityData.get("UpdatedLeadSource"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Lead Source", opportunityData.get("UpdatedLeadSource"))));

        reusableBusinessLibrary.clickSaveBtn();

        verifyOpportunityIsSaved();

    }
    /**
     * Validates that the fields edited on an existing Opportunity have been saved successfully.
     * @param oppData A LinkedHashMap containing the expected values for the updated fields.
     */
    @Step("Verify that fields that were edited have been saved successfully on the Opportunity")
    public void validateUpdatedFieldsOnNewSalesOpportunity(LinkedHashMap<String, String> oppData) {
        pageRefresh(driver);
        waitForElementToBePresent(driver, opportunityValidationTextField("Opportunity Name"));
        scrollToElement(driver, driver.findElement(opportunityValidationTextField("Lead Source")))
        ;
        Allure.step("Verify the Opportunity fields", step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Opportunity Name"))), oppyName, "Opportunity Name field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Stage"))), oppData.get("UpdatedStage"), "Opportunity stage field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Lead Source"))), oppData.get("UpdatedLeadSource"), "Opportunity lead source field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Opportunity Currency"))), oppData.get("UpdatedCurrency"), "Opportunity Currency field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Close Date"))),  oppData.get("OppyCloseDate"),"Opportunity close date field not saved on the Opportunity");
        });
            softAssert.assertAll();
            loggerManager.getLogger().info("Fields that were updated on the Opportunity are validated successfully.");

        takeScreenshot(TCName, driver);
    }
    /**
     * Overrides the probability of conversion on the Opportunity Creation form.
     */
    @Step("Override the probability of conversion on Opportunity Creation form")
    public void overrideProbabilityOnOpportunity() {
        reusableBusinessLibrary.clickEditBtn();

        scrollToElement(driver,formTextField("Probability (%)"));
        formTextField("Probability (%)").clear();

        String probabilityOverridePercent = String.valueOf(generateRandomNumber(2));
        sendKeysToElement(driver, formTextField("Probability (%)"), probabilityOverridePercent );
        reusableLibrary.writeToExcel(opportunitiesFilePath, TCName, "OppyProbabilityOverridePercent",probabilityOverridePercent );
        elementClickByJS(driver, probabilityOverrideCheckBox);

        formTextArea("Probability Override Reason").clear();
        sendKeysToElement(driver, formTextArea("Probability Override Reason"), "Probability needs to be overriden for testing");

        takeScreenshot(TCName, driver);
        //click this out so that save button can be clicked as it gives error if you try to save right after overriding probability
        scrollToElement(driver, driver.findElement(picklistButtonElement("Renewal Type")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Renewal Type")));

        reusableBusinessLibrary.clickSaveBtn();

        wait.until(ExpectedConditions.invisibilityOf(formTextField("Probability (%)")));
        loggerManager.getLogger().info("Probability overriden in opportunity creation form");

    }


/**
 * This method iterates through every possible stage in the Stage field on an opportunity.
 * It first determines the list of stages based on the opportunity record type (New Sales or Renewal Sales).
 * Then, it selects each stage in the list sequentially.
 *
 * @param opportunityRecordType The type of the opportunity record (e.g., "New Sales" or "Renewal Sales").
 */

    @Step("Switch through every possible stage in the Stage field on opportunity")
    public void changeStages(String opportunityRecordType) {
        List<String> opportunityStages= new ArrayList<>();

        if(Objects.equals(opportunityRecordType, "New Sales"))
        {
            opportunityStages.add("SDR Qualified");
            opportunityStages.add("Opportunity Identification");
            opportunityStages.add("Opportunity Discovery/Research");
            opportunityStages.add("Opportunity Qualified/Early Review/RFP");
            opportunityStages.add("Proposal/Price Quote");
            opportunityStages.add("Workshop/POC");
            opportunityStages.add("Pricing Negotiation");
            opportunityStages.add("Contract Negotiation");
            opportunityStages.add("Verbal Agreement");
            opportunityStages.add("Pending Signature");
            opportunityStages.add("Closed Won");
            opportunityStages.add("Closed Lost");
            opportunityStages.add("Closed Contract Merge");
            opportunityStages.add("Closed Lost - Rep Update Pending");
        }
        else if (Objects.equals(opportunityRecordType, "Renewal Sales"))
        {
            opportunityStages.add("Downgrade / Medium Risk");
            opportunityStages.add("High Cancellation Risk");
            opportunityStages.add("Low Cancellation Risk");
            opportunityStages.add("Not Yet Updated");
            opportunityStages.add("New Service Proposed");
            opportunityStages.add("Under Review / Stable");
            opportunityStages.add("Renewal Sent / Secure");
            opportunityStages.add("Closed Won");
            opportunityStages.add("Closed Lost");
            opportunityStages.add("Closed Contract Merge");
            opportunityStages.add("Closed Lost - Rep Update Pending");
        }

        waitForElementToBePresent(driver, picklistButtonElement("Stage"));
        for (String stageSelected : opportunityStages) {
            selectStage(stageSelected);
        }
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("All stages on the opportunity have been switched to successfully");
    }

    /**
     * Selects a specific stage in the Stage field on an opportunity.
     * @param stageSelected String - The stage to be selected in the Stage field.
     */
    public void selectStage(String stageSelected) {
        try {
            elementClickByJS(driver, driver.findElement(picklistButtonElement("Stage")));
            scrollToElement(driver, driver.findElement(picklistButtonElementOption("Stage", stageSelected)));
            elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Stage", stageSelected)));
            Assert.assertTrue(isElementPresent(driver, filledFormDropDownField("Stage", stageSelected)), "Not able to switch to " + stageSelected + " stage");
            takeScreenshot(TCName, driver);
            loggerManager.getLogger().info("Switched to stage: " + stageSelected);
        } catch (Exception e) {
            loggerManager.getLogger().error("Failed to switch to stage: " + stageSelected, e);
            softAssert.fail("Failed to switch to stage: " + stageSelected);
        }
    }





    /**
     * This method selects the Partnership Alliance Sales Type value on the Opportunity.
     * @param value String - The value to be selected for Partnership Alliance Sales Type.
     */
    @Step("Select Partnership Alliance Sales Type value as {value}")
    public void selectPartnershipAllianceSalesTypeValue(String value){
        scrollToElement(driver, partnershipAllianceSalesTypeLabel);
        if(value.contains(";")) {
            String[] values = value.split(";");
            for (String val : values) {
                scrollWithinElement(driver, partnershipAllianceSalesTypeMultiselectPicklist, 100);
                waitForElementToBeVisible(driver, driver.findElement(partnershipSalesTypeOption(val)));
                elementClickByJS(driver, driver.findElement(partnershipSalesTypeOption(val)));
                elementClickByJS(driver, partnershipAllianceMoveToChosenBtn);
                loggerManager.getLogger().info("Partnership Alliance Sales Type value " + val + " is selected");
            }
        }
        else {
            scrollWithinElement(driver, partnershipAllianceSalesTypeMultiselectPicklist, 100);
            waitForElementToBeVisible(driver, driver.findElement(partnershipSalesTypeOption(value)));
            elementClickByJS(driver, driver.findElement(partnershipSalesTypeOption(value)));
            elementClickByJS(driver, partnershipAllianceMoveToChosenBtn);
            loggerManager.getLogger().info("Partnership Alliance Sales Type value " + value + " is selected");
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method selects the Partner Account on the Opportunity.
     * @param accountName String - The value to be selected for Partner Account.
     */

    @Step("Select Partner Account as {accountName}")
    public void selectPartnerAccountOnOpportunity(String accountName){
        scrollToElement(driver, thirdPartySectionLabel);
        if (isElementDisplayed(driver, selectedPartnerAccount)){
            elementClick(driver, partnerAccountClearBtn);
        }
        waitForElementToBeVisible(driver, partnerAccountTextField);
        partnerAccountTextField.click();
        sendKeysToElement(driver, partnerAccountTextField, accountName);
        try{
            Thread.sleep(6000);
        }catch (InterruptedException e){
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForElementToBeVisible(driver, driver.findElement(opportunityPagePicklistOption(accountName)));
        elementClick(driver, driver.findElement(opportunityPagePicklistOption(accountName)));
        loggerManager.getLogger().info("Partner Account " + accountName + " is selected");
    }

    /**
     * This method verifies the value of Partnership Alliance Sales Type on the Opportunity.
     * @param value String - The expected value of Partnership Alliance Sales Type.
     */

    @Step("Verify that Partnership Alliance Sales Type value is {value}")
    public void verifyPartnershipAllianceSalesTypeValue(String value){
        waitForPageTitleToContain(driver, "Opportunity");
        scrollToElement(driver, contractTermLabel);
        waitForElementToBeVisible(driver, partnershipAllianceSalesTypeValue);
        Assert.assertEquals(getElementText(driver, partnershipAllianceSalesTypeValue), value, "Partnership Alliance Sales Type value is not " + value);
        loggerManager.getLogger().info("Partnership Alliance Sales Type value is " + value);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method selects Account Name on the Opportunity.
     * @param accountName String - The value to be selected for Account Name.
     */

    @Step("Select Account Name as {accountName}")
    public void selectAccountNameOnOpportunity(String accountName){
        waitForElementToBeVisible(driver, accountNameTextField);
        sendKeysTypeAheadField(accountNameTextField, accountName);
        waitForElementToBePresent(driver, recordToSelectAfterSendingKeys(accountName));
        elementClick(driver, driver.findElement(recordToSelectAfterSendingKeys(accountName)));
        isElementPresent(driver, filledFormTextField("Account Name", accountName));
        loggerManager.getLogger().info("Account Name " + accountName + " is selected");
    }

    /**
     * This method selects the value for Related to Third Party field on the Opportunity.
     * @param value String - The value to be selected for Related to Third Party field.
     */
    @Step("Select the value for Related to Third Party field on the Opportunity as {value}")
    public void selectRelatedToThirdPartyOnOpportunity(String value){
        scrollToElement(driver, relatedToThirdPartyDropdown);
        elementClick(driver, relatedToThirdPartyDropdown);
        try {
            waitForElementToBeVisible(driver, driver.findElement(selectDropDownOption(value)));
            elementClick(driver, driver.findElement(selectDropDownOption(value)));
            loggerManager.getLogger().info("Related to Third Party value " + value + " is selected");
        }
        catch (AssertionError e){
            //Retry if dropdown is closed because of browser pop up
            elementClick(driver, relatedToThirdPartyDropdown);
            loggerManager.getLogger().info("Related to Third Party dropdown is reopened after it was closed due to browser pop up");
            waitForElementToBeVisible(driver, driver.findElement(selectDropDownOption(value)));
            elementClick(driver, driver.findElement(selectDropDownOption(value)));
            loggerManager.getLogger().info("Related to Third Party value " + value + " is selected");
        }
    }

    /**
     * This method selects the Opportunity Stage value on the Opportunity.
     * @param stage String - The value to be selected for Opportunity Stage.
     */
    @Step("Select Opportunity Stage as {stage}")
    public void selectOpportunityStage(String stage){
        waitForElementToBeVisible(driver, stageDropdown);
        elementClick(driver, stageDropdown);
        waitForElementToBeVisible(driver, driver.findElement(selectDropDownOption(stage)));
        Assert.assertTrue(isElementDisplayed(driver, driver.findElement(selectDropDownOption(stage))), "Opportunity Stage " + stage + " is not displayed");
        loggerManager.getLogger().info("Opportunity Stage " + stage + " is displayed");
        takeScreenshot(TCName, driver);
        elementClick(driver, opportunityCancelBtn);
    }

    /**
     * This method verifies the value of the Opportunity Stage on the Opportunity page for the given Record Type.
     * @param stages String - The expected values of the Opportunity Stages.
     * @param opportunityRecordType String - The Record Type of the Opportunity.
     */
    @Step("Verify that Opportunity Stages {stages} are available for selection for {opportunityRecordType}")
    public void verifyOpportunityStages(String stages, String opportunityRecordType){
        reusableBusinessLibrary.clickNewBtn();
        reusableBusinessLibrary.selectRecordType(opportunityRecordType);
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        List<String> stageList = Arrays.asList(stages.split(";"));
        for (String stage : stageList) {
            selectOpportunityStage(stage);
        }
    }

    /**
     * This method verifies that Renewal Source Right Arrow Icon is displayed on the Renewal Opportunity.
     */
    @Step("Verify that Renewal Source Right Arrow Icon is displayed on the Renewal Opportunity")
    public void verifyRenewalSourceRightArrowIcon(){
        waitForElementToBeVisible(driver, renewalSourceRightArrowIcon);
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, stageStepActionButton);
        scrollToElement(driver, stageStepActionButton);
        waitForElementToBeVisible(driver, renewalSourceRightArrowIcon);
        waitForElementToBeClickable(driver, renewalSourceRightArrowIcon);
        Assert.assertTrue(isElementDisplayed(driver, renewalSourceRightArrowIcon) && isElementDisplayed(driver, renewalSourceLabel), "Renewal Source Right Arrow Icon is not displayed on the Renewal Opportunity");
        loggerManager.getLogger().info("Renewal Source Right Arrow Icon is displayed on the Renewal Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks on Renewal Source Right Arrow Icon on the Renewal Opportunity.
     */
    @Step("Click on Renewal Source Right Arrow Icon on the Renewal Opportunity")
    public void clickRenewalSourceIcon(){
        waitForElementToBeVisible(driver, renewalSourceRightArrowIcon);
        elementClickByJS(driver, renewalSourceRightArrowIcon);
        switchToWindowByNumber(driver, 1);
    }

    /**
     * This method verifies that Renewal Opportunity Left Arrow Icon is displayed on the Renewal Source Opportunity.
     */
    @Step("Verify that Renewal Opportunity Left Arrow Icon is displayed on the Renewal Source Opportunity")
    public void verifyRenewalOpportunityLeftArrowIcon(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        for (int i = 0; i < 3; i++) {
            pageRefresh(driver);
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
            waitForPageTitleToContain(driver, "| Opportunity | Salesforce");
            waitForElementToBeVisible(driver, fulfillmentQuickLink);
            scrollToElement(driver, fulfillmentQuickLink);
            if (isElementDisplayed(driver, renewalSourceLeftArrowIcon)) {
                break;
            }
            loggerManager.getLogger().info("Page refreshed");
        }
        waitForElementToBeVisible(driver, renewalSourceLeftArrowIcon);
        waitForElementToBeClickable(driver, renewalSourceLeftArrowIcon);
        Assert.assertTrue(isElementDisplayed(driver, renewalSourceLeftArrowIcon) && isElementDisplayed(driver, renewalOpportunityLabel), "Renewal Opportunity Left Arrow Icon is not displayed on the Renewal Source Opportunity");
        loggerManager.getLogger().info("Renewal Opportunity Left Arrow Icon is displayed on the Renewal Source Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the sequence of Opportunity Products List View column headers.
     * @param expectedHeaders String - The expected sequence of Opportunity Products List View column headers.
     */
    @Step("Get the sequence of Opportunity Products List View column headers")
    public void verifyOpportunityProductsColumnSequence(String expectedHeaders) {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        String actualHeaders = getOppyProductsColumnHeaders(opportunityProductsListViewColumnHeaders);
        Allure.step("Verify that the sequence of Opportunity Products List View column headers is " + expectedHeaders, step -> {
            if (actualHeaders.equals(expectedHeaders)) {
                loggerManager.getLogger().info("Opportunity Products List View Column headers match the expected sequence: " + expectedHeaders);
            } else {
                loggerManager.getLogger().error("Opportunity Products List View Column headers do not match the expected sequence. Expected: " + expectedHeaders + ", but found: " + actualHeaders);
            }
            Assert.assertEquals(actualHeaders, expectedHeaders, "Opportunity Products List View Column headers do not match the expected sequence " + expectedHeaders);
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks on the Save button on the Opportunity page and validates that the Opportunity is saved.
     */
    @Step("Save the Opportunity")
    public void saveOpportunity(){
        reusableBusinessLibrary.clickSaveBtn();
        waitForElementToBeVisible(driver, reusableBusinessLibrary.showMoreActionsButton);
        Assert.assertTrue(isElementDisplayed(driver, reusableBusinessLibrary.showMoreActionsButton), "Failed to save the Opportunity");
        oppyID = getSFDCRecordIDFromURL(getUrl());
        loggerManager.getLogger().info("Opportunity saved successfully and the record ID is " + oppyID);
    }

    /**
     * This method navigates to the Products Related List on Opportunity.
     */
    @Step("Navigate to Products Related List on Opportunity")
    public void navigateToProductsRelatedList(){
        waitForElementToBeVisible(driver, productsTab);
        elementClickByJS(driver, productsTab);
        scrollToElement(driver, fulfillmentQuickLink);
        waitForElementToBeVisible(driver, productsRelatedList);
        elementClickByJS(driver, productsRelatedList);
        loggerManager.getLogger().info("Navigated to Products Related List on Opportunity");
    }

    /**
     * This method navigates to the Contact Roles Related List on Opportunity.
     */
    @Step("Navigate to Contact Roles Related List on Opportunity")
    public void navigateToContactRolesRelatedList(){
        waitForElementToBeVisible(driver, contactsTab);
        elementClickByJS(driver, contactsTab);
        waitForElementToBeVisible(driver, contactRolesRelatedList);
        elementClickByJS(driver, contactRolesRelatedList);
        loggerManager.getLogger().info("Navigated to Contact Roles Related List on Opportunity");
    }

    /**
     * This method verifies the sequence of Contact Roles List View column headers on Opportunity.
     * @param expectedHeaders String - The expected sequence of Contact Roles List View column headers.
     */
    @Step("Verify the sequence of Contact Roles List View column headers on Opportunity")
    public void verifyContactRolesColumnSequence(String expectedHeaders) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        String actualHeaders = getColumnHeaders(contactRolesListViewColumnHeaders);

        Allure.step("Verify that the sequence of Contact Roles List View column headers is " + expectedHeaders, step -> {
            if (actualHeaders.equals(expectedHeaders)) {
                loggerManager.getLogger().info("Contact Roles List View Column headers match the expected sequence: " + expectedHeaders);
            } else {
                loggerManager.getLogger().error("Contact Roles List View Column headers do not match the expected sequence. Expected: " + expectedHeaders + ", but found: " + actualHeaders);
            }
            Assert.assertEquals(actualHeaders, expectedHeaders, "Contact Roles List View Column headers do not match the expected sequence " + expectedHeaders);
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method gets the sequence of column headers of a List View or fields from a section on the Opportunity.
     * @param headersLocator By - The locator for the column headers or fields.
     * @return String - The sequence of column headers or the fields.
     */
    @Step("Get the sequence of column headers")
    public String getColumnHeaders(By headersLocator) {
        String actualHeaders = "";
        waitForElementToBePresent(driver, headersLocator);

        List<WebElement> headers = driver.findElements(headersLocator);
        for (WebElement header : headers) {
            actualHeaders = actualHeaders + header.getText() + ",";
        }

        return actualHeaders.substring(0, actualHeaders.length() - 1);
    }

    /**
     * This method gets the sequence of Contact Role Record fields on the Opportunity.
     * @return String - The sequence of Contact Role Record fields.
     */
    @Step("Get the sequence of Contact Role Record fields")
    public String getContactRoleRecordFields(){
        String actualFields = "";
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, contactRoleRecordFields);
        List<WebElement> contactRoleFields = driver.findElements(contactRoleRecordFields);
        for (WebElement field : contactRoleFields)
            actualFields = actualFields + field.getText() + ",";

        return actualFields.substring(0, actualFields.length() - 1);
    }

    /**
     * This method verifies the sequence of Contact Role Record fields on the Opportunity.
     * @param expectedFields String - The expected sequence of Contact Role Record fields.
     */
    @Step("Verify the sequence of Contact Role Record fields")
    public void verifyContactRoleRecordFields(String expectedFields){
        String actualFields = getContactRoleRecordFields();
        Allure.step("Verify that the sequence of Contact Role Record fields is " + expectedFields, step -> {
            if (actualFields.equals(expectedFields)) {
                loggerManager.getLogger().info("Contact Role Record fields match the expected sequence: " + expectedFields);
            } else {
                loggerManager.getLogger().error("Contact Role Record fields do not match the expected sequence. Expected: " + expectedFields + ", but found: " + actualFields);
            }
            Assert.assertEquals(actualFields, expectedFields, "Contact Role Record fields do not match the expected sequence " + expectedFields);
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method navigates to the Contact Roles record on the Opportunity.
     */
    @Step("Navigate to Contact Roles record")
    public void navigateToContactRolesRecord(){
        waitForElementToBeVisible(driver, contactRoleRecord);
        elementClick(driver, contactRoleRecord);
        loggerManager.getLogger().info("Navigated to Contact Roles record");
    }

    /**
     * This method verifies the sequence of Service Data section fields on the Opportunity.
     * @param expectedFields String - The expected sequence of Service Data section fields.
     */
    @Step("Verify that the sequence of Service Data section fields is {expectedFields}")
    public void verifyServiceDataSectionFields(String expectedFields) {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, thirdPartySectionLabel);
        scrollToElement(driver, thirdPartySectionLabel);
        String actualFields = getColumnHeaders(servicesDataSectionFields);
        Allure.step("Verify that the sequence of Service Data section fields is " + expectedFields, step -> {
            if (actualFields.equals(expectedFields)) {
                loggerManager.getLogger().info("Service Data section fields match the expected sequence: " + expectedFields);
            } else {
                loggerManager.getLogger().error("Service Data section fields do not match the expected sequence. Expected: " + expectedFields + ", but found: " + actualFields);
            }
            Assert.assertEquals(actualFields, expectedFields, "Service Data section fields do not match the expected sequence " + expectedFields);
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the Commit Amount and Manager Notes fields are displayed on the Opportunity.
     */
    @Step("Verify that the Commit Amount and Manager Notes field is displayed on the Opportunity")
    public void verifyCommitAmountAndManagerNotesFields(){
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        scrollToElement(driver, forecastSectionLabel);
        waitForElementToBeVisible(driver, commitAmountField);
        waitForElementToBeVisible(driver, managerNotesField);
        Assert.assertTrue(isElementDisplayed(driver, commitAmountField) && isElementDisplayed(driver, managerNotesField), "Commit Amount and Manager Notes fields are not displayed on the Opportunity");
        loggerManager.getLogger().info("Commit Amount and Manager Notes fields are displayed on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that Quip tab is displayed on the Opportunity.
     */
    @Step("Verify that Quip tab is displayed on the Opportunity")
    public void verifyQuipTab(){
        waitForElementToBeVisible(driver, moreTab);
        if(isElementDisplayed(driver, moreTab)) {
            elementClickByJS(driver, moreTab);
            Assert.assertTrue(isElementDisplayed(driver, quipTabUnderMore), "Quip tab is not displayed on the Opportunity");
            loggerManager.getLogger().info("Quip tab is displayed under More on the Opportunity");
        }
        else{
            waitForElementToBeVisible(driver, quipTab);
            Assert.assertTrue(isElementDisplayed(driver, quipTab), "Quip tab is not displayed on the Opportunity");
            loggerManager.getLogger().info("Quip tab is displayed on the Opportunity");
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the Business Sector field is renamed to Segment on Opportunity.
     */
    @Step("Verify that the Business Sector field is renamed to Segment on Opportunity")
    public void verifyBusinessSectorToSegmentFieldRename() {
        waitForElementToBeVisible(driver, fulfillmentQuickLink);
        scrollToElement(driver, fulfillmentQuickLink);
        waitForElementToBeVisible(driver, segmentField);
        Assert.assertTrue(isElementDisplayed(driver, segmentField) && !isElementDisplayed(driver,businessSectorField), "Business Sector field is not renamed to Segment on Opportunity");
        loggerManager.getLogger().info("Business Sector field is renamed to Segment on Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the ERS DOA field is not displayed on the Opportunity.
     */
    @Step("Verify that ERS DOA field is not displayed on the Opportunity")
    public void verifyERSDOAFieldNotDisplayed(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        Assert.assertFalse(isElementDisplayed(driver, ERSDOAField), "ERS DOA field is displayed on the Opportunity");
        loggerManager.getLogger().info("ERS DOA field is not displayed on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that Key Attributes - Crediting Report Icon is displayed on the Opportunity.
     */
    @Step("Verify that Key Attributes - Crediting Report Icon is displayed on the Opportunity")
    public void verifyKeyAttributesCreditingReportIcon(){
        scrollToTop(driver);
        scrollToElement(driver, fulfillmentQuickLink);
        waitForElementToBeVisible(driver, keyAttributesCreditingReportIcon);
        Assert.assertTrue(isElementDisplayed(driver, keyAttributesCreditingReportIcon), "Key Attributes - Crediting Report Icon is not displayed on the Opportunity");
        loggerManager.getLogger().info("Key Attributes - Crediting Report Icon is displayed on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the Regulatory picklist contains the expected values.
     * @param expectedValues String - The expected values in the Regulatory picklist.
     */
    @Step("Verify that Regulatory picklist contains the values: {expectedValues}")
    public void verifyRegulatoryPicklistValues(String expectedValues){
        reusableBusinessLibrary.clickEditBtn();
        waitForElementToBeVisible(driver, regulatoryPicklist);
        elementClickByJS(driver, regulatoryPicklist);
        String[] expectedValuesArray = expectedValues.split(",");
        ArrayList<String> expectedValuesList = new ArrayList<>(Arrays.asList(expectedValuesArray));
        ArrayList<String> actualValuesList = getOpportunityPicklistValues(regulatoryPicklistOptions);
        Allure.step("Verify that Regulatory picklist contains the values: " + expectedValues, step -> {
            if (actualValuesList.containsAll(expectedValuesList)) {
                loggerManager.getLogger().info("Regulatory picklist values contains the values: " + expectedValues);
            } else {
                loggerManager.getLogger().error("Regulatory picklist values does not contain the values: " + expectedValues);
            }
            Assert.assertTrue(actualValuesList.containsAll(expectedValuesList), "Regulatory picklist values does not contain the values: " + expectedValues + " Actual values: " + actualValuesList);
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method gets the option values from the specified picklist on the Opportunity.
     * @param picklistOptions List<WebElement> - The list of picklist options.
     * @return ArrayList<String> - The option values from the picklist.
     */
    @Step("Get the option values from the picklist")
    public ArrayList<String> getOpportunityPicklistValues(List<WebElement> picklistOptions) {
        ArrayList<String> values = new ArrayList<>();
        for (WebElement option : picklistOptions) {
            values.add(option.getAttribute("data-value"));
        }
        return values;
    }

    /**
     * This method verifies that the Regulatory picklist values are sorted.
     */
    @Step("Verify if the Regulatory picklist values are sorted")
    public void verifyRegulatoryPicklistValuesSorted(){
        ArrayList<String> actualValuesList = getOpportunityPicklistValues(regulatoryPicklistOptions);
        ArrayList<String> sortedValuesList = new ArrayList<>(actualValuesList);
        sortedValuesList.sort(String.CASE_INSENSITIVE_ORDER);
        Allure.step("Verify that Regulatory picklist values are sorted", step -> {
            if (actualValuesList.equals(sortedValuesList)) {
                loggerManager.getLogger().info("Regulatory picklist values are sorted");
            } else {
                loggerManager.getLogger().error("Regulatory picklist values are not sorted");
            }
            Assert.assertEquals(actualValuesList, sortedValuesList, "Regulatory picklist values are not sorted");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method creates Quote/Proposal from the Opportunity.
     */
    @Step("Create Quote/Proposal from Opportunity")
    public void createQuoteFromOpportunity(){
        waitForElementToBeVisible(driver, createQuoteBtn);
        elementClick(driver, createQuoteBtn);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, oppyName);
        waitForElementToBePresent(driver, proposalNameOnApttus("Proposal " + oppyName));
        Assert.assertTrue(driver.getTitle().contains("Salesforce"), "Failed to create Quote/Proposal from Opportunity");
        loggerManager.getLogger().info("Quote/Proposal created successfully from Opportunity");
    }

    /**
     * This method verifies that the Account Name is replaced with Proposal Name under the Proposals Related List on Opportunity.
     */
    @Step("Verify that Account Name is replaced with Proposal Name under the Proposals Related List on Opportunity")
    public void verifyProposalNameFieldOnOpportunity(){
        waitForPageTitleToContain(driver, "| Opportunity | Salesforce");
        scrollToElement(driver, fulfillmentQuickLink);
        waitForElementToBeVisible(driver, proposalsRelatedList);
        waitForElementToBeVisible(driver, stageDropdown);
        waitForElementToBeVisible(driver, fieldsUnderProposalsRelatedList.get(0));
        List<String> proposalFieldsNames = fieldsUnderProposalsRelatedList.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());

        if(proposalFieldsNames.contains("Proposal Name:") && !proposalFieldsNames.contains("Account Name:"))
            loggerManager.getLogger().info("Proposal Name is displayed on the Proposals Related List");
        else
            loggerManager.getLogger().error("Proposal Name is not displayed on the Proposals Related List");

        Assert.assertTrue(proposalFieldsNames.contains("Proposal Name:") && !proposalFieldsNames.contains("Account Name:"), "Proposal Name is not displayed on the Proposals Related List");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method populates the mandatory fields for creating a new Opportunity with custom start and end dates.
     */
    @Step("Populate mandatory fields for creating a new Opportunity with start date as {startDate} and end date as {endDate}")
    public void enterNewSalesOpportunityDetailsWithCustomDates(String startDate, String endDate) {
        waitForPageTitleToContain(driver,"New Sales");
        selectAccountNameOnOpportunity(readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        waitForElementToBePresent(driver, newOpportunityHeader());
        oppyName= readExcelData(opportunitiesFilePath, TCName, "OpportunityName")+generateRandomString("_Automation");
        sendKeysToElement(driver, opportunityNameTextField, oppyName);
        sendKeysToElement(driver, soldToContactTextField, readExcelData(opportunitiesFilePath, TCName, "SoldToContactName"));
        try{
            Thread.sleep(6000);
        }catch (InterruptedException e){
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, driver.findElement(soldToContactOption(readExcelData(opportunitiesFilePath, TCName, "SoldToContactName"))));
        sendKeysToElement(driver, contractSpecialistTextField, readExcelData(opportunitiesFilePath, TCName, "ContractSpecialistName"));
        try{
            Thread.sleep(6000);
        }catch (InterruptedException e){
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, driver.findElement(contractSpecialistOption(readExcelData(opportunitiesFilePath, TCName, "ContractSpecialistName"))));
        scrollToElement(driver, stageDropdown);
        elementClick(driver, stageDropdown);
        elementClick(driver, driver.findElement(selectDropDownOption(readExcelData(opportunitiesFilePath, TCName, "OppyStage"))));
        scrollToElement(driver, leadSourceDropdown);
        elementClick(driver, leadSourceDropdown);
        elementClick(driver, driver.findElement(selectDropDownOption(readExcelData(opportunitiesFilePath, TCName, "OppyLeadSource"))));
        sendKeysToElement(driver, firstAppointmentDateTextField, getCurrentDateInMMddyyyyFormat());
        sendKeysToElement(driver, closeDateTextField, currentDatePlusMonths(1));
        sendKeysToElement(driver, formTextField("Contract Start Date"), startDate);
        sendKeysToElement(driver, formTextField("Contract End Date"), endDate);
        elementClick(driver, renewalTypeDropdown);
        elementClick(driver, driver.findElement(selectDropDownOption(readExcelData(opportunitiesFilePath, TCName, "OppyRenewalOption"))));
        scrollToElement(driver, relatedToThirdPartyDropdown);
        elementClick(driver, relatedToThirdPartyDropdown);
        elementClick(driver, driver.findElement(selectDropDownOption(readExcelData(opportunitiesFilePath, TCName, "OppyThirdPartyOption"))));
        loggerManager.getLogger().info("All the mandatory fields are entered for the Opportunity creation");
    }

    /**
     * This method verifies that the Multiyear checkbox is not checked for Contract Term less than 24 months.
     */
    @Step("Verify that the Multi year checkbox not getting checked for contract term less than 24 months")
    public void verifyMultiyearCheckboxNotChecked() {
        waitForElementToBeVisible(driver, descriptionLabel);
        scrollToElement(driver, descriptionLabel);
        waitForElementToBeVisible(driver, multiyearCheckbox);
        if (multiyearCheckbox.getAttribute("checked") == null) {
            loggerManager.getLogger().info("Multiyear checkbox value is not checked when Contract Term is less than 24 months");
        } else {
            loggerManager.getLogger().error("Failed to verify that Multiyear checkbox is not checked when Contract Term is less than 24 months");
        }
        Assert.assertNull(multiyearCheckbox.getAttribute("checked"), "Failed to verify that Multiyear checkbox value is not checked when Contract Term is less than 24 months");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the values in the Usage Type picklist on the Opportunity page.
     */
    @Step("Verify that all values from the Usage Type picklist are present on the Opportunity object")
    public void verifyUsageTypePicklistValues(String expectedValues) {
        reusableBusinessLibrary.clickEditBtn();
        waitForElementToBeVisible(driver, usageTypePicklist);
        elementClickByJS(driver, usageTypePicklist);
        ArrayList<String> actualValuesList = getOpportunityPicklistValues(usageTypePicklistOptions);
        List<String> expectedValuesList = Arrays.asList(expectedValues.split(";"));
        Allure.step("Verify that all values from the Usage Type picklist are present on the Opportunity object", step -> {
            if (actualValuesList.containsAll(expectedValuesList)) {
                loggerManager.getLogger().info("All expected values are present in the Usage Type picklist on the Opportunity object");
            } else {
                loggerManager.getLogger().error("Some expected values are missing in the Usage Type picklist on the Opportunity object");
            }
            Assert.assertTrue(actualValuesList.containsAll(expectedValuesList), "Usage Type picklist on the Opportunity object does not have the expected values " + expectedValues + " but has " + actualValuesList);
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method updates the Contract Start and End Dates on the Opportunity.
     */
    @Step("Update Contract Start and End Dates on Opportunity")
    public void updateDatesOnOpportunity(){
        reusableBusinessLibrary.clickEditBtn();
        newStartDate = currentDatePlusMonths(1);
        newEndDate = customDatePlusYears(1, currentDatePlusMonths(1));
        formTextField("Contract Start Date").clear();
        sendKeysToElement(driver, formTextField("Contract Start Date"), newStartDate);
        formTextField("Contract End Date").clear();
        sendKeysToElement(driver, formTextField("Contract End Date"), newEndDate);
        elementClick(driver, renewalTypeDropdown);
        saveOpportunity();
    }

    /**
     * This method verifies the updated Contract Start and End Dates on the Opportunity.
     */
    @Step("Verify updated Contract Start and End Dates on Opportunity")
    public void verifyDatesOnOpportunity(){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("edit")));
        wait.until(ExpectedConditions.invisibilityOfElementLocated(oppySavedSuccessBanner));
        waitForElementToBeVisible(driver, forecastSectionLabel);
        scrollToElement(driver, forecastSectionLabel);
        waitForElementToBeVisible(driver, contractStartDateText);
        if(getElementText(driver, contractStartDateText).equals(newStartDate) &&
            getElementText(driver,contractEndDateText).equals(newEndDate))
            loggerManager.getLogger().info("Dates are updated on the Opportunity");
        else
            loggerManager.getLogger().error("Failed to update dates on the Opportunity");

        Assert.assertTrue(getElementText(driver, contractStartDateText).equals(newStartDate) &&
                getElementText(driver,contractEndDateText).equals(newEndDate), "Failed to update dates on the Opportunity. Actual Start Date: " + getElementText(driver, contractStartDateText) + ", Actual End Date: " + getElementText(driver,contractEndDateText) + ", Expected Start Date: " + newStartDate + ", Expected End Date: " + newEndDate);
    }

    /**
     * This method verifies that Primary Campaign Source field is editable on the Opportunity.
     */
    @Step("Verify that user is able to update Primary Campaign Source field on Opportunity")
    public void verifyPrimaryCampaignSourceField(){
        if(isElementDisplayed(driver, clearPrimaryCampaignSourceBtn)){
            elementClickByJS(driver, clearPrimaryCampaignSourceBtn);
        }
        waitForElementToBeVisible(driver, searchCampaignsTextField);
        sendKeysToElement(driver, searchCampaignsTextField, readExcelData(opportunitiesFilePath, TCName, "CampaignName"));
        waitForElementToBePresent(driver, opportunityPagePicklistOption(readExcelData(opportunitiesFilePath, TCName, "CampaignName")));
        waitForElementToBeVisible(driver, driver.findElement(opportunityPagePicklistOption(readExcelData(opportunitiesFilePath, TCName, "CampaignName"))));
        elementClick(driver,driver.findElement(opportunityPagePicklistOption(readExcelData(opportunitiesFilePath, TCName, "CampaignName"))));
        reusableBusinessLibrary.clickSaveBtn();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("edit")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        scrollToElement(driver, renewalSourceFieldLabel);
        if(campaignNameLink.getAttribute("text").equals(readExcelData(opportunitiesFilePath, TCName, "CampaignName")))
            loggerManager.getLogger().info("Primary Campaign Source field is updated on the Opportunity");
        else
            loggerManager.getLogger().error("Failed to update Primary Campaign Source field on the Opportunity");
        Assert.assertEquals(campaignNameLink.getAttribute("text"), readExcelData(opportunitiesFilePath, TCName, "CampaignName"), "Failed to update Primary Campaign Source field on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the field Mismatched Allocation is not displayed on the Opportunity.
     */
    @Step("Verify that user is not able to see the field Mismatched Allocation on the Opportunity")
    public void verifyMismatchedAllocationFieldVisibility(){
        waitForElementToBeVisible(driver, fulfillmentQuickLink);
        scrollToElement(driver, fulfillmentQuickLink);
        if(!isElementDisplayed(driver, mismatchedAllocationField))
            loggerManager.getLogger().info("Mismatched Allocation field is not displayed on the Opportunity");
        else
            loggerManager.getLogger().error("Mismatched Allocation field is displayed on the Opportunity");
        Assert.assertFalse(isElementDisplayed(driver, mismatchedAllocationField), "Mismatched Allocation field is displayed on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that Custom Links Section is displayed on the Renewal Opportunity and the links under it are working.
     */
    @Step("Verify the Custom Links Section on the Renewal Opportunity")
    public void verifyCustomLinksSection(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        scrollToBottom(driver);
        waitForElementToBeVisible(driver, customLinksSection);
        Allure.step("Verify that Custom Links Section is displayed on the Renewal Opportunity", step -> {
                    softAssert.assertTrue(isElementDisplayed(driver, customLinksSection), "Custom Links Section is not displayed on the Renewal Opportunity");
                    loggerManager.getLogger().info("Custom Links Section is displayed on the Renewal Opportunity");
                    takeScreenshot(TCName, driver);
        });

        Allure.step("Verify that My Renewal Sales Opportunities link is displayed under Custom Links and is working", step -> {
            elementClickByJS(driver, myRenewalSalesOpportunitiesLink);
            switchToWindowByNumber(driver, 1);
            waitForPageTitle(driver, "My Renewal Sales Opportunities | Opportunities | Salesforce");
            waitForElementToBeVisible(driver, myRenewalSalesOpportunitiesListViewText);
            softAssert.assertTrue(isElementDisplayed(driver, myRenewalSalesOpportunitiesListViewText), "My Renewal Sales Opportunities link is not working");
            loggerManager.getLogger().info("My Renewal Sales Opportunities link under Custom Links is working");
            takeScreenshot(TCName, driver);
            switchToWindowByNumber(driver, 0);
        });

        Allure.step("Verify that SRB Detail link is displayed under Custom Links and is working", step -> {
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
            scrollToBottom(driver);
            waitForElementToBeVisible(driver, customLinksSection);
            waitForElementToBeVisible(driver, srbDetailLink);
            elementClickByJS(driver, srbDetailLink);
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
            waitForPageTitle(driver, "SRB Detail (For Link) | Salesforce");
            waitforFrametoLoad(driver, srbDetailReportFrame);
            waitForElementToBeVisible(driver, srbDetailReportHeaderText);
            softAssert.assertTrue(isElementDisplayed(driver, srbDetailReportHeaderText), "SRB Detail link is not working");
            loggerManager.getLogger().info("SRB Detail link under Custom Links is working");
            takeScreenshot(TCName, driver);
            switchToDefaultContent(driver);
        });
        softAssert.assertAll();
    }

    /**
     * This method verifies that Order and Fulfillment Related Lists are present on the Opportunity below Agreement.
     */
    @Step("Verify that Order and Fulfillment Related Lists are present on the Opportunity below Agreement")
    public void verifyOrderAndFulfillmentRelatedList() {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        scrollToElement(driver, quickLinksWidgetLabel);
        waitForElementToBeVisible(driver, ordersRelatedList);
        scrollToElement(driver, ordersRelatedList);
        waitForElementToBeVisible(driver, fulfillmentsRelatedListLabel);
        List<String> relatedLists = rightPanelRelatedListsOnOpportunity.stream()
                .map(WebElement::getText)
                .collect(Collectors.toList());
        int agreementIndex = relatedLists.indexOf("Agreements");
        int orderIndex = relatedLists.indexOf("Orders");
        int fulfillmentIndex = relatedLists.indexOf("Fulfillments");

        Allure.step("Verify that Order and Fulfillment Related Lists are present on the Opportunity below Agreement", step -> {
            if (agreementIndex != -1 && orderIndex != -1 && fulfillmentIndex != -1) {
                if ((agreementIndex < orderIndex && orderIndex < fulfillmentIndex) && isElementDisplayed(driver, rightPanelRelatedListsOnOpportunity.get(agreementIndex)) &&
                        isElementDisplayed(driver, rightPanelRelatedListsOnOpportunity.get(orderIndex)) && isElementDisplayed(driver, rightPanelRelatedListsOnOpportunity.get(fulfillmentIndex))) {
                    loggerManager.getLogger().info("Order and Fulfillment Related Lists are present on the Opportunity below Agreement");
                } else {
                    loggerManager.getLogger().error("Order and Fulfillment Related Lists are not in the correct order below Agreement");
                }
                Assert.assertTrue(agreementIndex < orderIndex && orderIndex < fulfillmentIndex, "Order and Fulfillment Related Lists are not in the correct order below Agreement");
            } else {
                loggerManager.getLogger().error("Agreement, Order, or Fulfillment Related List is not present on the Opportunity");
                Assert.fail("Agreement, Order, or Fulfillment Related List is not present on the Opportunity");
            }
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that Owner Assigner Manually checkbox is editable on the Opportunity.
     */
    @Step("Verify that Owner Assigner Manually checkbox is editable on the Opportunity")
    public void verifyOwnerAssignedManuallyCheckbox(){
        reusableBusinessLibrary.clickEditBtn();
        waitForElementToBeVisible(driver, ownerAssignedManuallyCheckboxOnEditPage);
        elementClick(driver, ownerAssignedManuallyCheckboxOnEditPage);
        takeScreenshot(TCName, driver);
        reusableBusinessLibrary.clickSaveBtn();
        waitForUrlToContain(driver, "/view");
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, showAllQuickLinks);
        scrollToElement(driver, showAllQuickLinks);
        waitForElementToBeVisible(driver, ownerAssignedManuallyCheckboxOnViewPage);
        if(ownerAssignedManuallyCheckboxOnViewPage.getAttribute("checked") != null && !ownerAssignedManuallyCheckboxOnViewPage.getAttribute("checked").isEmpty())
            loggerManager.getLogger().info("Owner Assigner Manually checkbox is checked on the Opportunity");
        else
            loggerManager.getLogger().info("Failed to check Owner Assigner Manually checkbox on the Opportunity");
        Assert.assertEquals(ownerAssignedManuallyCheckboxOnViewPage.getAttribute("checked"), "true", "Failed to check Owner Assigner Manually checkbox on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    @Step("Verify that user is able to send email with merge fields and attachments from the Activity Section on the Opportunity")
    public void sendEmailFromActivityTabOnOpportunity(){
        waitForElementToBeVisible(driver, ordersRelatedList);
        scrollToElement(driver, ordersRelatedList);
        waitForElementToBeVisible(driver, activityTab);
        elementClickByJS(driver, activityTab);
        takeScreenshot(TCName, driver);
        waitForElementToBeVisible(driver, sendEmailBtn);
        elementClickByJS(driver, sendEmailBtn);
        waitForElementToBeVisible(driver, emailToTextField);
        sendKeysToElement(driver, emailToTextField, getConfigProperty("OutlookEmailAddress"));
        sendKeysToElement(driver, emailSubjectTextField, readExcelData(opportunitiesFilePath, TCName, "EmailSubject") + " - " + oppyID);

        driver.switchTo().frame(driver.findElement(emailEditorFrame));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        driver.switchTo().frame(driver.findElement(emailBodyFrame));
        driver.findElement(emailBodyTextField).sendKeys(readExcelData(opportunitiesFilePath, TCName, "EmailBody"));
        switchToDefaultContent(driver);
        waitForElementToBeVisible(driver, emailAttachmentBtn);
        elementClickByJS(driver, emailAttachmentBtn);
        waitForElementToBeVisible(driver, uploadFilesBtn);
        elementClick(driver, uploadFilesBtn);
        uploadFileUsingRobot(emailAttachmentFileUploadPath);
        waitForElementToBeVisible(driver, insertMergeFieldBtn);
        elementClickByJS(driver, insertMergeFieldBtn);
        waitForElementToBeVisible(driver, opportunitySectionLabelOnMergeFieldPage);
        elementClickByJS(driver, opportunitySectionLabelOnMergeFieldPage);
        waitForElementToBeVisible(driver, searchMergeFieldTextField);
        sendKeysToElement(driver, searchMergeFieldTextField, readExcelData(opportunitiesFilePath, TCName, "MergeFieldName"));
        waitForElementToBePresent(driver, mergeFieldOption(readExcelData(opportunitiesFilePath, TCName, "MergeFieldName")));
        elementClickByJS(driver, driver.findElement(mergeFieldOption(readExcelData(opportunitiesFilePath, TCName, "MergeFieldName"))));
        waitForElementToBeVisible(driver, insertBtn);
        elementClickByJS(driver, insertBtn);
        takeScreenshot(TCName, driver);
        waitForElementToBeVisible(driver, emailSendBtn);
        elementClickByJS(driver, emailSendBtn);
        try {
            elementClick(driver, attachAndSendBtn);
            loggerManager.getLogger().info("Clicked on Attach and Send button");
        }
        catch (Exception e){
            loggerManager.getLogger().warn("Attach and Send button is not displayed");
        }
        scrollToElement(driver, ordersRelatedList);
        scrollToElement(driver, activityTab);
        waitForElementToBeVisible(driver, activityTab);
        elementClickByJS(driver, activityTab);
        waitForElementToBePresent(driver, emailRecordLinkUnderActivityTab(readExcelData(opportunitiesFilePath, TCName, "EmailSubject") + " - " + oppyID));
        waitForElementToBeVisible(driver, driver.findElement(emailRecordLinkUnderActivityTab(readExcelData(opportunitiesFilePath, TCName, "EmailSubject") + " - " + oppyID)));
        Assert.assertTrue(isElementDisplayed(driver, driver.findElement(emailRecordLinkUnderActivityTab(readExcelData(opportunitiesFilePath, TCName, "EmailSubject") + " - " + oppyID))), "Failed to send email from the Activity Section on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    @Step("Get the value of Sold To Contact Address on Opportunity")
    public String getSoldToContactAddressOnOpportunity(){
        scrollToElement(driver, opportunityOwnerFieldLabel);
        waitForElementToBeVisible(driver, soldToContactAddressFieldValue);
        loggerManager.getLogger().info("Sold To Contact Address on Opportunity: " + getElementText(driver, soldToContactAddressFieldValue));
        return getElementText(driver, soldToContactAddressFieldValue);
    }

    @Step("Verify the details of the email received in the user mailbox")
    public void verifyEmailDetails(String mergeFieldValue){
        try {
            Thread.sleep(90000);   //Wait for the email to be received in the recipient's inbox
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        List<Map<String, String>> mailDetails;
        String actualEmailSubject, expectedEmailSubject, attachmentName, actualEmailBody, expectedEmailBody, expectedAttachmentName = null;
        outlookSupport.readMails();
        mailDetails = outlookSupport.getMailDetails();

        boolean flag = false;
        for (Map<String, String> mail : mailDetails) {
            actualEmailSubject = mail.get("Email Subject");
            expectedEmailSubject = "Sandbox: " + readExcelData(opportunitiesFilePath, TCName, "EmailSubject") + " - " + oppyID;
            actualEmailBody = mail.get("Email Body");
            expectedEmailBody = readExcelData(opportunitiesFilePath, TCName, "EmailBody")  + mergeFieldValue.replace("\n", " ");
            Path path = Paths.get(emailAttachmentFileUploadPath);
            expectedAttachmentName = path.getFileName().toString();
           if (actualEmailSubject.equals(expectedEmailSubject)) {
                loggerManager.getLogger().info("Actual Email Subject: " + actualEmailSubject + " | " + "Expected Email Subject: " + expectedEmailSubject);
                loggerManager.getLogger().info("Actual Email Body: " + actualEmailBody + " | " + "Expected Email Body: " + expectedEmailBody);
                attachmentName = outlookSupport.getEmailAttachmentName(mail.get("ID"));
                loggerManager.getLogger().info("Actual Attachment Name: " + attachmentName + " | " + "Expected Attachment Name: " + expectedAttachmentName);
                softAssert.assertEquals(attachmentName, expectedAttachmentName, "Expected Email Attachment is present in the email");
                softAssert.assertTrue(actualEmailBody.contains(expectedEmailBody), "Email sent from Activity Tab on Opportunity has incorrect Body");
                softAssert.assertAll();
                loggerManager.getLogger().info("Email sent from Activity Tab on Opportunity received successfully");
                flag = true;
                break;
            }
        }

        if (!flag) {
            loggerManager.getLogger().error("Email sent from Activity Tab on Opportunity is not received in the recipient's inbox");
            Assert.fail("Email sent from Activity Tab on Opportunity is not received in the recipient's inbox");
        }
    }

    /**
     * This method gets the sequence of column headers of a List View or fields from a section on the Opportunity.
     * @param headersLocator By - The locator for the column headers or fields.
     * @return String - The sequence of column headers or the fields.
     */
    @Step("Get the sequence of column headers")
    public String getOppyProductsColumnHeaders(By headersLocator) {
        String actualHeaders = "";
        waitForElementToBePresent(driver, headersLocator);

        List<WebElement> headers = driver.findElements(headersLocator);
        for (WebElement header : headers) {
            actualHeaders = actualHeaders + header.getAttribute("title") + ",";
        }

        return actualHeaders.substring(0, actualHeaders.length() - 1);
    }
    /**
     * This method validates that the Edit button is not present on the Opportunity page.
     * It performs the following steps:
     * 1. Verifies that an opportunity is opened by checking the URL.
     * 2. Waits for the Contacts tab to be visible, ensuring the Opportunity page is loaded.
     * 3. Asserts that the Edit button is not present on the page.
     * 4. Asserts that the Edit button is not present under the "Show More" dropdown.
     * 5. Logs a message confirming the Edit button is not present.
     * 6. Takes a screenshot of the page for documentation purposes.
     */
    @Step("Validate that Edit Button is not present on Page")
    public void verifyInvisibilityOfEditButton() {
        //verifies that an opportunity is opened
        waitForUrlToContain(driver, readExcelData(opportunitiesFilePath, TCName, "ExistingNewSalesOpportunityID"));
        waitForElementToBeVisible(driver, contactsTab);

        Assert.assertFalse(isElementPresent(driver, reusableBusinessLibrary.editButton), "Edit Button is present on the page when it should not be");
        Assert.assertFalse(isElementPresent(driver, reusableBusinessLibrary.editBtnUnderShowMore), "Edit Button is present on the page under dropdown when it should not be");
        loggerManager.getLogger().info("Edit Button is not present on the page, it is confirmed that opportunity cannot be edited");
        takeScreenshot(TCName, driver);
    }
    /**
     * This method verifies that the Delete button is not present on the Opportunity page.
     * It performs the following steps:
     * 1. Waits for the Contacts tab to be visible, ensuring the Opportunity page is loaded.
     * 2. Asserts that the Delete button is not present on the page.
     * 3. Asserts that the Delete button is not present under the "Show More" dropdown.
     * 4. Logs a message confirming the Delete button is not present.
     * 5. Takes a screenshot of the page for documentation purposes.
     */
    @Step("Validate that Delete Button is not present on Page")
    public void verifyInvisibilityOfDeleteButton() {
        //verifies that an opportunity is opened
        waitForElementToBeVisible(driver, contactsTab);

        Assert.assertFalse(isElementPresent(driver, reusableBusinessLibrary.deleteButton), "Delete Button is present on the page when it should not be");
        Assert.assertFalse(isElementPresent(driver, reusableBusinessLibrary.deleteButtonUnderShowMore), "Delete Button is present on the page under dropdown when it should not be");

        loggerManager.getLogger().info("Delete Button is not present on the page, it is confirmed that opportunity cannot be deleted");
        takeScreenshot(TCName, driver);
    }
    /**
     * This method selects the "Reason Lost - Primary" picklist on the Opportunity.
     */
    @Step("Select Reason Lost - Primary field on Opportunity")
    public void selectReasonLostFieldOnOpportunity(){

        scrollToElement(driver,driver.findElement(picklistButtonElement("Reason Lost - Primary") ));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Reason Lost - Primary")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Reason Lost - Primary",readExcelData(opportunitiesFilePath, TCName, "ReasonLostPrimary"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Reason Lost - Primary",readExcelData(opportunitiesFilePath, TCName, "ReasonLostPrimary"))));

        if (isElementPresent(driver, filledFormPicklistField("Reason Lost - Primary", readExcelData(opportunitiesFilePath, TCName, "ReasonLostPrimary")))){
            loggerManager.getLogger().info("Reason Lost - Primary field has been entered successfully");
        }
        else{
            loggerManager.getLogger().error("Reason Lost - Primary field has not been entered successfully");
            Assert.fail("Reason Lost - Primary field has not been entered successfully");
        }
    }
    /**
     * This method validates that the "Reason Lost - Primary" field is entered successfully on the Opportunity.
     */
    @Step("Validate that Reason Lost - Primary field is entered successfully")
    public void validateReasonLostFieldOnOpportunity(){

        Allure.step("Validate Reason Lost - Primary field on Opportunity", step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Reason Lost - Primary"))),readExcelData(opportunitiesFilePath, TCName, "ReasonLostPrimary"));
        });
        softAssert.assertAll();
        loggerManager.getLogger().info("Reason Lost - Primary field is validated successfully");
    }

       /**
     * This method selects the Partnership Alliance tool on the Opportunity Creation form.
     * @param partnershipAllianceToolOption The value to be selected for the "Partnership / Alliance Tool" field.
     */
    @Step("Select option in partnership/alliance tool dropdown")
    public void selectPartnershipAllianceToolOnOpportunity(String partnershipAllianceToolOption){

        elementClickByJS(driver, driver.findElement(picklistButtonElement("Partnership / Alliance Tool")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Partnership / Alliance Tool",partnershipAllianceToolOption)));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Partnership / Alliance Tool",partnershipAllianceToolOption)));
        if (isElementPresent(driver,filledFormPicklistField("Partnership / Alliance Tool", partnershipAllianceToolOption))){
            loggerManager.getLogger().info("Partnership / Alliance Tool field has been entered successfully");
        }
        else{
            loggerManager.getLogger().error("Partnership / Alliance Tool field has not been entered successfully");
            Assert.fail("Partnership / Alliance Tool field has not been entered successfully");
        }
        takeScreenshot(TCName, driver);
    }

    /**
     *
     * This method enters the Referral Entitlement percentage on the Opportunity page.
     * @param referralEntitlement The percentage value to be entered in the Referral Entitlement % field.
     */
    @Step("Enter Referral Entitlement % on Opportunity")
    public void enterReferralEntitlementOnOpportunity(String referralEntitlement){

        scrollToElement(driver,formTextField("Referral Entitlement %"));
        sendKeysToElement(driver, formTextField("Referral Entitlement %"), referralEntitlement);
        loggerManager.getLogger().info("Referral Entitlement % field has been entered successfully");

    }

    @Step("Validate all of the Partnership/Alliance Fields on Opportunity")
    public void validatePartnershipAllianceFieldsOnOpportunity () {
        scrollToElement(driver, driver.findElement(opportunityValidationTextField("Renewal Type")));

        Allure.step("Validate Partnership Alliance field on Opportunity", step -> {
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Partnership / Alliance Tool"))),readExcelData(opportunitiesFilePath, TCName, "Partnership_AllianceTool"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Partnership / Alliance: Sales Type"))),readExcelData(opportunitiesFilePath, TCName, "PartnershipAllianceSalesType"));
            softAssert.assertEquals(extractNumber(getElementText(driver, driver.findElement(opportunityValidationNumberField("Referral Entitlement %")))),readExcelData(opportunitiesFilePath, TCName, "ReferralEntitlement"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextFieldLinks("Partner Account"))),readExcelData(opportunitiesFilePath, TCName, "AccountName"));
        });
        softAssert.assertAll();
        loggerManager.getLogger().info("Partnership Alliance fields are validated successfully");

        takeScreenshot(TCName, driver);
    }

    /**
     * Clears the current value in the "Services Probability" field on the Opportunity page and enters a new random value.
     * This method performs the following steps:
     * 1. Generates a random percentage value.
     * 2. Clears the existing value in the "Services Probability" field.
     * 3. Scrolls to the "Services Probability" field and enters the new random value.
     * 4. Writes the new value to an Excel file for record-keeping.
     * 5. Logs the successful entry of the new value.
     * 6. Takes a screenshot of the updated field.
     * 7. Scrolls to the "Renewal Type" dropdown to ensure the field is entered and the opportunity can be saved.
     */
    @Step("Clear Services Probability Value on Opportunity and enter a new value")
    public void clearAndEnterServicesProbabilityFieldOnOpportunity(){

        String randomServicesProbabilityPercent= String.valueOf(generateRandomNumber(2));
        formTextField("Services Probability").clear();
        scrollToElement(driver,formTextField("Services Probability"));
        sendKeysToElement(driver, formTextField("Services Probability"),randomServicesProbabilityPercent);
        writeToExcel(opportunitiesFilePath, TCName, "ServicesProbabilityPercent",randomServicesProbabilityPercent+"%");
        loggerManager.getLogger().info("Services Probability field has been entered successfully");
        takeScreenshot(TCName, driver);
        //this is just to ensure Services Probability Field is entered and the opportunity can be saved
        scrollToElement(driver, driver.findElement(picklistButtonElement("Renewal Type")));
        elementClick(driver, driver.findElement(picklistButtonElement("Renewal Type")));

    }
    /**
     * This method validates that the Services Probability field on the Opportunity page has been saved successfully.
     */
    @Step("Validate Services Probability Field is saved on Opportunity")
    public void validateServicesProbabilityFieldOnOpportunity(){
        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("edit")));
        Assert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationNumberField("Services Probability"))),readExcelData(opportunitiesFilePath, TCName, "ServicesProbabilityPercent"),
                "Services Probability field not saved on the Opportunity");
        loggerManager.getLogger().info("Services Probability field has been saved successfully");
        scrollToElement(driver, driver.findElement(opportunityValidationTextField("Renewal Type")));
        takeScreenshot(TCName, driver);
    }
    /**
     * Clears the current value in the "Services Owner" field and enters a new value.
     * Also clears the "Consulting Comments" field and enters a new random comment.
     * This method performs the following steps:
     * 1. Scrolls to the "Services Owner" field and clears its current value.
     * 2. Enters a new value in the "Services Owner" field.
     * 3. Verifies that the new value is entered successfully.
     * 4. Clears the "Consulting Comments" field.
     * 5. Generates a random comment and enters it in the "Consulting Comments" field.
     * 6. Takes a screenshot of the updated fields.
     * 7. Scrolls to the "Renewal Type" dropdown to ensure the fields are entered and the opportunity can be saved.
     */
    @Step("Clear and Enter values into Services Owner Field and Consulting Comments Field on Opportunity Creation Page")
    public void clearAndEnterServicesOwnerAndConsultingCommentsOnOpportunity() {

        scrollToElement(driver,clearServicesOwnerBtn);
        elementClick(driver, clearServicesOwnerBtn);

        sendKeysTypeAheadField(formTextField("Services Owner"), readExcelData(opportunitiesFilePath, TCName, "ServicesOwner"));
        waitForElementToBePresent(driver, recordToSelectAfterSendingKeys( readExcelData(opportunitiesFilePath, TCName, "ServicesOwner")));
        elementClickByJS(driver, driver.findElement(recordToSelectAfterSendingKeys(readExcelData(opportunitiesFilePath, TCName, "ServicesOwner"))));
        if(isElementPresent(driver,filledFormTextField("Services Owner", readExcelData(opportunitiesFilePath, TCName, "ServicesOwner")))){
            loggerManager.getLogger().info("Services Owner field has been entered successfully");
        }
        else{
            loggerManager.getLogger().error("Services Owner field has not been entered successfully");
            Assert.fail("Services Owner has not been entered successfully");
        }

        formTextArea("Consulting Comments").clear();

        String consulting_comments = generateRandomString("Test Automation");
        writeToExcel(opportunitiesFilePath, TCName, "ConsultingComments", consulting_comments);
        sendKeysToElement(driver,formTextArea("Consulting Comments"),  consulting_comments);

        takeScreenshot(TCName, driver);
        //this is just to ensure the rest of the fields are saved and the opportunity can be saved successfully
        scrollToElement(driver, driver.findElement(picklistButtonElement("Renewal Type")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Renewal Type")));

        loggerManager.getLogger().info("Services Owner and Consulting Comments are entered sucessfully");

    }
    /**
     * This method validates that the Services Owner and Consulting Comments fields have been saved on the Opportunity.
     */
    @Step("Validate Services Owner and Consulting Comments Fields have been saved on Opportunity")
    public void validateServicesOwnerAndConsultingCommentsOnOpportunity() {

        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("edit")));

        Allure.step("Validate Services Owner and Consulting Comments fields on Opportunity", step -> {
            softAssert.assertEquals(servicesOwnerValidationField.getAttribute("title").contains(readExcelData(opportunitiesFilePath, TCName, "ServicesOwner")), true, "Services Owner field not saved on the Opportunity");
            softAssert.assertEquals(getElementText(driver, driver.findElement(opportunityValidationTextField("Consulting Comments"))),readExcelData(opportunitiesFilePath, TCName, "ConsultingComments"), "Consulting Comments field not saved on the Opportunity");
        });
        softAssert.assertAll();
        scrollToElement(driver, driver.findElement(opportunityValidationTextField("Related to Third Party")));
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Services Owner and Consulting Comments fields are saved on Opportunity");

    }
    public By quickLinks(String buttonName){
        return By.xpath("//lightning-icon[@title='"+buttonName+"']");
    }

    /**
     * This method verifies that the Quick Links section is visible on the Opportunity page.
     */
    @Step("Validate that Quick Links are present on Opportunity Page")
    public void verifyQuickLinksAreVisibleOnOpportunity() {

        waitForElementToBeVisible(driver, quickLinksHeader);
        Assert.assertTrue(isElementDisplayed(driver, quickLinksHeader), "Quick Links Header is not displayed on the Opportunity");

        String[] allLinks = readExcelData(opportunitiesFilePath, TCName, "QuickLinks").split(";");

        for (String linkName : allLinks) {
            Assert.assertTrue(isElementDisplayed(driver, driver.findElement(quickLinks(linkName))), linkName+" link is not displayed on the Opportunity");
        }

        loggerManager.getLogger().info("Quick Links header and all links are present on opportunity");
        takeScreenshot(TCName, driver);
    }
    /**
     * This method validates that the Quick Links section is not visible on the Opportunity page.
     */
    @Step("Validate that Quick Links are not present on Opportunity Page")
    public void verifyQuickLinksAreInvisibleOnOpportunity() {

        waitForElementToBeVisible(driver, contactsTab);
        Assert.assertFalse(isElementDisplayed(driver, quickLinksHeader), "Quick Links Header is displayed on the Opportunity");
        Assert.assertFalse(isElementDisplayed(driver, quickLink), " A quick Link is displayed on the Opportunity");

        loggerManager.getLogger().info("Quick Links header and none of the quick links are present on opportunity");
        takeScreenshot(TCName, driver);

    }
    /**
     * Clears the current value in the "Commit Amount" field on the Opportunity Creation form and enters a new random value.
     */
    @Step("Clear and enter values into Commit Amount Field on opportunity Creation Page")
    public void clearAndEnterCommitAmountOnOpportunity() {
        scrollToElement(driver,formTextField("Commit Amount"));
        if (!formTextField("Commit Amount").getAttribute("value").isEmpty())
        {
            formTextField("Commit Amount").clear();
        }
        String commitAmount = Integer.toString(generateRandomNumber(4));

        sendKeysToElement(driver, formTextField("Commit Amount"), commitAmount);
        writeToExcel(opportunitiesFilePath, TCName, "CommitAmount", commitAmount);

        takeScreenshot(TCName, driver);
        //this is just to ensure the rest of the fields are saved and the opportunity can be saved successfully
        scrollToElement(driver, driver.findElement(picklistButtonElement("Stage")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Stage")));

        loggerManager.getLogger().info("Commit Amount field has been entered successfully");
    }
    /**
     * This method validates that the Commit Amount field on the Opportunity page has been saved successfully.
     */
    @Step("Validate Commit Amount Field is saved on Opportunity")
    public void validateCommitAmountFieldOnOpportunity() {
        wait.until(ExpectedConditions.not(ExpectedConditions.urlContains("edit")));
        Assert.assertEquals(extractNumber(getElementText(driver, driver.findElement(opportunityValidationTextField("Commit Amount")))),readExcelData(opportunitiesFilePath, TCName, "CommitAmount"),
                "Commit Amount field not saved on the Opportunity");
        loggerManager.getLogger().info("Commit Amount field has been saved successfully");
        scrollToElement(driver, driver.findElement(opportunityValidationTextField("Year 1 Amount")));
        takeScreenshot(TCName, driver);
    }
    /**
     * This method verifies the currency values in the Opportunity creation form.
     * It performs the following steps:
     * 1. Validates that the default currency is selected as USD - U.S. Dollar.
     * 2. Clicks on the currency dropdown to display all available currency options.
     * 3. Validates the presence of each required currency in the dropdown list.
     * 4. Takes a screenshot after each validation step.
     */
    @Step("Verify the Opportunity Currency values in Opportunity creation form")
    public void verifyCurrencyValues(){
        Allure.step("Validate default currency is selected as USD - U.S. Dollar", step->{
            softAssert.assertEquals(getElementAttributeValue(driver,opportunityCurrencyDrpDown,"data-value"), "USD - U.S. Dollar","Default currency is not selected as USD - U.S. Dollar");
            loggerManager.getLogger().info("Default currency is selected as USD - U.S. Dollar");
            takeScreenshot(TCName, driver);    });
        elementClick(driver, opportunityCurrencyDrpDown);
        Allure.step("Validate all the currencies as per the requirement", step->{
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("AED - UAE Dirham")), "AED - UAE Dirham currency is not present");
            loggerManager.getLogger().info("AED - UAE Dirham currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("AUD - Australian Dollar")), "AUD - Australian Dollar currency is not present");
            loggerManager.getLogger().info("AUD - Australian Dollar currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("BRL - Brazilian Real")), "BRL - Brazilian Real currency is not present");
            loggerManager.getLogger().info("BRL - Brazilian Real currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("CAD - Canadian Dollar")), "CAD - Canadian Dollar currency is not present");
            loggerManager.getLogger().info("CAD - Canadian Dollar currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("CNY - Chinese Yuan")), "CNY - Chinese Yuan currency is not present");
            loggerManager.getLogger().info("CNY - Chinese Yuan currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("EUR - Euro")), "EUR - Euro currency is not present");
            loggerManager.getLogger().info("EUR - Euro currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("GBP - British Pound")), "GBP - British Pound currency is not present");
            loggerManager.getLogger().info("GBP - British Pound currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("HKD - Hong Kong Dollar")), "HKD - Hong Kong Dollar currency is not present");
            loggerManager.getLogger().info("HKD - Hong Kong Dollar currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("IDR - Indonesian Rupiah")), "IDR - Indonesian Rupiah currency is not present");
            loggerManager.getLogger().info("IDR - Indonesian Rupiah currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("INR - Indian Rupee")), "INR - Indian Rupee currency is not present");
            loggerManager.getLogger().info("INR - Indian Rupee currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("JPY - Japanese Yen")), "JPY - Japanese Yen currency is not present");
            loggerManager.getLogger().info("JPY - Japanese Yen currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("KRW - Korean Won")), "KRW - Korean Won currency is not present");
            loggerManager.getLogger().info("KRW - Korean Won currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("LKR - Sri Lanka Rupee")), "LKR - Sri Lanka Rupee currency is not present");
            loggerManager.getLogger().info("LKR - Sri Lanka Rupee currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("MXN - Mexican Peso")), "MXN - Mexican Peso currency is not present");
            loggerManager.getLogger().info("MXN - Mexican Peso currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("MYR - Malaysian Ringgit")), "MYR - Malaysian Ringgit currency is not present");
            loggerManager.getLogger().info("MYR - Malaysian Ringgit currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("NOK - Norwegian Krone")), "NOK - Norwegian Krone currency is not present");
            loggerManager.getLogger().info("NOK - Norwegian Krone currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("NZD - New Zealand Dollar")), "NZD - New Zealand Dollar currency is not present");
            loggerManager.getLogger().info("NZD - New Zealand Dollar currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("PHP - Philippine Peso")), "PHP - Philippine Peso currency is not present");
            loggerManager.getLogger().info("PHP - Philippine Peso currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("SGD - Singapore Dollar")), "SGD - Singapore Dollar currency is not present");
            loggerManager.getLogger().info("SGD - Singapore Dollar currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("THB - Thai Baht")), "THB - Thai Baht currency is not present");
            loggerManager.getLogger().info("THB - Thai Baht currency is present");
            softAssert.assertTrue(isElementPresent(driver, oppyCurrencyValue("TWD - Taiwan Dollar")), "TWD - Taiwan Dollar currency is not present");
            loggerManager.getLogger().info("TWD - Taiwan Dollar currency is present");
            takeScreenshot(TCName, driver);
            softAssert.assertAll();
        });
    }

    /**
     * This method updates the currency value to a new currency on the Opportunity page.
     * It performs the following steps:
     * 1. Selects the new currency value from the dropdown list.
     * 2. Clicks the "Save" button using the Action class to save the changes.
     */
    @Step("Update the currency value to a new currency")
    public void updateCurrencyValue(){
        try {
            waitForElementToBeVisible(driver, reusableBusinessLibrary.showMoreActionsButton);
            elementClick(driver, reusableBusinessLibrary.showMoreActionsButton);
            waitForElementToBeVisible(driver, updateCurrencyLink);
            elementClick(driver, updateCurrencyLink);
            waitForElementToBeVisible(driver, chooseNewCurrencyDrpDown);
            elementClick(driver, chooseNewCurrencyDrpDown);
            waitForElementToBeClickable(driver, driver.findElement(oppyCurrencyValue(reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"))));
            elementClickByJS(driver, driver.findElement(oppyCurrencyValue(reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"))));
            takeScreenshot(TCName, driver);
            reusableBusinessLibrary.clickSaveBtnUsingActionClass(driver);
            loggerManager.getLogger().info("Currency value is updated to a new currency and Save button is clicked");
        }catch (Exception e){
            loggerManager.getLogger().error("Failed to update the currency value to a new currency");
            Assert.fail("Failed to update the currency value to a new currency");
        }
    }

    /**
     * This method verifies that the warning message is displayed when there is a currency change on the Opportunity page.
     * It performs the following steps:
     * 1. Asserts that the actual warning message matches the expected warning message from the Excel data.
     * 2. Logs a message indicating that the currency error message is displayed as expected.
     * Note: As this a browser alert, Selenium does not support takeScreenshot function to capture the page screenshot. Hence its skipped.
     */
    @Step("Verify the error message")
    public void verifyCurrencyChnageWarningMessage(){
        Assert.assertEquals(reusableLibrary.getAlterText(), reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "ErrorMessage"), "Error message is not displayed as expected");
        loggerManager.getLogger().info("Currency error message is displayed as expected");
    }

    @Step("Override currency value to {reusableLibrary.readExcelData(opportunitiesFilePath, TCName, \"OppyCurrency\")}")
    public void overrideCurrencyValue(){
        try {
            waitForElementToBeVisible(driver, chooseNewCurrencyDrpDown);
            elementClick(driver, opportunityCurrencyDrpDown);
            waitForElementToBeClickable(driver, driver.findElement(oppyCurrencyValue(reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"))));
            elementClickByJS(driver, driver.findElement(oppyCurrencyValue(reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"))));
            loggerManager.getLogger().info("updated currency value to " + reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"));
        }catch (Exception e){
            loggerManager.getLogger().error("Failed to update the currency value to " + reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"));
            Assert.fail("Failed to update the currency value to " + reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"));
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method selects the Opportunity Currency as per the data provided in the Excel sheet.
     */
    @Step("Select Opportunity Currency as {reusableLibrary.readExcelData(opportunitiesFilePath, TCName, \"OppyCurrency\")}")
    public void selectOpportunityCurrency(){
        waitForElementToBeVisible(driver, opportunityCurrencyDrpDown);
        elementClickByJS(driver, opportunityCurrencyDrpDown);
        waitForElementToBePresent(driver, oppyCurrencyValue(reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency")));
        elementClickByJS(driver, driver.findElement(oppyCurrencyValue(reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"))));
        loggerManager.getLogger().info("Selected Opportunity Currency as " + reusableLibrary.readExcelData(opportunitiesFilePath, TCName, "OppyCurrency"));
    }

    /**
     * This method verifies that the Product Forecast Date field is displayed next to Opportunity field on the Opportunity Product record.
     */
    @Step("Verify that Product Forecast Date field is displayed next to Opportunity field on the Opportunity Product")
    public void verifyProductForecastDateFieldOnOppyProduct(){
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, fieldNameNextToOpportunityField);
        if(getElementText(driver, fieldNameNextToOpportunityField).equals("Product Forecast Date")) {
            Assert.assertEquals(getElementText(driver, fieldNameNextToOpportunityField), "Product Forecast Date", "Product Forecast Date field is not displayed next to Opportunity field on the Opportunity Product");
            loggerManager.getLogger().info("Product Forecast Date field is displayed next to Opportunity field on the Opportunity Product");
        }
        else {
            loggerManager.getLogger().error("Product Forecast Date field is not displayed next to Opportunity field on the Opportunity Product");
            Assert.fail("Product Forecast Date field is not displayed next to Opportunity field on the Opportunity Product");
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies navigation to the first record Opportunity Product record.
     */
    @Step("Navigate to the Opportunity Product record")
    public void navigateToOpportunityProductRecord(){
        navigateToProductsRelatedList();
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, firstOppyProductLink);
        elementClick(driver, firstOppyProductLink);
    }

    /**
     * This method updated the Sold to Contact on the Opportunity to a new Contact.
     */
    @Step("Change the Sold to Contact on Opportunity to {newContactName}")
    public void updateSoldToContactOnOpportunity(String newContactName){
        reusableBusinessLibrary.clickEditBtn();
        waitForElementToBePresent(driver, reusableBusinessLibrary.clearSelectedValueBtnOnEditPage("Sold to Contact"));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.clearSelectedValueBtnOnEditPage("Sold to Contact")));
        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldElement("Sold to Contact"));
        driver.findElement(reusableBusinessLibrary.textfieldElement("Sold to Contact")).clear();
        sendKeysToElement(driver, driver.findElement(reusableBusinessLibrary.textfieldElement("Sold to Contact")), newContactName);
        waitForElementToBePresent(driver, reusableBusinessLibrary.textfieldResult(newContactName));
        elementClickByJS(driver, driver.findElement(reusableBusinessLibrary.textfieldResult(newContactName)));
        saveOpportunity();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
    }

    /**
     * This method verifies that the warning message is displayed on the Opportunity after Sold to Contact is changed.
     */
    @Step("Verify that warning message is displayed on the Opportunity after Sold to Contact Change")
    public void verifySoldToContactChangeWarningMessage(){
        waitForElementToBeVisible(driver, soldToContactChangeWarningMessage);
        Assert.assertTrue(isElementDisplayed(driver, soldToContactChangeWarningMessage), "Warning message for Sold To Contact change is not displayed on the Opportunity");
        loggerManager.getLogger().info("Warning message for Sold To Contact change is displayed on the Opportunity");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the warning message for Sold to Contact Change is not displayed on the Opportunity after the Quote is finalized.
     */
    @Step("Verify that warning message for Sold to Contact Change is not displayed on the Opportunity after the Quote is finalized")
    public void verifyWarningMessageInvisibility(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        Assert.assertFalse(isElementDisplayed(driver, soldToContactChangeWarningMessage), "Warning message for Sold To Contact change is displayed on the Opportunity after the Quote is finalized");
        loggerManager.getLogger().info("Warning message for Sold To Contact change is not displayed on the Opportunity after the related Quote is finalized");
        takeScreenshot(TCName, driver);
    }

    // This method verify if user can access the Site profile.
    @Step("Verify user can access to Site profile")
    public void verifyAccesstoSiteProfile() {
        reusableBusinessLibrary.clickShowMoreActionsBtn();
        if (isElementDisplayed(driver, addUpdateSiteProfiles)) {
            loggerManager.getLogger().info("User can access to Site profile");
        } else {
            loggerManager.getLogger().error("User can not access to Site profile");
            Assert.fail("User can not access to Site profile");
        }
        takeScreenshot(TCName, driver);
    }

    //This method opens the Site Profile Detail page.
    @Step("Open Site Profile Detail")
    public void openSiteProfileDetail() {
        Allure.step("Check if Add/Update Site Profiles button is displayed", () -> {
            if (isElementDisplayed(driver, addUpdateSiteProfiles)) {
                elementClickByJS(driver, addUpdateSiteProfiles);
                waitForPageToLoad(Duration.ofSeconds(60));
                Allure.step("Verify Site Profiles Details Page is displayed", () -> {
                    if (isElementDisplayed(driver, siteProfilesDetailsPage)) {
                        loggerManager.getLogger().info("Site Profiles Details Page is displayed");
                        Assert.assertTrue(isElementDisplayed(driver, siteProfilesDetailsPage), "Site Profiles Details Page is displayed");
                    } else {
                        loggerManager.getLogger().error("Site Profiles Details Page is not displayed");
                        Assert.fail("Site Profiles Details Page is not displayed");
                    }
                });
            } else {
                loggerManager.getLogger().error("Unable to find Add/Update Site Profiles button");
                Allure.step("Unable to find Add/Update Site Profiles button", () -> {
                    Assert.fail("Unable to find Add/Update Site Profiles button");
                });
            }
            takeScreenshot(TCName, driver);
        });
    }

    //This method will verify & return the count of available Site Name on site profiles
    public int siteNameCountOnSiteProfile() {
        if (isElementDisplayed(driver, siteProfilesList.get(0))) {
            loggerManager.getLogger().info("Total number of sites on site profile : " + siteProfilesList.size());
            return siteProfilesList.size();
        } else {
            loggerManager.getLogger().error("Unable to find any site name of site profile screen");
            Allure.step("Unable to find any site name of site profile screen", () -> {
                Assert.fail("Unable to find any site name of site profile screen");
            });
            return 0;
        }
    }

    //This method checks if a Site Name exists to add a Site Profile.
    @Step("Check if Site Name exists to add Site Profile")
    public void siteNameExistToAddSiteProfile() {
        int siteCount = siteNameCountOnSiteProfile();
        Allure.step("Verify if Site Name exists to add Site Profile", () -> {
            if (siteCount > 0) {
                loggerManager.getLogger().info("Site Name exists to add Site Profile. Total sites: " + siteCount);
                takeScreenshot(TCName, driver);
            } else {
                loggerManager.getLogger().error("No Site Name exists to add Site Profile.");
                Assert.fail("No Site Name exists to add Site Profile.");
                takeScreenshot(TCName, driver);
            }
        });
    }

    //This method adds a site profile from the Site Profile Detail page.
    @Step("Add site profile from site profile details screen")
    public void addSiteProfilefromSiteProfileDetailPage() {
        Allure.step("Add site profile from site profile details screen", () -> {
            if (isElementDisplayed(driver, firstSiteNameCheckbox)) {
                elementClickByJS(driver, firstSiteNameCheckbox);
                loggerManager.getLogger().info("Site Name checkbox is selected");

                ReusableLibrary.elementClick(driver, firstSiteType);
                ReusableLibrary.sendKeysToElement(driver, firstSiteType, "Deliver To");
                ReusableLibrary.elementClick(driver, firstDeliveryTo);
                ReusableLibrary.elementClick(driver, firstFulfilmentMethod);
                ReusableLibrary.sendKeysToElement(driver, firstFulfilmentMethod, "Hosted");
                ReusableLibrary.elementClick(driver, firstHostedFulfillmentMethod);
                reusableBusinessLibrary.clickSaveBtn();
                String toastSiteProfileText = new WebDriverWait(driver, Duration.ofSeconds(240))
                        .until(ExpectedConditions.visibilityOf(siteProfileSuccesstoast)).getText().toLowerCase();
                Assert.assertTrue(toastSiteProfileText.contains("site profiles saved successfully"), "Site Profile is not saved successfully");
                loggerManager.getLogger().info("Site Name checkbox is selected and Save button is clicked");
            } else {
                loggerManager.getLogger().error("Site Name entry is not present to select on Site Profile Details screen");
                Assert.fail("Site Name entry is not present to select on Site Profile Details screen");
            }
            takeScreenshot(TCName, driver);
        });
    }

    @Step("Enter opportunity trail dates in Opportunity Form page")
    public void enterOpportunityTrialDates(LinkedHashMap<String, String> opportunityData){
        waitForElementToBeVisible(driver,formTextField("Trial Start"));
        sendKeysToElement(driver, formTextField("Trial Start"), getCurrentDateInMMddyyyyFormat());
        trialEndDate = currentDatePlusDays(15);
        sendKeysToElement(driver, formTextField("Trial End"), trialEndDate);
        loggerManager.getLogger().info("Opportunity Trail Dates are entered in Opportunity Form page");
    }

    @Step("Verify trail button on Opportunity record")
    public void verifyTrialButton(){
        scrollToElement(driver, scrollToContactInfo);
        waitForElementToBeClickable(driver, createTrailButton);
        Assert.assertTrue(isElementDisplayed(driver,createTrailButton), "Create Trail button is getting displayed in the opportunity record");
        takeScreenshot(TCName,driver);
        loggerManager.getLogger().info("Create Trail button is displayed");
    }

    @Step("Click on Create Trail button")
    public void clickCreateTrialButton(){
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        scrollToElement(driver, scrollToContactInfo);
        waitForElementToBeClickable(driver, createTrailButton);
        elementClick(driver, createTrailButton);
        loggerManager.getLogger().info("Clicked on Create Trail button");
    }

    /**
     * This method stores the Change Opportunity information in an Excel file.
     */
    @Step("Store Change Opportunity Information in Excel")
    public void storeChangeOpportunityInformationInExcel() {
        pageRefresh(driver);
        waitForElementToBeVisible(driver, opportunityRecordTypeText);
        oppyName = driver.findElement(opportunityValidationTextField("Opportunity Name")).getText();
        writeToExcel(opportunitiesFilePath, TCName, "OpportunityName", oppyName);
        scrollToElement(driver, opportunityRecordTypeText);
        writeToExcel(opportunitiesFilePath,TCName, "ContractSpecialistName", driver.findElement(opportunityValidationTextFieldLinks("Contract Specialist")).getText());
        writeToExcel(opportunitiesFilePath,TCName, "SoldToContactName", soldToContactNameOnOpportunity.getText());
        writeToExcel(opportunitiesFilePath,TCName, "AccountName", driver.findElement(opportunityValidationTextFieldLinks("Account Name")).getText());
        writeToExcel(opportunitiesFilePath,TCName, "ABOType", "Change");
    }

    /**
     * This method navigates to the linked proposal from the Opportunity.
     */

    @Step("Navigate to linked proposal from Opportunity")
    public void navigateToProposalFromOpportunity(){
        scrollToElement(driver, contractSpecialistValidationField);
        waitForElementToBeVisible(driver, proposalLink);
        elementClickByJS(driver, proposalLink);
        waitForPageTitleToContain(driver, "Proposal");
        Assert.assertTrue(driver.getTitle().contains("Proposal"), "Failed to navigate to Quote/Proposal from Opportunity");
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Navigated to proposal successfully");
    }

}

