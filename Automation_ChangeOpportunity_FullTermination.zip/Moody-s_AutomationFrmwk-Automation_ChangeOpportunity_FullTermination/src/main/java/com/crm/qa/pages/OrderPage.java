package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.WebElement;
import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;
import org.openqa.selenium.By;

import java.time.Duration;
import java.util.*;

public class OrderPage extends TestBase {

    public OrderPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();

    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);

    // Page Factory - OR:
    @FindBy(xpath = "//span[text()='Order Number']//following::slot[1]/lightning-formatted-text")
    WebElement orderNumber;

    //Please check if object can be reused from ReusableBusinessLibrary for other quick links validation
    public By quickLinks(String buttonName){
        return By.xpath("//lightning-icon[@title='"+buttonName+"']");
    }
    public By actionBtn(String buttonName){
        return By.xpath("//img[@alt='"+buttonName+"']");
    }
    public By messageValidation(String msg){
        return By.xpath("//span[text()='"+msg+"']");
    }

    @FindBy(xpath = "//span[text()='Configure  Products']")
    WebElement configureProductsFieldLabel;

    @FindBy(xpath = "//span[text()='MA Contracting Entity on Agreement']")
    WebElement maContractingEntityOnAgreementFieldLabel;

    @FindBy(xpath = "//div[contains(@data-target-selection-name, 'Fulfillment__c')]//a")
    WebElement fulfillmentLink;

    //Actions:

    /**
     * This method gets the order number and write it to the Excel
     */
    @Step("Get Order Number")
    public void getOrderNumber() {
        waitForElementToBeVisible(driver, orderNumber);
        writeToExcel(agreementsFilePath, agreementTCDependency, "OrderNo", getElementText(driver, orderNumber));
        loggerManager.getLogger().info("Order Number is: " + getElementText(driver, orderNumber));
    }

    /**
     * This method verifies the details on the Order record
     */
    @Step("Verify Order Details")
    public void verifyOrderDetails() {
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Order Number", readExcelData(agreementsFilePath, TCName, "OrderNo")));
        Allure.step("Verify Sales Representative in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Sales Representative", readExcelDataWithSheet(userCredentialsFilePath, prop.getProperty("LoginAs"), "Sales Rep", "User")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Sales Representative", readExcelDataWithSheet(userCredentialsFilePath, prop.getProperty("LoginAs"), "Sales Rep", "User")))), "Sales Representative is not displayed as expected in Order Page");
        });
        Allure.step("Verify Contract Representative in Order Page", step -> {
            waitForElementToBePresent(driver,reusableBusinessLibrary.linkField("Contract Specialist", readExcelData(opportunitiesFilePath, TCDependency, "ContractSpecialistName")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Contract Specialist", readExcelData(opportunitiesFilePath, TCDependency, "ContractSpecialistName")))), "Contract Specialist is not displayed as expected in Order Page");
        });
        Allure.step("Verify Primary Contact in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Primary Contact", readExcelData(opportunitiesFilePath, TCDependency, "SoldToContactName")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Primary Contact", readExcelData(opportunitiesFilePath, TCDependency, "SoldToContactName")))), "Primary Contact is not displayed as expected in Order Page");
        });
        Allure.step("Verify Sold To in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Sold To", readExcelData(opportunitiesFilePath, TCDependency, "AccountName")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Sold To", readExcelData(opportunitiesFilePath, TCDependency, "AccountName")))), "Sold To is not displayed as expected in Order Page");
        });
        Allure.step("Verify Legal Contracting Entity in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Legal Contracting Entity", readExcelData(opportunitiesFilePath, TCDependency, "AccountName")));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Legal Contracting Entity", readExcelData(opportunitiesFilePath, TCDependency, "AccountName")))), "Legal Contracting Entity is not displayed as expected in Order Page");
        });
        //if test cases are divided into 2 then oppyName needs to be saved in the excel
        Allure.step("Verify Related Opportunity in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Related Opportunity", oppyName));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Related Opportunity", oppyName))), "Related Opportunity is not displayed as expected in Order Page");
        });
        //same goes for Quote/Proposal field as well
        Allure.step("Verify Quote/Proposal in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Quote/Proposal", proposalID));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Quote/Proposal", proposalID))), "Quote/Proposal is not displayed as expected in Order Page");
        });
        //Agreement name needs to be saved in QuoteData sheet
        Allure.step("Verify Agreement in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.linkField("Agreement", agreementName));
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(reusableBusinessLibrary.linkField("Agreement", agreementName))), "Agreement is not displayed as expected in Order Page");
        });
        Allure.step("Verify Order Total in Order Page", step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Order Total"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Order Total"))), quoteAndAgreementTotal, "Order Total is not matching with the expected as expected value in Order Page");
        });
        if(readExcelData(opportunitiesFilePath, TCDependency, "ABOType").equals("Change")){
            Allure.step("Verify quoteTotal is equal to Delta Amount", step -> {
                waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Delta Amount"));
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Delta Amount"))), quoteAndAgreementTotal, "Fulfillment Total is not displayed as expected.");
            });
        }
        waitForElementToBeVisible(driver, maContractingEntityOnAgreementFieldLabel);
        scrollToElement(driver, maContractingEntityOnAgreementFieldLabel);
        waitForElementToBeVisible(driver, configureProductsFieldLabel);
        scrollToElement(driver, configureProductsFieldLabel);
        //Its better to capture the oppy start date and end date in OpportunityData sheet
        Allure.step("Verify that value of Expected Order Start Date is " + expectedStartDate, step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Order Start Date"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Order Start Date"))), expectedStartDate, "Order Start Date is not displayed as expected.");
        });
        Allure.step("Verify that value of Order End Date is " + expectedEndDate, step -> {
            waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Order End Date"));
            softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Order End Date"))), expectedEndDate, "Order End Date is not displayed as expected.");
        });
        scrollToTop(driver);
        if (orderActivationFlag) {
            Allure.step("Verify Status in Order Page", step -> {
                waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status"));
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status"))), "Activated", "Status is not matching with the expected value in Order Page");
            });
        } else {
            Allure.step("Verify Status in Order Page", step -> {
                waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Status"));
                softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Status"))), "Pending", "Status is not matching with the expected value in Order Page");
            });
        }
        //Need to add ABOType column in OpportunityData sheet
        switch (readExcelData(opportunitiesFilePath, TCDependency, "ABOType")) {
            case "New":
                Allure.step("Verify Type in Order Page", step -> {
                    waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Type"));
                    softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Type"))), "New", "Type is not matching with the expected value in Order Page");
                });
                break;
            case "Change":
                Allure.step("Verify Type in Order Page", step -> {
                    waitForElementToBePresent(driver, reusableBusinessLibrary.textFieldValue("Type"));
                    softAssert.assertEquals(getElementText(driver, driver.findElement(reusableBusinessLibrary.textFieldValue("Type"))), "Change", "Type is not matching with the expected value in Order Page");
                });
                break;
            default:
                loggerManager.getLogger().info("Type is missing in the Opportunity Data sheet");
                break;
        }

        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Order Details are verified successfully");
    }

    /**
     * This method verifies the quick links and actions buttons on the Order record
     */
    @Step("Verify quick links and Actions button in Order Page")
    public void verifyQuickLinksAndActionsButton() {

        Allure.step("Verify Quick Links in Order Page", step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(quickLinks("Site Profiles"))), "Site Profiles button is not displayed in Order Page");
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(quickLinks("Populate AC Fields"))), "Populate AC Fields button is not displayed in Order Page");
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(quickLinks("Validate Order"))), "Validate Order button is not displayed in Order Page");
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(quickLinks("View Products"))), "View Products button is not displayed in Order Page");
        });
        Allure.step("Verify Actions buttons in Order Page", step -> {
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(actionBtn("Validate"))), "Validate button is not displayed in Order Page");
            softAssert.assertTrue(isElementDisplayed(driver, driver.findElement(actionBtn("Configure Products"))), "Configure Products button is not displayed in Order Page");
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Quick Links and Actions button are verified successfully");
    }

    /**
     * This method clicks on the Validate Order button on the Order page
     */
    @Step("Validate order details")
    public void validateOrderDetails() {
        waitForElementToBePresent(driver, (quickLinks("Validate Order")));
        elementClick(driver, driver.findElement(quickLinks("Validate Order")));
        Allure.step("Verify order validation message", step -> {
            waitForElementToBePresent(driver, messageValidation("Order Validated Successfully"));
            Assert.assertTrue(isElementDisplayed(driver, driver.findElement(messageValidation("Order Validated Successfully"))), "Order Validation Message is not displayed in Order Page");
        });
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Order validation is successfully completed");
    }

    /**
     * This method clicks on the Accept Order button on the Order page
     */
    @Step("Activate order")
    public void activateOrder(){
        waitForElementToBeClickable(driver, driver.findElement(quickLinks("Accept Order")));
        elementClick(driver, driver.findElement(quickLinks("Accept Order")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForUrlToContain(driver, "https://moodysanalytics--supportqa.sandbox.lightning.force.com/lightning/r/Apttus_Config2__Order__c/" + orderRecordID + "/view");
        waitForElementToBePresent(driver, messageValidation("Order Accepted Successfully"));
        Allure.step("Verify order activation message", step -> {
            Assert.assertTrue(isElementDisplayed(driver, driver.findElement(messageValidation("Order Accepted Successfully"))), "Order Activation Message is not displayed in Order Page");
        });
        orderActivationFlag = true;
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Order is activated successfully");
    }

    /**
     * This method validates and accepts the Order
     */
    @Step("Validate and accept order")
    public void validateAndAcceptOrder(){
        getOrderNumber();
        verifyOrderDetails();
        verifyQuickLinksAndActionsButton();
        validateOrderDetails();
        activateOrder();
    }

    /**
     * This method navigates to Order Line Items related list
     */
    @Step("Navigate to Order Line Items")
    public void navigateToOrderLineItems(){
        reusableBusinessLibrary.clickOnRelatedList("Order Line Items");
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, "Order Line Items | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Order Line Items | Salesforce"), "Navigated to Order Line Items page");
        loggerManager.getLogger().info("Navigated to Order Line Items page");
    }

    /**
     * This method verifies the Order Line Items on the Order
     * @param quoteData - The product details from the Quote to be validated on the Order Line Items
     */
    @Step("Verify that Order Line Items are displayed on the Order")
    public void verifyOrderLineItems(List<LinkedHashMap<String, String>> quoteData) {
        List<String> actualProductNames = new ArrayList<>();
        List<String> expectedProductNames = new ArrayList<>();
        List<String> actualStartDate = new ArrayList<>();
        List<String> actualEndDate = new ArrayList<>();
        List<String> actualBillingCycle = new ArrayList<>();
        List<String> actualLineStatus = new ArrayList<>();
        setScreenZoom(driver, 75);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, reusableBusinessLibrary.lineItemsTableData("Order Line Items"));
        List<WebElement> orderLineItems = driver.findElements(reusableBusinessLibrary.lineItemsTableData("Order Line Items"));
        for (WebElement orderLineItem : orderLineItems) {
            waitForElementToBeVisible(driver, orderLineItem);
            String dataLabel = orderLineItem.getAttribute("data-label");
            if (dataLabel != null)
                switch (dataLabel) {
                    case "Description":
                        actualProductNames.add(getElementText(driver, orderLineItem));
                        break;
                    case "Start Date":
                        actualStartDate.add(getElementText(driver, orderLineItem));
                        break;
                    case "End Date":
                        actualEndDate.add(getElementText(driver, orderLineItem));
                        break;
                    case "Billing Cycle":
                        actualBillingCycle.add(getElementText(driver, orderLineItem));
                        break;
                    case "Line Status":
                        actualLineStatus.add(getElementText(driver, orderLineItem));
                        break;
                    default:
                        break;
                }
        }

        // Get all product names including any option products from the quote data
        for (LinkedHashMap<String, String> data : quoteData) {
            expectedProductNames.add(data.get("ProductName"));
            if (data.get("ProductType").equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(",");
                expectedProductNames.addAll(Arrays.asList(optionProducts));
            }
        }
        Allure.step("Verify that Order Line Item is created for all products" + expectedProductNames, step -> {
            softAssert.assertEquals(actualProductNames, expectedProductNames, "Order Line Item is not created for all products");
        });
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Order Line Items", "Description"));
        List<WebElement> orderLineItemsProductNames = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Order Line Items", "Description"));
        waitForElementToBePresent(driver, reusableBusinessLibrary.relatedListColumnData("Order Line Items", "Sales Price"));
        List<WebElement> orderLineItemsPrice = driver.findElements(reusableBusinessLibrary.relatedListColumnData("Order Line Items", "Sales Price"));
        reusableBusinessLibrary.verifyLineItemsPrice(quoteData, orderLineItemsProductNames, orderLineItemsPrice);

        Allure.step("Verify that Start Date is " + expectedStartDate + " on Order Line Items ", step -> {
            softAssert.assertTrue(actualStartDate.stream().allMatch(val -> val.equals(expectedStartDate)), "Start Date is not displayed as expected");
        });
        Allure.step("Verify that End Date is " + expectedStartDate + " on Order Line Items ", step -> {
            softAssert.assertTrue(actualEndDate.stream().allMatch(val -> val.equals(expectedEndDate)), "End Date is not displayed as expected");
        });
        Allure.step("Verify that Billing Cycle is " + readExcelData(agreementsFilePath,agreementTCDependency,"BillingCycle") + " on Order Line Items ", step -> {
            String expectedBillingCycle = readExcelData(agreementsFilePath,agreementTCDependency,"BillingCycle");
            softAssert.assertTrue(actualBillingCycle.stream().allMatch(val -> val.equals(expectedBillingCycle)), "Billing Cycle is not displayed as expected");
        });
        switch (readExcelData(opportunitiesFilePath, TCDependency, "ABOType")) {
            case "New":
                Allure.step("Verify that Line Status is New on Order Line Items ", step -> {
                    softAssert.assertTrue(actualLineStatus.stream().allMatch(val -> val.equals("New")), "Line Status is not displayed as expected");
                });
                break;
            default:
                loggerManager.getLogger().info("Line Status is missing in the Opportunity Data sheet");
                break;
        }
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Order Line Items are displayed correctly on the Order");
        setScreenZoom(driver, 100);
    }

    /**
     * This method clicks on the Fulfillment link on the Order page
     */
    @Step("Click on Fulfillment link")
    public void clickOnFulfillmentLink(){
        waitForElementToBePresent(driver, reusableBusinessLibrary.fieldLabel("Order Total"));
        scrollToElement(driver, driver.findElement(reusableBusinessLibrary.fieldLabel("Order Total")));
        waitForElementToBeVisible(driver, fulfillmentLink);
        elementClickByJS(driver, fulfillmentLink);
        waitForPageTitleToContain(driver, "Fulfillment | Salesforce");
        Assert.assertTrue(driver.getTitle().contains("Fulfillment | Salesforce"), "Navigated to Fulfillment page");
        loggerManager.getLogger().info("Navigated to Fulfillment page successfully");
    }


}
