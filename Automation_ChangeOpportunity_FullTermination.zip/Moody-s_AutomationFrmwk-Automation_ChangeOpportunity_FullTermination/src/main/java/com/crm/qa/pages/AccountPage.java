package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.NoSuchElementException;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.getSFDCRecordIDFromURL;
import static com.crm.qa.util.ReusableLibrary.*;
import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;


/**
 * This class contains methods related to the Account functionality.
 * Author: Bhagyashree Wani
 * Last Modified By: Arshin Shaikh
 * Date: 11/12/2024
 * Comment: Added methods - selectPartnershipAllianceAuthorization and saveAccountNameInExcel
 */

public class AccountPage extends TestBase {

    //Initializing the Page Objects:
    public AccountPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    LeadPage leadPage = new LeadPage(driver);
    SoftAssert softAssert = new SoftAssert();
    OpportunityPage opportunityPage = new OpportunityPage(driver);
    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);

    HomePage homePage = new HomePage(driver);

    //Page Factory - OR:
    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//a[text()='Details']")
    WebElement detailsTabOnAccount;

    @FindBy(xpath = "//span[text()='RDC Customer Success Segment']")
    WebElement rdcCustomerSuccessSegmentOnAccount;

    WebElement accountAddressFieldText(String fieldName) {
        return driver.findElement(By.xpath("//span[text()='" + fieldName + "' and @class='test-id__field-label']/following::lightning-formatted-text[1]"));
    }

    @FindBy(xpath = "(//div[contains(@class,'windowViewMode-normal')]//a[text()='Details'])[1]")
    WebElement detailsTab;

    public By accountPrimaryAddressText(String addressFieldName){
        return By.xpath("(//span[text()='" + addressFieldName + "' and contains(@class,'field')]/following::lightning-formatted-text)[1]");
    }

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//lightning-button-menu[contains(@class,'menu')]//button")
    WebElement showMoreActionsButton;

    @FindBy(xpath = "//span[text()='RDC Customer Success Segment']")
    WebElement rdcCustomerSuccessSegmentLabelOnAccount;

    public By accountPhoneText = By.xpath("//records-output-phone//a");

    @FindBy(xpath = "//span[text()='AC Primary City']")
    WebElement ACPrimaryCityLabelOnAccount;

    @FindBy(xpath = "//button[@name='PrimaryCountryPicklist__c']")
    WebElement primaryCountryPicklistOnAccount;

    public By primaryCountryPicklistOptionOnAccount(String countryName) {
        return By.xpath("//span/span[text()='" + countryName + "']");
    }

    @FindBy(xpath = "(//input[@placeholder='Enter data here to validate address'])[1]")
    WebElement addressSuggestionTextFieldOnAccount;

    @FindBy(xpath = "//div[contains(@class,'slds-media slds-listbox__option')]")
    WebElement addressSuggestionOptionOnAccount;

    @FindBy(xpath = "//button[text()='Skip Validation']")
    WebElement skipValidationButton;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//th[@data-label='Location Name']//a//span[@class]")
    WebElement accountLocationRecordLink;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Apttus_Config2__AccountLocation__c.Name')]//lightning-formatted-text")
    WebElement accountLocationNameText;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Apttus_Config2__AccountLocation__c.Street_1')]//lightning-formatted-text")
    WebElement accountLocationStreet1Text;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Apttus_Config2__City__c')]//lightning-formatted-text")
    WebElement accountLocationCityText;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Apttus_Config2__State__c')]//lightning-formatted-text")
    WebElement accountLocationStateText;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Apttus_Config2__PostalCode__c')]//lightning-formatted-text")
    WebElement accountLocationPostalCodeText;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'Apttus_Config2__AccountLocation__c.Country')]//slot[@lwc-47ngqe6rvah]")
    WebElement accountLocationCountryText;

    @FindBy(xpath = "//a[text()='Account Locations']")
    WebElement accountLocationsSubTab;

    @FindBy(xpath = "//a[contains(@href,'RelatedList') and contains(@class,'header')]")
    WebElement accountLocationsRelatedList;

    public By moreAccountDetailsSubTabBtn = By.xpath("(//button[@title='More Tabs'])[last()]");

    @FindBy(xpath = "//span[text()='Account Locations']")
    WebElement accountLocationsSubTabUnderMore;

    @FindBy(xpath = "//span[text()='OFAC Date Stamp']")
    WebElement ofacDateStampLabelonAccount;

    @FindBy(xpath = "//div[contains(@data-target-selection-name,'BusinessType')]//lightning-formatted-text")
    WebElement businessTypeText;

    @FindBy(xpath = "//slot[contains(@class,'header__title')]//lightning-formatted-text[@slot='primaryField']")
    WebElement accountNameOnHeader;

    @FindBy(xpath = "(//span[text()='Phone']//following::a)[1]")
    WebElement accountPhoneValue;

    @FindBy(xpath = "//span[text()='Alternate Character Fields']")
    WebElement altCharacterSection;

    @FindBy(xpath = "//li[@title='Contacts']")
    WebElement contactsTab;

    @FindBy(xpath = "//div[@title='New Contact']")
    WebElement newContactButton;

    public By nextBtnOnNewContact = By.xpath("//span [text()='Next']");


    public By editRightPanelButton = By.xpath("//button[text()='Edit']");

    @FindBy(xpath = "//lightning-icon[@icon-name='action:close']")
    WebElement unlinkAccountIcon;

    @FindBy(css = "button[name='unlink']")
    WebElement unlinkAccountButton;

    @FindBy(xpath = "(//a[@title='Link Company'])[1]")
    WebElement orbisMatchTool_LinkCompany;

    @FindBy(xpath = "//a[text()='Details']")
    WebElement accountDetailsTab;

    @FindBy(xpath = "(//a[text()='Details'])[2]")
    WebElement accountDetailsDetailsTab;

    @FindBy(xpath = "(//a[text()='Orbis Matching Tool'])")
    WebElement orbisMatchingToolTab;

    @FindBy(xpath = "//*[@data-target-selection-name='bvd_connector_MatchingCompaniesWidgetWithPermission']")
    WebElement orbisCompanyMatchingTable;

    @FindBy(css = "[class*=bvd_connectorStatusComponent]")
    WebElement bvd_connectorStatusComponent;

    @FindBy(xpath = "//*[text()='BvD Id']/following::lightning-formatted-text[1]")
    WebElement BvDId;

    @FindBy(xpath = "//lightning-icon[@icon-name='action:google_news']")
    WebElement reportIcon;

    @FindBy(xpath = "//lightning-icon[@icon-name='action:new_group']")
    WebElement hierarchyIcon;

    @FindBy(css = "[class*=hierarchy-table_container]")
    WebElement hierarchyContainer;

    @FindBy(xpath = "//button[text()='Back to record']")
    WebElement hierarchyBacktoRecordBtn;

    @FindBy(xpath = "//div[text()='Bureau van Dijk Connector - BvD Linking']")
    WebElement bvdSuccessLinkageToast;

    @FindBy(xpath = "//runtime_platform_actions-actions-ribbon//*[@data-target-selection-name='sfdc:StandardButton.Account.Edit']")
    WebElement account_editButton;

    @FindBy(xpath = "//*[contains(@class,'windowViewMode-normal')]//input[@name='Phone']")
    WebElement accountEdit_phone;

    @FindBy(xpath = "//*[contains(@class,'windowViewMode-normal')]//*[@kx-scope='button-brand']")
    WebElement accountEdit_saveButton;

    @FindBy(xpath = "//*[contains(@class,'toastMessage')][text()='Record saved']")
    WebElement recordSavedToast;

    @FindBy(xpath = "//*[contains(@class,'windowViewMode-normal')]//*[@data-key='change_record_type']")
    WebElement updateIcon_OrbisComponent;

    @FindBy(xpath = "//div[text()='Orbis']/following::a[text()='Select All']")
    WebElement selectAllLnk_Orbis;

    @FindBy(xpath = "//button[text()='Merge Records']")
    WebElement mergeRecordsBtn_Orbis;

    @FindBy(xpath = "//*[contains(@class,'windowViewMode-normal')]//*[@data-key='approval']")
    WebElement approvalIcon_OrbisComponent;
    @FindBy(xpath = "//button[@name='BusinessType__c']")
    WebElement businessTypePicklist;

    @FindBy(xpath = "//button[@name='PrimaryStatePicklist__c']")
    WebElement primaryStatePicklistOnAccount;

    @FindBy(xpath = "//span[text()='Tax Exempt']")
    WebElement taxExemptLabelOnAccount;

    @FindBy(xpath = "//button[@name='Type_of_Entity__c']")
    WebElement typeOfEntityPicklist;

    public By accountMultiSelectOption(String option){
        return By.xpath("//div[@data-value='" + option + "']");
    }

    @FindBy(xpath = "(//div[text()='Partner Type']//following::button[@title='Move to Chosen'])[1]")
    WebElement partnerTypeMoveToChosenButton;

    @FindBy(xpath = "//span[text()='Primary Site']")
    WebElement primarySiteCheckbox;

    public By mandatoryFieldErrorMessage(String fieldName){
        return By.xpath("//span[text()='" + fieldName + "']/parent::div[text()='Complete this field.']");
    }

    @FindBy(xpath = "//span[text()='Segmentation Information']")
    WebElement segmentationInformationSectionLabel;

    @FindBy(xpath = "//span[text()='Partner Information']")
    WebElement partnerInformationSectionLabel;

    @FindBy(xpath = "//span[text()='Address Information']")
    WebElement addressInformationSectionLabel;

    @FindBy(xpath = "//span[text()='Alternate Character Fields']")
    WebElement alternateCharacterFieldsSectionLabel;

    @FindBy(xpath = "(//p[text()='Website']//following::a)[1]")
    WebElement accountWebsiteValue;

    @FindBy(xpath = "//div[contains(@data-target-selection-name, 'Primary_Site__c')]//lightning-input")
    WebElement primarySiteCheckboxValue;

    @FindBy(xpath = "(//span[text()='Type of Entity']//following::span[contains(@class,'field-value')])[1]")
    WebElement typeOfEntityValue;

    @FindBy(xpath = "(//span[text()='Partner Type']//following::span[contains(@class,'field-value')])[1]")
    WebElement partnerTypeValue;

    @FindBy(xpath = "//span[text()='Status']")
    WebElement statusSectionLabel;

    public By accountTextField(String fieldName){
        return By.xpath("(//label[text()='" + fieldName + "']/following::input)[1]");
    }

    public By accountRecordTypeRadioButton(String recordType){
        return By.xpath("(//span[text()='" + recordType + "']/preceding::span[contains(@class,'radio')])[last()]");
    }

    public By accountPicklistOption(String option){
        return By.xpath("//lightning-base-combobox-item[@data-value='" + option + "']");
    }

    @FindBy(xpath = "//a[text()='Agreements']")
    WebElement agreementsTabOnAccount;

    @FindBy(xpath = "//span[text()='In Progress Agreements']")
    WebElement inProgressAgreementsList;

    @FindBy(xpath = "//button[text()='New Legal Contracting Entity']")
    WebElement newLegalContractingEntityBtnUnderAgreementsTab;

    @FindBy(xpath = "//h4[text()='Legal Contracting Entity']")
    WebElement legalContractingEntityText;

    @FindBy(xpath = " (//label[text()='Legal Contracting Entity Name']/following::input) [1]")
    WebElement legalContractingEntityNameTextField;

    @FindBy(xpath = "//input[@aria-label='Primary State']")
    WebElement primaryStatePicklistOnLegalContractingEntity;


    @FindBy(xpath = "(//span[text()='Country of Registration']/following::select) [1]")
    WebElement primaryCountryPicklistOnLegalContractingEntity;

    @FindBy(xpath = "//textarea[@name='street']")
    WebElement primaryStreetTextFieldOnLegalContractingEntity;

    @FindBy(xpath = "//input[@name='city']")
    WebElement primaryCityTextFieldnLegalContractingEntity;

    @FindBy(xpath = "//input[@name='postalCode']")
    WebElement primaryZipcodeTextFieldOnLegalContractingEntity;

    @FindBy(xpath = " //footer//button[text()='Save']")
    WebElement saveButtonOnLegalContractingEntity;

    public By primaryStatePicklistOnLegalContractingEntityOption(String stateFieldSelection){
            return  By.xpath("//span[text()='"+stateFieldSelection+"']");
    }

    @FindBy(xpath = "//a//span[@title='Legal Contracting Entities']")
    WebElement legalContractingEntityList;

    @FindBy(xpath = "//a[text()='Team']")
    WebElement accountTeamSubTab;

    @FindBy(xpath = "//span[text()='Account Team' and @class='slds-truncate']")
    WebElement accountTeamHeader;

    @FindBy(xpath = "//span[text()='Account Team' and @class='slds-truncate slds-m-right--xx-small']")
    WebElement accountTeamsLink;
    @FindBy(xpath = "//div[text()='Add Team Members']")
    WebElement newAddTeamMembersButton;

    @FindBy(xpath = "(//button[@title='Edit User: Item '])[1]")
    WebElement addTeamMemberUser;

    @FindBy(xpath = "//input[@placeholder='Search People...']")
    WebElement addTeamMemberUserSearchField;

    WebElement addTeamMemberUserSearchFieldOption(String user){
        return driver.findElement(By.xpath("//div[@title='"+ user +"']"));
    }

    @FindBy(xpath = "(//button[@title='Edit Team Role: Item '])[1]")
    WebElement teamRoleHeader;

    @FindBy(xpath = "//div[@class='slds-grow uiMenu']//a[@role='combobox']")
    WebElement addTeamMemberRole;

    WebElement addTeamMemberRolePicklistOption(String option){
        return driver.findElement(By.xpath("//li[@role='presentation']//a[text()='"+ option +"']"));
    }
    @FindBy(xpath = "//button[@title='Save']")
    WebElement saveBtnOnTeamMember;

    @FindBy(xpath = "//div[@class='name']//a")
    WebElement accountTeamMemberNameLink;

    @FindBy(xpath = "//div[text()='Account Team Member']")
    WebElement accountTeamMemberRecordHeader;

    @FindBy(xpath = "//span[text()='User']//following::a")
    WebElement accountTeamMemberUserValue;

    @FindBy(xpath = "//span[text()='Team Role' and @class='test-id__field-label']//following::span[4]")
    WebElement accountTeamMemberRoleValue;

    @FindBy(xpath = "//span[text()='Team Member Active?' and @class='test-id__field-label']")
    WebElement teamMemberActiveField;

    @FindBy(xpath = "//span[text()='Team Member Active?']//following::span[2]")
    WebElement teamMemberActiveFieldValue;

    WebElement accountTeamMemberField(String fieldName){
        return driver.findElement(By.xpath("//span[text()='"+fieldName+"'and @class='test-id__field-label']//following::div[1]"));
    }

    @FindBy(xpath = "//div[@class='tooltip-advanced tooltip-body active']")
    WebElement accountTeamMemberFieldsHelpText;

    @FindBy(xpath = "//span[text()='Source' and @class='test-id__field-label']")
    WebElement sourceField;

    @FindBy(xpath = "//span[text()='Source' and @class='test-id__field-label']//following::span[4]")
    WebElement sourceFieldValue;

    @FindBy(xpath = "//a[@title='Edit']")
    WebElement editBtnOnAccountTeamMember;

    @FindBy(xpath = "//span[text()='Crediting Manager']//following::input[@placeholder='Search People...' and @role='combobox'][1]")
    WebElement creditingManagerSearchField;

    @FindBy(xpath = "//span[text()='Handler Role']//parent::label//following-sibling::input")
    WebElement handlerRoleSearchField;

    @FindBy(xpath = "//span[text()='Product']//parent::label//following-sibling::input")
    WebElement productSearchField;

    @FindBy(xpath = "(//span[text()='Team Role']//following::div[@class='uiMenu']//a)[1]")
    WebElement editTeamMemberRole;

    @FindBy(xpath = "(//button[text()='Edit'])[1]")
    WebElement accountEditButton;

    @FindBy(xpath = "(//button[text()='New'])[1]")
    WebElement openOppoyNewButton;

    @FindBy(xpath = "//button[contains(@name,'Company_Status')]")
    WebElement companyStatusPicklist;

    @FindBy(xpath = "//span[@title='Unknown']")
    WebElement companyStatusUnknownOption;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//label[text()='Parent Account']//following::input[1]")
    WebElement parentAccountField;

    public By parentAccountOption(String parentAccountName){
        return By.xpath("//lightning-base-combobox-formatted-text[@title='"+parentAccountName+"']");
    }

    public By oppyNameValidation(String oppyName){
        return By.xpath("//span[text()='"+oppyName+"']");
    }

    @FindBy(xpath = "(//span[text()='AC Name']//following::span[contains(@class,'field-value')])[1]")
    WebElement ACNameValue;

    @FindBy(xpath = "//a[contains(@href,'CombinedAttachments')]")
    WebElement notesAndAttachmentsQuickLink;

    @FindBy(xpath = "(//span[text()='Website']//following::a)[1]")
    WebElement competitorAccountWebsiteValue;

    @FindBy(xpath = "//lightning-click-to-dial/span[last()]")
    WebElement clickToDialDisabledPhoneValue;

    @FindBy(xpath = "//span[text()='Phone']//following::span[4]")
    WebElement accountPhoneValue_nonHyperlink;


    @FindBy(xpath = "(//div[text()='Partnership/Alliance Authorization']/following::button[@title='Move to Chosen'])[1]")
    WebElement partnershipAllianceAuthorizationMoveToChosenBtn;

    @FindBy(xpath = "//label[text()='Access to Training Centre']")
    WebElement accessToTrainingCentreLabel;

    @FindBy(xpath = "(//div[text()='Partnership/Alliance Authorization']//following::ul[contains(@id,'selected')])[1]//span[contains(@class,'truncate')]")
    List<WebElement> selectedPartnershipAllianceAuthorizationValues;


    //Actions:

    /**
     * Verifies that the address and phone details on the converted account
     * match the address and phone details on the lead.
     * This method performs the following steps:
     * 1. Retrieves the address and phone details from the lead.
     * 2. Compares these details with the address and phone details on the converted account.
     * 3. Asserts that the details match and logs the results.
     */
    @Step("Step: Verify that the converted Account Address is same as the Lead Address")
    public void verifyAddressPhoneOnConvertedAccount(){
        try{
            waitForElementToBeVisible(driver,detailsTabOnAccount);
            ReusableLibrary.elementClick(driver,detailsTabOnAccount);
            Thread.sleep(7000);
            js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0, 300);");
            ReusableLibrary.scrollToElement(driver,rdcCustomerSuccessSegmentOnAccount);
            waitForElementToBeVisible(driver, accountAddressFieldText("Primary Country"));
            softAssert.assertEquals(separateAddressInfo.get("Country"),ReusableLibrary.getElementText(driver,accountAddressFieldText("Primary Country")), "Country field on the Account not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("Street"),ReusableLibrary.getElementText(driver,accountAddressFieldText("Primary Street 1")), "Street1 field on the Account not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("City"),ReusableLibrary.getElementText(driver,accountAddressFieldText("Primary City")), "City field on the Account not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("State"),ReusableLibrary.getElementText(driver,accountAddressFieldText("Primary State")), "State field on the Account not copied over from the Lead");
            softAssert.assertEquals(separateAddressInfo.get("Zip Code"),ReusableLibrary.getElementText(driver,accountAddressFieldText("Primary Zip/Postal Code")), "Postal Code field on the Account not copied over from the Lead");
            // Commenting the below line as phone number field is not displayed on the Account Page.
            //softAssert.assertEquals(Temp2,"Phone: " + ReusableLibrary.getElementText(driver,accountPhoneValue), "Phone is not matching");
            softAssert.assertAll();
            loggerManager.getLogger().info("Lead's Address/Phone details are updated successfully on Account's Address/Phone details");
            ReusableLibrary.takeScreenshot("verifyAddressPhoneOnConvertedAccount", driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Lead's Address/Phone details are not updated on Account's Address/Phone details");
            Assert.assertTrue(false, "Lead's Address/Phone details are not updated on Account's Address/Phone details");
        }

    }

    /**
     * This method gets the Address Details from the Account page.
     */
    @Step("Get Account Address Details")
    public LinkedHashMap<String, String> getAccountAddressDetails(){
        LinkedHashMap<String, String> accountAddressDetails = new LinkedHashMap<>();
        waitForElementToBeVisible(driver, detailsTab);
        elementClickByJS(driver, detailsTab);
        waitForElementToBePresent(driver, accountPrimaryAddressText("Primary Country"));
        waitForElementToBeVisible(driver, showMoreActionsButton);
        js = (JavascriptExecutor) driver;
        if (TCName.contains("CompetitorAccount")) {
            js.executeScript("window.scrollBy(0, 500);");
            scrollToElement(driver, taxExemptLabelOnAccount);
        }
        else {
            js.executeScript("window.scrollBy(0, 900);");
            scrollToElement(driver, rdcCustomerSuccessSegmentLabelOnAccount);
        }
        accountAddressDetails.put("Country", driver.findElement(accountPrimaryAddressText("Primary Country")).getText());
        accountAddressDetails.put("Street 1", driver.findElement(accountPrimaryAddressText("Primary Street 1")).getText());
        accountAddressDetails.put("City", driver.findElement(accountPrimaryAddressText("Primary City")).getText());
        accountAddressDetails.put("State", driver.findElement(accountPrimaryAddressText("Primary State")).getText());
        accountAddressDetails.put("Postal Code", driver.findElement(accountPrimaryAddressText("Primary Zip/Postal Code")).getText());
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Account Address Details: " + accountAddressDetails);
        return accountAddressDetails;
    }

    /**
     * This method gets the value of Phone field from the Account page.
     */
    @Step("Get Account Phone Value")
    public String getAccountPhone(){
        String actualPhoneValue = null;
        driver.navigate().refresh();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, showMoreActionsButton);
        waitForElementToBeVisible(driver, detailsTab);
        elementClickByJS(driver, detailsTab);
        waitForElementToBePresent(driver, accountPhoneText);
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 1800);");
        scrollToElement(driver, ACPrimaryCityLabelOnAccount);
        waitForElementToBeVisible(driver, clickToDialDisabledPhoneValue);
        if (!getElementText(driver, clickToDialDisabledPhoneValue).isEmpty())
            actualPhoneValue = getElementText(driver, clickToDialDisabledPhoneValue);
        else {
            waitForElementToBeVisible(driver, driver.findElement(accountPhoneText));
            actualPhoneValue = getElementText(driver, driver.findElement(accountPhoneText));
        }

        takeScreenshot(TCName, driver);
        return actualPhoneValue;
    }

    /**
     * This method verifies that the Account location gets created while converting a Lead to an Account.
     *
     * @param leadData LinkedHashMap<String, String> - The data of the lead that was converted.
     */
    @Step("Verify that Account location gets created while conversion of lead into account.")
    public void verifyAccountLocationOnConvertedAccount(LinkedHashMap<String, String> leadData){

        // Open Account Location
        elementClick(driver, detailsTab);
        try {
            waitForElementToBeVisible(driver, driver.findElement(moreAccountDetailsSubTabBtn));
            elementClickByJS(driver, driver.findElement(moreAccountDetailsSubTabBtn));
            elementClick(driver, accountLocationsSubTabUnderMore);
        }
        catch (NoSuchElementException e){
            loggerManager.getLogger().info("More Tab is not available. Clicking on Account Locations sub tab directly");
            waitForElementToBeVisible(driver, accountLocationsSubTab);
            elementClick(driver, accountLocationsSubTab);
        }
        waitForElementToBeVisible(driver, accountLocationsRelatedList);
        elementClickByJS(driver, accountLocationsRelatedList);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        switchToDefaultContent(driver);
        waitForElementToBeVisible(driver, accountLocationRecordLink);
        waitForElementToBeClickable(driver, accountLocationRecordLink);
        elementClickByJS(driver, accountLocationRecordLink);

        //Verify Account Location Name and Address
        waitForElementToBeVisible(driver, accountLocationNameText);
        String actualAccountLocation = accountLocationNameText.getText();
        String expectedAccountLocation = leadData.get("Primary City") + " " + leadData.get("Primary Country") + " " + leadData.get("Primary Zip/Postal Code");
        String actualAccountLocationCountry = accountLocationCountryText.getText();
        String expectedAccountLocationCountry = leadData.get("Primary Country");
        String actualAccountLocationStreet1 = accountLocationStreet1Text.getText();
        String expectedAccountLocationStreet1 = leadData.get("Primary Street 1");
        String actualAccountLocationCity = accountLocationCityText.getText();
        String expectedAccountLocationCity = leadData.get("Primary City");
        String actualAccountLocationState = accountLocationStateText.getText();
        String expectedAccountLocationState = leadData.get("Primary State");
        String actualAccountLocationPostalCode = accountLocationPostalCodeText.getText();
        String expectedAccountLocationPostalCode = leadData.get("Primary Zip/Postal Code");

        loggerManager.getLogger().info("Validating the Account Location name and address");
        Allure.step("Validate that the Account Location name and address is updated correctly", step-> {
            softAssert.assertEquals(actualAccountLocation, expectedAccountLocation, "Account Location Name not updated correctly");
            softAssert.assertEquals(actualAccountLocationCountry, expectedAccountLocationCountry, "Account Location Country not updated correctly");
            softAssert.assertEquals(actualAccountLocationStreet1, expectedAccountLocationStreet1, "Account Location Street1 not updated correctly");
            softAssert.assertEquals(actualAccountLocationCity, expectedAccountLocationCity, "Account Location City not updated correctly");
            softAssert.assertEquals(actualAccountLocationState, expectedAccountLocationState, "Account Location State not updated correctly");
            softAssert.assertEquals(actualAccountLocationPostalCode, expectedAccountLocationPostalCode, "Account Location Postal Code not updated correctly");
        });
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the Account Phone after Lead Conversion.
     *
     * @param object String - The object for which the state is to be verified.
     * @param beforeConversionPhoneValue String - The state value before Lead Conversion.
     * @param afterConversionPhoneValue String - The state value after Lead Conversion.
     */
    @Step("Compare Phone Before and After Lead Conversion")
    public void comparePhoneBeforeAndAfterLeadConversion(String object, String beforeConversionPhoneValue, String afterConversionPhoneValue){
        loggerManager.getLogger().info(object + " Phone before conversion: " + beforeConversionPhoneValue);
        loggerManager.getLogger().info(object + " Phone after conversion: " + afterConversionPhoneValue);
        Allure.step("Validate that " + object + " phone should not be updated for Existing " + object + " used for Lead Conversion", step -> {
            Assert.assertEquals(beforeConversionPhoneValue, afterConversionPhoneValue, object + " Phone is updated on Existing " + object + " used for Lead Conversion");
            loggerManager.getLogger().info(object + " Phone is the same before and after Lead Conversion with Existing " + object);
        });
    }

    /**
     * This method checks if the Account Address State is populated and updates the Account Address with blank State.
     */
    @Step("Update Account Address if state is populated")
    public void clearAccountStateIfPopopulated(){
        if(getAccountAddressDetails().get("State") != ""){
            updateAddressOnAccountWithNoState();
        }
    }

    /**
     * This method updates the Account Address with blank State on the Account.
     */
    @Step("Add Account Address with blank State on the Account")
    public void updateAddressOnAccountWithNoState(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));

        waitForElementToBePresent(driver, editRightPanelButton);
        waitForElementToBeVisible(driver, driver.findElement(editRightPanelButton));
        elementClick(driver, driver.findElement(editRightPanelButton));

        waitForElementToBeVisible(driver, primaryCountryPicklistOnAccount);
        scrollToElement(driver, primaryCountryPicklistOnAccount);
        elementClickByJS(driver, primaryCountryPicklistOnAccount);
        elementClick(driver, driver.findElement(primaryCountryPicklistOptionOnAccount("United Kingdom")));
        sendKeysTypeAheadField(addressSuggestionTextFieldOnAccount, "Flat A-B 12 Churchfield Road");
        elementClickByJS(driver, addressSuggestionOptionOnAccount);
        takeScreenshot(TCName, driver);
        reusableBusinessLibrary.clickSaveBtn();
        if(isElementDisplayed(driver, skipValidationButton))
            elementClick(driver, skipValidationButton);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForUrlToContain(driver, "/view");
        waitForElementToBeVisible(driver, showMoreActionsButton);
        waitForElementToBeClickable(driver, showMoreActionsButton);
        Allure.step("Validate that Account Address with blank State is saved", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Account Address not saved");
            loggerManager.getLogger().info("Account Address with blank State is saved successfully");
        });
        waitForElementToBeVisible(driver, detailsTab);
        elementClick(driver, detailsTab);
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 900);");
        scrollToElement(driver, rdcCustomerSuccessSegmentLabelOnAccount);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the Account State is not updated after Lead Conversion when blank.
     */
    @Step("Verify that Account State is not updated after Lead Conversion when blank")
    public void verifyAccountStatePostLeadConv() {
        Allure.step("Validate that Account State is not updated after Lead Conversion when blank", step -> {
            Assert.assertNull(getAccountAddressDetails().get("Primary State"), "Account State is updated after Lead Conversion");
            loggerManager.getLogger().info("Account State is not updated after Lead Conversion when blank");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method converts a lead to an opportunity in Salesforce (SFDC).
     * It first clicks on the "Show More Actions" button, then clicks on the "Convert" button.
     * After a brief pause, it clicks on the "Lead Convert" button.
     * It then verifies the account, contact, and opportunity records.
     * @param leadName String - The name of the lead to be converted.
     */
    @Step("Convert Lead to Opportunity in SFDC")
    public void convertLeadToOpportunity(String leadName) {
        leadPage.performLeadConversion();

        //Verify Account
        loggerManager.getLogger().info("Opening Account " + companyText);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Accounts", companyText);
        takeScreenshot(TCName, driver);
        //Open Contact
        loggerManager.getLogger().info("Opening Contact " + leadName);
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Contacts", leadName);
        takeScreenshot(TCName, driver);

        //Open Opportunity
        loggerManager.getLogger().info("Opening Opportunity " + companyText );
        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Opportunities", companyText+ "-");

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
            wait.until(ExpectedConditions.titleIs(companyText + "- | Opportunity | Salesforce"));
            Allure.step("Validate that Converted Opportunity " + companyText + " is opened successfully", step-> {
                Assert.assertEquals(driver.getTitle(), companyText + "- | Opportunity | Salesforce", "Failed to open Converted Opportunity " + companyText + "-");
                loggerManager.getLogger().info("Converted Opportunity " + companyText + "- is opened successfully");
            });

        }
        catch (NoSuchElementException | TimeoutException e){
            loggerManager.getLogger().error("Failed to open Converted Opportunity " + companyText + "-");
        }

    }

    //This method unlink account from orbis if it's already linked and validate availability of linkage, just validate availability of linkage for unlink account.
    public void unlinkAccountfromOrbisValidateLinkage() {
        waitForPageToLoad(Duration.ofSeconds(60));

        // Check if bvd_connectorStatusComponent is displayed
        if (isElementDisplayed(driver, bvd_connectorStatusComponent)) {
            // Check if unlinkAccountIcon exists and click on it
            if (isElementDisplayed(driver, unlinkAccountIcon)) {
                elementClickByJS(driver,unlinkAccountIcon);
                waitForPageToLoad(Duration.ofSeconds(60));
                elementClickByJS(driver,unlinkAccountButton);
                loggerManager.getLogger().info("Clicked on Unlink Account Button");

            }
            waitForElementToBeVisible(driver, accountDetailsTab);
            // Navigate to accountDetailsTab and then accountDetailsDetailsTab
            if (isElementDisplayed(driver, accountDetailsTab)) {
                loggerManager.getLogger().info("Navigating to Account Details Tab");
                elementClickByJS(driver,accountDetailsTab);
                waitForPageToLoad(Duration.ofSeconds(60));
            }
            waitForPageToLoad(Duration.ofSeconds(60));
            if (isElementDisplayed(driver, accountDetailsDetailsTab)) {
                loggerManager.getLogger().info("Navigating to Account Details Details Tab");
                elementClickByJS(driver,accountDetailsDetailsTab);
                waitForPageToLoad(Duration.ofSeconds(60));
            }
            waitForPageToLoad(Duration.ofSeconds(60));
            elementClickByJS(driver,orbisMatchingToolTab);
            waitForPageToLoad(Duration.ofSeconds(60));
            // If orbisCompanyMatchingTable is displayed, assert orbisMatchTool_LinkCompany exists
            if (isElementDisplayed(driver, orbisCompanyMatchingTable)) {
                // Refresh the page and renavigate to accountDetailsTab and accountDetailsDetailsTab, this is due to Orbis match component doesn't load sometimes.
                pageRefresh(driver);
                waitForPageToLoad(Duration.ofSeconds(60));

                // Navigate to accountDetailsTab and then accountDetailsDetailsTab
                if (isElementDisplayed(driver, accountDetailsTab)) {
                    elementClickByJS(driver, accountDetailsTab);
                    waitForPageToLoad(Duration.ofSeconds(60));
                }
                if (isElementDisplayed(driver, accountDetailsDetailsTab)) {
                    elementClickByJS(driver, accountDetailsDetailsTab);
                    waitForPageToLoad(Duration.ofSeconds(60));
                    loggerManager.getLogger().info("Navigating to Account Details Details Tab");
                }
                waitForPageToLoad(Duration.ofSeconds(60));
                elementClickByJS(driver,orbisMatchingToolTab);
                if (!isElementDisplayed(driver, orbisMatchTool_LinkCompany)) {
                    Allure.step("orbisMatchTool_LinkCompany does not exist after unlinking account", step -> {
                        softAssert.fail("orbisMatchTool_LinkCompany does not exist after unlinking account");
                        takeScreenshot("orbisMatchTool_LinkCompany does not exist after unlinking account", driver);
                        loggerManager.getLogger().error("orbisMatchTool_LinkCompany does not exist after unlinking account");
                    });
                }
                else {
                    Allure.step("orbisMatchTool_LinkCompany exists after unlinking account", step -> {
                        softAssert.assertTrue(isElementDisplayed(driver, orbisMatchTool_LinkCompany), "orbisMatchTool_LinkCompany exists after unlinking account");
                        takeScreenshot("orbisMatchTool_LinkCompany exists after unlinking account", driver);
                        loggerManager.getLogger().info("orbisMatchTool_LinkCompany exists after unlinking account");
                    });
                }
            }
        } else {
            //Already unlinked account scenario
            // Navigate to accountDetailsTab and then accountDetailsDetailsTab
            elementClickByJS(driver,accountDetailsTab);
            waitForPageToLoad(Duration.ofSeconds(60));
            accountDetailsDetailsTab.click();
            waitForPageToLoad(Duration.ofSeconds(60));
            elementClickByJS(driver,orbisMatchingToolTab);
            waitForPageToLoad(Duration.ofSeconds(60));
            // If orbisCompanyMatchingTable is displayed, assert orbisMatchTool_LinkCompany exists
            if (isElementDisplayed(driver, orbisCompanyMatchingTable)) {
                if (!isElementDisplayed(driver, orbisMatchTool_LinkCompany)) {
                    Allure.step("orbisMatchTool_LinkCompany does not exist", step -> {
                        Assert.fail("orbisMatchTool_LinkCompany does not exist");
                        takeScreenshot("orbisMatchTool_LinkCompany does not exist", driver);
                        loggerManager.getLogger().error("orbisMatchTool_LinkCompany does not exist");
                    });
                }
                else {
                    Allure.step("orbisMatchTool_LinkCompany exists", step -> {
                        softAssert.assertTrue(isElementDisplayed(driver, orbisMatchTool_LinkCompany), "orbisMatchTool_LinkCompany exists");
                        takeScreenshot("orbisMatchTool_LinkCompany exists", driver);
                        loggerManager.getLogger().info("orbisMatchTool_LinkCompany exists");
                    });
                }
            }
            else {
                Allure.step("Orbis matching table does not exist", step -> {
                    Assert.fail("Orbis matching table does not exist");
                    takeScreenshot("Orbis matching table does not exist", driver);
                    loggerManager.getLogger().error("Orbis matching table does not exist");
                });
            }
        }
        softAssert.assertAll();
    }

    //This method link account from orbis if it's not linked already.
    public void linkAccountfromOrbisifNotLinkedAlready() {
        waitForPageToLoad(Duration.ofSeconds(60));
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        waitForElementToBeClickable(driver,bvd_connectorStatusComponent);
        // Check if bvd_connectorStatusComponent is displayed
        if (isElementDisplayed(driver, bvd_connectorStatusComponent)) {
            Allure.step("Account is already linked to Orbis", step -> {
                softAssert.assertTrue(isElementDisplayed(driver, bvd_connectorStatusComponent), "Account is already linked to Orbis");
                takeScreenshot("Account is already linked to Orbis", driver);
                loggerManager.getLogger().info("Account is already linked to Orbis");
            });
        } else {
            // Navigate to accountDetailsTab and then accountDetailsDetailsTab
            waitForPageToLoad(Duration.ofSeconds(60));
            // Navigate to accountDetailsTab and then accountDetailsDetailsTab
            if (isElementDisplayed(driver, accountDetailsTab)) {
                elementClickByJS(driver, accountDetailsTab);
                waitForPageToLoad(Duration.ofSeconds(60));
            }
            if (isElementDisplayed(driver, accountDetailsDetailsTab)) {
                elementClickByJS(driver, accountDetailsDetailsTab);
                waitForPageToLoad(Duration.ofSeconds(60));
            }
            elementClickByJS(driver,orbisMatchingToolTab);
            waitForPageToLoad(Duration.ofSeconds(60));
            if (!isElementDisplayed(driver, orbisMatchTool_LinkCompany)) {
                Allure.step("orbisMatchTool_LinkCompany does not exist to link account", step -> {
                    Assert.fail("orbisMatchTool_LinkCompany does not exist to link account");
                    takeScreenshot("orbisMatchTool_LinkCompany does not exist to link account", driver);
                    loggerManager.getLogger().error("orbisMatchTool_LinkCompany does not exist to link account");
                });
            } else {
                elementClickByJS(driver, orbisMatchTool_LinkCompany);
                if (isElementDisplayed(driver, bvdSuccessLinkageToast)) {
                    Allure.step("Account linked to Orbis successfully", step -> {
                        softAssert.assertTrue(isElementDisplayed(driver, bvdSuccessLinkageToast), "Account linked to Orbis successfully");
                        takeScreenshot("Account linked to Orbis successfully", driver);
                        loggerManager.getLogger().info("Account linked to Orbis successfully");
                    });
                }

            }
        }
        softAssert.assertAll();
    }
    //This method verify accessibility of Hierarchy and Reports for orbis linked account.
    public void verifyOrbisHierarchyReportsAccessibility() {
        verifyBvdIDExist();
        //include steps for hierarchy navigation, validate component and come back
        if (isElementDisplayed(driver, hierarchyIcon)) {
            elementClickByJS(driver, hierarchyIcon);
            waitForPageToLoad(Duration.ofSeconds(60));

            Allure.step("Verify hierarchy component populated", () -> {
                if (isElementDisplayed(driver, hierarchyContainer)) {
                    softAssert.assertTrue(isElementDisplayed(driver, hierarchyContainer), "Hierarchy component found");
                    takeScreenshot("Hierarchy component found", driver);
                    loggerManager.getLogger().info("Hierarchy component found");
                } else {
                    softAssert.fail("Unable to find hierarchy component");
                    takeScreenshot("Unable to find hierarchy component", driver);
                    loggerManager.getLogger().error("Unable to find hierarchy component");
                }
            });
            elementClickByJS(driver, hierarchyBacktoRecordBtn);
            waitForPageToLoad(Duration.ofSeconds(60));
        } else {
            Allure.step("Hierarchy icon not found", () -> {
                Assert.fail("Hierarchy icon not found");
                takeScreenshot("Hierarchy icon not found", driver);
                loggerManager.getLogger().error("Hierarchy icon not found");
            });
        }
        //include steps for report navigation and validate report component , logout
        if (isElementDisplayed(driver, reportIcon)) {
            elementClickByJS(driver, reportIcon);
            waitForPageToLoad(Duration.ofSeconds(60));
            Allure.step("Verify orbis account reports detail populated", () -> {
                if (isElementDisplayed(driver, homePage.orbisAccountiframe)) {
                    softAssert.assertTrue(isElementDisplayed(driver, homePage.orbisAccountiframe), "Orbis report component found");
                    takeScreenshot("Orbis report component found", driver);
                    loggerManager.getLogger().info("Orbis report component found");
                } else {
                    softAssert.fail("Unable to find orbis report component");
                    takeScreenshot("Unable to find orbis report component", driver);
                    loggerManager.getLogger().error("Unable to find orbis report component");
                }
            });
        } else {
            Allure.step("Report icon not found", () -> {
                Assert.fail("Report icon not found");
                takeScreenshot("Report icon not found", driver);
                loggerManager.getLogger().error("Report icon not found");
            });
        }
        softAssert.assertAll();
    }

    //This method access orbis account and validate orbis panel
    public void accessOrbisSFDCAccount_ValidateOrbisPanel() {
        if (isElementDisplayed(driver, orbisImportedAccountelement_global)) {
            loggerManager.getLogger().info("orbis Imported Account element is displayed");
            takeScreenshot("orbis Imported Account element is displayed", driver);
            elementClickByJS(driver, orbisImportedAccountelement_global);
            waitForPageToLoad(Duration.ofSeconds(60));
            driver.switchTo().window(driver.getWindowHandles().toArray()[1].toString());
            waitForElementToBeClickable(driver, bvd_connectorStatusComponent);

            Allure.step("Verify that Orbis component panel exists", () -> {
                if (isElementDisplayed(driver, bvd_connectorStatusComponent)) {
                    softAssert.assertTrue(isElementDisplayed(driver, bvd_connectorStatusComponent), "Orbis component panel exists");
                    takeScreenshot("Orbis component panel exists", driver);
                    loggerManager.getLogger().info("Orbis component panel exists");
                } else {
                    softAssert.fail("Orbis component panel does not exist");
                    takeScreenshot("Orbis component panel does not exist", driver);
                    loggerManager.getLogger().error("Orbis component panel does not exist");
                }
            });
        } else {
            Allure.step("Orbis import account element is not displayed", () -> {
                Assert.fail("Orbis import account element is not displayed");
                takeScreenshot("Orbis import account element is not displayed", driver);
                loggerManager.getLogger().error("Orbis import account element is not displayed");
            });
        }
        softAssert.assertAll();
    }

    //Verify absence of unlink account from orbis, in use when certain user do not have permission to unlink account.
    public void verifyAbsenceofUnlinkAccountfromOrbis() {
    waitForPageToLoad(Duration.ofSeconds(60));
    Allure.step("Verify absence of unlink account icon from Orbis", () -> {
        if (isElementDisplayed(driver, unlinkAccountIcon)) {
            takeScreenshot("unlink account icon is displayed", driver);
            Assert.fail("unlink account icon is displayed");
            loggerManager.getLogger().error("Unlink account icon is displayed");
        } else {
            takeScreenshot("unlink accountIcon is not displayed", driver);
            softAssert.assertTrue(true, "unlinkAccountIcon is not displayed");
            loggerManager.getLogger().info("unlink account icon is not displayed");
        }
    });
    softAssert.assertAll();
}
    //Return status of account linked to orbis
    public boolean isAccountLinktoOrbis() {
        try {
            Thread.sleep(10000);
            waitForPageToLoad(Duration.ofSeconds(360));
            waitForElementToBeClickable(driver, bvd_connectorStatusComponent);
            boolean isDisplayed = isElementDisplayed(driver, bvd_connectorStatusComponent);
            if (isDisplayed) {
                loggerManager.getLogger().info("Account is linked to Orbis");
                takeScreenshot("Account is linked to Orbis", driver);
            }
            return isDisplayed;
        } catch (Exception e) {
            loggerManager.getLogger().info("Account is not linked to Orbis");
            takeScreenshot("Account is not linked to Orbis", driver);
            return false;
        }
    }

    //Verify BvD id exist and match
    public void verifyBvdIDExist() {

        // Refresh the page and renavigate to accountDetailsTab and accountDetailsDetailsTab, this is due to Orbis match component doesn't load sometimes.
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(60));

        // Navigate to accountDetailsTab and then accountDetailsDetailsTab
        if (isElementDisplayed(driver, accountDetailsTab)) {
            elementClickByJS(driver, accountDetailsTab);
            waitForPageToLoad(Duration.ofSeconds(60));
        }
        if (isElementDisplayed(driver, accountDetailsDetailsTab)) {
            elementClickByJS(driver, accountDetailsDetailsTab);
            waitForPageToLoad(Duration.ofSeconds(60));
        }
        waitForPageToLoad(Duration.ofSeconds(60));
        if (isElementDisplayed(driver,BvDId))   {
            moveToElement(driver, BvDId);
            Allure.step("BvD Id exists", step -> {
                softAssert.assertEquals(BvDId.getText(),readExcelData(accountsFilePath,TCName,"BvdID"), "BvD Id matches");
                takeScreenshot("BvD Id exists", driver);
                loggerManager.getLogger().info("BvD Id exists");
            });
        }
        else{
            Allure.step("BvD Id does not match", step -> {
                softAssert.fail("BvD Id does not match");
                takeScreenshot("BvD Id does not match", driver);
                loggerManager.getLogger().error("BvD Id does not match");
            });
        }
    }

    //Verify orbis component does not exist.
    public void verifyOrbisComponentdoesnotExist() {
        waitForPageToLoad(Duration.ofSeconds(60));

        Allure.step("Verify that Orbis component is not displayed", () -> {
            if (isElementDisplayed(driver, bvd_connectorStatusComponent)) {
                takeScreenshot("Orbis component is still displayed after unlink account", driver);
                Assert.fail("Orbis component is still displayed after unlink account");
                loggerManager.getLogger().error("Orbis component is still displayed after unlink account");
            } else {
                takeScreenshot("Orbis component is not displayed", driver);
                Assert.assertTrue(true, "Orbis component is not displayed is not displayed");
                loggerManager.getLogger().info("Orbis component is not displayed");
            }
        });
    }
    //This method update SFDC account with information from Orbis.
    public void updateSFDCAccountwithOrbisInfo() {
        waitForPageToLoad(Duration.ofSeconds(60));
        // Update phone number detail on Account
        Allure.step("Check if account edit button is displayed", () -> {
            if (isElementDisplayed(driver, account_editButton)) {
                account_editButton.click();
                waitForElementToBeVisible(driver, accountEdit_phone);
                // Update the phone number by changing the last digit randomly
                String currentPhone = accountEdit_phone.getAttribute("value");
                String newPhone = currentPhone.substring(0, currentPhone.length() - 1) + (int)(Math.random() * 10);
                accountEdit_phone.clear();
                accountEdit_phone.sendKeys(newPhone);
                accountEdit_saveButton.click();
                // Check if success toast is displayed
                if (isElementDisplayed(driver, recordSavedToast)) {
                    Allure.step("Account record updated successfully", step -> {
                        softAssert.assertTrue(isElementDisplayed(driver, recordSavedToast), "Account record updated successfully");
                        takeScreenshot("Account record updated successfully", driver);
                        loggerManager.getLogger().info("Account record updated successfully");
                    });
                }
                waitForPageToLoad(Duration.ofSeconds(60));
                // Check if update icon is displayed
                if (isElementDisplayed(driver, updateIcon_OrbisComponent)) {
                    updateIcon_OrbisComponent.click();
                    waitForPageToLoad(Duration.ofSeconds(60));
                    takeScreenshot("Update icon clicked", driver);
                    elementClickByJS(driver, selectAllLnk_Orbis);
                    elementClickByJS(driver, mergeRecordsBtn_Orbis);
                    waitForPageToLoad(Duration.ofSeconds(60));
                    waitForElementToBeVisible(driver, approvalIcon_OrbisComponent);

                    Allure.step("Verify account record update completion", () -> {
                        if (isElementDisplayed(driver, approvalIcon_OrbisComponent)) {
                            loggerManager.getLogger().info("Orbis component shows account up to date, completed successfully");
                            softAssert.assertTrue(isElementDisplayed(driver, approvalIcon_OrbisComponent), "Orbis component shows account up to date, completed successfully");
                            takeScreenshot("Orbis component shows account up to date, completed successfully", driver);
                        } else if (isElementDisplayed(driver, updateIcon_OrbisComponent)) {
                            loggerManager.getLogger().error("Update icon still displayed after account record update.");
                            Assert.fail("Update icon still displayed after account record update");
                            takeScreenshot("Update icon still displayed after account record update", driver);
                        }
                    });
                } else {
                    Allure.step("Update button is not displayed on Orbis components", step -> {
                        Assert.fail("Update button is not displayed on Orbis components");
                        loggerManager.getLogger().error("Update button is not displayed on Orbis components");
                    });
                }
            } else {
                loggerManager.getLogger().error("User is unable to edit account detail");
                takeScreenshot("User is unable to edit account detail", driver);
                softAssert.fail("User is unable to edit account detail");
            }
        });
        softAssert.assertAll();
    }
    /**
     * This method navigates to an account page using the provided Salesforce (SFDC) ID.
     * It first opens the record by its SFDC ID.
     * Then, it waits for the details tab on the account page to be visible.
     * Finally, it clicks on the details tab and takes a screenshot of the account page.
     *
     * @param RecordID String - The Salesforce (SFDC) ID of the account to navigate to.
     */
    @Step("Navigate to account record with SFDC ID")
    public void navigateToAccountPageWithRecordId(String RecordID){
        ReusableBusinessLibrary.openRecordBySFDCID(RecordID);
        waitForElementToBeVisible(driver, detailsTabOnAccount);
        elementClick(driver, detailsTabOnAccount);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method retrieves and stores the account details required for creating a contact.
     * It performs the following steps:
     * 1. Waits for the account name to be visible on the header.
     * 2. Writes the account name and business type to an Excel file.
     * 3. Scrolls to the alternate character section and writes the phone number to the Excel file.
     * 4. Retrieves the account address details and writes them to the Excel file.
     * 5. Logs the successful storage of account details in the Excel file.
     */
    @Step("Store the Account Details(Business Type, Phone & Address details) in Excel.")
    public void getAccountDetailsForValidation(){
        waitForElementToBeVisible(driver, accountNameOnHeader);

        writeToExcel(contactsFilePath, TCName, "Account Name", accountNameOnHeader.getText());
        writeToExcel(contactsFilePath, TCName, "Business Type", businessTypeText.getText());

        scrollToElement(driver, altCharacterSection);
        switch (TCName){
            case "createContactFromAccount_BusinessAdmin":
                waitForElementToBeVisible(driver,accountPhoneValue_nonHyperlink);
                writeToExcel(contactsFilePath, TCName, "Phone", accountPhoneValue_nonHyperlink.getText());
                break;
            case "createContactFromAccount_SalesRep":
            case "createContactFromAccount_OperationalAnalyst":
            case "createContactFromAccount_DataManagement":
                waitForElementToBeVisible(driver,accountPhoneValue);
                writeToExcel(contactsFilePath, TCName, "Phone", accountPhoneValue.getText());
                break;
            default:
                loggerManager.getLogger().info("TCName does not exist for Account Phone number capture");
        }
        LinkedHashMap<String, String> addressDetails = getAccountAddressDetails();
        writeToExcel(contactsFilePath, TCName, "Primary Country", addressDetails.get("Country"));
        writeToExcel(contactsFilePath, TCName, "Primary Street 1", addressDetails.get("Street 1"));
        writeToExcel(contactsFilePath, TCName, "Primary City", addressDetails.get("City"));
        writeToExcel(contactsFilePath, TCName, "Primary State", addressDetails.get("State"));
        writeToExcel(contactsFilePath, TCName, "Primary Zip/Postal Code", addressDetails.get("Postal Code"));

        loggerManager.getLogger().info("Business Type, Phone & Address Details on Account record are stored in Excel successfully");
        ReusableLibrary.scrollToTop(driver);
    }

    /**
     * This method navigates to the Contact tab and clicks on the New button.
     * It then waits for the new contact frame to be visible and switches to the iframe.
     * Finally, it logs the successful navigation to the new contact screen from the account.
     */
    @Step("Navigate to Contact tab and click on New button from Account Sub Tabs.")
    public void clickOnContactSubTabFromAccountPage(){
        elementClick(driver, contactsTab);
        waitForElementToBeVisible(driver, newContactButton);
        Allure.step("Navigated to contact Tab.", step -> {
            loggerManager.getLogger().info("Contact tab opened successfully.");
            ReusableLibrary.takeScreenshot("ContactTab", driver);
        });

        elementClick(driver, newContactButton);
        try {
            waitForElementToBePresent(driver, nextBtnOnNewContact);
            waitForElementToBeVisible(driver, driver.findElement(nextBtnOnNewContact));
            elementClick(driver, driver.findElement(nextBtnOnNewContact));
        } catch (Exception e) {
            loggerManager.getLogger().warn("Next button not found, proceeding to check for new contact frame.");
        }
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        Allure.step("Navigated to new contact screen from Account", step -> {
            loggerManager.getLogger().info("User Navigated to New Contact screen from Account");
            ReusableLibrary.takeScreenshot(TCName, driver);
        });
        loggerManager.getLogger().info("User Navigated to New Contact screen from Account");
    }

    /**
     * This method navigates to the Agreements tab on the Account record page.
     * Steps:
     * 1. Clicks on the Agreements tab.
     * 2. Waits for the "New Legal Contracting Entity" button to be visible.
     * 3. Checks if the "In Progress Agreements" list is displayed.
     */
    @Step("Click agreements button under account record page")
    public void navigateToAgreementsTabOnAccount() {

        elementClick(driver, agreementsTabOnAccount);
        waitForElementToBeVisible(driver, newLegalContractingEntityBtnUnderAgreementsTab);
        //if this element is not displayed then write a fail logger message
        if(!isElementDisplayed(driver, inProgressAgreementsList)){
            loggerManager.getLogger().error("Not able to click new legal contracting entity button");
        }
        Assert.assertTrue(isElementDisplayed(driver, inProgressAgreementsList), "Not able to navigate to agreements tab");
        loggerManager.getLogger().info("Navigated to Agreements Tab successfully");
        takeScreenshot("navigateToAgreementsTabOnAccount",driver);

    }
    /**
     * This method clicks the "New Legal Contracting Entity" button under the Agreements tab on the Account record page.
     */
    @Step("Click new legal contracting entity Button Under Agreement Tab on Account Record")
    public void clickNewLegalContractingEntity() {
        try{
            elementClick(driver,newLegalContractingEntityBtnUnderAgreementsTab);
            waitForElementToBeVisible(driver, legalContractingEntityText);
            pageRefresh(driver);
            waitForElementToBeVisible(driver, legalContractingEntityText);
            Assert.assertTrue(isElementDisplayed(driver,legalContractingEntityText), "Not able to click new legal contracting entity button");
            loggerManager.getLogger().info("Clicked new legal contracting entity button successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Not able to click new legal contracting entity button");
        }
        takeScreenshot("clickNewLegalContractingEntity",driver);
    }
    /**
     * This method fills out the mandatory fields required to add a legal contracting entity as an agreement under an account record.
     * Steps:
     * 1. Generates a unique name for the legal contracting entity by appending a random string to the base name retrieved from the `accountData` map.
     * 2. Inputs the generated name into the `legalContractingEntityNameTextField`.
     * 3. Selects the country from the `primaryCountryPicklistOnLegalContractingEntity` dropdown based on the value provided in the `accountData` map.
     * 4. Clicks on the state picklist and verifies that the desired state option is available. If available, it selects the state from the `primaryStatePicklistOnLegalContractingEntity`.
     * 5. Inputs the street, city, and postal code into their respective fields using the values from the `accountData` map.
     */
    @Step("Enter mandatory fields to add legal contracting entity as an agreement under Account record")
    public void filloutLegalContractingEntityMandatoryFields(LinkedHashMap<String, String> accountData)
    {
        try{
            String legalContractingEntityName = accountData.get("Legal Contracting Entity Name") + generateRandomString("_Auto");
            legalContractingEntityNameTextField.sendKeys(legalContractingEntityName);
            selectByValue(driver, primaryCountryPicklistOnLegalContractingEntity, accountData.get("Legal Contracting Entity Country"));
            elementClick(driver, primaryStatePicklistOnLegalContractingEntity);
            waitForElementToBePresent(driver, primaryStatePicklistOnLegalContractingEntityOption(accountData.get("Legal Contracting Entity State")));
            Allure.step("Validate that the desired state is displayed in the state picklist", step -> {
                Assert.assertTrue(isElementPresent(driver, primaryStatePicklistOnLegalContractingEntityOption(accountData.get("Legal Contracting Entity State"))),
                        "The" + accountData.get("Legal Contracting Entity State") + " option is not available in the picklist");
                loggerManager.getLogger().info("The option for Primary State is present in the dropdown");

            });
            elementClickByJS(driver, driver.findElement(primaryStatePicklistOnLegalContractingEntityOption(accountData.get("Legal Contracting Entity State"))));
            sendKeysToElement(driver, primaryStreetTextFieldOnLegalContractingEntity, accountData.get("Legal Contracting Entity Street"));
            sendKeysToElement(driver, primaryCityTextFieldnLegalContractingEntity, accountData.get("Legal Contracting Entity City"));
            sendKeysToElement(driver, primaryZipcodeTextFieldOnLegalContractingEntity, accountData.get("Legal Contracting Entity Zipcode"));
        }
        catch (Exception e){
            loggerManager.getLogger().error("Not able to fill out legal contracting entity mandatory fields");
        }
        takeScreenshot("filloutLegalContractingEntityMandatoryFields",driver);
    }
    /**
     * This method saves the legal contracting entity under the Agreements tab on the Account record.
     * Steps:
     * 1. Clicks the "Save" button for the legal contracting entity.
     * 2. Clicks the address validation confirmation button.
     * 3. Waits for the Agreements tab to be visible.
     */
    @Step("Save Legal Contracting Entity under Agreements Tab on Account record")
    public void saveLegalContractingEntity() {
        try{
            elementClick(driver, saveButtonOnLegalContractingEntity);
            waitForElementToBeVisible(driver, reusableBusinessLibrary.addressValidationConfirmButton);
            elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
            waitForElementToBeVisible(driver, agreementsTabOnAccount);
            Assert.assertTrue(isElementDisplayed(driver,agreementsTabOnAccount), "Not able to save Legal Contracting Entity");
            loggerManager.getLogger().info("Successfully saved Legal Contracting Entity");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Not able to save Legal Contracting Entity");
        }
        takeScreenshot("saveLegalContractingEntity", driver);
    }
    /**
     * This method verifies that the Legal Contracting Entities list exists under the Agreements tab on the Account page.
     */
    @Step("Verify that Legal Contracting Entities List Exists Under Agreements Tab on Account Page")
    public void verifyLegalContractingEntitiesList() {

        try{
            Assert.assertTrue(isElementDisplayed(driver,legalContractingEntityList), "Legal Contracting Entity List is not displayed");
            loggerManager.getLogger().info("Legal Contracting Entity List is displayed");
        }
        catch(Exception e){
            Assert.fail("Legal Contracting Entity List is not displayed");
            loggerManager.getLogger().error("Legal Contracting Entity List is not displayed");
        }
        takeScreenshot("verifyLegalContractingEntitiesList",driver);
    }

    /**
     * This method creates a new Standard Account record with mandatory fields in Salesforce (SFDC).
     */
    @Step("Create a new Standard Account record with mandatory fields using Save button")
    public void createStandardAccountWithSaveButton(LinkedHashMap<String, String> accountData) {
        selectAccountRecordType("Standard Account");
        enterAccountNameAndBusinessType(accountData);
        scrollToElement(driver, driver.findElement(accountTextField("GUO Id")));
        enterAddressDetailsOnAccount(accountData);
        saveAccount();
        Allure.step("Validate that Standard Account is created with mandatory fields", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to create Standard Account with mandatory fields");
            loggerManager.getLogger().info("Standard Account created with mandatory fields successfully.");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method gets the Account ID from the URL and stores it in the AccountData Excel file.
     * @return String - The new Account ID.
     */
    @Step("Save the new Account ID in Excel")
    public String getAccountIDAndStoreInExcel(){
        waitForElementToBeVisible(driver, showMoreActionsButton);
        String newAccountID = getSFDCRecordIDFromURL(driver.getCurrentUrl());
        loggerManager.getLogger().info("SFDC Account ID: " + newAccountID);
        if(newAccountID != null) {
            Assert.assertNotNull(newAccountID, "Failed to get the SFDC Account ID");
            writeToExcel(accountsFilePath, TCName, "SFDC Account ID", newAccountID);
        }
        else {
            loggerManager.getLogger().error("Failed to get the SFDC Account ID");
            Assert.fail("Failed to get the SFDC Account ID");
        }
        return newAccountID;
    }

    @Step("Select Account Record Type as {recordType}")
    public void selectAccountRecordType(String recordType){
        reusableBusinessLibrary.clickNewBtn();
        waitForElementToBePresent(driver, accountRecordTypeRadioButton(recordType));
        elementClick(driver, driver.findElement(accountRecordTypeRadioButton(recordType)));
        waitForElementToBeVisible(driver, reusableBusinessLibrary.recordTypeSelectionNextButton);
        takeScreenshot(TCName, driver);
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();
        waitForUrlToContain(driver, "/Account/new?recordTypeId");
        Assert.assertTrue(driver.getCurrentUrl().contains("recordTypeId"), "Failed to select Account Record Type");
        loggerManager.getLogger().info("Selected Account Record Type as " + recordType);
        waitForElementToBePresent(driver, accountTextField("Account Name"));
        takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks on the "Details" tab on the Account page.
     * Steps:
     * 1. Waits for the "Details" tab to be visible.
     * 2. Clicks on the "Details" tab.
     * 3. Logs the successful click action.
     * 4. Handles any exceptions that occur during the process.
     */
    @Step("Click on Details Tab on Account Page")
    public void clickOnDetailsTabOnAccountPage() {
        try {
            waitForElementToBeVisible(driver, detailsTabOnAccount);
            elementClick(driver, detailsTabOnAccount);
            loggerManager.getLogger().info("Clicked on Details Tab on Account Page");
            takeScreenshot(TCName, driver);

        } catch (Exception e) {
            loggerManager.getLogger().error("Failed to click on Details Tab on Account Page");
            Assert.assertTrue(false, "Failed to click on Details Tab on Account Page");
        }
    }

    /**
     * This method navigates to the Account Team sub-tab from the Account page.
     * Steps:
     * 1. Clicks on the Account Team sub-tab.
     * 2. Clicks on the "Account Team" link to ensure all team members are visible.
     * 3. Refreshes the page to ensure the latest data is loaded.
     * 4. Waits for the "New Account Team Member" button to be visible.
     * 5. Logs the successful navigation to the Account Team tab.
     * 6. Handles any exceptions that occur during the process.
     */
    @Step("Click on Account Team Sub Tab from Account Page")
    public void clickOnTeamSubTabFromDetailsTabOnAccountPage(){
        try{
            waitForElementToBeVisible(driver, accountTeamSubTab);
            elementClick(driver, accountTeamSubTab);
            scrollToElement(driver,accountTeamHeader);
            elementClickByJS(driver, accountTeamsLink);
            pageRefresh(driver);
            waitForElementToBeVisible(driver, newAddTeamMembersButton);
            Allure.step("Navigated to Account Team Tab.", step -> {
                loggerManager.getLogger().info("Account Team tab opened successfully.");
                ReusableLibrary.takeScreenshot(TCName, driver);
            });
            loggerManager.getLogger().info("Navigated to Account Team Tab successfully");

        }catch (Exception e){
            loggerManager.getLogger().error("Failed to navigate to Account Team Tab");
            Assert.assertTrue(false, "Failed to navigate to Account Team Tab");
        }

    }

    /**
     * This method clicks the "New Add Team Member" button on the Account Team sub-tab.
     * Steps:
     * 1. Clicks on the "New Add Team Member" button.
     * 2. Logs the successful click action.
     * 3. Takes a screenshot for documentation.
     * 4. Handles any exceptions that occur during the process.
     */
    @Step("Click on New Add Team Member Button")
    public void clickOnNewAddTeamMemberButton(){
        try{
            elementClick(driver, newAddTeamMembersButton);
            waitForElementToBeVisible(driver, addTeamMemberUser);
            Allure.step("Clicked on New Add Team Member button.", step -> {
                loggerManager.getLogger().info("Clicked on New Add Team Member button successfully");
                ReusableLibrary.takeScreenshot(TCName, driver);
            });
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to click on New Add Team Member button");
            Assert.assertTrue(false, "Failed to click on New Add Team Member button");
        }
    }

    /**
     * This method adds and saves a new team member's details on the Account Team sub-tab.
     * Steps:
     * 1. Waits for the "Add Team Member User" button to be visible.
     * 2. Clicks on the "Add Team Member User" button.
     * 3. Reads the new team member's name from the Excel file.
     * 4. Enters the new team member's name.
     * 5. Clicks on the "Add Team Member Role" button.
     * 6. Selects the role from the dropdown.
     * 7. Clicks on the "Save" button to save the new team member's details.
     * 8. Logs the successful addition and saving of the new team member.
     * 9. Handles any exceptions that occur during the process.
     * 10. Waits for the Account Team page header to be visible.
     * 11. Takes a screenshot for documentation.
     */
    @Step("Add and Save New Team Member Details")
    public void addandSaveNewTeamMemberDetails(){
        try{
            waitForElementToBeVisible(driver, addTeamMemberUser);
            elementClick(driver, addTeamMemberUser);
            elementClick(driver, addTeamMemberUserSearchField);
            String newTeamMemberName = readExcelData(accountsFilePath, TCName, "New Team Member");
            sendKeysToElement(driver, addTeamMemberUserSearchField, newTeamMemberName);
            takeScreenshot(TCName, driver);
            elementClick(driver, addTeamMemberUserSearchFieldOption(newTeamMemberName));
            elementClick(driver, teamRoleHeader);
            elementClick(driver, addTeamMemberRole);
            waitForElementToBeClickable(driver, addTeamMemberRolePicklistOption(readExcelData(accountsFilePath, TCName, "Team Role")));
            elementClickByJS(driver, addTeamMemberRolePicklistOption(readExcelData(accountsFilePath, TCName, "Team Role")));
            takeScreenshot(TCName, driver);
            elementClick(driver, saveBtnOnTeamMember);
            loggerManager.getLogger().info("New Team Member Details are added and saved successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to add and save new team member details");
            Assert.assertTrue(false, "Failed to add and save new team member details");
        }
        waitForElementToBeVisible(driver, accountTeamMemberNameLink);
        takeScreenshot(TCName,driver);
    }

    /**
     * This method navigates to the Account Team Member Record page.
     * Steps:
     * 1. Waits for the Account Team page header to be visible.
     * 2. Refreshes the page to ensure the latest data is loaded.
     * 3. Reads the new team member's name from the Excel file.
     * 4. Clicks on the new team member's record to navigate to the details page.
     * 5. Logs the successful navigation to the Account Team Member Record page.
     * 6. Handles any exceptions that occur during the process.
     * 7. Takes a screenshot for documentation.
     */
    @Step("Navigate to Account Team Member Record Page")
    public void navigateToAccountTeamMemberRecord(){
        try{
            waitForElementToBeVisible(driver, accountTeamMemberNameLink);
            pageRefresh(driver);
            waitForElementToBeVisible(driver, accountTeamMemberNameLink);
            elementClickByJS(driver, accountTeamMemberNameLink);
            loggerManager.getLogger().info("Navigated to Account Team Member Record Page successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to navigate to Account Team Member Record Page");
            Assert.assertTrue(false, "Failed to navigate to Account Team Member Record Page");
        }
        waitForElementToBeVisible(driver, accountTeamMemberUserValue);
        takeScreenshot(TCName,driver);

    }

    /**
     * This method validates the details of a newly added Account Team Member.
     * Steps:
     * 1. Waits for the Account Team Member page header to be visible.
     * 2. Refreshes the page to ensure the latest data is loaded.
     * 3. Asserts that the new team member's name matches the expected value from the Excel file.
     * 4. Asserts that the team member's role matches the expected value from the Excel file.
     * 5. Logs the successful validation of the Account Team Member details.
     * 6. Handles any exceptions that occur during the process.
     */
    @Step("Verify Account Team Member Details ")
    public void validateAccountTeamMemberDetails(LinkedHashMap<String, String> accountData){
        try{
            waitForElementToBeVisible(driver, accountTeamMemberUserValue);
            pageRefresh(driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberUserValue), accountData.get("New Team Member"), "New Team Member or User Name is not displayed");
            softAssert.assertEquals(getElementText(driver,accountTeamMemberRoleValue), accountData.get("Team Role"), "Team Role is not displayed");
            softAssert.assertAll();
            loggerManager.getLogger().info("Account Team Member details are displayed successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Account Team Member details are not displayed");
            Assert.assertTrue(false, "Account Team Member details are not displayed");
        }
        takeScreenshot(TCName,driver);
    }

    /**
     * This method validates the value of the "Source" field on the Account Team Member page.
     * Steps:
     * 1. Waits for the "Source" field to be visible.
     * 2. Refreshes the page to ensure the latest data is loaded.
     * 3. Depending on the test case name (`TCName`), it performs specific validations.
     * 4. Checks if the "Source" field is displayed.
     * 5. Takes a screenshot for documentation.
     * 6. Asserts that the value of the "Source" field matches the expected value.
     * 7. Logs the successful validation of the "Source" field value.
     */
    @Step("Verify Source Field Value on Account Team Member Record Page")
    public void validateSourceFieldValueOnAccountTeamMember() {
        waitForElementToBeVisible(driver, sourceField);
        pageRefresh(driver);
        switch (TCName) {
            case "verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_SalesRep":
            case "verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_OperationAnalyst":
            case "verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_CustomerSuccessAccountDevelopmentSpecialist":
            case "verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_DataManagement":
            case "verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_BusinessAdmin":
                isElementDisplayed(driver, sourceField);
                takeScreenshot(TCName, driver);
                // hardcoded the expected values as these are static values and  are not going to change
                Assert.assertEquals(getElementText(driver, sourceFieldValue), "Manual", "Source Field Value is not as expected");
                loggerManager.getLogger().info("Source Field Value" + sourceFieldValue + "is validated successfully");
                break;
            case "verifyAccountTeamMemberCreationAndItsFieldsInfoValidation_SystemAdmin":
                isElementDisplayed(driver, sourceField);
                takeScreenshot(TCName, driver);
                // hardcoded the expected values as these are static values and  are not going to change
                Assert.assertEquals(getElementText(driver, sourceFieldValue), "Sales", "Source Field Value is not as expected");
                loggerManager.getLogger().info("Source Field Value" + sourceFieldValue + "is validated successfully");
                break;
            default :
                loggerManager.getLogger().error("TCName is not available as an option");

        }
    }

    /**
     * This method validates the default value of the "Team Member Active" field.
     * Steps:
     * 1. Waits for the Account Team Member Record header to be visible.
     * 2. Refreshes the page to ensure the latest data is loaded.
     * 3. Asserts that the "Team Member Active" field is displayed.
     * 4. Asserts that the default value of the "Team Member Active" field is as expected.
     * 5. Logs the results.
     * 6. Takes a screenshot for documentation.
     */
    @Step("Verify Team Member Active Field availability and its Default Value on Account Team Member Record Page")
    public void validateTeamMemberActiveFieldandItsDefaultValue(){
        try{
            pageRefresh(driver);
            scrollToElement(driver, teamMemberActiveField);
            waitForElementToBeVisible(driver, teamMemberActiveField);
            Assert.assertTrue(teamMemberActiveField.isDisplayed(), "Team Member Active Field is not available on Account Team Member Record Page");
            Assert.assertEquals(getElementText(driver,teamMemberActiveFieldValue), "Yes", "Default value of 'Team Member Active' field is not as expected");
            loggerManager.getLogger().info("'Team Member Active' Field is available on Account Team Member Record Page and its default value is validated successfully");
            takeScreenshot(TCName,driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to validate availability of 'Team Member Active' Field and its default value");
            Assert.assertTrue(false, "Failed to validate availability of 'Team Member Active' Field and its default value ");
        }
    }

    /**
     * This method validates the help text for various fields on the Account Team Member page.
     * Steps:
     * 1. Waits for the Account Team Member Record header to be visible.
     * 2. Waits for the "Crediting Manager" field to be visible and moves to it.
     * 3. Takes a screenshot and asserts that the help text for the "Crediting Manager" field matches the expected value.
     * 4. Repeats the process for the "Reporting Manager" and "Team Role" fields.
     * 5. Logs the results and handles any exceptions that occur during the process.
     */
    @Step("Verify Help Text for Account Team Member Fields")
    public void validateHelpTextForAccountTeamMemberFields(){
        try{
            waitForElementToBeVisible(driver, accountTeamMemberRecordHeader);
            waitForElementToBeVisible(driver,accountTeamMemberField("Crediting Manager"));
            moveToElement(driver,accountTeamMemberField("Crediting Manager"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Crediting Manager HelpText"), "Help Text for Crediting Manager Field is not as expected");
            moveToElement(driver,accountTeamMemberField("Reporting Manager"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Reporting Manager HelpText"), "Help Text for Reporting Manager Field is not as expected");
            moveToElement(driver,accountTeamMemberField("Team Role"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Team Role HelpText"), "Help Text for Team Role Field is not as expected");
            moveToElement(driver,accountTeamMemberField("Handler Role"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Handler Role HelpText"), "Help Text for Handler Role Field is not as expected");
            moveToElement(driver,accountTeamMemberField("Team Group"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Team Group HelpText"), "Help Text for Team Group Field is not as expected");
            moveToElement(driver,accountTeamMemberField("Team Territory"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Team Territory  HelpText"), "Help Text for Team Territory Field is not as expected");
            moveToElement(driver,accountTeamMemberField("Product"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Product HelpText"), "Help Text for Product Field is not as expected");
            moveToElement(driver,accountTeamMemberField("Source"));
            takeScreenshot(TCName,driver);
            softAssert.assertEquals(getElementText(driver,accountTeamMemberFieldsHelpText), readExcelData(accountsFilePath,TCName,"Source HelpText"), "Help Text for Source Field is not as expected");
            softAssert.assertAll();
            loggerManager.getLogger().info("Help Text for Account Team Member Fields are validated successfully");

        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to validate Help Text for Account Team Member Fields");
            Assert.assertTrue(false, "Failed to validate Help Text for Account Team Member Fields");

        }
    }

    /**
     * This method clicks the "Edit" button on the Account Team Member page.
     * It waits for the "Edit" button to be visible, then clicks it.
     * After clicking the "Edit" button, it waits for the "Save" button to be visible.
     * Finally, it takes a screenshot of the Account Team Member page.
     */
    @Step("Click on Edit Button on Account Team Member Page")
    public void editAccountTeamMember(){
        try{
            waitForElementToBeVisible(driver, editBtnOnAccountTeamMember);
            elementClickByJS(driver, editBtnOnAccountTeamMember);
            waitForElementToBeVisible(driver, saveBtnOnTeamMember);
            loggerManager.getLogger().info("Clicked on Edit button on Account Team Member Page");
            takeScreenshot(TCName, driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to click on Edit button on Account Team Member Page");
            Assert.assertTrue(false, "Failed to click on Edit button on Account Team Member Page");
        }
    }

    /**
     * This method edits and saves some fields on the Account Team Member record.
     * Steps:
     * 1. Waits for the "Crediting Manager" search field to be visible.
     * 2. Clicks on the "Crediting Manager" search field and enters the new team member's name.
     * 3. Takes a screenshot and selects the new team member from the search results.
     * 4. Repeats the process for the "Reporting Manager" field.
     * 5. Clicks the "Save" button to save the changes.
     * 6. Waits for the Account Team Member user value to be visible.
     * 7. Takes a screenshot for documentation.
     * 8. Logs the successful editing and saving of the Account Team Member record.
     * 9. Handles any exceptions that occur during the process.
     */
    @Step("Edit  and Save Some fields on Account Team Member Record")
    public void editAndSaveAccountTeamMemberDetails(){
        try{
            waitForElementToBeVisible(driver, creditingManagerSearchField);
            elementClick(driver, creditingManagerSearchField);
            sendKeysToElement(driver, creditingManagerSearchField, readExcelData(accountsFilePath, TCName, "CreditingManager"));
            takeScreenshot(TCName, driver);
            elementClick(driver, addTeamMemberUserSearchFieldOption(readExcelData(accountsFilePath, TCName, "CreditingManager")));
            elementClick(driver, handlerRoleSearchField);
            sendKeysToElement(driver, handlerRoleSearchField, readExcelData(accountsFilePath, TCName, "Handler Role"));
            takeScreenshot(TCName, driver);
            elementClick(driver, productSearchField);
            sendKeysToElement(driver, productSearchField, readExcelData(accountsFilePath, TCName, "Product"));
            takeScreenshot(TCName, driver);
            elementClick(driver, saveBtnOnTeamMember);
            takeScreenshot(TCName, driver);
            waitForElementToBeVisible(driver, sourceField);
            loggerManager.getLogger().info("Edited and Saved  some fields on Account Team Member record successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to edit and save Account Team Member Record details");
            Assert.assertTrue(false, "Failed to edit and save Account Team Member Record details");
        }
    }

    /**
     * This method validates the updated value of the "Source" field on the Account Team Member page.
     * Steps:
     * 1. Waits for the "Source" field to be visible.
     * 2. Refreshes the page to ensure the latest data is loaded.
     * 3. Depending on the test case name (`TCName`), it performs specific validations.
     * 4. Checks if the "Source" field is displayed.
     * 5. Takes a screenshot for documentation.
     * 6. Asserts that the value of the "Source" field matches the expected value.
     * 7. Logs the successful validation of the "Source" field value.
     */
    @Step("Verify Updated Source Field Value on Account Team Member Record Page")
    public void validateSourceFieldValueUpdatedOnAccountTeamMember(){
        waitForElementToBeVisible(driver, sourceField);
        scrollToElement(driver, sourceField);
        switch (TCName) {
            case "verifySourceFieldValueUpdatedOnAccountTeamMember_SalesRep":
            case "verifySourceFieldValueUpdatedOnAccountTeamMember_OperationAnalyst":
            case "verifySourceFieldValueUpdatedOnAccountTeamMember_CustomerSuccessAccountDevelopmentSpecialist":
            case "verifySourceFieldValueUpdatedOnAccountTeamMember_DataManagement":
            case "verifySourceFieldValueUpdatedOnAccountTeamMember_BusinessAdmin":
                isElementDisplayed(driver, sourceField);
                // hardcoded the expected values as these are static values and  are not going to change
                Assert.assertEquals(getElementText(driver, sourceFieldValue), "Manual", "Source Field Value is not as expected");
                loggerManager.getLogger().info("Source Field Value should not be updated to Sales");
                takeScreenshot(TCName, driver);
                break;
            case "verifySourceFieldValueUpdatedOnAccountTeamMember_SystemAdmin":
                isElementDisplayed(driver, sourceField);
                // hardcoded the expected values as these are static values and  are not going to change
                Assert.assertEquals(getElementText(driver, sourceFieldValue), "Sales", "Source Field Value is not as expected");
                loggerManager.getLogger().info("Source Field Value should not be updated to Manual");
                takeScreenshot(TCName, driver);
                break;
            default :
                loggerManager.getLogger().error("TCName is not available as an option");

        }
    }

    /**
     * This method validates the updated value of the "Source" field on the Account Team Member page.
     * Steps:
     * 1. Waits for the "Source" field to be visible.
     * 2. Scrolls to the "Source" field to ensure it is in view.
     * 3. Asserts that the "Source" field is displayed.
     * 4. Asserts that the value of the "Source" field is updated to "Sales".
     * 5. Logs the successful validation of the updated "Source" field value.
     * 6. Takes a screenshot for documentation.
     * 7. Handles any exceptions that occur during the process.
     */
    @Step("Verify Source Field Value is Updated from Manual to Sales")
    public void validateSourceFieldValueUpdatedFromManualToSales(){
        try{
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
            waitForElementToBeVisible(driver, sourceField);
            scrollToElement(driver, sourceField);
            isElementDisplayed(driver, sourceField);
            Assert.assertEquals(getElementText(driver, sourceFieldValue), "Sales", "Source Field Value is not updated to Sales");
            loggerManager.getLogger().info("Source Field Value is updated to Sales successfully");
            takeScreenshot(TCName, driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Source Field Value is not updated to Sales");
            Assert.assertTrue(false, "Source Field Value is not updated to Sales");
        }
    }

    /**
     * This method validates the updated value of the "Source" field on the Account Team Member page.
     * Steps:
     * 1. Waits for the "Source" field to be visible.
     * 2. Scrolls to the "Source" field to ensure it is in view.
     * 3. Asserts that the "Source" field is displayed.
     * 4. Asserts that the value of the "Source" field is updated to "Manual".
     * 5. Logs the successful validation of the updated "Source" field value.
     * 6. Takes a screenshot for documentation.
     * 7. Handles any exceptions that occur during the process.
     */
    @Step("Verify Source Field Value is Updated from Sales to Manual")
    public void verifySourceFieldValueUpdatedFromSalesToManual(){
        try{
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
            waitForElementToBeVisible(driver, sourceField);
            scrollToElement(driver, sourceField);
            isElementDisplayed(driver, sourceField);
            Assert.assertEquals(getElementText(driver, sourceFieldValue), "Manual", "Source Field Value is not updated to Manual");
            loggerManager.getLogger().info("Source Field Value is updated to Manual successfully");
            takeScreenshot(TCName, driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Source Field Value is not updated to Manual");
            Assert.assertTrue(false, "Source Field Value is not updated to Manual");
        }
    }
    /**
     * This method validates that the value of the "Source" field on the Account Team Member page is "Manual".
     * Steps:
     * 1. Waits for the "Source" field to be visible.
     * 2. Asserts that the value of the "Source" field is "Manual".
     * 3. Logs the successful validation of the "Source" field value.
     * 4. Takes a screenshot for documentation.
     * 5. Handles any exceptions that occur during the process.
     */
    @Step("Verify Source Field Value is Manual")
    public void validateSourceFieldValueIsManual(){
        try{
            waitForElementToBeVisible(driver, sourceField);
            Assert.assertEquals(getElementText(driver, sourceFieldValue), "Manual", "Source Field Value is not as expected");
            loggerManager.getLogger().info("Source Field Value" + sourceFieldValue + "is validated successfully");
            takeScreenshot(TCName, driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Source Field Value is not as expected");
            Assert.assertTrue(false, "Source Field Value is not as expected");
        }
    }

    /**
     * This method validates that the value of the "Source" field on the Account Team Member page is "Sales".
     * Steps:
     * 1. Waits for the "Source" field to be visible.
     * 2. Asserts that the value of the "Source" field is "Sales".
     * 3. Logs the successful validation of the "Source" field value.
     * 4. Takes a screenshot for documentation.
     * 5. Handles any exceptions that occur during the process.
     */
    @Step("Verify Source Field Value is Sales")
    public void validateSourceFieldValueIsSales(){
        try{
            waitForElementToBeVisible(driver, sourceField);
            Assert.assertEquals(getElementText(driver, sourceFieldValue), "Sales", "Source Field Value is not as expected");
            loggerManager.getLogger().info("Source Field Value" + sourceFieldValue +  "is validated successfully");
            takeScreenshot(TCName, driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Source Field Value is not as expected");
            Assert.assertTrue(false, "Source Field Value is not as expected");
        }
    }

    /**
     * This method updates the role field value on the Account Team Member record.
     * Steps:
     * 1. Waits for the "Edit Team Member Role" button to be visible.
     * 2. Clicks on the "Edit Team Member Role" button.
     * 3. Waits for the role picklist option to be clickable.
     * 4. Selects the new role from the dropdown.
     * 5. Takes a screenshot for documentation.
     * 6. Clicks the "Save" button to save the changes.
     * 7. Logs the successful update of the role field value.
     * 8. Handles any exceptions that occur during the process.
     */
    @Step("Udpate Role Field Value on Account Team Member")
    public void updateRoleFieldValueOnAccountTeamMember(){
        try{
            waitForElementToBeVisible(driver, editTeamMemberRole);
            elementClickByJS(driver, editTeamMemberRole);
            takeScreenshot(TCName, driver);
            waitForElementToBeClickable(driver, addTeamMemberRolePicklistOption(readExcelData(accountsFilePath, TCName, "UpdatedTeamRole")));
            elementClickByJS(driver, addTeamMemberRolePicklistOption(readExcelData(accountsFilePath, TCName, "UpdatedTeamRole")));
            takeScreenshot(TCName, driver);
            elementClick(driver, saveBtnOnTeamMember);
            waitForElementToBeVisible(driver, accountTeamMemberRoleValue);
            wait.until(ExpectedConditions.textToBePresentInElement(accountTeamMemberRoleValue, readExcelData(accountsFilePath, TCName, "UpdatedTeamRole")));
            loggerManager.getLogger().info("Role Field Value is updated successfully on Account Team Member record successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to update Role Field Value on Account Team Member record");
            Assert.assertTrue(false, "Failed to update Role Field Value on Account Team Member record");
        }
    }

    /**
     * This method validates the updated value of the "Role" field on the Account Team Member record.
     * Steps:
     * 1. Waits for the "Role" field to be visible.
     * 2. Asserts that the value of the "Role" field matches the expected value from the Excel file.
     * 3. Logs the successful validation of the updated "Role" field value.
     * 4. Takes a screenshot for documentation.
     * 5. Handles any exceptions that occur during the process.
     */
    @Step("Verify that Role Field Value is updated on Account Team Member")
    public void validateRoleFieldValueOnAccountTeamMember() {
        try {
            waitForElementToBeVisible(driver, accountTeamMemberRoleValue);
            Assert.assertEquals(getElementText(driver, accountTeamMemberRoleValue), readExcelData(accountsFilePath, TCName, "UpdatedTeamRole"), "Failed to update Role Field Value on Account Team Member record");
            loggerManager.getLogger().info("Role Field Value is updated as" + accountTeamMemberRoleValue + " on Account Team Member record successfully");
            takeScreenshot(TCName, driver);
        } catch (Exception e) {
            loggerManager.getLogger().error("Failed to update Role Field Value on Account Team Member record");
            Assert.assertTrue(false, "Failed to update Role Field Value on Account Team Member record");
        }
    }
    /**
     * This method creates a new Competitor Account record with mandatory fields in Salesforce (SFDC).
     */
    @Step("Create a new Competitor Account record with mandatory fields using Save button")
    public void createCompetitorAccountWithSaveButton(LinkedHashMap<String, String> accountData) {
        selectAccountRecordType("Competitor Account");
        enterAccountNameAndBusinessType(accountData);
        scrollToElement(driver, driver.findElement(accountTextField("CapDB Score")));
        enterAddressDetailsOnAccount(accountData);
        saveAccount();
        Allure.step("Validate that Competitor Account is created with mandatory fields", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to create Competitor Account with mandatory fields");
            loggerManager.getLogger().info("Competitor Account created with mandatory fields successfully.");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method enters the Account Name and Business Type on the Account record in Salesforce (SFDC).
     */
    @Step("Enter Account Name and Business Type on Account")
    private void enterAccountNameAndBusinessType(LinkedHashMap<String, String> accountData) {
        accountName = readExcelData(accountsFilePath, TCName, "Account Name");
        if (accountName != null && accountName.contains("_Auto_"))
            accountName = accountName.substring(0, accountName.indexOf("_Auto_"));

        accountName =  accountName + generateRandomString("_Auto");
        waitForElementToBePresent(driver, accountTextField("Account Name"));
        sendKeysToElement(driver, driver.findElement(accountTextField("Account Name")), accountName);
        takeScreenshot(TCName, driver);
        waitForElementToBeVisible(driver, businessTypePicklist);
        elementClickByJS(driver, businessTypePicklist);
        waitForElementToBeVisible(driver, driver.findElement(accountPicklistOption(accountData.get("Business Type"))));
        takeScreenshot(TCName, driver);
        elementClickByJS(driver, driver.findElement(accountPicklistOption(accountData.get("Business Type"))));
        waitForElementToBeVisible(driver, primaryCountryPicklistOnAccount);
    }

    /**
     * This method enters the address details on the Account record in Salesforce (SFDC).
     */
    @Step("Enter Address Details on Account")
    private void enterAddressDetailsOnAccount(LinkedHashMap<String, String> accountData) {
        elementClick(driver, primaryCountryPicklistOnAccount);
        waitForElementToBePresent(driver, accountPicklistOption(accountData.get("Primary Country")));
        elementClickByJS(driver, driver.findElement(accountPicklistOption(accountData.get("Primary Country"))));
        sendKeysToElement(driver, driver.findElement(accountTextField("Primary Street 1")), accountData.get("Primary Street 1"));
        sendKeysToElement(driver, driver.findElement(accountTextField("Primary City")), accountData.get("Primary City"));
        elementClickByJS(driver, primaryStatePicklistOnAccount);
        waitForElementToBeVisible(driver, driver.findElement(accountPicklistOption(accountData.get("Primary State"))));
        elementClick(driver, driver.findElement(accountPicklistOption(accountData.get("Primary State"))));
        sendKeysToElement(driver, driver.findElement(accountTextField("Primary Zip/Postal Code")), accountData.get("Primary Zip/Postal Code"));
        takeScreenshot(TCName, driver);
    }

    /**
     * This method saves the Account record in Salesforce (SFDC).
     */
    @Step("Save the Account")
    public void saveAccount() {
        reusableBusinessLibrary.clickSaveBtn();
        waitForElementToBeVisible(driver, reusableBusinessLibrary.addressValidationConfirmButton);
        elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
        waitForElementToBeVisible(driver, showMoreActionsButton);
        Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to save the Account");
    }

    /**
     * This method creates a new Standard Account record with mandatory fields using Save and New button in Salesforce (SFDC).
     */
    @Step("Create a new Standard Account record with mandatory fields using Save button")
    public void createStandardAccountWithSaveAndNewButton(LinkedHashMap<String, String> accountData) {
        selectAccountRecordType("Standard Account");
        enterAccountNameAndBusinessType(accountData);
        scrollToElement(driver, driver.findElement(accountTextField("GUO Id")));
        enterAddressDetailsOnAccount(accountData);
        saveAndNewAccount();
        Allure.step("Validate that Standard Account is created with mandatory fields using Save and New button", step->{
            Assert.assertEquals(getElementText(driver, driver.findElement(accountTextField("Account Name"))), "", "Failed to click on Save and New button");
            loggerManager.getLogger().info("Standard Account created with mandatory fields successfully using Save and New button.");
        });
        takeScreenshot(TCName, driver);
    }

    @Step("Click on Save and New button")
    private void saveAndNewAccount() {
        reusableBusinessLibrary.clickSaveAndNewBtn();
        waitForElementToBeVisible(driver, reusableBusinessLibrary.addressValidationConfirmButton);
        elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
        waitForElementToBeVisible(driver, driver.findElement(accountTextField("Account Name")));
        Allure.step("Validate that Save and New button is clicked", step->{
            Assert.assertEquals(getElementText(driver, driver.findElement(accountTextField("Account Name"))),"", "Failed to click on Save and New button");
            loggerManager.getLogger().info("Clicked on Save and New button successfully.");
        });
        takeScreenshot(TCName, driver);
        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error("Error occurred while waiting for the page to load" + e.getMessage());
        }

    }

    /**
     * This method creates a new Competitor Account record with mandatory fields using Save and New button in Salesforce (SFDC).
     */
    @Step("Create a new Competitor Account record with mandatory fields using Save button")
    public void createCompetitorAccountWithSaveAndNewButton(LinkedHashMap<String, String> accountData) {
        selectAccountRecordType("Competitor Account");
        enterAccountNameAndBusinessType(accountData);
        scrollToElement(driver, driver.findElement(accountTextField("CapDB Score")));
        enterAddressDetailsOnAccount(accountData);
        saveAndNewAccount();
        Allure.step("Validate that Competitor Account is created with mandatory fields using Save and New button", step->{
            Assert.assertEquals(getElementText(driver, driver.findElement(accountTextField("Account Name"))), "", "Failed to create Competitor Account with mandatory fields using Save and New button");
            loggerManager.getLogger().info("Competitor Account created with mandatory fields successfully using Save and New button.");
        });
        takeScreenshot(TCName, driver);

        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
    }

    /**
     * This method validates if the mandatory account information if populated correctly on the created Account.
     */
    public void validateMandatoryAccountInfo(LinkedHashMap<String, String> accountData){
        LinkedHashMap<String, String> accountAddressDetails;
        waitForElementToBeVisible(driver, detailsTab);
        elementClickByJS(driver, detailsTab);

        //Scroll to the element's location so that it loads
        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 300);");
        scrollToElement(driver, ofacDateStampLabelonAccount);

        Allure.step("Verify the value of Business Type field should be " + accountData.get("Business Type"), step->{
            if (businessTypeText.getText().equals(accountData.get("Business Type"))) {
                loggerManager.getLogger().info("Business Type field value matches with expected value " + accountData.get("Business Type"));
            } else {
                loggerManager.getLogger().info("Business Type field value does not match with expected value " + accountData.get("Business Type"));
            }
            takeScreenshot(TCName, driver);
            softAssert.assertEquals(businessTypeText.getText(), accountData.get("Business Type"), "Business Type field value does not match with expected value " + accountData.get("Business Type"));
        });
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        accountAddressDetails = getAccountAddressDetails();
        loggerManager.getLogger().info("Account Address Details: " + accountAddressDetails);
        LinkedHashMap<String, String> finalAccountAddressDetails = accountAddressDetails;
        Allure.step("Verify the Account Address Details", step->{
            takeScreenshot(TCName, driver);
            softAssert.assertEquals(finalAccountAddressDetails.get("Country"), accountData.get("Primary Country"), "Country field not saved on the Account");
            softAssert.assertEquals(finalAccountAddressDetails.get("Street 1"), accountData.get("Primary Street 1"), "Street1 field not saved on the Account");
            softAssert.assertEquals(finalAccountAddressDetails.get("City"), accountData.get("Primary City"), "City field not saved on the Account");
            softAssert.assertEquals(finalAccountAddressDetails.get("State"), accountData.get("Primary State"), "State field not saved on the Account");
            softAssert.assertEquals(finalAccountAddressDetails.get("Postal Code"), accountData.get("Primary Zip/Postal Code"), "Postal Code field not saved on the Account");
        });

        Allure.step("Validate that mandatory account details are populated correctly on the created Account", step -> {
            softAssert.assertAll();
            loggerManager.getLogger().info("Mandatory details validated successfully on the created account.");
        });
    }

    /**
     * This method enters the optional fields on the Standard Account record in Salesforce (SFDC).
     */
    @Step("Enter Optional Fields on Standard Account")
    public void enterOptionalFieldsOnStandardAccount(LinkedHashMap<String, String> accountData){
        enterPhoneAndWebsiteOnAccount(accountData);
        Allure.step("Select Primary Site checkbox", step->{
            waitForElementToBeVisible(driver, primarySiteCheckbox);
            elementClick(driver, primarySiteCheckbox);
            takeScreenshot(TCName, driver);
        });
        Allure.step("Select Type of Entity as " + accountData.get("Type of Entity"), step->{
            scrollToElement(driver, segmentationInformationSectionLabel);
            waitForElementToBeVisible(driver, typeOfEntityPicklist);
            elementClick(driver, typeOfEntityPicklist);
            waitForElementToBePresent(driver, accountPicklistOption(accountData.get("Type of Entity")));
            elementClick(driver, driver.findElement(accountPicklistOption(accountData.get("Type of Entity"))));
            takeScreenshot(TCName, driver);
        });
        Allure.step("Select Partner Type as " + accountData.get("Partner Type"), step-> {
            scrollToElement(driver, partnerInformationSectionLabel);
            elementClickByJS(driver, driver.findElement(accountMultiSelectOption(accountData.get("Partner Type"))));
            elementClickByJS(driver, partnerTypeMoveToChosenButton);
            takeScreenshot(TCName, driver);
        });
    }

    /**
     * This method enters the optional fields on the Competitor Account record in Salesforce (SFDC).
     */
    @Step("Enter Optional Fields on Competitor Account")
    public void enterOptionalFieldsOnCompetitorAccount(LinkedHashMap<String, String> accountData){
        enterPhoneAndWebsiteOnAccount(accountData);
        Allure.step("Enter AC Name as " + accountData.get("AC Name"), step->{
            scrollToElement(driver, alternateCharacterFieldsSectionLabel);
            waitForElementToBePresent(driver, accountTextField("AC Name"));
            sendKeysToElement(driver, driver.findElement(accountTextField("AC Name")), accountData.get("AC Name"));
            takeScreenshot(TCName, driver);
        });
    }

    /**
     * This method enters the optional fields on the Standard Account record in Salesforce (SFDC) using Save and New button.
     */
    @Step("Enter Phone and Website on Account")
    public void enterPhoneAndWebsiteOnAccount(LinkedHashMap<String, String> accountData) {
        waitForElementToBePresent(driver, accountTextField("Phone"));
        waitForElementToBeVisible(driver, driver.findElement(accountTextField("Phone")));
        driver.findElement(accountTextField("Phone")).clear();
        sendKeysToElement(driver, driver.findElement(accountTextField("Phone")), accountData.get("Phone"));
        waitForElementToBeVisible(driver, driver.findElement(accountTextField("Website")));
        driver.findElement(accountTextField("Website")).clear();
        sendKeysToElement(driver, driver.findElement(accountTextField("Website")), accountData.get("Website"));
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the error message on the mandatory field of the Account that appears when the field is left blank.
     */
    @Step("Verify Mandatory Field Error Message for {fieldName}")
    public void verifyMissingMandatoryFieldError(String fieldName){
            waitForElementToBePresent(driver, mandatoryFieldErrorMessage(fieldName));
            Assert.assertTrue(isElementDisplayed(driver, driver.findElement(mandatoryFieldErrorMessage(fieldName))), "Mandatory field error message not displayed for " + fieldName);
            takeScreenshot(TCName, driver);
            loggerManager.getLogger().info("Mandatory field error message displayed successfully for " + fieldName);
    }

    /**
     * This method verifies the error message on the mandatory fields of the Standard Account that appears when the fields are left blank and the Save button is clicked.
     */
    @Step("Verify Mandatory Fields Error Message on Standard Account using Save button")
    public void validateMandatoryFieldErrorOnStandardAccountUsingSaveButton(){
        reusableBusinessLibrary.clickSaveBtn();
        validateMandatoryFieldErrorOnStandardAccount();
    }

    /**
     * This method verifies the error message on the mandatory fields of the Standard Account that appears when the fields are left blank.
     */
    @Step("Verify Mandatory Fields Error Message on Standard Account")
    public void validateMandatoryFieldErrorOnStandardAccount(){
        scrollToTop(driver);
        verifyMissingMandatoryFieldError("Account Name");
        scrollToElement(driver, driver.findElement(accountTextField("GUO Id")));
        verifyMissingMandatoryFieldError("Primary Country");
        scrollToElement(driver, addressInformationSectionLabel);
        verifyMissingMandatoryFieldError("Primary Street 1");
    }

    /**
     * This method verifies the error message on the mandatory fields of the Competitor Account that appears when the fields are left blank and the Save button is clicked.
     */
    @Step("Verify Mandatory Fields Error Message on Competitor Account using Save button")
    public void validateMandatoryFieldErrorOnCompetitorAccountUsingSaveButton(){
        reusableBusinessLibrary.clickSaveBtn();
        validateMandatoryFieldErrorOnCompetitorAccount();
    }

    /**
     * This method verifies the error message on the mandatory fields of the Competitor Account that appears when the fields are left blank.
     */
    @Step("Verify Mandatory Fields Error Message on Competitor Account")
    public void validateMandatoryFieldErrorOnCompetitorAccount() {
        scrollToTop(driver);
        verifyMissingMandatoryFieldError("Account Name");
        scrollToElement(driver, driver.findElement(accountTextField("CapDB Score")));
        verifyMissingMandatoryFieldError("Primary Country");
    }

    /**
     * This method verifies the error message on the mandatory fields of the Standard Account that appears when the fields are left blank and the Save and New button is clicked.
     */
    @Step("Verify Mandatory Fields Error Message on Standard Account using Save and New button")
    public void validateMandatoryFieldErrorOnStandardAccountUsingSaveAndNewButton(){
        reusableBusinessLibrary.clickSaveAndNewBtn();
        validateMandatoryFieldErrorOnStandardAccount();
    }

    /**
     * This method verifies the error message on the mandatory fields of the Competitor Account that appears when the fields are left blank and the Save and New button is clicked.
     */
    @Step("Verify Mandatory Fields Error Message on Competitor Account using Save and New button")
    public void validateMandatoryFieldErrorOnCompetitorAccountUsingSaveAndNewButton(){
        reusableBusinessLibrary.clickSaveAndNewBtn();
        validateMandatoryFieldErrorOnCompetitorAccount();
    }

    /**
     * This method creates a new Standard Account record with mandatory and optional fields in Salesforce (SFDC).
     */
    @Step("Create a new Standard Account record with mandatory and optional fields using Save button")
    public void createStandardAccountWithMandatoryAndOptionalInfoUsingSaveButton(LinkedHashMap<String, String> accountData) {
        selectAccountRecordType("Standard Account");
        enterAccountNameAndBusinessType(accountData);
        scrollToElement(driver, driver.findElement(accountTextField("GUO Id")));
        enterAddressDetailsOnAccount(accountData);
        enterOptionalFieldsOnStandardAccount(accountData);
        saveAccount();
        Allure.step("Validate that Standard Account is created with mandatory and optional fields fields", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to create Standard Account with mandatory and optional fields");
            loggerManager.getLogger().info("Standard Account created with mandatory and optional fields successfully.");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method validates if the optional account information if populated correctly on the created Account.
     */
    public void validateOptionalInfoOnStandardAccount(LinkedHashMap<String, String> accountData){

        validateWebsiteValueOnStandardAccount(accountData.get("Website"));
        validatePhoneValueOnStandardAccount(accountData.get("Phone"));
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, detailsTab);
        elementClickByJS(driver, detailsTab);

        waitForElementToBeVisible(driver, statusSectionLabel);
        scrollToElement(driver, statusSectionLabel);
        Allure.step("Verify the value of Primary Site checkbox should be true", step->{
            if (primarySiteCheckboxValue.getAttribute("checked").equals("true")) {
                loggerManager.getLogger().info("Primary Site checkbox value is set to true");
            } else {
                loggerManager.getLogger().info("Failed to verify that Primary Site checkbox value is set to true");
            }
            takeScreenshot(TCName, driver);
            softAssert.assertTrue(primarySiteCheckboxValue.getAttribute("checked").equals("true"), "Failed to verify that Primary Site checkbox value is set to true");
        });

        validateTypeOfEntity(accountData.get("Type of Entity"));

        scrollToElement(driver, partnerInformationSectionLabel);
        Allure.step("Verify the value of Partner Type field should be " + accountData.get("Partner Type"), step->{
            if (partnerTypeValue.getText().equals(accountData.get("Partner Type"))) {
                loggerManager.getLogger().info("Partner Type field value matches with expected value " + accountData.get("Partner Type"));
            } else {
                loggerManager.getLogger().info("Partner Type field value does not match with expected value " + accountData.get("Partner Type"));
            }
            takeScreenshot(TCName, driver);
            softAssert.assertEquals(partnerTypeValue.getText(), accountData.get("Partner Type"), "Partner Type field value does not match with expected value " + accountData.get("Partner Type"));
        });

        Allure.step("Validate that optional account details are populated correctly on the created Standard Account", step -> {
            softAssert.assertAll();
            loggerManager.getLogger().info("Optional details validated successfully on the created Standard account.");
        });
    }

    @Step("Click on Account Edit Button")
    public void clickEditButton(){
        waitForElementToBeVisible(driver, accountEditButton);
        elementClick(driver, accountEditButton);
    }

    @Step("Update Account Company status field value to {value}")
    public void updateAccountCompanyStatusInfo(String value){
        pageRefresh(driver);
        waitForElementToBeClickable(driver, companyStatusPicklist);
        scrollToElement(driver, companyStatusPicklist);
        elementClickByJS(driver, companyStatusPicklist);
        elementClickByJS(driver, companyStatusUnknownOption);
        takeScreenshot(TCName, driver);
        reusableBusinessLibrary.clickSaveBtn();
        loggerManager.getLogger().info("Updated Company status value to " + value);
        waitForElementToBeVisible(driver, accountEditButton);
        takeScreenshot(TCName, driver);
    }

    @Step("Click on New Open Opportunity from Opportunity subtab from Account record")
    public void clickNewSalesOpenOpportunityFromOpportunitySubTab(){
        waitForElementToBeVisible(driver, openOppoyNewButton);
        elementClickByJS(driver, openOppoyNewButton);
        takeScreenshot(TCName, driver);
        loggerManager.getLogger().info("Clicked on New Open Opportunity button from Opportunity subtab");
    }

    @Step("Create a new Standard Account record with mandatory fields and parent account using Save button")
    public void updateParentAccount(LinkedHashMap<String, String> accountData) {
        elementClick(driver, parentAccountField);
        sendKeysToElement(driver, parentAccountField, accountData.get("ParentAccount"));
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        elementClickByJS(driver, driver.findElement(parentAccountOption(accountData.get("ParentAccount"))));
        reusableBusinessLibrary.clickSaveBtn();
        Allure.step("Validate update account activity", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to update parent account information");
            loggerManager.getLogger().info("Failed to update parent account information.");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method creates a new Standard Account record with mandatory and optional fields in Salesforce (SFDC).
     */
    @Step("Create a new Competitor Account record with mandatory and optional fields using Save button")
    public void createCompetitorAcctWithMandatoryAndOptionalInfoUsingSaveBtn(LinkedHashMap<String, String> accountData) {
        selectAccountRecordType("Competitor Account");
        enterAccountNameAndBusinessType(accountData);
        scrollToElement(driver, driver.findElement(accountTextField("CapDB Score")));
        enterAddressDetailsOnAccount(accountData);
        enterOptionalFieldsOnCompetitorAccount(accountData);
        saveAccount();
        Allure.step("Validate that Competitor Account is created with mandatory and optional fields fields", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to create Competitor Account with mandatory and optional fields");
            loggerManager.getLogger().info("Competitor Account created with mandatory and optional fields successfully.");
        });
        takeScreenshot(TCName, driver);
    }


    /**
     * This method validates if the optional account information if populated correctly on the created Account.
     */
    @Step("Validate Optional Info on Competitor Account")
    public void validateOptionalInfoOnCompetitorAccount(LinkedHashMap<String, String> accountData){
        scrollToTop(driver);
        waitForElementToBeVisible(driver, notesAndAttachmentsQuickLink);
        scrollToElement(driver, notesAndAttachmentsQuickLink);
        waitForElementToBeVisible(driver, competitorAccountWebsiteValue);
        validateWebsiteValueOnCompetitorAccount(accountData.get("Website"));
        validatePhoneValueOnCompetitorAccount(accountData.get("Phone"));
        validateACNameOnCompetitorAccount(accountData.get("AC Name"));
    }

    /**
     * This method edits the fields on the Standard Account record in Salesforce (SFDC).
     * It updates the Phone, Website, and Type of Entity fields with the values provided in the `accountData` map.
     * @param accountData - A LinkedHashMap containing the updated values for the Phone, Website, and Type of Entity fields.
     */
    @Step("Edit Fields on Standard Account")
    public void editFieldsOnStandardAccount(LinkedHashMap<String, String> accountData){
        reusableBusinessLibrary.clickEditBtn();
        Allure.step("Update Phone to " + accountData.get("Updated Phone"), step-> {
            waitForElementToBePresent(driver, accountTextField("Phone"));
            waitForElementToBeVisible(driver, driver.findElement(accountTextField("Phone")));
            driver.findElement(accountTextField("Phone")).clear();
            sendKeysToElement(driver, driver.findElement(accountTextField("Phone")), accountData.get("Updated Phone"));
        });
        Allure.step("Update Website to " + accountData.get("Updated Website"), step-> {
            waitForElementToBeVisible(driver, driver.findElement(accountTextField("Website")));
            driver.findElement(accountTextField("Website")).clear();
            sendKeysToElement(driver, driver.findElement(accountTextField("Website")), accountData.get("Updated Website"));
            takeScreenshot(TCName, driver);
        });
        Allure.step("Update Type of Entity to " + accountData.get("Updated Type of Entity"), step-> {
            scrollToElement(driver, segmentationInformationSectionLabel);
            waitForElementToBeVisible(driver, typeOfEntityPicklist);
            elementClick(driver, typeOfEntityPicklist);
            waitForElementToBePresent(driver, accountPicklistOption(accountData.get("Updated Type of Entity")));
            elementClick(driver, driver.findElement(accountPicklistOption(accountData.get("Updated Type of Entity"))));
            takeScreenshot(TCName, driver);
        });

        reusableBusinessLibrary.clickSaveBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, showMoreActionsButton);
        Allure.step("Validate that Standard Account is saved after editing the fields", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to edit Standard Account");
            loggerManager.getLogger().info("Standard Account is saved successfully after editing the fields.");
        });
    }

    /**
     * This method validates the value of the Phone field on the Standard Account record.
     * @param expectedPhoneValue - The expected value of the Phone field.
     */
    @Step("Validate that Phone Value is {expectedPhoneValue} on Standard Account")
    public void validatePhoneValueOnStandardAccount(String expectedPhoneValue){
        waitForElementToBeVisible(driver, detailsTab);
        elementClickByJS(driver, detailsTab);

            String actualPhoneValue = getAccountPhone();
            if (actualPhoneValue.equals(expectedPhoneValue)) {
                loggerManager.getLogger().info("Phone field value matches with expected value " + expectedPhoneValue);
            } else {
                loggerManager.getLogger().info("Phone field value does not match with expected value " + expectedPhoneValue);
            }
            Assert.assertEquals(actualPhoneValue, expectedPhoneValue, "Phone field value does not match with expected value " + expectedPhoneValue);
    }

    /**
     * This method validates the value of the Website field on the Standard Account record.
     * @param expectedWebsiteValue - The expected value of the Website field.
     */
    @Step("Validate that Website Value is {expectedWebsiteValue} on Standard Account")
    public void validateWebsiteValueOnStandardAccount(String expectedWebsiteValue)
    {
        if (!expectedWebsiteValue.startsWith("https://"))
            expectedWebsiteValue = "https://" + expectedWebsiteValue;

        scrollToTop(driver);
        waitForElementToBeVisible(driver, accountWebsiteValue);
        String finalExpectedWebsiteValue = expectedWebsiteValue;
        Allure.step("Verify the value of Website field should be " + expectedWebsiteValue, step->{
            if (accountWebsiteValue.getText().equals(finalExpectedWebsiteValue)) {
                loggerManager.getLogger().info("Website field value matches with expected value " + finalExpectedWebsiteValue);
            } else {
                loggerManager.getLogger().info("Website field value does not match with expected value " + finalExpectedWebsiteValue);
            }
            takeScreenshot(TCName, driver);
            Assert.assertEquals(accountWebsiteValue.getText(), finalExpectedWebsiteValue, "Website field value does not match with expected value " + finalExpectedWebsiteValue);
        });
    }

    /**
     * This method validates the updated fields on the Standard Account record.
     * It verifies that the Phone, Website, and Type of Entity fields have been updated with the values provided in the `accountData` map.
     * @param accountData - A LinkedHashMap containing the updated values for the Phone, Website, and Type of Entity fields.
     */
    @Step("Validate updated Fields on Standard Account")
    public void validateUpdatedFieldsOnStandardAccount(LinkedHashMap<String, String> accountData){
        validateWebsiteValueOnStandardAccount(accountData.get("Updated Website"));
        validatePhoneValueOnStandardAccount(accountData.get("Updated Phone"));
        validateTypeOfEntity(accountData.get("Updated Type of Entity"));
    }

    /**
     * This method validates the value of the Type of Entity field on the Standard Account record.
     * @param expectedTypeOfEntityValue - The expected value of the Type of Entity field.
     */
    @Step("Verify the value of Type of Entity field should be {expectedTypeOfEntityValue}")
    public void validateTypeOfEntity(String expectedTypeOfEntityValue){
        scrollToElement(driver, segmentationInformationSectionLabel);
            if (getElementText(driver, typeOfEntityValue).equals(expectedTypeOfEntityValue)) {
                loggerManager.getLogger().info("Type of Entity field value matches with expected value " + expectedTypeOfEntityValue);
            } else {
                loggerManager.getLogger().info("Type of Entity field value does not match with expected value " + expectedTypeOfEntityValue);
            }
            takeScreenshot(TCName, driver);
            Assert.assertEquals(typeOfEntityValue.getText(), expectedTypeOfEntityValue, "Type of Entity field value does not match with expected value " + expectedTypeOfEntityValue);
    }

    /**
     * This method edits the fields on the Competitor Account record in Salesforce (SFDC).
     * It updates the Phone, Website, and AC Name fields with the values provided in the `accountData` map.
     * @param accountData - A LinkedHashMap containing the updated values for the Phone, Website, and AC Name fields.
     */
    @Step("Edit Fields on Competitor Account")
    public void editFieldsOnCompetitorAccount(LinkedHashMap<String, String> accountData){
        reusableBusinessLibrary.clickEditBtn();
        updatePhoneAndWebsiteOnAccount(accountData);
        Allure.step("Update AC Name to " + accountData.get("Updated AC Name"), step-> {
            scrollToElement(driver, alternateCharacterFieldsSectionLabel);
            waitForElementToBePresent(driver, accountTextField("AC Name"));
            driver.findElement(accountTextField("AC Name")).clear();
            sendKeysToElement(driver, driver.findElement(accountTextField("AC Name")), accountData.get("Updated AC Name"));
            takeScreenshot(TCName, driver);
        });
        reusableBusinessLibrary.clickSaveBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, showMoreActionsButton);
        Allure.step("Validate that Competitor Account is saved after editing the fields", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to edit Competitor Account");
            loggerManager.getLogger().info("Competitor Account is saved successfully after editing the fields.");
        });
    }

    /**
     * This method validates the updated fields on the Competitor Account record.
     * It verifies that the Phone, Website, and AC Name fields have been updated with the values provided in the `accountData` map.
     * @param accountData - A LinkedHashMap containing the updated values for the Phone, Website, and AC Name fields.
     */
    @Step("Validate updated Fields on Competitor Account")
    public void validateUpdatedFieldsOnCompetitorAccount(LinkedHashMap<String, String> accountData){
        validateWebsiteValueOnCompetitorAccount(accountData.get("Updated Website"));
        validatePhoneValueOnCompetitorAccount(accountData.get("Updated Phone"));
        validateACNameOnCompetitorAccount(accountData.get("Updated AC Name"));
    }

    /**
     * This method validates the value of the AC Name field on the Competitor Account record.
     * @param expectedACName - The expected value of the AC Name field.
     */
    @Step("Verify that the value of AC Name field should be {expectedACName}")
    public void validateACNameOnCompetitorAccount(String expectedACName){
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, detailsTab);
        elementClickByJS(driver, detailsTab);
        waitForElementToBeVisible(driver, alternateCharacterFieldsSectionLabel);
        scrollToElement(driver, alternateCharacterFieldsSectionLabel);
        Assert.assertEquals(expectedACName, getElementText(driver, ACNameValue), "Failed to verify that AC Name value is " + expectedACName);
        loggerManager.getLogger().info("AC Name value is not " + expectedACName);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method validates the value of the Phone field on the Competitor Account record.
     * @param expectedPhoneValue - The expected value of the Phone field.
     */
    @Step("Validate that Phone Value is {expectedPhoneValue} on Competitor Account")
    public void validatePhoneValueOnCompetitorAccount(String expectedPhoneValue){
        String actualPhoneValue = null;
        waitForElementToBeVisible(driver, detailsTab);
        elementClickByJS(driver, detailsTab);
        waitForElementToBeVisible(driver, clickToDialDisabledPhoneValue);
        if (!getElementText(driver, clickToDialDisabledPhoneValue).isEmpty())
            actualPhoneValue = getElementText(driver, clickToDialDisabledPhoneValue);
        else {
            waitForElementToBeVisible(driver, accountPhoneValue);
            actualPhoneValue = getElementText(driver, accountPhoneValue);
        }
        Assert.assertEquals(actualPhoneValue, expectedPhoneValue, "Phone field value does not match with expected value " + expectedPhoneValue);
        loggerManager.getLogger().info("Phone field value matches with expected value " + expectedPhoneValue);
    }

    /**
     * This method validates the value of the Website field on the Competitor Account record.
     * @param expectedWebsiteValue - The expected value of the Website field.
     */
    @Step("Validate that Website Value is {expectedWebsiteValue} on Competitor Account")
    public void validateWebsiteValueOnCompetitorAccount(String expectedWebsiteValue)
    {
        scrollToTop(driver);
        waitForElementToBeVisible(driver, competitorAccountWebsiteValue);
        Assert.assertEquals(getElementText(driver, competitorAccountWebsiteValue), expectedWebsiteValue, "Website field value does not match with expected value " + expectedWebsiteValue);
        loggerManager.getLogger().info("Website field value matches with expected value " + expectedWebsiteValue);
        takeScreenshot(TCName, driver);
    }

    @Step("Validate Opportunity creation from Account Record")
    public void validateOpportunityCreationinAccountPage(){
        waitForElementToBePresent(driver, oppyNameValidation(oppyName));
        Allure.step("Validate Opportunity creation from Account Record", step->{
            Assert.assertTrue(driver.findElement(oppyNameValidation(oppyName)).isDisplayed());
            loggerManager.getLogger().info("Opportunity created successfully from Account Record");
        });
        takeScreenshot(TCName, driver);
    }
    /**
     * This method navigates to the newly created Opportunity record from the Account record page.
     */
    @Step("Click On Opportunity Record Link from Account Record Page")
    public void navigateToNewlyCreatedOpportunity() {
        //ensure opportunity is done being created
        wait.until(invisibilityOfElementLocated(opportunityPage.newOpportunityHeader()));
        waitForElementToBePresent(driver, oppyNameValidation(oppyName));
        elementClickByJS(driver, driver.findElement(oppyNameValidation(oppyName)));
        waitForPageTitleToContain(driver, "Opportunity");
        Assert.assertTrue(driver.getTitle().contains(oppyName), "Failed to navigate to Opportunity Record");
        loggerManager.getLogger().info("Successfully navigated to opportunity record");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method updates the Phone and Website fields on the Account record in Salesforce (SFDC) using Save and New button.
     */
    @Step("Update Phone and Website on Account")
    public void updatePhoneAndWebsiteOnAccount(LinkedHashMap<String, String> accountData) {
        waitForElementToBePresent(driver, accountTextField("Phone"));
        waitForElementToBeVisible(driver, driver.findElement(accountTextField("Phone")));
        driver.findElement(accountTextField("Phone")).clear();
        sendKeysToElement(driver, driver.findElement(accountTextField("Phone")), accountData.get("Updated Phone"));
        waitForElementToBeVisible(driver, driver.findElement(accountTextField("Website")));
        driver.findElement(accountTextField("Website")).clear();
        sendKeysToElement(driver, driver.findElement(accountTextField("Website")), accountData.get("Updated Website"));
        takeScreenshot(TCName, driver);
    }

    /**
     * This method selects the Partnership Alliance Authorization values on the Account record in Salesforce (SFDC).
     * @param value - The value of the Partnership Alliance Authorization field to be selected.
     */
    @Step("Select Partnership Alliance Authorization as {value}")
    public void selectPartnershipAllianceAuthorization(String value){
        scrollToElement(driver, accessToTrainingCentreLabel);
        if(value.contains(";")) {
            String[] values = value.split(";");
            for (String val : values) {
                waitForElementToBeVisible(driver, driver.findElement(accountMultiSelectOption(val)));
                elementClick(driver, driver.findElement(accountMultiSelectOption(val)));
                elementClickByJS(driver, partnershipAllianceAuthorizationMoveToChosenBtn);
            }
        }
        else {
            waitForElementToBeVisible(driver, driver.findElement(accountMultiSelectOption(value)));
            elementClick(driver, driver.findElement(accountMultiSelectOption(value)));
            elementClickByJS(driver, partnershipAllianceAuthorizationMoveToChosenBtn);
        }
        takeScreenshot(TCName, driver);
    }



    /**
     * This method deselects the Partnership Alliance Authorization values if selected on the Account record in Salesforce (SFDC).
     */
    @Step("Deselect Partnership Alliance Authorization values if selected")
    public void deselectAllPartnershipAllianceAuthorizationValues() {
        scrollToElement(driver, accessToTrainingCentreLabel);
        boolean firstElement = true;
        if (!selectedPartnershipAllianceAuthorizationValues.isEmpty()) {
            for (WebElement option : selectedPartnershipAllianceAuthorizationValues) {
                if (firstElement) {
                    elementClick(driver, option);
                    firstElement = false;
                } else {
                    controlClickOnElement(driver, option);
                }
            }
            takeScreenshot(TCName, driver);
            loggerManager.getLogger().info("Deselected all values from Partnership Alliance Authorization picklist");
        }
        else {
            loggerManager.getLogger().info("No values are selected in Partnership Alliance Authorization picklist");
        }
    }
}

