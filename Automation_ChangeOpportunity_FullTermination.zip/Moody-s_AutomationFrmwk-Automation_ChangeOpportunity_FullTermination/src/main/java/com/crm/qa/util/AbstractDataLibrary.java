package com.crm.qa.util;

import io.restassured.response.Response;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Map;

/** This class provides a centralized location for storing file paths used in the project
 * These paths are used across the project to read and write data from/to these files
 * Author: Arshin Shaikh
 * Last Modified By: Arshin Shaikh
 * Date: 02/19/2025
 * Comment: Added new variables approverNamesList, terminatedProductName, terminatedProductPrice and changeOppyID
    */
public abstract class AbstractDataLibrary
{

    public static String userCredentialsFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/UserCredential.xlsx";
    public static String accountsFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/AccountData.xlsx";
    public static String leadsFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/LeadData.xlsx";
    public static String tasksFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/TaskData.xlsx";
    public static String campaignsFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/CampaignData.xlsx";
    public static String opportunitiesFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/OpportunityData.xlsx";
    public static String contactsFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/ContactData.xlsx";
    public static String quotesFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/QuoteData.xlsx";
    public static String agreementsFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/AgreementData.xlsx";
    public static String fulfillmentsFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/FulfillmentData.xlsx";
    public static String csvFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/testdata/NewSales.csv";
    public static String jsonFilePath = System.getProperty("user.dir") + "/src/main/resources/xRayAuth.json";
    public static String configFilePath = System.getProperty("user.dir") + "/src/main/java/com/crm/qa/config/config.properties";
    public static String takeScreenshotPath = System.getProperty("user.dir") + "\\screenshot/Test";
    public static String TCName,TCDependency = null;
    public static String downloadPath = System.getProperty("user.dir") + "\\downloads";
    public static  boolean flag, agreementApprovalFlag, orderActivationFlag, manualPriceRamp = false;
    public static String jiraClientId= "E58ED8CD83A94FBAAD70718E0B76BBBA";
    public static String jiraClientSecret= "d38dc5e1ccad925e442aced81b6fc415caeba14f73d3a14c0061f54ec15aa36d";
    public static String outlookClientId = "073d27c8-96cc-4ab2-8c47-875043eb754b";
    public static String outlookClientSecret = "kEw8Q~xXzHbCrjSO6GCvrXFdG~UFidomify2ecou";
    public static String outlookTenantId = "1061a8b8-b1ee-4249-bb84-9a2cd2792fae";
    public static Response authResponse, jiraResultParserResp, outlookAuthResponse, outlookMailResponse;
    public static String testNGReoportPath = System.getProperty("user.dir") + "/target/surefire-reports/testng-results.xml";
    public static String marketoLeadURL, sfdcLeadID, sfdcLeadTaskURL, sfdcLeadEmail, lastNameText, firstNameText, companyText, countryValue, accountName, oppyName, oppyID, newStartDate, newEndDate, proposalRecordID, quoteAndAgreementTotal, proposalID, agreementRecordID, agreementName, fulfillmentRecordID, expectedStartDate, expectedEndDate, agreementTCDependency, orderRecordID, trialEndDate, lineItemsPageLink, quoteTCdependency, terminatedProductName, terminatedProductPrice, changeOppyID = null;
    public static Map<String, String> separateAddressInfo = null;
    public static WebElement orbisImportedAccountelement_global;
    public static String emailAttachmentFileUploadPath = System.getProperty("user.dir") + "\\downloads\\EmailAttachmentFile.xlsx";
    public static int multiYearNumber = 1;
    public static List<String> approverNamesList = null;
}
