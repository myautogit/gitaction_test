package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import java.time.Duration;
import static com.crm.qa.util.AbstractDataLibrary.TCName;
import static com.crm.qa.util.AbstractDataLibrary.userCredentialsFilePath;
import static com.crm.qa.util.ReusableLibrary.*;

// This class contains methods related to login functionality
// Author: Sayon Das
// Last Modified By: Arshin Shaikh
// Date: 09/13/2024
// Comment: Added explicit wait to validate page title in login method to confirm successful login
public class LoginPage extends TestBase {
    
    //Initializing the Page Objects:
    public LoginPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    //Page Factory - OR:
    @FindBy(name="username")
    WebElement username;

    @FindBy(name="pw")
    WebElement password;

    @FindBy(id="Login")
    WebElement loginBtn;

    @FindBy(name="passwd")
    WebElement marketoPassword;

    @FindBy(id="loginButton")
    WebElement marketoLoginBtn;

    //Actions:
    @Step("Step : Login to the application")
    public void login(){
        String methodname = Thread.currentThread().getStackTrace()[1].getMethodName();
        loggerManager.getLogger().info("Logging in as " + ReusableLibrary.readExcelData(userCredentialsFilePath, TCName,"Username"));
        username.sendKeys(ReusableLibrary.readExcelData(userCredentialsFilePath, TCName,"Username"));
        password.sendKeys(decryptPassword(ReusableLibrary.readExcelData(userCredentialsFilePath, TCName,"EncryptedPassword")));
        ReusableLibrary.elementClickByJS(driver, loginBtn);
        waitForPageTitle(driver, "Home | Salesforce");
        ReusableLibrary.takeScreenshot(methodname, driver);
    }

    /**
     * This method logs into the Marketo application.
     * It first navigates to the Marketo URL.
     * It then enters the username and password, and clicks the login button.
     * It waits for the title of the page to be "My Marketo" to confirm successful login.
     * If the title does not change within the specified timeout, it logs an error message.
     *
     */
    @Step("Login to the Marketo application")
    public void loginToMarketo() {
        driver.get(prop.getProperty("Marketo_URL"));
        loggerManager.getLogger().info("Logging into Marketo as " + readExcelData(userCredentialsFilePath, TCName, "MarketoUser"));
        username.sendKeys(readExcelData(userCredentialsFilePath, TCName, "MarketoUser"));
        marketoPassword.sendKeys(decryptPassword(readExcelData(userCredentialsFilePath, TCName, "MarketoPassword")));
        elementClick(driver, marketoLoginBtn);

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
            wait.until(ExpectedConditions.titleIs("My Marketo"));
            loggerManager.getLogger().info("Logged into Marketo successfully");
            Allure.step("Validate that the user is logged in successfully", step->{
                Assert.assertEquals(driver.getTitle(), "My Marketo");
            });
        }
        catch (TimeoutException e) {
            loggerManager.getLogger().error("Failed to login to marketo" + e.getMessage());
        }
     }

}

