package com.crm.qa.util;

import com.crm.qa.base.TestBase;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;
import static com.crm.qa.util.ReusableLibrary.waitForPageTitleToContain;

/**
    * This class contains reusable methods/utilities that can be used across the framework
    * Author: Rishi Saini
    * Last Modified By: Arshin Shaikh
    * Date: 11/12/2024
    * Comment: Added method selectRecordType
    */

public class ReusableBusinessLibrary extends TestBase{

    public ReusableBusinessLibrary(WebDriver driver) {
       this.driver = driver;
       PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();

    //Page Factory - OR:
    @FindBy(xpath = "//div//button[@type='button' and @aria-label='Search']")
    WebElement globalSearchBar;

    @FindBy(xpath = "//input[@placeholder='Search...']")
    WebElement globalSearchTextField;

    @FindBy(xpath = "//span [text()='Home']")
    WebElement homeTab;

    public By objectFilterOnSearchResult(String objectName) {
        return By.xpath("//li//a[@title='" + objectName + "']");
    }

    public By searchResultRecord(String recordName) {
        return By.xpath("//a[@title='" + recordName + "']");
    }

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//button[text()='Save']")
    WebElement saveButton;

    @FindBy(xpath = "//button[text()='Save & New']")
    WebElement saveAndNewButton;

    @FindBy(xpath = "//div[@title='New']")
    WebElement newButton;

    public @FindBy(xpath = "//span[text()='Next']")
    WebElement recordTypeSelectionNextButton;

    public By objectTab(String tabName) {
        return By.xpath("//span [text()='" + tabName + "']");
    }

    public By objectTabInMoreMenu(String tabName) {
        return By.xpath("//a//span//span [text()='" + tabName + "']");
    }

    @FindBy(xpath = "//span [text()='More']")
    WebElement clickMoreMenu;

    public By btn (String buttonName) {
        return By.xpath("//button[text()='" + buttonName + "']");
    }

    //finds first linked item in a table of recently viewed items
    @FindBy(xpath = "(//a[@data-refid='recordId']) [1]")
    WebElement mostRecentFirstRecordLink;

    @FindBy(xpath = "//span[text()='Recently Viewed']")
    WebElement recentlyViewedText;

    public By subTabName(String tabName) {
        return By.xpath("//a[@data-label='"+tabName+"']");
    }

    public static By picklistButtonElement(String picklistTitle) {
        return By.xpath("//button[@aria-label ='" + picklistTitle + "']");
    }

    public static By picklistButtonElementOption(String picklistTitle, String optionName) {
        return By.xpath("//button[@aria-label ='" + picklistTitle + "']/following::span[text()='" + optionName + "']");
    }

    public static By filledFormTextField(String textFieldName, String expectedTextFieldValue) {
        return By.xpath("//label[text()='" + textFieldName + "']/following::input[@data-value='" + expectedTextFieldValue + "']");
    }

    public static WebElement formTextField(String textFieldName) {
        return driver.findElement(By.xpath("(//label[text()='" + textFieldName + "']/following::input) [1]"));
    }
    public static WebElement formTextArea(String textFieldName) {
        return driver.findElement(By.xpath("(//label[text()='" + textFieldName + "']/following::textarea) [1]"));
    }

    public static By recordToSelectAfterSendingKeys(String recordName) {
        return By.xpath("//lightning-base-combobox-formatted-text[contains(@title,'" + recordName + "')]");
    }
    public static By filledFormPicklistField(String picklistName, String expectedValueInPicklist) {
        return By.xpath("//button[@aria-label ='"+ picklistName+"' and @data-value='"+expectedValueInPicklist+"']");
    }

    public By editButton = By.xpath("//ul//button[text()='Edit']");

    public By deleteButton = By.xpath("//button[text()='Delete']");

    public @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//lightning-button-menu[contains(@class,'menu')]//button")
    WebElement showMoreActionsButton;

    public By editBtnUnderShowMore = By.xpath("//a/span[text()='Edit']");

    public By deleteButtonUnderShowMore = By.xpath("//a/span[text()='Delete']");

    public By recordTypeOption(String recordType){
        return By.xpath("(//span[text()='" + recordType + "']/preceding::span[contains(@class,'radio')])[last()]");
    }

    @FindBy(xpath = "//button[text()='Save']")
    WebElement saveButtononPopup;

    public By quickAction(String actionName) {
        return By.xpath("//div[contains(@style,'center')]//lightning-icon[@title='" + actionName + "']");
    }

    public By relatedList(String relatedListName) {
        return By.xpath("//span[@title='" + relatedListName + "']");
    }

    public By linkField(String fieldName, String fieldValue){
        return By.xpath("(//span[text()='" + fieldName + "']/following::span[text()=\"" + fieldValue + "\"])[1]/ancestor::a");
    }

    public By textFieldValue(String fieldName){
        return By.xpath("(//span[text()=\"" + fieldName + "\"]//following::lightning-formatted-text)[1]");
    }

    public By linkFieldValue(String fieldName) {
        return By.xpath("(//span[text()='" + fieldName + "']/following::a)[1]//slot//slot");
    }

    public By lineItemsTableData(String relatedListName){
        return By.xpath("//table[@aria-label='" + relatedListName + "']//tbody//tr//td");
    }

    public By relatedListColumnData(String relatedListName, String columnName){
        return By.xpath("//table[@aria-label='" + relatedListName + "']//tbody//tr//td[@data-label='" + columnName + "']");
    }

    public By fieldLabel(String fieldName){
        return By.xpath("//span[text()='" + fieldName + "']");
    }

    public @FindBy(xpath = "//a[contains(text(),'Show All')]")
    WebElement showAllQuickLink;

    public @FindBy(xpath = "//div[contains(@class,'recordTypeName')]/span")
    WebElement recordTypeValue;

    public @FindBy(xpath = "//input[@value='Continue']")
    WebElement recordTypeSelectionContinueButton;

    public By picklistListElement(String elementName){
        return By.xpath("//button[@aria-label='" + elementName + "']");
    }

    public By quickLink(String quickLinkName){
        return By.xpath("//slot[contains(text(),'" + quickLinkName + "')]/ancestor::a");
    }

    public By picklistOptionElement(String optionName){
        return By.xpath("//lightning-base-combobox-item[@data-value=\"" + optionName + "\"]");
    }

    public By textfieldElement(String elementName){
        return By.xpath("(//label[text()='" + elementName + "']/following::input)[1]");
    }

    public By textfieldResult(String resultName){
        return By.xpath("//lightning-base-combobox-formatted-text[@title='" + resultName + "']");
    }

    public By multiSelectPicklistOption(String optionName){
        return By.xpath("//span[text()='" + optionName + "']");
    }

    public By multiSelectPicklistMoveToChosenButton(String picklistName){
        return By.xpath("(//div[text()='" + picklistName + "']/following::button[@title='Move to Chosen'])[1]");
    }

    public @FindBy(xpath = "//button[text()='Confirm']")
    WebElement addressValidationConfirmButton;

    public @FindBy(xpath = "//button[text()='Skip Validation']")
    WebElement skipValidationButton;

    public By appNameInDropDown (String appName){ return By.xpath("//a[@data-label='"+appName+"']");}
    @FindBy(xpath = "//h1 [contains(@class,'appName')]")
    WebElement appName;

    @FindBy(xpath = "//button [@title='App Launcher']")
    WebElement appLauncher;

    @FindBy(xpath = "//input [@placeholder='Search apps and items...']")
    WebElement appSearchBar;

    @FindBy(xpath = "//p [@class='slds-truncate']")
    WebElement moodysDrpDwn;

    public By clearSelectedValueBtnOnEditPage(String fieldName){
        return By.xpath("(//label[text()='" + fieldName + "']/following::button[@title='Clear Selection'])[1]");
    }
    @FindBy(xpath = "//input[@name='FirstName']")
    public static WebElement firstNameTextField;

    @FindBy(xpath = "//input[@name='LastName']")
    public static WebElement lastNameTextField;

    @FindBy(xpath = "//input[@name='Email']")
    public static WebElement emailTextField;

    @FindBy(xpath = "//input[@name='Company']")
    public static WebElement companyTextField;

    @FindBy(xpath = "//input[@name='Email']")
    public static WebElement SFCDCEmailTextField;

    @FindBy(xpath = "//input[@name='Phone']")
    public static WebElement phoneTextField;

    @FindBy(xpath = "//input[@name='Title']")
    public static WebElement jobTitleTextField;

    @FindBy(xpath = "//input[@name='Street_1__c']")
    public static WebElement street1TextField;

    @FindBy(xpath= "//input[@name='City__c']")
    public static WebElement cityTextField;

    @FindBy(xpath = "//input[@name='Zip_Postal_Code__c']")
    public static WebElement zipPostalCodeTextField;

    public By lineItemIDLink(String productName, int multiYear){
        return By.xpath("(((//span[text()=\"" + productName + "\"])[" + multiYear + "])//preceding::a)[last()]" );
    }

    @FindBy(xpath = "//a[contains(@href,'AttributeValue__c')]")
    public WebElement attributeValueLink;

    @FindBy(xpath = "//input[@name='Send_to_Billing_Contract__c']")
    public WebElement sendToBillingContractCheckbox;

    @FindBy(xpath = "(//span[text()='Legacy Product Code']//following::lightning-formatted-text)[1]")
    WebElement legacyProductCodeValue;

    public By lineItemIDLinkAXISUserKeys(String productName, int multiYear){
        return By.xpath("(((//span[contains(text(),'" + productName + "')])[" + multiYear + "])//preceding::a)[last()]");
    }
    //Actions:

    /**
     * Extracts the Salesforce (SFDC) ID from a given URL.
     * This method uses a regular expression to find and return the SFDC ID
     * from the provided URL string. If the ID is not found, it returns null.
     *
     * @param url String - The URL from which to extract the SFDC ID.
     * @return String - The extracted SFDC ID, or null if not found.
     */
    public static String getSFDCIDFromURL(String url) {
        String extractedText = null;
        Pattern pattern = Pattern.compile("lightning/r/Lead/([^/]+)/view");

        Matcher matcher = pattern.matcher(url);
        if (matcher.find()) {
            extractedText = matcher.group(1);
        }
        return extractedText;
    }

    /**
     * Opens a Salesforce (SFDC) record by its ID.
     * This method constructs the URL for the record using the base URL of the current page
     * and the provided record ID. It then navigates to this URL to open the record.
     *
     * @param recordID String - The Salesforce (SFDC) ID of the record to open.
     */
    @Step("Open SFDC Record by ID: {recordID}")
    public static void openRecordBySFDCID(String recordID){
        String baseUrl = driver.getCurrentUrl();
        int index = baseUrl.indexOf(".force.com/");
        if (index != -1) {
            baseUrl = baseUrl.substring(0, index + ".force.com/".length());
        }
        String recordLink = baseUrl + recordID;
        loggerManager.getLogger().info("Opening SFDC link:" + recordLink);
        driver.get(recordLink);
        waitForPageTitleToContain(driver, " | Salesforce");
    }

    /**
     * This method extracts the Salesforce (SFDC) record ID from a given URL.
     * It uses a regular expression to match the 18 digit ID in the URL.
     * If a match is found, it returns the first 15 digits of the ID.
     * If no match is found, it returns null.
     *
     * @param url String - The URL from which to extract the SFDC record ID.
     * @return String - The 15 digit SFDC record ID if a match is found, null otherwise.
     */
    public static String getSFDCRecordIDFromURL(String url){
        // Regular expression to match the 18 digit ID
        String regex = "/([a-zA-Z0-9]{18})/";

        // Create a Pattern object
        Pattern pattern = Pattern.compile(regex);

        // Create a Matcher object
        Matcher matcher = pattern.matcher(url);

        // Check if the matcher found a match
        if (matcher.find()) {
            String id = matcher.group(1);
            return id.substring(0, id.length() - 3); // Return the 15 digit id
        } else
            return null;
    }

    /**
     * Opens a Salesforce (SFDC) record by its ID.
     *
     * @param objectName String - The name of the object.
     * @param recordName String - The name of the record to open.
     */
    @Step("Open {objectName} Record: {recordName} from Global Search")
    public void openSFDCRecordFromGlobalSearch(String objectName, String recordName){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, homeTab);
        elementClickByJS(driver, homeTab);
        waitForElementToBeVisible(driver, globalSearchBar);
        elementClick(driver, globalSearchBar);
        waitForElementToBeVisible(driver, globalSearchTextField);
        sendKeysToElement(driver, globalSearchTextField, recordName);
        globalSearchTextField.sendKeys(Keys.ENTER);
        waitForElementToBePresent(driver, objectFilterOnSearchResult(objectName));
        elementClick(driver, driver.findElement(objectFilterOnSearchResult(objectName)));
        waitForElementToBePresent(driver, searchResultRecord(recordName));
        elementClick(driver, driver.findElement(searchResultRecord(recordName)));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, recordName + " | ");
        Allure.step("Validate that " + objectName + ": " + recordName + " is opened in SFDC", step -> {
            Assert.assertTrue(driver.getTitle().contains(recordName + " | "), "Failed to open " + objectName + " record: " + recordName);
            ReusableLibrary.takeScreenshot(TCName, driver);
        });
    }

    /**
     * This method clicks on the Save button on the page.
     */
    @Step("Click Save Button")
    public void clickSaveBtn(){
        waitForElementToBeVisible(driver, saveButton);
        elementClickByJS(driver, saveButton);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks on the Save & New button on the page.
     */
    @Step("Click Save & New Button")
    public void clickSaveAndNewBtn(){
        waitForElementToBeVisible(driver, saveAndNewButton);
        takeScreenshot(TCName, driver);
        elementClickByJS(driver, saveAndNewButton);
    }


    /**
     * This method clicks on the New button to create a new SFDC Object Record.
     */
    @Step("Click New Button")
    public void clickNewBtn(){
        waitForElementToBeVisible(driver, newButton);
        takeScreenshot(TCName, driver);
        elementClickByJS(driver, newButton);
    }

    /**
     * This method clicks on the Next button on the Record Type Selection page.
     */
    @Step("Click Record Type Selection Next Button")
    public void clickRecordTypeSelectionNextBtn(){
        waitForElementToBeVisible(driver, recordTypeSelectionNextButton);
        takeScreenshot(TCName, driver);
        elementClick(driver, recordTypeSelectionNextButton);
    }

    /**
         * This method opens the Accounts tab.
         * If the Accounts tab is displayed on the home screen, it clicks on it.
         * Otherwise, it clicks on the "More" menu and then selects the Accounts tab from the dropdown.
         * It logs a message indicating from where the Accounts page was opened.
         */
        @Step("Open SFDC Tab: {tabName}")
        public void openSFDCTab(String tabName){
            waitForElementToBePresent(driver, objectTab(tabName));
            if (isElementDisplayed(driver, driver.findElement(objectTab(tabName)))) {
                executeJavaScript(driver, "arguments[0].click();", driver.findElement(objectTab(tabName)));
                loggerManager.getLogger().info("Clicked on " + tabName + " tab");
            }
            else {
                elementClick(driver, clickMoreMenu);
                executeJavaScript(driver, "arguments[0].click();", driver.findElement(objectTabInMoreMenu(tabName)));
                loggerManager.getLogger().info("Clicked on " + tabName + " tab from More Menu");
            }
            wait.until(ExpectedConditions.titleContains(tabName));
            Assert.assertTrue(driver.getTitle().contains(tabName), "Failed to open " + tabName + " page");
            takeScreenshot(TCName, driver);

    }

    /**
     * This method verifies that a button with the specified name is displayed on the page. * @param buttonName The name of the button to verify.
     */
    @Step("Verify that a button is displayed")
    public void verifyBtnIsDisplayed(String buttonName) {
        //refresh page to ensure elements are loaded and try to find the button
        pageRefresh(driver);
        waitForElementToBePresent(driver, btn(buttonName));
        if (isElementDisplayed(driver, driver.findElement(btn(buttonName)))) {
            Allure.step("Validate that " + buttonName + " button exists on page", step -> {
                Assert.assertTrue(isElementDisplayed(driver, driver.findElement(btn(buttonName))), buttonName + "button is not displayed");
                loggerManager.getLogger().info(buttonName + " button is successfully displayed");
            });
        } else {
            loggerManager.getLogger().error(buttonName + " button is not displayed");
            Assert.fail(buttonName + " button is not displayed");
        }
        takeScreenshot("verifyBtnIsDisplayed", driver);
    }

    /**
     * This method clicks on the most recently created item in a list and verifies that the item is opened successfully.
     * Steps:
     * 1. Clicks on the most recent item link.
      * 2. Asserts that the "Recently Viewed" text becomes invisible, indicating the item has been opened.
     */
    //this method assumes that user is on a page where all the recently created items are displayed
    @Step("Open recently created record")
    public void clickOnRecentlyCreatedRecord() {
        if (isElementDisplayed(driver, mostRecentFirstRecordLink)) {
            takeScreenshot("clickOnRecentlyCreatedItem", driver);
            elementClick(driver, mostRecentFirstRecordLink);
            Assert.assertTrue(wait.until(ExpectedConditions.invisibilityOf(recentlyViewedText)), "Not able to click on Recently Created Record");
            loggerManager.getLogger().info("Successfully able to open recently created item");
        } else {
            loggerManager.getLogger().error("First record in Recently Viewed items is not displayed");
            Assert.fail("First record in Recently Viewed items is not displayed");
        }
    }

    @Step(" Open SFDC Sub Tab: {tabName}")
    public void openSFDCSubTab(String tabName){
        waitForElementToBeClickable(driver, driver.findElement(subTabName(tabName)));
        elementClickByJS(driver, driver.findElement(subTabName(tabName)));
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks on the Edit button on the page.
     */
    @Step("Click on Edit button")
    public void clickEditBtn(){
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        try {
            waitForElementToBePresent(driver, editButton);
            waitForElementToBeVisible(driver, driver.findElement(editButton));
            elementClick(driver, driver.findElement(editButton));
        }
        catch (Exception e) {
            waitForElementToBeVisible(driver, showMoreActionsButton);
            elementClick(driver, showMoreActionsButton);
            waitForElementToBePresent(driver, editBtnUnderShowMore);
            elementClick(driver, driver.findElement(editBtnUnderShowMore));
        }
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, "Edit");
        Assert.assertTrue(driver.getTitle().contains("Edit"), "Failed to click on Edit button");
    }

    /**
     * This method selects the specified Record Type on the Record Type Selection page.
     *
     * @param recordType String - The Record Type to select.
     */
    @Step("Select Record Type: {recordType}")
    public void selectRecordType(String recordType) {
        waitForElementToBePresent(driver, recordTypeOption(recordType));
        waitForElementToBeVisible(driver, driver.findElement(recordTypeOption(recordType)));
        elementClick(driver, driver.findElement(recordTypeOption(recordType)));
        loggerManager.getLogger().info("Record Type selected as " + recordType);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks the "Save" button on a popup using the Action class.
     * It performs the following steps:
     * 1. Waits for the "Save" button on the popup to be visible.
     * 2. Uses the Action class to move to the "Save" button and click it.
     */
    @Step("Click Save Button by Action class")
    public void clickSaveBtnUsingActionClass(WebDriver driver){
        waitForElementToBeVisible(driver, saveButtononPopup);
        Actions actions = new Actions(driver);
        actions.moveToElement(saveButtononPopup).click().perform();
    }

    /**
     * This method clicks on the specified Quick Action on the page.
     * @param actionName The name of the Quick Action to click.
     */

    @Step("Click on {actionName} Quick Action")
    public void clickQuickAction(String actionName){
        waitForElementToBePresent(driver, quickAction(actionName));
        try {
            elementClick(driver, driver.findElement(quickAction(actionName)));
            loggerManager.getLogger().info("Clicked on " + actionName + " Quick Action");
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        }
        catch (Exception e){
            loggerManager.getLogger().error("Failed to click on " + actionName + " Quick Action with WebDriver");
            elementClickByJS(driver, driver.findElement(quickAction(actionName)));
            loggerManager.getLogger().info("Clicked on " + actionName + " Quick Action with JavaScript");
        }
    }

    @Step("Click on {relatedListName} Related List")
    public void clickOnRelatedList(String relatedListName){
        waitForElementToBePresent(driver, relatedList(relatedListName));
        elementClickByJS(driver, driver.findElement(relatedList(relatedListName)));
        loggerManager.getLogger().info("Clicked on " + relatedListName + " Related List");
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
    }

    /**
     * This method verifies the price of the line items on various SFDC Objects such as Quote/Proposal, Agreement, Order and Fulfillment
     * @param quoteData - The list of quote data.
     * @param lineItemsProductNames - The list of line items product names.
     * @param lineItemsPrice - The list of line items price.
     */
    @Step("Verify the price on the Line Items")
    public void verifyLineItemsPrice(List<LinkedHashMap<String, String>> quoteData, List<WebElement> lineItemsProductNames, List<WebElement> lineItemsPrice) {
    waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
    Map<String, Integer> productIndexMap = new HashMap<>();
    for (int i = 0; i < lineItemsProductNames.size(); i++) {
        String productName = getElementText(driver, lineItemsProductNames.get(i));
        productIndexMap.put(productName, i);
    }

    for (LinkedHashMap<String, String> data : quoteData) {
        String productName = data.get("ProductName");
        if (productIndexMap.containsKey(productName)) {
            int index = productIndexMap.get(productName);
            String[] actualPrice = getElementText(driver, lineItemsPrice.get(index)).split(" ");
            if (actualPrice.length < 2) {
                loggerManager.getLogger().error("Price format is incorrect for product: " + productName);
                continue;
            }
            String productType = data.get("ProductType");
            String pricingAtBundleHeader = data.get("PricingAtBundleHeader");

            if (productType.equals("Standalone")) {
                if (data.get("ZeroDollarProduct").equals("Y")) {
                    Assert.assertEquals(actualPrice[1], "0.00", "Product price is not zero for " + productName);
                    loggerManager.getLogger().info("Product price is zero for " + productName + ". Actual Price: " + lineItemsPrice.get(index).getText());
                } else {
                    Assert.assertNotEquals(actualPrice[1], "0.00", "Product price is zero for " + productName);
                    loggerManager.getLogger().info("Product price is non-zero for " + productName + ". Actual Price: " + lineItemsPrice.get(index).getText());
                }
            } else if (productType.equals("Bundle")) {
                String[] optionProducts = data.get("OptionProducts").split(",");
                if (pricingAtBundleHeader.equals("Y")) {
                    softAssert.assertNotEquals(actualPrice[1], "0.00", "Bundle header price is zero for " + productName);
                    loggerManager.getLogger().info("Bundle header price is non-zero for " + productName + ". Actual Price: " + lineItemsPrice.get(index).getText());
                    verifyOptionProductsPrice(optionProducts, productIndexMap, true, lineItemsPrice);
                } else if (pricingAtBundleHeader.equals("N")) {
                    softAssert.assertEquals(actualPrice[1], "0.00", "Bundle header price is not zero for " + productName);
                    loggerManager.getLogger().info("Bundle header price is zero for " + productName + ". Actual Price: " + lineItemsPrice.get(index).getText());
                    verifyOptionProductsPrice(optionProducts, productIndexMap, false, lineItemsPrice);
                }
            }
        } else {
            loggerManager.getLogger().error("Product name not found in the productIndexMap: " + productName);
        }
    }
    softAssert.assertAll();
}
    /**
     * This method verifies the price of the option products.
     * @param optionProducts The list of option products.
     * @param productIndexMap The map of product index.
     * @param isPricingAtBundleHeader The flag to indicate if pricing is at bundle header.
     * @param lineItemsPrice The list of line items price.
     */
    @Step("Verify option products price")
    private void verifyOptionProductsPrice(String[] optionProducts, Map<String, Integer> productIndexMap, boolean isPricingAtBundleHeader, List<WebElement> lineItemsPrice) {
        for (String optionProduct : optionProducts) {
            int index = productIndexMap.get(optionProduct);
            String[] optionPrice = getElementText(driver, lineItemsPrice.get(index)).split(" ");
            if (isPricingAtBundleHeader) {
                Assert.assertEquals(optionPrice[1], "0.00", "Option Product price is not zero where pricing is at bundle header");
                loggerManager.getLogger().info("Option Product price is zero where pricing is at bundle header. Actual Price: " + lineItemsPrice.get(index).getText());
            } else {
                Assert.assertNotEquals(optionPrice[1], "0.00", "Option Product price is zero where pricing is not at bundle header");
                loggerManager.getLogger().info("Option Product price is non-zero where pricing is not at bundle header. Actual Price: " + lineItemsPrice.get(index).getText());
            }
        }
    }


    /**
     * Switches to the specified app by its name.
     * This method performs the following steps:
     * 1. Waits for the App Launcher button to be visible.
     * 2. Clicks on the App Launcher button using JavaScript.
     * 3. Enters the app name in the search bar.
     * 4. Waits for the app name to appear in the dropdown.
     * 5. Clicks on the app name in the dropdown using JavaScript.
     * 6. Waits for the URL to contain "app".
     * 7. Waits for the app name to be visible on the header.
     * 8. Verifies that the current selected app matches the specified app name.
     * 9. Takes a screenshot of the selected app.
     *
     * @param nameOfApp The name of the app to switch to.
     */
    @Step("Switch to {nameOfApp} App")
    public void switchToApp(String nameOfApp) {
        waitForElementToBeVisible(driver,appLauncher);
        ReusableLibrary.elementClickByJS(driver, appLauncher);
        ReusableLibrary.sendKeysTypeAheadField( appSearchBar, nameOfApp);
        waitForElementToBePresent(driver,appNameInDropDown(nameOfApp));
        ReusableLibrary.elementClickByJS(driver, driver.findElement(appNameInDropDown(nameOfApp)));
        waitForUrlToContain(driver, "app");
        waitForElementToBeVisible(driver,appName);

        Allure.step("Check the current selected App", step-> {
            Assert.assertEquals(appName.getText(), nameOfApp);
            ReusableLibrary.takeScreenshot("switchto"+nameOfApp+"App", driver);
        });
    }
    /**
     * This method switches to the Moody's app.
     * It clicks on the App Launcher, searches for "Moodys", and selects the Moody's app from the dropdown.
     * It then verifies that the current selected app is "Moodys" by checking the app name.
     * If the app name matches, it takes a screenshot and logs the success.
     * If the app name does not match, it logs an error.
     */
    @Step("Switch to Moody's app")
    public void switchtoMoodysApp() {
        waitForElementToBeVisible(driver,appLauncher);
        ReusableLibrary.elementClick(driver, appLauncher);
        ReusableLibrary.sendKeysToElement(driver, appSearchBar, "Moodys");
        ReusableLibrary.elementClick(driver, moodysDrpDwn);
        waitForElementToBeVisible(driver,appName);
        //HS: removed the selectByVisibleText method as it is not required - under review
        //ReusableLibrary.selectByVisibleText(driver, moodysDrpDwn, "Moodys");
        Allure.step("Check the current selected App", step-> {
            Assert.assertEquals(appName.getText(), "Moodys");
            ReusableLibrary.takeScreenshot("switchtoMoodysApp", driver);
        });
    }


    /**
     * This method verifies that a field is renamed on a Salesforce (SFDC) record.
     * Note: Adding this method here since we do not have a dedicated page class for some objects for which data is not created manually, but from the backend. Ex. Sales Order, Sales Order Line, Usage and Overage by Asset, and Usage and Overage by Firm. But this can also be used objects other than these.
     * @param oldFieldName The old name of the field.
     * @param newFieldName The new name of the field.
     * @param scrollToElement The name of the field to scroll to for validating the field rename.
     */
    @Step("Verify that {oldFieldName} field is renamed to {newFieldName}")
    public void checkFieldRenameOnSFDCRecord(String oldFieldName, String newFieldName, String scrollToElement){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
        if(scrollToElement != null && !scrollToElement.isEmpty()){
            waitForElementToBePresent(driver, fieldLabel(scrollToElement));
            scrollToElement(driver, driver.findElement(fieldLabel(scrollToElement)));
        }
        waitForElementToBePresent(driver, fieldLabel(newFieldName));
        if(isElementDisplayed(driver, driver.findElement(fieldLabel(newFieldName))) && verifyFieldIsNotVisible(oldFieldName)){
            Assert.assertTrue(isElementDisplayed(driver, driver.findElement(fieldLabel(newFieldName))) && verifyFieldIsNotVisible(oldFieldName), newFieldName + " field is displayed on the page");
            loggerManager.getLogger().info(oldFieldName + " field is renamed to " + newFieldName);
        } else {
            loggerManager.getLogger().info(oldFieldName + " field is not renamed to " + newFieldName);
            Assert.fail(oldFieldName + " is not renamed to " + newFieldName);
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that a field with the specified name is not visible on the page.
     * @param fieldName The name of the field to verify.
     */
    @Step("Verify that {fieldName} field is not displayed on the page")
    public boolean verifyFieldIsNotVisible(String fieldName) {
        try {
            wait.until(ExpectedConditions.invisibilityOfElementLocated(fieldLabel(fieldName)));
            loggerManager.getLogger().info(fieldName + " field is not displayed on the page");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * This method clicks on the 'Show More Actions' button on the Lead page.
     * It uses JavaScript to perform the click action to ensure it works even if the button is not interactable through standard WebDriver click.
     * If the click action is successful, it logs a success message and takes a screenshot.
     * If an exception occurs, it logs an error message.
     */
    @Step("Step : Clicking on 'Show More Actions' button")
    public void clickShowMoreActionsBtn(){
        try{
            ReusableLibrary.elementClickByJS(driver, showMoreActionsButton);
            loggerManager.getLogger().info("'Show More Actions' button is clicked successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("'Show More Actions' button is not clicked successfully");
            Assert.assertTrue(false, "'Show More Actions' button is not clicked successfully");
        }
    }

    /**
     * This method verifies the value of fields on the Line Items and its associated Attribute Value record for different product Categories
     * @param quoteData - The list of quote details.
     */
    @Step("Verify the fields on Line Items for the Products")
    public void verifyFieldsOnLineItems(List<LinkedHashMap<String, String>> quoteData){
        lineItemsPageLink = driver.getCurrentUrl();
        String productCategory = "";
        if (TCName.contains("_"))
            productCategory = TCName.split("_")[1];
        int multiYearNumber = getMultiYearNumber();
        /**
         * This process the quote data for the specified number of years.
         * It iterates over the quote data and performs the necessary operations, handle both single and multi years.
         */
        for (int i = 0; i < multiYearNumber; i++) {
            loggerManager.getLogger().info("Processing year : " + (i + 1));
            for (LinkedHashMap<String, String> productData : quoteData) {
                driver.get(lineItemsPageLink);
                setScreenZoom(driver, 75);
                if ("AXIS User Keys".equals(productData.get("ProductName"))) {
                    waitForElementToBePresent(driver, lineItemIDLinkAXISUserKeys(productData.get("ProductName"), i + 1));
                    elementClickByJS(driver, driver.findElement(lineItemIDLinkAXISUserKeys(productData.get("ProductName"), i + 1)));
                } else {
                    waitForElementToBePresent(driver, lineItemIDLink(productData.get("ProductName"), i + 1));
                    elementClickByJS(driver, driver.findElement(lineItemIDLink(productData.get("ProductName"), i + 1)));
                }
                waitForPageTitleToContain(driver, "Line Item | Salesforce");
                Assert.assertTrue(driver.getTitle().contains("Line Item | Salesforce"), "Failed to navigate to Line Item from Apttus");
                loggerManager.getLogger().info("Successfully navigated to Line Item from Apttus");
                switch (productCategory) {
                    case "CorteraProducts":
                        verifySendToBillingContractCheckbox(productData);
                        clickOnAttributeValueLink();
                        verifyAttributeValueForCorteraUsageProducts(productData);
                        break;
                    case "CatylistProducts":
                        verifySendToBillingContractCheckbox(productData);
                        clickOnAttributeValueLink();
                        verifyAttributeValueForCatylistUsageProducts(productData);
                        break;
                    case "AxisProducts":
                        verifySendToBillingContractCheckbox(productData);
                        clickOnAttributeValueLink();
                        break;
                    case "RMSNonPackageProducts":
                        verifyLegacyProductCode(productData);
                        clickOnAttributeValueLink();
                        break;
                    case "RMSPackageProducts":
                        clickOnAttributeValueLink();
                        verifyAttributeValueForRMSPackageProducts(productData);
                        break;
                    case "KompanyProducts":
                        clickOnAttributeValueLink();
                        break;
                    default:
                        loggerManager.getLogger().error("Product Category is not valid");
                        break;
                }
                verifyAttributeValueForProducts(productData);
            }
        }
        setScreenZoom(driver, 100);
    }

    /**
     * This method clicks on the Attribute Value link on the Line Items page.
     */
    private void clickOnAttributeValueLink() {
        waitForElementToBeVisible(driver, attributeValueLink);
        elementClickByJS(driver, attributeValueLink);
    }

    /**
     * This method verifies the value of Send to Billing Contract checkbox on Line Items
     * @param productData - The list of product details.
     */
    @Step("Verify the value of Send to Billing Contract checkbox on Line Items")
    private void verifySendToBillingContractCheckbox(LinkedHashMap<String, String> productData) {
        waitForElementToBeVisible(driver, sendToBillingContractCheckbox);
        if (productData.get("SendToBillingContract").equals("Y")) {
            Assert.assertEquals(sendToBillingContractCheckbox.getAttribute("checked"), "true", "Send to Billing Contract checkbox is not checked");
            loggerManager.getLogger().info("Send to Billing Contract checkbox is checked as expected for usage product " + productData.get("ProductName"));
        } else {
            Assert.assertNull(sendToBillingContractCheckbox.getAttribute("checked"), "Send to Billing Contract checkbox is checked for non usage product" + productData.get("ProductName"));
            loggerManager.getLogger().info("Send to Billing Contract checkbox is not checked as expected for non usage product " + productData.get("ProductName"));
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the value of Products Attributes on the Attribute Value record associated with the Line Items
     * @param productData - The list of product details.
     */
    @Step("Verify that Products Attributes are displayed as expected on the Attribute Value record associated with the Line Items")
    public void verifyAttributeValueForProducts(LinkedHashMap<String, String> productData){
        verifyAttribute("Pricing Model", productData.get("ExpectedPricingModel"), productData.get("ProductName"));
        verifyAttribute("Delivery Channel", productData.get("ExpectedDeliveryChannel"), productData.get("ProductName"));
        verifyAttribute("Revenue Product Category", productData.get("ExpectedRevenueProductCategory"), productData.get("ProductName"));
        softAssert.assertAll();
    }

    /**
     * This method verifies the value of Option Products Attributes on the Attribute Value record associated with the Line Items
     * @param productData - The list of product details.
     */
    @Step("Verify that Option Products Attributes are displayed as expected on the Attribute Value record associated with the Line Items")
    public void verifyAttributeValueForOptionProducts(LinkedHashMap<String, String> productData){
        scrollToTop(driver);
        verifyAttribute("Pricing Model", productData.get("ExpectedPricingModelOnOption"), productData.get("ProductName"));
        verifyAttribute("Revenue Product Category", productData.get("ExpectedRevenueProductCategoryOnOption"), productData.get("ProductName"));
        verifyAttribute("Delivery Channel", productData.get("ExpectedDeliveryChannel"), productData.get("ProductName"));
        softAssert.assertAll();
    }

    /**
     * This method verifies the value of Cortera Usage Products Attributes on the Attribute Value record associated with the Line Items
     * @param productData - The list of product details.
     */
    @Step("Verify that Usage Products Attributes are displayed as expected on the Attribute Value record associated with the Line Items")
    public void verifyAttributeValueForCorteraUsageProducts(LinkedHashMap<String, String> productData) {
        if (!productData.get("SendToBillingContract").isEmpty() && productData.get("SendToBillingContract").equals("Y")) {
            {
                waitForElementToBePresent(driver, fieldLabel("Minimum Commitment Billing Cycle"));
                scrollToElement(driver, driver.findElement(fieldLabel("Minimum Commitment Billing Cycle")));
                verifyAttribute("Minimum Commitment Type", productData.get("Minimum Commitment Type_drp"), productData.get("ProductName"));

                if (productData.get("Minimum Commitment Coverage Term_drp") != null && !productData.get("Minimum Commitment Coverage Term_drp").isEmpty()) {
                    waitForElementToBePresent(driver, fieldLabel("Has Minimum Commitment"));
                    scrollToElement(driver, driver.findElement(fieldLabel("Has Minimum Commitment")));
                    verifyAttribute("Minimum Commitment Coverage Term", productData.get("Minimum Commitment Coverage Term_drp"), productData.get("ProductName"));
                }
                softAssert.assertAll();
            }
        }
    }

    /**
     * This method verifies the value of the specified attribute for the given product.
     * @param attributeName The name of the attribute to verify.
     * @param expectedValue The expected value of the attribute.
     * @param productName The name of the product.
     */
    @Step("Verify that the value of {attributeName} is {expectedValue} for {productName}")
    private void verifyAttribute(String attributeName, String expectedValue, String productName) {
        Allure.step("Verify that " + attributeName + " is " + expectedValue + " for " + productName, step -> {
            waitForElementToBePresent(driver, textFieldValue(attributeName));
            String actualValue = driver.findElement(textFieldValue(attributeName)).getText();
            if (actualValue.equals("")) {  // handle the case where the attribute value is empty in the UI and to match with spreadsheet data.
                actualValue = null;
            }
            softAssert.assertEquals(actualValue, expectedValue);
            loggerManager.getLogger().info(attributeName + " is displayed as expected for " + productName);
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the value of Catylist Usage Products Attributes on the Attribute Value record associated with the Line Items
     * @param productData - The list of product details.
     */
    @Step("Verify that Usage Products Attributes are displayed as expected on the Attribute Value record associated with the Line Items")
    public void verifyAttributeValueForCatylistUsageProducts(LinkedHashMap<String, String> productData) {
        if (!productData.get("SendToBillingContract").isEmpty() && productData.get("SendToBillingContract").equals("Y"))
        {
            waitForElementToBePresent(driver, fieldLabel("Minimum Commitment Billing Cycle"));
            scrollToElement(driver, driver.findElement(fieldLabel("Minimum Commitment Billing Cycle")));
            verifyAttribute("Minimum Commitment Type", productData.get("ExpectedMinimumCommitmentType"), productData.get("ProductName"));

            waitForElementToBePresent(driver, fieldLabel("Has Minimum Commitment"));
            scrollToElement(driver, driver.findElement(fieldLabel("Has Minimum Commitment")));
            verifyAttribute("Minimum Commitment Coverage Term", productData.get("ExpectedMinimumCommitmentCoverageTerm"), productData.get("ProductName"));
            softAssert.assertAll();
        }
    }

    /**
     * This method verifies the fields on the Option Line Items for the Usage Products
     * @param quoteData - The list of quote data.
     */
    @Step("Verify the fields on Option Line Items for the Usage Products")
    public void verifyFieldsOnOptionLineItemsForUsageProducts(List<LinkedHashMap<String, String>> quoteData){
        String productCategory = "";
        if (TCName.contains("_"))
            productCategory = TCName.split("_")[1];

        for (LinkedHashMap<String, String> productData : quoteData) {
            if (productData.get("ProductType").equals("Bundle")) {
                driver.get(lineItemsPageLink);
                setScreenZoom(driver, 75);
                waitForElementToBePresent(driver, lineItemIDLink(productData.get("OptionProducts"), 1)); // update integer parameter with multiyear variable when needed.
                elementClickByJS(driver, driver.findElement(lineItemIDLink(productData.get("OptionProducts"), 1))); // update integer parameter with multiyear variable when needed.
                waitForPageTitleToContain(driver, "Line Item | Salesforce");
                Assert.assertTrue(driver.getTitle().contains("Line Item | Salesforce"), "Failed to navigate to Line Item from Apttus");
                loggerManager.getLogger().info("Successfully navigated to Line Item from Apttus");
                switch (productCategory) {
                    case "CorteraProducts":
                        verifySendToBillingContractCheckbox(productData);
                        clickOnAttributeValueLink();
                        verifyAttributeValueForCorteraOptionProducts(productData);
                        break;
                    case "CatylistProducts":
                        verifySendToBillingContractCheckbox(productData);
                        clickOnAttributeValueLink();
                        verifyAttributeValueForCatylistOptionProducts(productData);
                        break;
                    default:
                        loggerManager.getLogger().error("Product Category is not valid");
                        break;
                }
                verifyAttributeValueForOptionProducts(productData);
            }
        }
        setScreenZoom(driver, 100);
    }

    /**
     * This method verifies the value of Cortera Usage Option Products Attributes on the Attribute Value record associated with the Line Items
     * @param productData - The list of product details.
     */
    @Step("Verify that Cortera Option Products Attributes are displayed as expected on the Attribute Value record associated with the Line Items")
    public void verifyAttributeValueForCorteraOptionProducts(LinkedHashMap<String, String> productData) {
        if (!productData.get("SendToBillingContract").isEmpty() && productData.get("SendToBillingContract").equals("Y")) {
            {
                waitForElementToBePresent(driver, fieldLabel("Minimum Commitment Billing Cycle"));
                scrollToElement(driver, driver.findElement(fieldLabel("Minimum Commitment Billing Cycle")));
                verifyAttribute("Minimum Commitment Type", productData.get("Minimum Commitment Type_drp"), productData.get("OptionProducts"));

                if (productData.get("Minimum Commitment Coverage Term_drp") != null && !productData.get("Minimum Commitment Coverage Term_drp").isEmpty()) {
                    waitForElementToBePresent(driver, fieldLabel("Has Minimum Commitment"));
                    scrollToElement(driver, driver.findElement(fieldLabel("Has Minimum Commitment")));
                    verifyAttribute("Minimum Commitment Coverage Term", productData.get("Minimum Commitment Coverage Term_drp"), productData.get("OptionProducts"));
                }
                softAssert.assertAll();
            }
        }
    }

    /**
     * This method verifies the value of Cortera Usage Option Products Attributes on the Attribute Value record associated with the Line Items
     * @param productData - The list of product details.
     */
    @Step("Verify that Catylist Option Products Attributes are displayed as expected on the Attribute Value record associated with the Line Items")
    public void verifyAttributeValueForCatylistOptionProducts(LinkedHashMap<String, String> productData) {
        if (!productData.get("SendToBillingContract").isEmpty() && productData.get("SendToBillingContract").equals("Y")) {
            {
                waitForElementToBePresent(driver, fieldLabel("Minimum Commitment Billing Cycle"));
                scrollToElement(driver, driver.findElement(fieldLabel("Minimum Commitment Billing Cycle")));
                verifyAttribute("Minimum Commitment Type", productData.get("ExpectedMinimumCommitmentType"), productData.get("OptionProducts"));

                if (productData.get("Minimum Commitment Coverage Term_drp") != null && !productData.get("Minimum Commitment Coverage Term_drp").isEmpty()) {
                    waitForElementToBePresent(driver, fieldLabel("Has Minimum Commitment"));
                    scrollToElement(driver, driver.findElement(fieldLabel("Has Minimum Commitment")));
                    verifyAttribute("Minimum Commitment Coverage Term", productData.get("ExpectedMinimumCommitmentCoverageTerm"), productData.get("OptionProducts"));
                }
                softAssert.assertAll();
            }
        }
    }

    @Step("Verify that RMS Package Products Attributes are displayed as expected on the Attribute Value record associated with the Line Items")
    public void verifyAttributeValueForRMSPackageProducts(LinkedHashMap<String, String> productData){
        waitForElementToBePresent(driver, fieldLabel("Overage Rate Tier3 – Risk Score"));
        scrollToElement(driver, driver.findElement(fieldLabel("Overage Rate Tier3 – Risk Score")));
        verifyAttribute("RMS Package Product Codes",productData.get("ExpectedRMSPackageProductCodes"),productData.get("ProductName"));
        verifyAttribute("RMS Package Product Names",productData.get("ExpectedRMSPackageProductNames"),productData.get("ProductName"));
        scrollToTop(driver);
    }

    @Step("Verify that Legacy Product Code is displayed as expected on the Line Items")
    public void verifyLegacyProductCode(LinkedHashMap<String, String> productData){
        waitForElementToBePresent(driver, fieldLabel("Revenue Product Category"));
        scrollToElement(driver, driver.findElement(fieldLabel("Revenue Product Category")));
        softAssert.assertEquals(legacyProductCodeValue.getText(), productData.get("ExpectedLegacyProductCode"), "Legacy Product Code is not displayed as expected");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method reads the "ContractTerm_Months" from the OpportunityData.xlsx file.
     * If the value is null or empty, it returns the default multiYearNumber.
     * Otherwise, it divides the value by 12 and returns the result.
     * @return int - The multi-year number.
     */
    public int getMultiYearNumber() {
        loggerManager.getLogger().info("Reading ContractTerm_Months from OpportunityData.xlsx");
        String contractTermMonths = readExcelData(opportunitiesFilePath, TCName, "ContractTerm_Months");
        if (contractTermMonths == null || contractTermMonths.isEmpty()) {
            loggerManager.getLogger().info("ContractTerm_Months is null or empty, returning default multiYearNumber: " + multiYearNumber);
            return multiYearNumber;
        } else {
            try {
                int contractTerm = Integer.parseInt(contractTermMonths);
                int result = contractTerm / 12;
                loggerManager.getLogger().info("ContractTerm_Months is valid, returning multiYearNumber: " + result);
                return result;
            } catch (NumberFormatException e) {
                loggerManager.getLogger().error("ContractTerm_Months is not a valid integer or is null", e);
                throw new RuntimeException("ContractTerm_Months is not a valid integer or is null");
            }
        }
    }
}