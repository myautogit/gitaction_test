package com.crm.qa.pages;
import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import static com.crm.qa.util.ReusableLibrary.*;
import static com.crm.qa.util.ReusableLibrary.waitForElementToBeVisible;

public class TaskPage extends TestBase {

    public TaskPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);

    }
    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);

    //Page Factory - OR:
    @FindBy(xpath = "//li[contains(@data-target-reveals,'NewTask')]//a[contains(@title,'more action')]")
    WebElement showMoreActionBtn;

    @FindBy(xpath = "//a[@title='New Task']")
    WebElement newTaskBtn;

    public WebElement TaskRecordTypeRadioButton(String taskType) {
        return driver.findElement(By.xpath("//h2[text()='New Task']/following::span[text()='"+taskType+"']"));
    }

    @FindBy(xpath = "(//label[text()='Subject']/following::input) [1]")
    WebElement taskSubjectTextField;

    @FindBy(xpath = "//span[text()='Lead Source']")
    WebElement leadSourceField;

    @FindBy(xpath = "//span[text()='Details']")
    WebElement detailsTab;
    @FindBy(xpath = "(//span[text()='Country']/following::span)[2]")
    WebElement countryFieldOfTask;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//div[@title='Edit']")
    WebElement editTaskButton;
    @FindBy(xpath = "//h2[text()='New Task']")
    WebElement newTaskText;

    @FindBy(xpath = "(//h2[contains(text(), 'Edit')]/following::span[text()='Country']/following::a) [1]")
    WebElement countryPicklist;
    public WebElement countryOption(String countryOptionValue) {
        return driver.findElement(By.xpath("//a[text()='"+countryOptionValue+"']"));
    }
    @FindBy(xpath = "//button[@title='Save']")
    WebElement saveTaskButton;
    @FindBy(xpath = "(//dt[@title='Name']/following::a[@data-refid ='recordId']) [1]")
    WebElement leadLink;
    @FindBy(xpath = "//div[text()='Task']")
    WebElement taskText;
    @FindBy(xpath = "//button[@title='Save']")
    WebElement leadTaskSaveButton;

    //Actions:

    /**
     * This method creates a new task in the application.
     * It performs the following steps:
     * 1. Clicks the "Show More Actions" button.
     * 2. Clicks the "New Task" button.
     * 3. Waits for the "New Task" text to be visible.
     * 4. Selects the specified task type.
     * 5. Validates that the task type is selected.
     * 6. Takes a screenshot of the selected task type.
     * 7. Clicks the "Next" button to proceed.
     * 8. Refreshes the page.
     * 9. Enters the task subject in the task creation form.
     * 10. Clicks the "Save" button to save the task.
     * 11. Waits until the "Save" button is no longer visible.
     *
     * @param taskType The type of task to be created.
     */
    @Step("Create a new task")
    public void createNewTask(String taskType) {
        //click show more actions button
        ReusableLibrary.waitForElementToBeClickable(driver, showMoreActionBtn);
        elementClickByJS(driver, showMoreActionBtn);
        //click new task button
        elementClickByJS(driver, newTaskBtn);
        ReusableLibrary.waitForElementToBeVisible(driver,newTaskText);
        //select task type
        reusableBusinessLibrary.selectRecordType(taskType);
        Allure.step("Validate that the Lead Task type is selected", step -> {
            Assert.assertTrue(isElementDisplayed(driver, TaskRecordTypeRadioButton(taskType)), "Failed to select Lead Task");
            loggerManager.getLogger().info("Lead Task Type successfully created");
        });
        takeScreenshot("selectLeadTaskType", driver);

        elementClick(driver, reusableBusinessLibrary.recordTypeSelectionNextButton);
        pageRefresh(driver);
        //enter task subject in task creation form
        waitForElementToBeVisible(driver, taskSubjectTextField);
        sendKeysToElement(driver, taskSubjectTextField, "Call");
        elementClick(driver, leadTaskSaveButton);
        wait.until(ExpectedConditions.invisibilityOf(leadTaskSaveButton));
    }
    /**
     * This method verifies that a task has been created successfully.
     * It performs the following steps:
     * 1. Validates that the "Details" tab is displayed, indicating the task creation was successful.
     * If the "Details" tab is not displayed, it logs an error message and fails the test.
     */
    @Step("Verify that task is created")
    public void verifyTaskISCreated(){
        Allure.step("Validate that the Lead Task is created in SFDC", step -> {
            Assert.assertTrue(isElementDisplayed(driver, detailsTab), "Failed to create Lead Task in SFDC");
            loggerManager.getLogger().info("Lead Task created successfully in SFDC");
        });
        takeScreenshot("verifyTaskISCreated", driver);
    }
    /**
     * This method verifies that the "Lead Source" field exists on the task.
     * It performs the following steps:
     * 1. Waits for the "Lead Source" field to be visible.
     * 2. Asserts that the "Lead Source" field is displayed.
     */
    @Step("Verify that lead source field exists on the task")
    public void verifyLeadSourceFieldExistsOnTask(){
        waitForElementToBeVisible(driver, leadSourceField);
        try{
            Assert.assertTrue(leadSourceField.isDisplayed());
            loggerManager.getLogger().info("'Lead Source' Field is available on lead record");
            ReusableLibrary.takeScreenshot("Verify Lead Source Field is displayed", driver);
        }
        catch(Exception e){
            Assert.fail("'Lead Source' Field is not available on lead record");
            loggerManager.getLogger().error("'Lead Source' Field is not available on lead record");
        }
    }
    /**
     * This method verifies that the Country value matches between the lead and the task.
     * It performs the following steps:
     * 1. Waits for the "Country" field of the task to be visible.
     * 2. Asserts that the "Country" field is not null.
     * 3. Compares the Country value of the task with the provided lead country value.
     * @param expectedCountryValue The expected Country value from the lead.
     */
    @Step("Verify that Country Value matches in lead and task")
    public void verifyCountryValueInTaskRecord(String expectedCountryValue){
        waitForElementToBeVisible(driver, detailsTab);
        pageRefresh(driver);
        waitForElementToBeVisible(driver, detailsTab);
        Assert.assertNotNull(getElementText(driver, countryFieldOfTask), "The country field in Task is null");
        Assert.assertEquals(getElementText(driver, countryFieldOfTask), expectedCountryValue, "Country value in Lead and Task do not match");
        loggerManager.getLogger().info("Country value in Lead and Task Match");
        ReusableLibrary.takeScreenshot("Verify Country Value Match in Lead and Task", driver);
    }

    /**
     * This method navigates to the lead associated with the task that is currently open on the screen.
     * It performs the following steps:
     * 1. Clicks on the lead link using JavaScript.
     * 2. Waits until the task text is no longer visible.
     * If any exception occurs during the process, it logs an error message and fails the test.
     */
    @Step ("navigate to lead associated With the task that is open on screen")
    public void navigateToLeadFromTaskPage(){
        try{
            ReusableLibrary.elementClickByJS(driver, leadLink);
            loggerManager.getLogger().info("Navigate to Lead Successfully ");
        }
        catch(Exception e){
            Assert.fail("Could not navigate to lead", e);
            loggerManager.getLogger().error("Could not navigate to lead");
        }
        wait.until(ExpectedConditions.invisibilityOf(taskText));
        ReusableLibrary.takeScreenshot("navigateToLead", driver);
    }
    /**
     * This method clicks the "Edit Task" button on the task page.
     * It performs the following steps:
     * 1. Attempts to click the "Edit Task" button using JavaScript.
     * 2. Asserts that the "Save" button is displayed, indicating the task is in edit mode.
     */
    @Step ("Edit the Task")
    public void clickEditTaskBtn(){
        try{
            ReusableLibrary.elementClickByJS(driver, editTaskButton);
            waitForElementToBeVisible(driver, saveTaskButton);
            Assert.assertTrue(isElementDisplayed(driver, saveTaskButton), "Edit Task button is not clicked successfully");
            loggerManager.getLogger().info("'Edit Task' button is clicked successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("'Edit Task' button is not clicked successfully");
        }}
    /**
     * This method updates the country field of the task.
     * It performs the following steps:
     * 1. Clicks the "Edit Task" button.
     * 2. Clicks the country picklist to open the dropdown.
     * 3. Scrolls to the specified country option and selects it.
     * 4. Clicks the "Save" button to save the changes.
     * 5. Waits until the "Save" button is no longer visible, indicating the changes have been saved.
     * @param countryName The name of the country to be selected.
     */
    @Step ("Update the country field of the task")
    public void updateTaskCountryField(String countryName){
        try{
            clickEditTaskBtn();
            elementClick(driver, countryPicklist);
            scrollToElement(driver, countryOption(countryName));
            elementClick(driver, countryOption(countryName));
            elementClick(driver, saveTaskButton);
            wait.until(ExpectedConditions.invisibilityOf(saveTaskButton));
            loggerManager.getLogger().info("Country field of the task has been updated");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Failed to update the country field of the task");
            Assert.fail("Failed to update the country field of the task");
        }
        ReusableLibrary.takeScreenshot("updateTaskCountryField", driver);
    }

}
