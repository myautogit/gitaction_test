package com.crm.qa.util;

import com.crm.qa.base.TestBase;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.getConfigProperty;
import static io.restassured.RestAssured.given;

/**
 This class provides methods to read and extract mail details using the Outlook API.
 Author: Arshin Shaikh
 Last Modified By: Arshin Shaikh
 Date: 08/02/2024
 Comment: Added methods to generate access token, read mails, and get mail details.
 */

public class OutlookSupport extends TestBase {

    private static final String OUTLOOK_AUTHORIZE_URL = getConfigProperty("OutlookAuthorizeURL");
    private static final String OUTLOOK_RESOURCE_URL = getConfigProperty("OutlookResourceURL");
    private static final String OUTLOOK_EMAIL_ADDRESS = getConfigProperty("OutlookEmailAddress");

    /**
     * This method generates an access token for the Outlook API.
     * It constructs the URL for the token request using the Outlook authorize URL and tenant ID.
     * It then sends a POST request to this URL with the necessary parameters (client ID, resource URL, client secret, and grant type).
     * If the response status code is not 200, it logs an error message with the status code and response body and returns null.
     * Otherwise, it extracts the access token from the response and returns it.
     *
     * @return The access token as a String, or null if the access token could not be generated.
     */
    public String generateAccessToken(){
        // Construct the URL for the token request
        String url = OUTLOOK_AUTHORIZE_URL + "/" + outlookTenantId + "/oauth2/token";

        // Send a POST request to the URL with the necessary parameters
        outlookAuthResponse = given()
                .formParam("client_id", outlookClientId)
                .formParam("resource", OUTLOOK_RESOURCE_URL)
                .formParam("client_secret",outlookClientSecret)
                .formParam("grant_type", "client_credentials")
                .post(url);


        // Check if the status code of the response is not 200 (HTTP OK)
        if (outlookAuthResponse.getStatusCode() != 200) {

            // If it's not 200, log an error message with the status code and response body
            loggerManager.getLogger().error("Failed to generate access token. Response code: " + outlookAuthResponse.getStatusCode() + ", Response: " + outlookAuthResponse.getBody().asString());

            // Return null to indicate that the access token could not be generated
            return null;
        }
        else{
            // Convert the response body to a string and create a JSONObject from it
            JSONObject jsonObject = new JSONObject(outlookAuthResponse.getBody().asString());

            // Retrieve the access token from the JSONObject and return it
            return jsonObject.getString("access_token");
        }
    }

    /**
     * This method reads mails from the Outlook API using the provided access token.
     * It constructs the URL for the mail request using the Outlook resource URL and the email address.
     * It then sends a GET request to this URL with the access token as the Authorization header.
     * If the response status code is not 200, it logs an error message with the status code and response body.
     * If the status code is 200, it logs a success message.
     */
    public void readMails() {

        // Generate an access token
        String accessToken = generateAccessToken();

        // Construct the URL for the mail request
        String url = OUTLOOK_RESOURCE_URL + "/v1.0/users/" + OUTLOOK_EMAIL_ADDRESS + "/messages";

        // Send a GET request to the URL with the access token as the Authorization header
        outlookMailResponse = given()
                .header("Authorization", "Bearer " + accessToken.replace("\"", ""))
                .get(url);

        // Check if the status code of the response is not 200 (HTTP OK)
        if (outlookAuthResponse.getStatusCode() != 200) {
            // If it's not 200, log an error message with the status code and response body
            loggerManager.getLogger().error("Failed to generate access token. Response code: " + outlookAuthResponse.getStatusCode() + ", Response: " + outlookAuthResponse.getBody().asString());
        } else {
            // If the status code is 200, log a success message
            loggerManager.getLogger().info("Emails read successfully");
        }
    }

    /**
     * This method retrieves the details of each mail from the Outlook API response.
     * It creates a list of maps where each map contains the details of a single mail.
     * The details include the subject, sender's name, sender's address, and the body of the mail.
     *
     * @return A List of Map objects where each Map contains the details of a single mail.
     */
    public List<Map<String, String>> getMailDetails() {
        // Create a new list to store the mail details
        List<Map<String, String>> mailsDetails = new ArrayList<>();

        // Convert the response body to a string and create a JSONObject from it
        JSONObject jsonObject = new JSONObject(outlookMailResponse.getBody().asString());

        // Retrieve the array of mails from the JSONObject
        JSONArray valueArray = jsonObject.getJSONArray("value");

        // For each mail in the array
        for (int i = 0; i < valueArray.length(); i++) {
            // Retrieve the mail object
            JSONObject mailObject = valueArray.getJSONObject(i);

            // Create a new map to store the details of the current mail
            Map<String, String> mailDetails = new HashMap<>();

            // Retrieve the subject, from name, from address, and body of the mail
            try {
                String id = mailObject.optString("id");
                String subject = mailObject.optString("subject");
                String fromName = mailObject.optJSONObject("from").optJSONObject("emailAddress").optString("name");
                String fromAddress = mailObject.optJSONObject("from").optJSONObject("emailAddress").optString("address");
                String emailBody = mailObject.optJSONObject("body").optString("content");
                
                // Parse the body to extract the text
                String bodyText = Jsoup.parse(emailBody).body().text();

                // Add the mail details to the map
                mailDetails.put("ID", id);
                mailDetails.put("Email Subject", subject);
                mailDetails.put("Email From Name", fromName);
                mailDetails.put("Email From Address", fromAddress);
                mailDetails.put("Email Body", bodyText);
            }
            catch (NullPointerException e){
                loggerManager.getLogger().error("Null value encountered while reading mail details: " + e.getMessage());
            }

            // Add the map to the list
            mailsDetails.add(mailDetails);
            loggerManager.getLogger().info("Mail " + i + ": "+ mailDetails + "\n");
        }

        // Return the list containing the mail details
        return mailsDetails;
    }

    /**
     * This method gets the name of the attachment from the email using the Outlook API.
     * It constructs the URL for the attachment request using the Outlook resource URL, email address, and email ID.
     * It then sends a GET request to this URL with the access token as the Authorization header.
     * If the response status code is not 200, it logs an error message with the status code and response body and returns null.
     * If the status code is 200, it logs a success message.
     * It then extracts the attachment name from the response and returns it.
     * @param emailID - The record ID of the email from the JSONResponse from which to get the attachment name.
     */
    public String getEmailAttachmentName(String emailID) {
        String attachmentName = null;
        // Generate an access token
        String accessToken = generateAccessToken();

        // Construct the URL for the mail request
        String url = OUTLOOK_RESOURCE_URL + "/v1.0/users/" + OUTLOOK_EMAIL_ADDRESS + "/messages/" + emailID + "/attachments";

        if(accessToken != null) {
            // Send a GET request to the URL with the access token as the Authorization header
            outlookMailResponse = given()
                    .header("Authorization", "Bearer " + accessToken.replace("\"", ""))
                    .get(url);

            // Check if the status code of the response is not 200 (HTTP OK)
            if (outlookAuthResponse.getStatusCode() != 200) {
                // If it's not 200, log an error message with the status code and response body
                loggerManager.getLogger().error("Failed to read the attachment details. Response code: " + outlookAuthResponse.getStatusCode() + ", Response: " + outlookAuthResponse.getBody().asString());
            } else {
                // If the status code is 200, log a success message
                loggerManager.getLogger().info("Attachment read successfully");
                // Convert the response body to a string and create a JSONObject from it
                JSONObject jsonObject = new JSONObject(outlookMailResponse.getBody().asString());

                // Retrieve the array of attachments from the JSONObject
                JSONArray valueArray = jsonObject.getJSONArray("value");
                // Retrieve the attachment object
                JSONObject mailAttachmentObject = valueArray.getJSONObject(0);
                attachmentName = mailAttachmentObject.optString("name");
            }
        }
        else {
            loggerManager.getLogger().error("Access token is null. Cannot read attachment details.");
        }
        return attachmentName;
    }

}