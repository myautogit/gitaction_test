package com.crm.qa.util;

import com.crm.qa.base.TestBase;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.openqa.selenium.TakesScreenshot;

// This class implements the ITestListener interface and provides custom implementation for the methods.
// It is used to add allure reporting capabilities to the test framework.
// Author: Sayon Das
// Last Modified By: Sayon Das
// Date: 06/21/2024
// Comment: Initial version of the AllureListener class. This class is used to capture Failed screenshots and attach them to the allure report.
public class AllureListener implements ITestListener {

 LoggerManager loggerManager = new LoggerManager(AllureListener.class.getName());

    public AllureListener() throws Exception {
    }

    // This method returns the name of the test method that is currently being executed.
 private static String getTestMethodName(ITestResult iTestResult) {
  return iTestResult.getMethod().getConstructorOrMethod().getName();
 }

 // This method captures a screenshot and attaches it to the allure report.
 @Attachment(value = "Page screenshot", type = "image/png")
 public byte[] saveScreenshotPNG (WebDriver driver) {
  return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
 }

 // This method attaches a text log to the allure report.
 @Attachment(value = "{0}", type = "text/plain")
 public static String saveTextLog(String message) {
  return message;
 }

 // This method attaches an HTML log to the allure report.
 @Attachment(value = "{0}", type = "text/html")
 public static String attachHtml(String html) {
  return html;
 }

 // This method is called before the start of the test suite.
 @Override
 public void onStart(ITestContext iTestContext) {
  loggerManager.getLogger().info("I am in onStart method " + iTestContext.getName());
  iTestContext.setAttribute("WebDriver", TestBase.getDriver());
 }

 // This method is called after the test suite has finished execution.
 @Override
 public void onFinish(ITestContext iTestContext) {
  loggerManager.getLogger().info("I am in onFinish method " + iTestContext.getName());
 }

 // This method is called before the start of each test method.
 @Override
 public void onTestStart(ITestResult iTestResult) {
  loggerManager.getLogger().info("I am in onTestStart method " + getTestMethodName(iTestResult) + " start");
 }

 // This method is called when a test method has passed.
 @Override
 public void onTestSuccess(ITestResult iTestResult) {
  loggerManager.getLogger().info("I am in onTestSuccess method " + getTestMethodName(iTestResult) + " passed");
 }

 // This method is called when a test method has failed.
 @Override
 public void onTestFailure(ITestResult iTestResult) {
  loggerManager.getLogger().error("I am in onTestFailure method " + getTestMethodName(iTestResult) + " failed");
  Object testClass = iTestResult.getInstance();
  WebDriver driver = TestBase.getDriver();
  if (driver instanceof WebDriver) {
   loggerManager.getLogger().info("Screenshot captured for test case: " + getTestMethodName(iTestResult));
   saveScreenshotPNG(driver);
  }
  saveTextLog(getTestMethodName(iTestResult) + " failed and screenshot taken!");
 }

 // This method is called when a test method has been skipped.
 @Override
 public void onTestSkipped(ITestResult iTestResult) {
  loggerManager.getLogger().warn("I am in onTestSkipped method " + getTestMethodName(iTestResult) + " skipped");
 }

 // This method is called when a test method has failed but it is within the success percentage.
 @Override
 public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {
  loggerManager.getLogger().warn("Test failed but it is in defined success ratio " + getTestMethodName(iTestResult));
 }
}