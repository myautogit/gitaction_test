package com.crm.qa.util;

public class WebEventListener {
}
