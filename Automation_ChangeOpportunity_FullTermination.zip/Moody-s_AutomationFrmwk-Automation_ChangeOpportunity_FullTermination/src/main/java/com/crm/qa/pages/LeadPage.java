package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.OutlookSupport;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableBusinessLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;

/**
 * This class contains methods related to the Lead functionality.
 * Author: Arshin Shaikh
 * Last Modified By: Arshin Shaikh
 * Date: 09/25/2024
 * Comment: Added elements and methods for automating the test cases from Lead #WF11
 */
public class LeadPage extends TestBase {

    public LeadPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);
    SoftAssert softAssert = new SoftAssert();
    OutlookSupport outlookSupport = new OutlookSupport();
    private String Temp1,Temp2;

    //Page Factory - OR:

    @FindBy(xpath = "//span[text()='All People']")
    WebElement allPeopleOption;

    @FindBy(xpath = "//button[text()='New']/ancestor::td[@class='x-btn-mc']")
    WebElement newButton;

    @FindBy(xpath = "//span[text()='New Person']")
    WebElement newPersonOption;



    @FindBy(xpath = "//span[text()='Create']")
    WebElement createButton;

    @FindBy(xpath = "//span[text()='People']")
    WebElement peopleTab;

    @FindBy(xpath = "//input[contains(@placeholder,'Quick Find')]")
    WebElement quickFindTextField;

    @FindBy(xpath = "//iframe[contains(@class, 'ClassicIframe')]")
    WebElement marketoIFrame;

    @FindBy(xpath = "(//a[@class='mktGridLink' and contains(@href, 'lead')])[last()]")
    WebElement leadLink;

    @FindBy(xpath = "//button[text()='Person Actions']")
    WebElement personActionButton;

    @FindBy(xpath = "//span[text()='Salesforce']")
    WebElement salesforceOption;

    @FindBy(xpath = "//span[contains(text(),'Sync Person to SFDC')]/parent::a")
    WebElement syncPersonToSFDCOption;

    @FindBy(xpath = "//span[contains(text(),'Create Task')]/parent::a")
    WebElement createTaskOption;

    @FindBy(xpath = "//button[text()='Run Now']")
    WebElement runNowButton;

    @FindBy(xpath = "//div[text()='People processed: 1']")
    WebElement peopleProcessedMessage;

    @FindBy(xpath = "//span[text()='Database' and contains(@class,'GlobalNavBar')]")
    WebElement marketoGlobalDatabaseTab;

    @FindBy(xpath = "//div[@data-id='TreeNodeDragSource_9']//button[@data-id]")
    WebElement systemSmartListsFolder;

    public By marketoLeadTab(String tabName) {
        return By.xpath("//span[text()='" + tabName + "']");
    }

    public By marketoLeadField(String fieldName) {
        return By.xpath("//input[@name='" + fieldName + "']");
    }

    public By marketoLeadDropdownOption(String optionValue) {
        return By.xpath("//div[contains(@class, 'combo-list-item') and text()='" + optionValue + "']");
    }

    public By sfdcRecordHeader(String leadName) {
        return By.xpath("//lightning-formatted-name[@slot='primaryField' and text()='" + leadName + "']");
    }

    public By sfdcLeadTextField(String fieldName) {
        return By.xpath("(//span[text()='" + fieldName + "']/following::span)[1]");
    }

    @FindBy(xpath = "//input[@name='HasOptedOutOfEmail']")
    WebElement globalEmailOptOutCheckbox;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//span[text()='Marketing VIP']")
    WebElement marketingVIPCheckboxSFDC;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//lightning-button-menu[contains(@class,'menu')]//button")
    WebElement showMoreActionsButton;

    @FindBy(xpath = "//li[contains(@data-aura-class,'DropDown')]")
    WebElement showMoreActionsButtonOnLeadTask;

    @FindBy(xpath = "//a/span[text()='Edit']")
    WebElement editButton;

    @FindBy(xpath = "//a/span[text()='Convert']")
    WebElement convertButton;

    @FindBy(xpath = "//span[contains(@class,'leadConvert')]/button")
    WebElement leadConvertButton;

    @FindBy(xpath = "//button[@name='Convert']")
    WebElement leadConvertRightPanelButton;

    @FindBy(xpath="//button[@name='Country__c']")
    WebElement countryPicklist;

    @FindBy(xpath="//div[contains(@class,'windowViewMode-normal')]//a[text()='Related']")
    WebElement relatedTab;

    public By convertedAccountAndOppyLink(String recordName) {
        return By.xpath("//div[contains(@class,'primaryField')]//a[text()='" + recordName + "']");
    }

    public By convertedContactLink(String contactName) {
        return By.xpath("//div[contains(@class,'primaryField')]//a[contains(text(),'" + contactName + "')]");
    }

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//a/span[text()='Open Activities']")
    WebElement openActivitiesRelatedList;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//a/span[text()='Activity History']")
    WebElement activityHistoryRelatedList;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//a[contains(@title,'Call|Email New Lead')]")
    WebElement leadTaskRecordLink;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//a[contains(@title,'Call')]")
    WebElement leadTaskCallRecordLink;

    public By leadTaskRecordNameLink(String taskName) {
        return By.xpath("//div[contains(@class,'Highlight')]//a[text()='" + taskName + "']");
    }

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//button[@title='Change Owner']")
    WebElement changeOwnerButton;

    @FindBy(xpath = "//input[@title='Search Users']")
    WebElement searchOwnerTextField;

    public By ownerOption(String ownerName) {
        return By.xpath("//div[@title='" + ownerName + "']/ancestor::a[@role='option']");
    }

    @FindBy(xpath = "//button[@value='change owner']")
    WebElement changeOwnerSaveButton;

    public @FindBy(xpath = "//span[contains(@class,'owner-name')]//slot")
    WebElement leadOwnerQueueName;

    public @FindBy(xpath = "//div[contains(@data-target-selection-name,'Task.Status')]//a")
    WebElement sfdcLeadTaskStatusDropdown;

    public @FindBy(xpath = "//div[contains(@data-target-selection-name,'Task.Reason')]//a")
    WebElement sfdcLeadTaskReasonDropdown;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//button[@title='Edit Status']")
    WebElement editLeadTaskStatusButton;

    public By leadTaskPicklistOption(String optionValue) {
        return By.xpath("//a[@title='" + optionValue + "']");
    }

    @FindBy(xpath = "//span[text()='Type']/following::span[text()='Task']")
    WebElement taskTypeText;

    @FindBy(xpath = "//div[contains(@class,'recordTypeName')]/span")
    WebElement leadRecordTypeText;

    @FindBy(xpath = "//input[@title='Search Campaigns']")
    WebElement campaignTextFieldOnLeadTaskForm;

    @FindBy(xpath = "//button[@title='Save']")
    WebElement leadTaskSaveButton;

    @FindBy(xpath = "//label[text()='Notify:']//following::input[contains(@placeholder,'Select')]")
    WebElement notifyTextField;

    @FindBy(xpath = "//div[text()='There are errors with some of the fields. They have been highlighted below']")
    WebElement marektoLeadError;

    @FindBy(xpath = "//input[contains(@placeholder,'Select')]")
    WebElement marketoAssignToDropdown;

    @FindBy(xpath = "//div[@class='header']//input[contains(@name,'Contact')]")
    WebElement chooseExistingContactRadioButton;

    @FindBy(xpath = "((//span[text()='Function'])[1]/following::lightning-formatted-text) [1]")
    WebElement functionValueText;

    @FindBy(xpath = "//div[text()='Validation error on Account: Update Lead: All Leads converting to new Contacts require a valid Country, Street, & City populated. For United States, Canada, & India locations, State & Zip/Postal Code are also required.']")
    WebElement missingAddressValidationError;

    @FindBy(xpath = "//button[text()='Cancel' and contains(@class,'leadConvertModalFooter')]")
    WebElement leadConvertCancelButton;

    @FindBy(xpath = "//h2[text()='Something went wrong.']/following::li[text()='Business Type cannot be blank once populated.']")
    WebElement missingBusinessTypeError;

    @FindBy(xpath = "//input[@title='Search for matching contacts']")
    WebElement searchContactTextField;

    @FindBy(xpath = "//li[contains(@class,'default uiAutocompleteOption')]/a")
    WebElement searchContactOption;

    @FindBy(xpath = "//span[text()=\"Don't create an opportunity upon conversion checkbox\"]/preceding-sibling::span")
    WebElement dontCreateOpportunityCheckbox;

    @FindBy(xpath = "//div[text()=\"Validation error on Contact: A contact with this email address already exists. Click 'Choose existing' option to search and select the contact using the email address to proceed. Please contact Data Ops team: moodyssfdcdataoperations@moodys.com for any assistance required.\"]")
    WebElement contactExistsValidationError;


    @FindBy(xpath = "//h2[text()='Your lead has been converted']")
    WebElement leadConvertedMessage;

    public By editRightPanelButton = By.xpath("//button[text()='Edit']");

    @FindBy(xpath = "(//div[contains(@class,'windowViewMode-normal')]//a[text()='Details'])[1]")
    WebElement detailsTab;

    @FindBy(xpath = "//a[@title='New Task']")
    WebElement newTaskButton;


    @FindBy(xpath = "//a[@title='Convert to Opportunity']")
    WebElement convertToOpportunityButtonOnLeadTask;

    @FindBy(xpath = "//div[text()='This task is associated with Lead. You may need to covert Lead.']")
    WebElement leadTaskConversionMessage;

    @FindBy(xpath = "//div[@class='header']//input[contains(@name,'Account')]")
    WebElement chooseExistingAccountRadioButton;

    @FindBy(xpath = "//input[@title='Search for matching accounts']")
    WebElement searchAccountTextField;

    @FindBy(xpath = "//div[text()='Validation error on Contact: Update Lead: All Leads converting to new Contacts require a valid Country, Street, & City populated. For United States, Canada, & India locations, State & Zip/Postal Code are also required.']")
    WebElement missingContactAddressValidationError;


    @FindBy(xpath = "//span[text()='Update Address/Phone']")
    WebElement updateAddressPhoneBtn ;

    @FindBy(xpath = "//input[@type='search' and @part='input']")
    WebElement searchAccountName;

    WebElement selectAccountName(String accountName){
        return driver.findElement(By.xpath("//div[@data-mainfield='"+accountName+"']"));
    }

    @FindBy(xpath = "//input[@name='input-9']/parent::span[@class='slds-radio']")
    WebElement accAddressBtn;

    @FindBy(xpath = "//input[@name='input-10']/parent::span[@class='slds-radio']")
    WebElement accPhoneBtn;


    @FindBy(xpath = "//span[text()='Phone']//following::lightning-formatted-phone[1]")
    WebElement leadPhoneValue;

    @FindBy(xpath = "(//p[text()='Country']/following::p) [1]")
    WebElement leadCountryValue;

    @FindBy(xpath = "//span[text()='Street 1']//following::lightning-formatted-text[1]")
    WebElement leadStreet1Value;

    @FindBy(xpath = "//span[text()='City']//following::lightning-formatted-text[1]")
    WebElement leadCityValue;

    @FindBy(xpath = "//span[text()='State']//following::lightning-formatted-text[1]")
    WebElement leadStateValue;

    @FindBy(xpath = "//span[text()='Zip/Postal Code']//following::lightning-formatted-text[1]")
    WebElement leadPostalCodeValue;

    @FindBy(xpath = "//input[@name='input-9']/following::div[1]")
    WebElement updateBtnAddressDetails;

    @FindBy(xpath = "//input[@name='input-10']//following::div[1]")
    WebElement updateBtnPhoneDetails;

    @FindBy(xpath = "//input[@name='Lead_Source_Detail__c']")
    WebElement leadSourceDetailTextField;

    @FindBy(xpath = "//textarea[@name='Description']")
    WebElement descriptionTextField;

    @FindBy(xpath = "//input[@name='Website']")
    WebElement websiteTextField;

    @FindBy(xpath = "//slot[contains(@class,'header__title')]//lightning-formatted-name[@slot='primaryField']")
    WebElement leadNameOnHeader;

    @FindBy(xpath = "//span[text()='Name']/following::lightning-formatted-name[@slot='outputField']")
    WebElement leadNameOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Company']//following::lightning-formatted-text)[1]")
    WebElement companyOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Business Type']//following::lightning-formatted-text)[1]")
    WebElement businessTypeOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Phone']//following::lightning-formatted-phone)[1]")
    WebElement phoneOnLeadRecord;

    @FindBy(xpath = "//span[text()='Email']//ancestor::dt//following-sibling::dd//a")
    WebElement emailOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Country']//following::lightning-formatted-text)[1]")
    WebElement countryOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Street 1']//following::lightning-formatted-text)[1]")
    WebElement street1OnLeadRecord;

    @FindBy(xpath = "(//span[text()='City']//following::lightning-formatted-text)[1]")
    WebElement cityOnLeadRecord;

    @FindBy(xpath = "(//span[text()='State']//following::lightning-formatted-text)[1]")
    WebElement stateOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Zip/Postal Code']//following::lightning-formatted-text)[1]")
    WebElement zipCodeOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Lead Source Detail']//following::lightning-formatted-text)[1]")
    WebElement leadSourceDetailOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Description']//following::lightning-formatted-text)[1]")
    WebElement descriptionOnLeadRecord;

    @FindBy(xpath = "//span[text()='Website']//following::lightning-formatted-url//a")
    WebElement websiteOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Job Title (Free Text)']//following::lightning-formatted-text)[1]")
    WebElement jobTitleOnLeadRecord;

    @FindBy(xpath = "(//span[text()='Lead Status']//following::lightning-formatted-text)[1]")
    WebElement statusOnLeadRecord;

    @FindBy(xpath = "//h2[@title='An error has occurred']")
    WebElement errorAlert;

    @FindBy(xpath = "//a[@id='detailTab__item']")
    WebElement detailsTabOnLead;

    @FindBy(xpath = "//h3[text()='Account']")
    WebElement accountHeaderLeadConversionTab;

    @FindBy(xpath = "//div[@class='']//li[contains(@class,'default uiAutocompleteOption')]/a")
    WebElement searchOption;

    public By convertedStatusOption(String status){
        return By.xpath("//span[text()='" + status + "']");
    }

    @FindBy(xpath = "//button[@aria-label='Converted Status']")
    WebElement convertedStatusDropdown;

    @FindBy(xpath = "//button[@name='Status']")
    WebElement statusDropdown;

    @FindBy(xpath = "//div[text()='Complete this field.'] [1]")
    WebElement warningToCompleteField;

    @FindBy(xpath = "//input[@name='firstName']")
    WebElement firstNameTextFieldMarketo;

    @FindBy(xpath = "//input[@name='lastName']")
    WebElement lastNameTextFieldMarketo;

    @FindBy(xpath = "//input[@name='email']")
    WebElement emailTextFieldMarketo;

    @FindBy(xpath = "//input[@name='company']")
    WebElement companyTextFieldMarketo;

    //Actions:

    /**
     * This method creates a lead in Marketo with the provided lead data.
     * It generates a random email for the lead, navigates to the Marketo page, fills in the lead details,
     * and creates the lead. It then verifies the lead creation and writes the lead details to an Excel file.
     *
     * @param leadData LinkedHashMap<String, String> - The data for the lead to be created.
     * @return String - The full name of the created lead.
     */
    @Step("Create a lead in Marketo")
    public String createLeadInMarketo(LinkedHashMap<String, String> leadData) {
        String firstName = readExcelData(leadsFilePath, TCName, "First Name");
        String lastName = readExcelData(leadsFilePath, TCName, "Last Name");

        if (lastName.contains("_"))
            lastName = lastName.substring(0, lastName.indexOf("_"));

        lastName = lastName + "_Automation" + generateRandomNumber(4);

        sfdcLeadEmail = generateRandomString("testuser") + "_" + generateRandomNumber(3) + "@automationtest.com";

        companyText = leadData.get("Company") + generateRandomString("_Auto");
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        elementClick(driver, marketoGlobalDatabaseTab);
        waitforFrametoLoad(driver, marketoIFrame);
        elementClick(driver, newButton);
        elementClick(driver, newPersonOption);
        sendKeysToElement(driver, firstNameTextFieldMarketo, firstName);
        sendKeysToElement(driver, lastNameTextFieldMarketo, lastName);
        sendKeysToElement(driver, companyTextFieldMarketo, companyText);
        elementClick(driver, createButton);
        verifyLeadCreationErrorInMarketo();
        elementClick(driver, createButton);
        sendKeysToElement(driver, emailTextFieldMarketo, sfdcLeadEmail);
        elementClick(driver, createButton);
        switchToDefaultContent(driver);
        elementClickByJS(driver, systemSmartListsFolder);
        elementClickByJS(driver, allPeopleOption);

        switchToIframeByXpath(driver, marketoIFrame);
        waitForElementToBeVisible(driver, peopleTab);
        elementClickByJS(driver, peopleTab);
        sendKeysToElement(driver, quickFindTextField, firstName + " " + lastName);
        try {
            // Add a small delay
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        sendKeysToElement(driver, quickFindTextField, Keys.ENTER + "");

        try {
            Thread.sleep(20000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error("Error occurred while waiting for the page to load" + e.getMessage());
        }

        elementClickByJS(driver, leadLink);
        switchToDefaultContent(driver);

        // Switch to the new tab and close the old one
        switchToWindowByNumber(driver, 1);
        switchToWindowByNumber(driver, 0);
        driver.close();
        switchToWindowByNumber(driver, 0);


        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
            wait.until(ExpectedConditions.titleIs(firstName + " " + lastName + " - " + companyText));
            Assert.assertEquals(driver.getTitle(), firstName + " " + lastName + " - " + companyText, "Lead creation failed");
            loggerManager.getLogger().info("Lead created successfully");

            String leadTitle = firstName + " " + lastName + " - " + companyText;
            Allure.step("Validate that the Lead is created successfully", step->{
                Assert.assertEquals(driver.getTitle(), leadTitle, "Lead creation failed");
            });
        }
        catch (NoSuchElementException | TimeoutException e){
            loggerManager.getLogger().error("Lead creation failed" + e.getMessage());
        }

        takeScreenshot(TCName, driver);

        marketoLeadURL = getUrl();
        writeToExcel(leadsFilePath, TCName, "Last Name", lastName);
        writeToExcel(leadsFilePath, TCName, "Marketo Lead URL", marketoLeadURL);
        writeToExcel(leadsFilePath, TCName, "Email", sfdcLeadEmail);


        return firstName + " " + lastName;
    }

    /**
     * This method syncs a lead to Salesforce from Marketo.
     * It first clicks on the person action button, moves to the Salesforce option and clicks on the sync person to SFDC option.
     * After a brief pause, it clicks on the run now button.
     * It then validates that the lead has been successfully synced to Salesforce.
     */
    @Step("Sync Lead to SFDC")
    public void syncLeadToSFDC(){
        waitForElementToBeVisible(driver, personActionButton);
        elementClick(driver, personActionButton);
        moveToElement(driver, salesforceOption);
        elementClick(driver, syncPersonToSFDCOption);
        waitForElementToBeVisible(driver, marketoAssignToDropdown);
        waitForElementToBeClickable(driver, marketoAssignToDropdown);
        elementClick(driver, runNowButton);

        try {
            Allure.step("Validate that the Lead is synced to SFDC", step -> {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
                wait.until(ExpectedConditions.visibilityOf(peopleProcessedMessage));
                loggerManager.getLogger().info("Lead synced to SFDC successfully");
                softAssert.assertTrue(peopleProcessedMessage.isDisplayed(), "Lead sync to SFDC failed");
            });
        }
        catch (NoSuchElementException | TimeoutException e){
            loggerManager.getLogger().error("Lead sync to SFDC failed");
            softAssert.fail("Lead sync to SFDC failed");
        }
        softAssert.assertAll();
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method retrieves the Salesforce Lead ID from Marketo.
     * It first waits for the page to load, then navigates to the "SFDC Custom Fields" tab.
     * It finds the "LeadId" field and retrieves its value.
     * The method then writes this ID to an Excel file for future reference.
     *
     * @return String - The Salesforce Lead ID retrieved from Marketo.
     */
    @Step("Get SFDC Lead ID from Marketo")
    public String getSFDCLeadIDFromMarketo(){
        try {
            Thread.sleep(15000);
            driver.navigate().refresh();
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        navigateToMarketoLeadTab("SFDC Custom Fields");
        WebElement leadSFDCID = driver.findElement(marketoLeadField("LeadId"));
        scrollToElement(driver, leadSFDCID);
        sfdcLeadID = leadSFDCID.getAttribute("value");
        Allure.step("Validate that the SFDC Lead ID is found in Marketo", step->{
            Assert.assertTrue(!sfdcLeadID.equals(""), "SFDC Lead ID not found in Marketo");
        });
        loggerManager.getLogger().info("SFDC Lead ID: " + sfdcLeadID);
        writeToExcel(leadsFilePath, TCName, "SFDC Lead ID", sfdcLeadID);
        takeScreenshot(TCName, driver);
        return sfdcLeadID;
    }

    /**
     * This method opens a Salesforce record by its ID.
     * It first retrieves the base URL of the current page, then constructs the URL for the record by appending the record ID.
     * Finally, it navigates to the constructed URL.
     *
     * @param recordID String - The ID of the Salesforce record to be opened.
     */
    @Step("Open SFDC Record by ID")
    public void openLeadRecordByID(String recordID){
        String baseUrl = getUrl();
        int index = baseUrl.indexOf(".force.com/");
        if (index != -1) {
            baseUrl = baseUrl.substring(0, index + ".force.com/".length());
        }
        String recordLink = baseUrl + recordID;
        loggerManager.getLogger().info("Opening SFDC link:" + recordLink);
        driver.get(recordLink);
        waitForElementToBeVisible(driver, detailsTabOnLead);
        ReusableLibrary.elementClickByJS(driver, detailsTabOnLead);
        waitForElementToBeVisible(driver, leadNameOnLeadRecord);
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies if a record is present in Salesforce (SFDC).
     * It first tries to find the record by its name in SFDC. If the record is found, it logs a success message.
     * If the record is not found, it logs an error message.
     * After the verification, it takes a screenshot of the current state.
     *
     * @param recordName String - The name of the record to be verified.
     */
    @Step("Verify if the record is present in SFDC")
    public void verifyRecordInSFDC(String recordName){
        waitForPageToLoad(Duration.ofSeconds(60));
        waitForPageTitle(driver, recordName + " | Lead | Salesforce");

        try {
            Allure.step("Validate that the record is found in SFDC", step-> {
                waitForElementToBeVisible(driver, driver.findElement(sfdcRecordHeader(recordName)));
                Assert.assertTrue(isElementDisplayed(driver, driver.findElement(sfdcRecordHeader(recordName))), recordName + " Record not found in SFDC");
                loggerManager.getLogger().info(recordName + " Record found in SFDC");
            });
        } catch (NoSuchElementException | TimeoutException e)  {
            loggerManager.getLogger().error("Could not locate the element" + recordName + " " + e.getMessage());
            Assert.assertTrue(false, recordName + " Record not found in SFDC");
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method updates a text field in Marketo with the provided field name and value.
     * It first locates the text field by its name, then clears any existing value and inputs the new value.
     * After the update, it validates that the field value has been updated correctly.
     * If the field is not found, it logs an error message.
     * Finally, it takes a screenshot of the current state.
     *
     * @param fieldName String - The name of the field to be updated.
     * @param fieldValue String - The new value for the field.
     */
    @Step("Update Lead Text Field in Marketo")
    public void updateLeadTextFieldInMarketo(String fieldName, String fieldValue){
        WebElement textField = driver.findElement(marketoLeadField(fieldName));
        scrollToElement(driver, textField);
        textField.clear();
        sendKeysToElement(driver, textField, fieldValue);

        try {
            Allure.step("Validate that " + fieldName + " is updated to " + fieldValue + " in SFDC", step-> {
                Assert.assertEquals(textField.getAttribute("value"),fieldValue, fieldName + " is not updated to " + fieldValue + " in Marketo");
                loggerManager.getLogger().info(fieldName + " is updated to " + fieldValue + " in Marketo");
            });
        } catch (NoSuchElementException | TimeoutException e)  {
            loggerManager.getLogger().error("Could not locate the element" + fieldName + " " + e.getMessage());
        }

        ReusableLibrary.takeScreenshot(TCName, driver);

    }

    /**
     * This method updates a dropdown field in Marketo with the provided field name and value.
     * It first locates the dropdown field by its name, then clears any existing value and inputs the new value.
     * After the update, it validates that the field value has been updated correctly.
     * If the field is not found, it logs an error message.
     * Finally, it takes a screenshot of the current state.
     *
     * @param fieldName String - The name of the field to be updated.
     * @param fieldValue String - The new value for the field.
     */
    @Step("Update Lead DropDown Field in Marketo")
    public void updateLeadDropdownFieldInMarketo(String fieldName, String fieldValue){

        WebElement dropDownField = driver.findElement(marketoLeadField(fieldName));
        scrollToElement(driver, dropDownField);
        dropDownField.clear();
        sendKeysTypeAheadField(dropDownField, fieldValue);
        waitForElementToBePresent(driver, marketoLeadDropdownOption(fieldValue));
        waitForElementToBeVisible(driver, driver.findElement(marketoLeadDropdownOption(fieldValue)));
        waitForElementToBeClickable(driver, driver.findElement(marketoLeadDropdownOption(fieldValue)));
        elementClick(driver, driver.findElement(marketoLeadDropdownOption(fieldValue)));

        try {
            waitForElementToBeVisible(driver, dropDownField);
            Allure.step("Validate that the field " + fieldName + " is updated to " + fieldValue + " in SFDC", step-> {
                Assert.assertEquals(dropDownField.getAttribute("value"), fieldValue, fieldName + " is not updated in Marketo");
                loggerManager.getLogger().info(fieldName + " is updated to " + fieldValue + " in Marketo");
            });
        } catch (NoSuchElementException | TimeoutException e)  {
            loggerManager.getLogger().error("Could not locate the element" + fieldName + " " + e.getMessage());
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the value of a specific field in Salesforce (SFDC).
     * It first locates the field by its name, then retrieves its value.
     * It then compares this value with the expected value and logs a success message if they match.
     * If the field is not found, it logs an error message.
     * If the values do not match, it logs an error message.
     * Finally, it takes a screenshot of the current state.
     *
     * @param fieldName String - The name of the field to be verified.
     * @param expectedValue String - The expected value of the field.
     */
    @Step("Verify Lead Field Value in SFDC")
    public void verifyLeadFieldValueInSFDC(String fieldName, String expectedValue){
        waitForElementToBePresent(driver, sfdcLeadTextField(fieldName));
        waitForElementToBeVisible(driver, driver.findElement(sfdcLeadTextField(fieldName)));
        WebElement element = driver.findElement(sfdcLeadTextField(fieldName));
        scrollToElement(driver, element);
        String elementValue = element.getText();
        try {
            Allure.step("Validate that the field " + fieldName + " is updated to " + expectedValue + " in SFDC", step-> {
                Assert.assertEquals(elementValue, expectedValue, fieldName + " field value not updated in SFDC");
                loggerManager.getLogger().info(fieldName + " field value updated to " + expectedValue + " in SFDC");
            });
        } catch (NoSuchElementException | TimeoutException e)  {
            loggerManager.getLogger().error("Could not locate the element" + fieldName + " " + e.getMessage());
        }
        catch (AssertionError e){
            loggerManager.getLogger().error(fieldName + " field value not updated to " + expectedValue + "in SFDC" + e.getMessage());
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method navigates to a specific tab in Marketo.
     * It first locates the tab by its name, then clicks on it to navigate to the tab.
     *
     * @param tabName String - The name of the tab to navigate to.
     */
    public void navigateToMarketoLeadTab(String tabName){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBePresent(driver, marketoLeadTab(tabName));
        waitForElementToBeVisible(driver, driver.findElement(marketoLeadTab(tabName)));
        elementClick(driver, driver.findElement(marketoLeadTab(tabName)));
    }

    /**
     * This method selects a checkbox in Marketo based on the provided field name.
     * It first waits for the page to load, then locates the checkbox by its name.
     * If the checkbox is not already selected, it selects the checkbox.
     * After the checkbox is selected, it validates that the checkbox is indeed selected.
     * If the checkbox is not found, it logs an error message.
     * Finally, it takes a screenshot of the current state.
     *
     * @param fieldName String - The name of the checkbox field to be selected.
     */
    @Step("Select Checkbox in Marketo")
    public void selectCheckBoxInMarketo(String fieldName){
        waitForElementToBeVisible(driver, driver.findElement(marketoLeadField(fieldName)));
        waitForElementToBeClickable(driver, driver.findElement(marketoLeadField(fieldName)));
        WebElement checkbox = driver.findElement(marketoLeadField(fieldName));
        scrollToElement(driver, checkbox);
        if (!checkbox.isSelected())
            elementClick(driver, checkbox);

        try {
            Allure.step("Validate that the checkbox " + fieldName + " is checked in Marketo", step-> {
                Assert.assertTrue(checkbox.isSelected(), "Could not check " + fieldName + " in Marketo");
                loggerManager.getLogger().info(fieldName + " checkbox is checked in Marketo");
            });
        } catch (NoSuchElementException | TimeoutException e)  {
            loggerManager.getLogger().error("Could not locate the element " + checkbox + " " + e.getMessage());
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the value of the Global Email Opt Out checkbox in Salesforce (SFDC).
     * It first waits for the page to load, then locates the checkbox and retrieves its value.
     * It then compares this value with the expected value and logs a success message if they match.
     * If the values do not match, it logs an error message.
     *
     * @param expectedValue boolean - The expected value of the Global Email Opt Out checkbox.
     */
    @Step("Verify the value of Global Email Opt Out Checkbox in SFDC")
    public void verifyGlobalEmailOptOutCheckboxInSFDC(boolean expectedValue){
        scrollToElement(driver, globalEmailOptOutCheckbox);
        boolean globalEmailOptOut = globalEmailOptOutCheckbox.isSelected();

        if (globalEmailOptOut == expectedValue) {
            loggerManager.getLogger().info("Global Email Opt Out checkbox is set to " + expectedValue + " as expected in SFDC");
            Assert.assertTrue(true, "Global Email Opt Out checkbox is not set to " + expectedValue + " as expected in SFDC");
        } else {
            loggerManager.getLogger().error("Global Email Opt Out checkbox is not set to " + expectedValue + " in SFDC");
            Assert.assertTrue(true, "Global Email Opt Out checkbox is not set to " + expectedValue + " as expected in SFDC");
        }
        takeScreenshot(TCName, driver);
    }


    /**
     * This method updates the Lead fields in Marketo.
     * It first refreshes the page, then navigates to the "Info" tab.
     * It updates the "Country", "Job Title", and "Lead Source" fields with new values.
     * It also selects the "Unsubscribed" checkbox.
     * After updating the fields, it navigates to the "SFDC Custom Fields" tab and selects the "Marketing VIP" checkbox.
     * Finally, it navigates to the "Custom" tab.
     */
    @Step("Update Lead Fields in Marketo")
    public void updateLeadFieldsInMarketo(){
        driver.navigate().refresh();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        switchToDefaultContent(driver);
        navigateToMarketoLeadTab("Info");
        updateLeadTextFieldInMarketo("Country","Kosovo");
        updateLeadDropdownFieldInMarketo("Job Title", "Head of AML/KYC/ Onboarding/Financial crime");
        if (!TCName.contains("_MarketingUser")) {
            updateLeadDropdownFieldInMarketo("Lead Source", "AdWords");
        }
        selectCheckBoxInMarketo("Unsubscribed");
        navigateToMarketoLeadTab("Custom");
    }

    /**
     * This method verifies the field values in Salesforce (SFDC) that were updated in Marketo.
     * It first refreshes the page, then waits for the page to load.
     * It verifies the "Country", "Job Title", "Lead Source", "Global Email Opt Out", and "Marketing VIP" fields.
     */
    @Step("Verify the field values in SFDC that were updated in Marketo")
    public void verifyFieldUpdateInSFDC(){
        driver.navigate().refresh();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, detailsTab);
        elementClick(driver, detailsTab);
        verifyLeadFieldValueInSFDC("Country", "Kosovo");
        verifyLeadFieldValueInSFDC("Job Title (Free Text)", "Head of AML/KYC/ Onboarding/Financial crime");
        if (!TCName.contains("_MarketingUser")) {
            verifyLeadFieldValueInSFDC("Lead Source", "AdWords");
        }
        verifyGlobalEmailOptOutCheckboxInSFDC(true);
    }

    /**
     * This method verifies the field values in Salesforce (SFDC) that were updated in Marketo.
     * It first refreshes the page, then waits for the page to load.
     * It verifies the "Country", "Job Title", "Lead Source", "Global Email Opt Out", and "Marketing VIP" fields.
     */
    @Step("Verify the Lead Status Dropdown Option Values in SFDC")
    public void verifyStatusDropdownOptionValues(String expectedValues) {

        reusableBusinessLibrary.clickEditBtn();
        waitForElementToBeVisible(driver, statusDropdown);
        statusDropdown.click();
        List<WebElement> options = driver.findElements(By.tagName("lightning-base-combobox-item"));
        String[] expectedValuesArray = expectedValues.split(",");

        for (int i = 0; i < options.size() - 1; i++) {
            String actualValue = options.get(i+1).getAttribute("value");
            String expectedValue = expectedValuesArray[i];
            if(actualValue.equals(""))
                continue;

            if (actualValue.equals(expectedValue)) {
                loggerManager.getLogger().info("Expected value: " + expectedValue + " matches with Actual value: " + actualValue);
                softAssert.assertEquals(actualValue,expectedValue, "Mismatch found: Expected - " + expectedValue + ", Actual - " + actualValue);
            }
            else{
                loggerManager.getLogger().error("Mismatch found: Expected - " + expectedValue + ", Actual - " + actualValue);
                softAssert.assertEquals(actualValue,expectedValue, "Mismatch found: Expected - " + expectedValue + ", Actual - " + actualValue);
            }
        }
        softAssert.assertAll();
    }

    /**
     * This method fills the lead details in Salesforce (SFDC) using the provided lead data.
     * It selects the business type, inputs the phone number, selects the primary country, inputs the primary street, city, state, and zip/postal code.
     * After filling the details, it clicks the save button and waits for the page to load.
     * It then switches to the default content.
     *
     * @param leadData LinkedHashMap<String, String> - The data for the lead details to be filled.
     */
    @Step("Fill Lead Details in SFDC")
    public void fillLeadDetailsInSFDC(LinkedHashMap<String, String> leadData){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, firstNameTextField);

        elementClickByJS(driver,driver.findElement(picklistButtonElement("Business Type")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Business Type",leadData.get("Business Type"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Business Type",leadData.get("Business Type"))));

        phoneTextField.clear();
        sendKeysToElement(driver, phoneTextField, leadData.get("Phone"));

        elementClickByJS(driver,driver.findElement(picklistButtonElement("Lead Source")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Lead Source",leadData.get("Lead Source"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Lead Source",leadData.get("Lead Source"))));

        scrollToElement(driver, driver.findElement(picklistButtonElement("Country")));
        elementClickByJS(driver,driver.findElement(picklistButtonElement("Country")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Country",readExcelData(leadsFilePath, TCName,"Primary Country"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Country",readExcelData(leadsFilePath, TCName,"Primary Country"))));
        sendKeysToElement(driver, street1TextField, leadData.get("Primary Street 1"));
        sendKeysToElement(driver, cityTextField, leadData.get("Primary City"));

        elementClickByJS(driver,driver.findElement(picklistButtonElement("State")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("State",readExcelData(leadsFilePath, TCName,"Primary State"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("State",readExcelData(leadsFilePath, TCName,"Primary State"))));

        zipPostalCodeTextField.clear();
        if (leadData.get("Primary Zip/Postal Code") != null)
            sendKeysToElement(driver, zipPostalCodeTextField, leadData.get("Primary Zip/Postal Code"));
        reusableBusinessLibrary.clickSaveBtn();
        if(isElementDisplayed(driver, reusableBusinessLibrary.addressValidationConfirmButton))
        {
            elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
            loggerManager.getLogger().info("Clicked on Address Validation Confirm button successfully.");
        }
        else {
            loggerManager.getLogger().info("Address Validation Confirm button not displayed. Saving lead without clicking on the address validation confirm button.");
        }
        waitForAlertAndAccept(driver, Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, showMoreActionsButton);
        waitForElementToBeClickable(driver, showMoreActionsButton);
        Allure.step("Validate that the Lead details are saved", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Lead details not saved");
            loggerManager.getLogger().info("Lead details saved successfully");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method updates the Lead fields in Salesforce (SFDC) using the provided lead data.
     * It first clicks on the "Show More Actions" button, then clicks on the "Edit" button.
     * After a brief pause, it selects the "Marketing VIP" checkbox, updates the "Status", "Sector", "Division", and "Function" fields.
     * After updating the fields, it clicks the save button and waits for the page to load.
     * It then switches to the default content.
     *
     * @param leadData LinkedHashMap<String, String> - The data for the lead details to be updated.
     */
    @Step("Update Lead Details in SFDC")
    public void updateLeadFieldsInSFDC(LinkedHashMap<String, String> leadData){
        reusableBusinessLibrary.clickEditBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        if (!TCName.contains("_MarketingUser")) {
            waitForElementToBeVisible(driver, marketingVIPCheckboxSFDC);
            elementClickByJS(driver, marketingVIPCheckboxSFDC);
        }
        waitForElementToBePresent(driver, picklistButtonElement("Lead Status"));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Lead Status")));
        waitForElementToBePresent(driver, picklistButtonElementOption("Lead Status", leadData.get("Status")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Lead Status", leadData.get("Status"))));

        scrollToElement(driver, driver.findElement(picklistButtonElement("Sector")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Sector")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Sector", leadData.get("Sector"))));

        elementClickByJS(driver, driver.findElement(picklistButtonElement("Division")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Division", leadData.get("Division"))));

        elementClickByJS(driver, driver.findElement(picklistButtonElement("Function")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Function", leadData.get("Function"))));

/*
        This code is commented out as Lead Source field is no longer available on the UI

        waitForElementToBePresent(driver, picklistButtonElement("Lead Source"));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Lead Source")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Lead Source", leadData.get("Lead Source"))));
*/

        reusableBusinessLibrary.clickSaveBtn();
        waitForAlertAndAccept(driver, Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        switchToDefaultContent(driver);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the field values in Marketo that were updated in Salesforce (SFDC).
     * It first refreshes the page, then navigates to the "SFDC Custom Fields" tab.
     * It verifies the "BvD Sector", "BvD Division", "BvD Use-Case", and "Marketing VIP" fields.
     * After the verification, it navigates to the "Info" tab and verifies the "Lead Status" field.
     * Finally, it takes a screenshot of the current state.
     * @param leadData LinkedHashMap<String, String> - The data for the lead details to be verified.
     */
    @Step("Verify the field values in Marketo that were updated in SFDC")
    public void verifyFieldUpdateInMarketo(LinkedHashMap<String, String> leadData){
        driver.navigate().refresh();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        navigateToMarketoLeadTab("SFDC Custom Fields");
        verifyTextFieldInMarketo("BvD Sector", leadData.get("Sector"));
        verifyTextFieldInMarketo("BvD Division", leadData.get("Division"));
        if(TCName.contains("SalesRep"))
            verifyTextFieldInMarketo("Function", leadData.get("Function"));
        else
            verifyTextFieldInMarketo("BvD Use-Case", leadData.get("Function"));
        if (!TCName.contains("_MarketingUser")) {
            verifyMarketingVIPCheckboxInMarketo();
        }
        navigateToMarketoLeadTab("Info");
        verifyTextFieldInMarketo("Lead Status", leadData.get("Status"));
        takeScreenshot(TCName, driver);
    }


    /**
     * This method verifies the value of a specific field in Marketo.
     * It first locates the field by its name, then retrieves its value.
     * It then compares this value with the expected value and logs a success message if they match.
     * If the field is not found, it logs an error message.
     * Finally, it takes a screenshot of the current state.
     *
     * @param fieldName String - The name of the field to be verified.
     * @param expectedValue String - The expected value of the field.
     */
    public void verifyTextFieldInMarketo(String fieldName, String expectedValue){
        WebElement element = driver.findElement(marketoLeadField(fieldName));
        scrollToElement(driver, element);
        String actualValue = element.getAttribute("value");
        try {
            Allure.step("Validate that the field " + fieldName + " value is updated to " + expectedValue + " in Marketo", step-> {
                Assert.assertEquals(actualValue, expectedValue, fieldName + " field value not updated in Marketo");
                loggerManager.getLogger().info("Field value updated to " + expectedValue + " in Marketo");
            });
        } catch (NoSuchElementException | TimeoutException e)  {
            loggerManager.getLogger().error("Could not locate the element" + element + " " + e.getMessage());
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the value of the Marketing VIP checkbox in Marketo.
     * It first locates the checkbox and retrieves its value.
     * It then compares this value with the expected value and logs a success message if they match.
     * If the checkbox is not found, it logs an error message.
     * Finally, it takes a screenshot of the current state.
     */
    public void verifyMarketingVIPCheckboxInMarketo(){
        Allure.step("Validate that the Marketing VIP checkbox is selected", step->{
            waitForElementToBeVisible(driver, driver.findElement(marketoLeadField("Marketing VIP")));
            WebElement marketingVIPCheckbox = driver.findElement(marketoLeadField("Marketing VIP"));
            boolean isSelected = marketingVIPCheckbox.isSelected();

            if (isSelected)
                loggerManager.getLogger().info("Marketing VIP checkbox is checked in Marketo");
            else
                loggerManager.getLogger().error("Marketing VIP checkbox is not checked in Marketo");

            Assert.assertTrue(isSelected, "Marketing VIP checkbox is not checked in Marketo");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method creates a lead task in Marketo.
     * It first navigates to the "Custom" tab, then refreshes the page and waits for it to load.
     * It clicks on the person action button, moves to the Salesforce option and clicks on the create task option.
     * After a brief pause, it inputs "true" into the notify text field and clicks on the run now button.
     * It then validates that the lead task has been successfully created in Marketo.
     */
    @Step("Create Lead Task in Marketo")
    public void createLeadTaskInMarketo(){
        navigateToMarketoLeadTab("Custom");
        driver.navigate().refresh();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        elementClick(driver, personActionButton);
        moveToElement(driver, salesforceOption);
        elementClick(driver, createTaskOption);
        waitForElementToBeVisible(driver, notifyTextField);
        sendKeysToElement(driver, notifyTextField, "true");
        elementClick(driver, runNowButton);

        Allure.step("Validate that Lead Task is created in Marketo", step -> {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
            wait.until(ExpectedConditions.visibilityOf(peopleProcessedMessage));
            loggerManager.getLogger().info("Lead task created in Marketo successfully");
            Assert.assertTrue(isElementDisplayed(driver,peopleProcessedMessage), "Lead task creation failed in Marketo");
        });

        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the lead task created in Marketo is synced to Salesforce (SFDC).
     * It first navigates to the "Related" tab, then clicks on the "Open Activities" related list.
     * It then clicks on the lead task record link and validates that the lead task is synced to SFDC.
     *
     * @param leadName String - The name of the lead task to be verified.
     */
    @Step("Verify Lead Task sync created in Marketo is synced to SFDC")
    public void verifyLeadTaskCreationInSFDC(String leadName){
        elementClick(driver, relatedTab);
        elementClick(driver, openActivitiesRelatedList);
        elementClick(driver, leadTaskRecordLink);
        waitForElementToBePresent(driver, leadTaskRecordNameLink(leadName));
        boolean isLeadTaskNameDisplayed = driver.findElement(leadTaskRecordNameLink(leadName)).isDisplayed();

        Allure.step("Validate that Lead Task is synced to SFDC ", step -> {
            if (isLeadTaskNameDisplayed) {
                loggerManager.getLogger().info("Lead Task " + leadName + " created successfully in SFDC");
                sfdcLeadTaskURL = getUrl();
            }
            else
                loggerManager.getLogger().error("Lead Task creation failed in SFDC");
            Assert.assertTrue(isLeadTaskNameDisplayed, "Lead Task creation failed in SFDC");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method changes the owner of a lead in Salesforce (SFDC).
     * It first waits for the page to load, then clicks on the "Change Owner" button.
     * It clears the "Search Owner" text field, then inputs the new owner's name.
     * It then selects the new owner from the dropdown and clicks on the "Save" button.
     *
     * @param ownerName String - The name of the new owner.
     */
    @Step("Change Lead Owner in SFDC")
    public void changeLeadOwner(String ownerName){
        waitForElementToBeVisible(driver, detailsTab);
        elementClick(driver, detailsTab);
        waitForElementToBeVisible(driver, changeOwnerButton);
        elementClick(driver, changeOwnerButton);
        waitForElementToBeVisible(driver, searchOwnerTextField);
        waitForElementToBeClickable(driver, searchOwnerTextField);
        searchOwnerTextField.clear();
        sendKeysTypeAheadField(searchOwnerTextField, ownerName);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        loggerManager.getLogger().info("Option for owner name " + ownerName + " is displayed: "+  isElementPresent(driver, ownerOption(ownerName)));
        waitForElementToBePresent(driver, ownerOption(ownerName));
        waitForElementToBeVisible(driver, driver.findElement(ownerOption(ownerName)));
        elementClick(driver, driver.findElement(ownerOption(ownerName)));
        elementClick(driver, changeOwnerSaveButton);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the lead owner has been successfully changed in Salesforce (SFDC).
     * It first waits for the page to load, then retrieves the new owner's name.
     * It then compares this name with the expected owner's name and logs a success message if they match.
     * If the owner's name does not match, it logs an error message.
     * Finally, it takes a screenshot of the current state.
     *
     * @param expectedOwner String - The expected name of the new owner.
     */
    @Step("Verify the Lead Owner is {expectedOwner}")
    public void verifyLeadOwner(String expectedOwner, WebElement ownerElement){
        waitForElementToBeVisible(driver, detailsTab);
        elementClick(driver, detailsTab);
        scrollToElement(driver, ownerElement);
        String actualOwner = ownerElement.getText();
        try {
            Allure.step("Validate that the Lead Owner is " + expectedOwner, step -> {
                Assert.assertEquals(actualOwner, expectedOwner, "Lead Owner not " + expectedOwner);
                loggerManager.getLogger().info("Lead Owner is " + expectedOwner);
            });
        } catch (NoSuchElementException | TimeoutException e) {
            loggerManager.getLogger().error("Lead Owner is not " + expectedOwner);
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the options of the Lead Task Status dropdown in Salesforce (SFDC).
     * It first splits the expected options by comma to get an array of expected options.
     * It then waits for 5 seconds to ensure the page is fully loaded.
     * It scrolls down the page by 300 pixels and clicks on the "Edit Lead Task Status" button.
     * It then clicks on the "SFDC Lead Task Status" dropdown.
     * For each expected option, it checks if the option is displayed in the dropdown.
     * If the option is displayed, it logs a success message.
     * If the option is not displayed, it logs an error message.
     * It then asserts that the actual option matches the expected option.
     * Finally, it asserts all the assertions using SoftAssert.
     *
     * @param expectedOptions String - The expected options of the Lead Task Status dropdown, separated by comma.
     */
    public void verifyLeadTaskStatusOptions(String expectedOptions){
        String[] expectedOptionsArray = expectedOptions.split(",");

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().info(e.getMessage());
        }

        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 300);");
        elementClickByJS(driver, editLeadTaskStatusButton);
        waitForElementToBeVisible(driver, sfdcLeadTaskStatusDropdown);
        waitForElementToBeClickable(driver, sfdcLeadTaskStatusDropdown);
        elementClickByJS(driver, sfdcLeadTaskStatusDropdown);

        for (String s : expectedOptionsArray) {

            if (isElementDisplayed(driver, driver.findElement(leadTaskPicklistOption(s)))) {
                loggerManager.getLogger().info("Lead Task Status Expected value: " + s + " matches with Actual value");
            } else {
                loggerManager.getLogger().error("Failed: Lead Task Status Expected value: " + s + " does not match with Actual value");
            }
            softAssert.assertEquals(driver.findElement(leadTaskPicklistOption(s)).getText(), s, "Lead Task Status Expected value: " + s + " does not match with Actual value");
        }
        softAssert.assertAll();
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the Lead Task record has Type as Task in Salesforce (SFDC).
     * It first checks if the "Task Type" text is displayed on the page.
     * If the text is displayed, it logs a success message.
     * If the text is not displayed, it catches the NoSuchElementException or TimeoutException and logs an error message.
     * Finally, it takes a screenshot of the current state.
     */
    @Step("Verify that the Lead Task record has Type as Task")
    public void verifyLeadTaskType(){
        try {
            Allure.step("Validate that the Lead Task record has Type as Task", step -> {
                Assert.assertTrue(isElementDisplayed(driver, taskTypeText), "Lead Task record does not have Type as Task");
                loggerManager.getLogger().info("Lead Task record has Type as Task");
            });
        } catch (NoSuchElementException | TimeoutException e) {
            loggerManager.getLogger().error("Lead Task record does not have Type as Task");
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the Lead Record Type is MA Leads in Salesforce (SFDC).
     * It first checks if the "Lead Record Type" is displayed as MA Leads on the page.
     * If the text is displayed, it logs a success message.
     * If the text is not displayed, it catches the NoSuchElementException or TimeoutException and logs an error message.
     * Finally, it takes a screenshot of the current state.
     */
    @Step("Verify that the Lead Record Type is MA Leads")
    public void verifyLeadRecordType(){
        try {
            Allure.step("Validate that the Lead Record Type is MA Leads", step -> {
                Assert.assertEquals(leadRecordTypeText.getText(), "MA Leads", "Lead Record Type is not MA Leads");
                loggerManager.getLogger().info("Lead Record Type is MA Leads");
            });
        } catch (NoSuchElementException | TimeoutException e) {
            loggerManager.getLogger().error("Lead Record Type is not MA Leads");
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method updates the status of a Lead Task in Salesforce (SFDC).
     * @param status String - The new status to be set for the Lead Task.
     */
    @Step("Update Lead Task Status to {status}")
    public void updateLeadTaskStatus(String status){
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().info(e.getMessage());
        }

        js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 300);");

        elementClickByJS(driver, editLeadTaskStatusButton);
        elementClickByJS(driver, sfdcLeadTaskStatusDropdown);
        elementClickByJS(driver, driver.findElement(leadTaskPicklistOption(status)));

        if (status.equals("Closed - Return to Marketing")) {
            elementClickByJS(driver, sfdcLeadTaskReasonDropdown);
            elementClickByJS(driver, driver.findElement(leadTaskPicklistOption("No budget")));
        }
        else if (status.equals("Closed - Not Qualified")) {
            elementClickByJS(driver, sfdcLeadTaskReasonDropdown);
            elementClickByJS(driver, driver.findElement(leadTaskPicklistOption("Duplicate")));
        }

        elementClick(driver, leadTaskSaveButton);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));

        try {
            Allure.step("Validate that the Lead Task Status is updated to " + status, step -> {
                Assert.assertEquals(sfdcLeadTaskStatusDropdown.getText(), status, "Lead Task Status not updated to " + status);
                loggerManager.getLogger().info("Lead Task Status updated to " + status);
            });
        } catch (NoSuchElementException | TimeoutException e) {
            loggerManager.getLogger().error("Lead Task Status not updated to " + status);
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method checks if the Lead Task record is present in the specified Related List in Salesforce (SFDC).
     * It first clicks on the "Related" tab, then clicks on the specified Related List.
     * It then checks if the Lead Task record link is displayed on the page.
     *
     * @param relatedListElement WebElement - The Related List in which to check for the Lead Task record.
     * @return boolean - Returns true if the Lead Task record link is displayed, false otherwise.
     */
    @Step("Verify the Lead Task record is present in the Related List {relatedListElement}")
    public boolean checkLeadTaskInRelatedList(WebElement relatedListElement){
        waitForElementToBeVisible(driver, relatedTab);
        waitForElementToBeClickable(driver, relatedTab);
        elementClickByJS(driver, relatedTab);
        waitForElementToBeVisible(driver, relatedListElement);
        elementClickByJS(driver, relatedListElement);
        waitForElementToBeVisible(driver, leadTaskRecordLink);
        takeScreenshot(TCName, driver);
        return leadTaskRecordLink.isDisplayed();
    }

    /**
     * This method verifies the location of the Lead Task record in Salesforce (SFDC) based on its status.
     * It first checks the status of the Lead Task record.
     * If the status is "Working", "Converted to Opportunity", "Closed - Return to Marketing", or "Closed - Not Qualified", it checks if the Lead Task record is present in the "Activity History" related list.
     * If the status is "Follow up Not Started", it checks if the Lead Task record is present in the "Open Activities" related list.
     * If the status does not match any of the above, it logs an error message.
     *
     * @param status String - The status of the Lead Task record.
     */
    @Step("Verify the Lead Task record location by status {status}")
    public void verifyLeadTaskLocationByStatus(String status){
        Allure.step("Verify the Lead Task record is located in the expected related list as per its status", step -> {

            if(status.equals("Working") | status.equals("Converted to Opportunity") | status.equals("Closed - Return to Marketing") | status.equals("Closed - Not Qualified")){
                Assert.assertTrue(checkLeadTaskInRelatedList(activityHistoryRelatedList), "Lead Task record not found in Activity History related list");
                loggerManager.getLogger().info("Lead Task record in " +  status + " status found in Activity History related list");
            }
            else if(status.equals("Follow up Not Started")){
                Assert.assertTrue(checkLeadTaskInRelatedList(openActivitiesRelatedList), "Lead Task record not found in Open Activities related list");
                loggerManager.getLogger().info("Lead Task record in " +  status + " status found in Open Activities related list");
            }
            else
                loggerManager.getLogger().error(status + " is not a valid status for a Lead Task record");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies the location of the Lead Task record in Salesforce (SFDC) for all status values.
     * It first defines an array of statuses.
     * For each status in the array, it navigates to the SFDC Lead Task URL, updates the Lead Task status, opens the SFDC record by ID, clicks on the "Related" tab, and verifies the Lead Task location by status.
     *
     * @param sfdcLeadRecordID String - The ID of the SFDC Lead Record.
     */
    @Step("Verify the Lead Task record location for all status values")
    public void verifyLeadTaskLocation(String sfdcLeadRecordID){
        String[] statuses = {"Working", "Follow up Not Started", "Converted to Opportunity", "Closed - Return to Marketing", "Closed - Not Qualified"};

        for (String status : statuses) {
            driver.get(sfdcLeadTaskURL);
            updateLeadTaskStatus(status);
            openLeadRecordByID(sfdcLeadRecordID);
            elementClick(driver, relatedTab);
            verifyLeadTaskLocationByStatus(status);
        }
    }

    /**
     * This method verifies the Lead Task Assignment Notification email.
     * It first prepares the expected subject and body of the email.
     * It then reads the emails and checks if there is an email with the expected subject.
     * If such an email is found, it verifies the sender and the body of the email.
     * If the email is not found or the sender or body does not match the expected values, it logs an error message.
     *
     * @param leadName String - The name of the lead.
     * @param company String - The company of the lead.
     */
    @Step("Verify the Lead Task Assignment Notification email")
    public void verifyLeadTaskAssignmentNotification(String leadName, String company, String email){

        List<Map<String, String>> mailDetails;
        String dueDate = convertDateFormat(currentDatePlusDays(5), "MM/dd/yyyy", "M/d/yyyy");
        String expectedSubject = "Sandbox: Call|Email New Lead: " + leadName + " ( at " + company + ")";
        String expectedFrom = "Integration Marketo";
        String expectedBody = "Integration Marketo has assigned you the following new task: Subject: Call|Email New Lead: " + leadName + " ( at " + company + ") Lead: " + leadName + ", " + company + " Due Date: " + dueDate + " Priority: Normal Comments: Email Address: " + email.toLowerCase() + ", Phone Number: , Source: For more details, click the following link: https://moodysanalytics--supportqa.sandbox.my.salesforce.com/" + getSFDCRecordIDFromURL(sfdcLeadTaskURL);
        outlookSupport.readMails();
        mailDetails = outlookSupport.getMailDetails();
        boolean flag = false;
        for (Map<String, String> mail : mailDetails) {
            if (mail.get("Email Subject").equals(expectedSubject)) {
                loggerManager.getLogger().info("Actual Email Subject: " + mail.get("Email Subject") + " | " + "Expected Email Subject: " + expectedSubject);
                loggerManager.getLogger().info("Actual Email From Name: " + mail.get("Email From Name") + " | " + "Expected Email From Name: " + expectedFrom);
                loggerManager.getLogger().info("Actual Email Body: " + mail.get("Email Body") + " | " + "Expected Email Body: " + expectedBody);
                Assert.assertEquals(mail.get("Email From Name"), expectedFrom, "Lead Task Assignment Notification email has incorrect From Name");
                Assert.assertTrue(mail.get("Email Body").contains(expectedBody), "Lead Task Assignment Notification email has incorrect Body");
                loggerManager.getLogger().info("Lead Task Assignment Notification email received successfully");
                flag = true;
                break;
            }
        }

        if (!flag)
            loggerManager.getLogger().error("Lead Task Assignment Notification email not received");
    }

    /**
     * This method extracts the Salesforce (SFDC) record ID from a given URL.
     * It uses a regular expression to match the 18 digit ID in the URL.
     * If a match is found, it returns the first 15 digits of the ID.
     * If no match is found, it returns null.
     *
     * @param url String - The URL from which to extract the SFDC record ID.
     * @return String - The 15 digit SFDC record ID if a match is found, null otherwise.
     */
    public String getSFDCRecordIDFromURL(String url){

        // Regular expression to match the 18 digit ID
        String regex = "/([a-zA-Z0-9]{18})/";

        // Create a Pattern object
        Pattern pattern = Pattern.compile(regex);

        // Create a Matcher object
        Matcher matcher = pattern.matcher(url);

        // Check if the matcher found a match
        if (matcher.find()) {
            String id = matcher.group(1);
            return id.substring(0, id.length() - 3); // Return the 15 digit id
        } else
            return null;
    }

    /**
     * This method verifies that a user cannot create a lead in Marketo if the required fields are not filled in.
     */
    @Step("Verify that user should not able to create a lead in marketo if the required fields are not filled in")
    public void verifyLeadCreationErrorInMarketo(){

        Allure.step("Verify that user gets an error if the email address is not filled while creating a Lead in Marketo", step -> {
            if(isElementDisplayed(driver, marektoLeadError)){
                loggerManager.getLogger().info("Validation error message displayed for missing email address while creating in Marketo");
                Assert.assertTrue(true, "Validation error message displayed for missing fields while creating in Marketo");
            }
            else {
                loggerManager.getLogger().error("Validation error message not displayed for missing email address while creating a lead in Marketo");
                Assert.assertTrue(false, "Validation error message not displayed for missing email address while creating a lead in Marketo");
            }
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method clicks on the Edit button on the Lead Page in Salesforce (SFDC).
     */
    @Step("Click on Edit Lead")
    public void editLead(){
            waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
            try {
                waitForElementToBePresent(driver, editRightPanelButton);
                waitForElementToBeVisible(driver, driver.findElement(editRightPanelButton));
                elementClick(driver, driver.findElement(editRightPanelButton));
            } catch (Exception e) {
                waitForElementToBeVisible(driver, showMoreActionsButton);
                elementClick(driver, showMoreActionsButton);
                waitForElementToBeVisible(driver, editButton);
                elementClick(driver, editButton);
            }
            takeScreenshot(TCName, driver);

    }

    /**
     * This method navigates to the Lead creation screen in Salesforce.
     * It clicks on the "New" button, waits for the page to load, and verifies that the "New Lead" page is opened.
     * It also takes a screenshot of the Lead creation screen.
     */
    @Step("Navigate to the Lead creation screen.")
    public void navigateToLeadCreationScreen() {
        reusableBusinessLibrary.clickNewBtn();
        waitForPageTitle(driver, "New Lead | Salesforce");
        Assert.assertEquals(driver.getTitle(), "New Lead | Salesforce", "New Lead page not opened");
    }

    /**
     * This method enters all the mandatory fields on the lead record.
     * It reads data from an Excel file and populates the fields such as Last Name, Company, Phone, Email, etc.
     * It also logs a message indicating that the mandatory fields were entered successfully.
     *
     */
    @Step("Enter all the mandatory fields on lead record.")
    public String enterMandatoryFields() {
        firstNameText = ReusableLibrary.readExcelData(leadsFilePath, TCName,"First Name");
        ReusableLibrary.sendKeysToElement(driver, firstNameTextField, firstNameText);
        lastNameText = ReusableLibrary.readExcelData(leadsFilePath, TCName,"Last Name")+ReusableLibrary.generateRandomString("_Auto");
        ReusableLibrary.sendKeysToElement(driver, lastNameTextField, lastNameText);
        companyText = ReusableLibrary.readExcelData(leadsFilePath, TCName,"Company")+ReusableLibrary.generateRandomString("_Auto");
        ReusableLibrary.sendKeysToElement(driver, companyTextField, companyText);
        sfdcLeadEmail = (generateRandomString("testuser") + "_" + generateRandomNumber(3) + "@automationtest.com").toLowerCase();
        ReusableLibrary.sendKeysToElement(driver, emailTextField, sfdcLeadEmail);

        phoneTextField.clear();
        ReusableLibrary.sendKeysToElement(driver, phoneTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Phone"));

        elementClickByJS(driver,driver.findElement(picklistButtonElement("Business Type")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Business Type",ReusableLibrary.readExcelData(leadsFilePath, TCName,"Business Type"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Business Type",ReusableLibrary.readExcelData(leadsFilePath, TCName,"Business Type"))));

        countryValue = ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary Country");
        scrollToElement(driver, driver.findElement(picklistButtonElement("Country")));
        elementClickByJS(driver,driver.findElement(picklistButtonElement("Country")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Country",countryValue)));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Country",countryValue)));

        ReusableLibrary.sendKeysToElement(driver, street1TextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary Street 1"));
        ReusableLibrary.sendKeysToElement(driver, cityTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary City"));

        elementClickByJS(driver,driver.findElement(picklistButtonElement("State")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("State",readExcelData(leadsFilePath, TCName,"Primary State"))));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("State",readExcelData(leadsFilePath, TCName,"Primary State"))));

        ReusableLibrary.sendKeysToElement(driver, zipPostalCodeTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary Zip/Postal Code"));
        ReusableLibrary.takeScreenshot("enterMandatoryFields", driver);
        loggerManager.getLogger().info("Mandatory fields entered successfully");
        return firstNameText + " " + lastNameText;
    }


    /**
     * This method enters some optional fields on the lead record.
     * It reads data from an Excel file and populates the fields such as First Name, Lead Source, etc.
     * It also logs a message indicating that the optional fields were entered successfully.
     */
    @Step("Enter some optional fields on lead record.")
    public void enterOptionalFields(){
        ReusableLibrary.sendKeysToElement(driver, jobTitleTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Job Title"));
        scrollToElement(driver, descriptionTextField);
        ReusableLibrary.sendKeysToElement(driver, descriptionTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Description"));
        ReusableLibrary.sendKeysToElement(driver, websiteTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Website"));
        scrollToElement(driver, leadSourceDetailTextField);
        ReusableLibrary.sendKeysToElement(driver, leadSourceDetailTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Lead Source Details"));
        ReusableLibrary.takeScreenshot("enterOptionalFields", driver);
        loggerManager.getLogger().info("Optional fields entered successfully");
    }





    /**
     * This method validates the mandatory fields on the lead record.
     * It compares the values of the fields such as Lead Name, Company, Phone, Email, etc. with the expected values from the Excel file.
     * It also logs a message indicating that the mandatory fields were validated successfully.
     */
    @Step("Validating mandatory fields on lead record.")
    public void validateLeadMandatoryInfo(){
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, leadNameOnHeader), firstNameText+" "+lastNameText);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, leadRecordTypeText), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Lead Record Type"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, leadNameOnLeadRecord), firstNameText+" "+lastNameText);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, companyOnLeadRecord), companyText);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, emailOnLeadRecord), sfdcLeadEmail);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, phoneOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Phone"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, businessTypeOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Business Type"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, countryOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary Country"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, street1OnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary Street 1"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, cityOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary City"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, stateOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary State"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, zipCodeOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Primary Zip/Postal Code"));
        softAssert.assertAll();
        ReusableLibrary.scrollToElement(driver, companyOnLeadRecord);
        ReusableLibrary.takeScreenshot("validateLeadMandatoryInfo", driver);
        loggerManager.getLogger().info("Mandatory fields validated successfully");
        Allure.step("Validated following mandatory fields successfully: Name, Company, Email, Phone, Business Type, Lead Record Type, Primary Country, Primary Street 1, Primary City, Primary State & Primary Zip/Postal Code");
    }


    /**
     * This method validates the optional fields on the lead record.
     * It compares the values of the fields such as Lead Source, Lead Source Detail, Description, etc. with the expected values from the Excel file.
     * It also logs a message indicating that the optional fields were validated successfully.
     */
    @Step("Validating optional fields on lead record.")
    public void validateLeadOptionalInfo(){
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, leadSourceDetailOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Lead Source Details"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, descriptionOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Description"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, websiteOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Website"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, jobTitleOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Job Title"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, statusOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Status"));
        softAssert.assertAll();
        ReusableLibrary.scrollToElement(driver, statusOnLeadRecord);
        ReusableLibrary.takeScreenshot("validateLeadOptionalInfo", driver);
        loggerManager.getLogger().info("Optional fields validated successfully");
        Allure.step("Validated following optional fields successfully: Lead Source Details, Description, Website, Job Title & Status");
    }


    @Step("Validate updated lead Info")
    public void validateUpdatedLeadInfo(){
        waitForElementToBeVisible(driver, leadRecordTypeText);
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, leadRecordTypeText), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Lead Record Type"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, descriptionOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Description"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, websiteOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Website"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, jobTitleOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Job Title"));
        softAssert.assertEquals(ReusableLibrary.getElementText(driver, leadSourceDetailOnLeadRecord), ReusableLibrary.readExcelData(leadsFilePath, TCName,"Lead Source Details"));
        softAssert.assertAll();
        ReusableLibrary.scrollToElement(driver, leadSourceDetailOnLeadRecord);
        ReusableLibrary.takeScreenshot("validateUpdatedLeadInfo", driver);
        loggerManager.getLogger().info("Updated fields validated successfully");
        Allure.step("Validated following updated fields successfully: Lead Record Type, Description, Website, Job Title & Lead Source Details");
    }

    /**
     * This method edits the lead details on the lead record.
     * It reads data from an Excel file and populates the fields such as First Name, Company, Email, Phone, etc.
     * It also logs a message indicating that the lead record was edited successfully.
     */
    @Step("Edit Lead Source Detail and other details on lead record.")
    public void editLeadDetail(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        ReusableLibrary.sendKeysToElement(driver, jobTitleTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Job Title"));
        ReusableLibrary.sendKeysToElement(driver, descriptionTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Description"));
        ReusableLibrary.sendKeysToElement(driver, websiteTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Website"));
        ReusableLibrary.sendKeysToElement(driver, leadSourceDetailTextField, ReusableLibrary.readExcelData(leadsFilePath, TCName,"Lead Source Details"));
        ReusableLibrary.takeScreenshot("editLeadDetail", driver);
        loggerManager.getLogger().info("Lead record edited successfully.");
    }

    /**
     * This method navigates to a specific lead record in Salesforce.
     * It performs the following steps:
     * 1. Clicks on the global search bar.
     * 2. Enters the lead's full name (first name and last name) in the global search text field.
     * 3. Hits the Enter key to initiate the search.
     * 4. Clicks on the lead record from the search results.
     * 5. Clicks on the lead record link to open the lead's detailed view.
     */
    @Step("Navigate to Lead record.")
    public void navigateToLeadRecord() {

        reusableBusinessLibrary.openSFDCRecordFromGlobalSearch("Leads", firstNameText+" "+lastNameText);

        ReusableLibrary.waitForElementToBeVisible(driver, detailsTabOnLead);
        ReusableLibrary.elementClickByJS(driver, detailsTabOnLead);
        ReusableLibrary.takeScreenshot("navigateToLeadRecord", driver);
        loggerManager.getLogger().info("Navigated to lead record successfully.");
    }

    @Step("Save the new lead ID in Excel")
    public void getLeadIDAndStoreInExcel(){
        waitForElementToBeVisible(driver, leadNameOnHeader);
        String newLeadURL = driver.getCurrentUrl();
        String newLeadID = ReusableBusinessLibrary.getSFDCIDFromURL(newLeadURL);
        loggerManager.getLogger().info("SFDC Lead ID: " + newLeadID);
        writeToExcel(leadsFilePath, TCName, "SFDC Lead ID", newLeadID);
    }

    /**
     * This method saves the lead record and ignores any duplicate warnings.
     * It clicks on the "Save" button and logs a message indicating that the lead record was saved successfully.
     */
    @Step("Save the lead record and ignore duplicates.")
    public void saveLead(){
        reusableBusinessLibrary.clickSaveBtn();
        if(isElementDisplayed(driver, reusableBusinessLibrary.addressValidationConfirmButton))
        {
            elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
            loggerManager.getLogger().info("Clicked on Address Validation Confirm button successfully.");
        }
        else {
            loggerManager.getLogger().info("Address Validation Confirm button not displayed. Saving lead without clicking on the address validation confirm button.");
        }
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, firstNameText + " " + lastNameText);
        pageRefresh(driver);
        waitForElementToBeVisible(driver, detailsTabOnLead);
        Assert.assertEquals(ReusableLibrary.getElementText(driver, leadNameOnLeadRecord), firstNameText+" "+lastNameText);
        ReusableLibrary.takeScreenshot("newLeadRecord", driver);
    }

    /**
     * This method saves the lead record, navigates to new lead screen, and ignores any duplicate warnings.
     * It clicks on the "Save and New" button, verifies that the "New Lead" page is opened, and logs a message indicating that the lead record was created successfully.
     */
    @Step("Save the record, create new lead and ignore duplicates.")
    public void saveAndNewLead(){
        waitForPageToLoad(Duration.ofSeconds(10));
        reusableBusinessLibrary.clickSaveAndNewBtn();
        loggerManager.getLogger().info("Clicked on Save and New button successfully.");
        if(isElementDisplayed(driver, reusableBusinessLibrary.addressValidationConfirmButton))
        {
            elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
            loggerManager.getLogger().info("Clicked on Address Validation Confirm button successfully.");
        }
        else {
            loggerManager.getLogger().info("Address Validation Confirm button not displayed. Saving lead without clicking on the address validation confirm button.");
        }

        ReusableLibrary.waitForPageTitleToContain(driver, "New Lead");
        Assert.assertTrue( driver.getTitle().contains("New Lead"), "New Lead page not opened");
        ReusableLibrary.waitForElementToBeVisible(driver, firstNameTextField);
        waitForAlertAndAccept(driver, Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration")));
        ReusableLibrary.takeScreenshot("saveAndNewLeadPage", driver);
        loggerManager.getLogger().info("Lead record created and New Lead page opened successfully");
    }

    /**
     * This method saves the lead record and ignores any duplicate warnings.
     * It clicks on the "Save" button and logs a message indicating that the lead record was saved successfully.
     */
    @Step("Save the lead record and ignore duplicates.")
    public void saveOnEditLead(){
        waitForPageToLoad(Duration.ofSeconds(10));
        reusableBusinessLibrary.clickSaveBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, leadNameOnHeader);
        pageRefresh(driver);
        waitForElementToBeVisible(driver, detailsTabOnLead);
        Assert.assertEquals(getSFDCIDFromURL(getUrl()), readExcelData(leadsFilePath, TCDependency, "SFDC Lead ID"));
        loggerManager.getLogger().info("Lead record is saved successfully.");
        takeScreenshot(TCName, driver);
    }


    /**
     * This method checks for errors on the lead creation screen.
     * If an error alert is displayed, it takes a screenshot and logs an error message.
     * Otherwise, it logs a message indicating that the optional fields were entered successfully.
     */
    @Step("Check error on lead creation screen.")
    public void checkErrorOnLeadCreationScreen(){
        waitForElementToBeVisible(driver, errorAlert);
        switch (TCName){
            case "saveLeadWithMissingMandatoryField_SalesRep":
            case "saveLeadWithMissingMandatoryField_MarketingUser":
            case "saveLeadWithMissingMandatoryField_EventsAndOutreach":
            case "saveLeadWithMissingMandatoryField_ProductStrategyMarketoAdmin":
                ReusableLibrary.isElementDisplayed(driver, warningToCompleteField);
                ReusableLibrary.takeScreenshot("checkErrorOnLeadCreationScreen", driver);
                loggerManager.getLogger().error(warningToCompleteField.getText());
                break;
            case "updateLeadSourceDetailsOnExistingLead_SalesRep":
            case "updateLeadSourceDetailsOnExistingLead_MarketingUser":
            case "updateLeadSourceDetailsOnExistingLead_EventsAndOutreach":
            case "updateLeadSourceDetailsOnExistingLead_ProductStrategyMarketoAdmin":
                ReusableLibrary.isElementDisplayed(driver, errorAlert);
                ReusableLibrary.takeScreenshot("checkErrorOnLeadCreationScreen", driver);
                loggerManager.getLogger().error(errorAlert.getText());
                break;
            default :
                loggerManager.getLogger().info("TCName is not available as an option");
        }
    }

    /**
     * This method updates the Sector, Division and Function values on the Lead Page in Salesforce (SFDC).
     *
     * @param leadData String - The data of the lead to be converted.
     */
    @Step("Populate Function Value on Lead")
    public void populateFunctionAndLeadSource(LinkedHashMap<String, String> leadData){
        reusableBusinessLibrary.clickEditBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, firstNameTextField);

        scrollToElement(driver, driver.findElement(picklistButtonElement("Sector")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Sector")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Sector", leadData.get("Sector"))));

        elementClickByJS(driver, driver.findElement(picklistButtonElement("Division")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Division", leadData.get("Division"))));

        elementClickByJS(driver, driver.findElement(picklistButtonElement("Function")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Function", leadData.get("Function"))));

        elementClickByJS(driver, driver.findElement(picklistButtonElement("Lead Source")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Lead Source", leadData.get("Lead Source"))));

        reusableBusinessLibrary.clickSaveBtn();

        waitForAlertAndAccept(driver, Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        pageRefresh(driver);
        waitForElementToBeVisible(driver, detailsTabOnLead);
        scrollToElement(driver, functionValueText);
        String elementValue = functionValueText.getText();
        try {
            Allure.step("Validate that the field Function is updated to " + leadData.get("Function") + " in SFDC", step-> {
                Assert.assertEquals(elementValue, leadData.get("Function"), "Function field value not updated in SFDC");
                loggerManager.getLogger().info("Function field value updated to " + leadData.get("Function") + " in SFDC");
            });
        } catch (NoSuchElementException | TimeoutException e)  {
            loggerManager.getLogger().error("Could not locate the Function picklist text value" + e.getMessage());
        }
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the user gets a validation error message if the address fields are not filled in while converting a Lead.
     * It validates the address for different countries and scenarios.
     *
     */
    @Step("Verify that the user gets a validation error message if the address fields are not filled in while converting a Lead")
    public void verifyAddressValidationOnLeadConversion() {
        // Validation error message should appear on screen if user converts lead without State or Postal Code for Country India
        validateAddress("India", "Bhopal Bypass Road", "Bhopal");

        // Validation for fields 'Country', 'City', 'State', and 'Postal Code' on new Contacts from Lead to Contact conversion where 'Country' is US or Canada
        validateAddress("United States", "45 1/2 10th St SW", "");
        validateAddress("Canada", "Highway 401", "");

        // Validation for fields 'Country' and 'City' on new Contacts from Lead to Contact conversion where 'Country' is not the United States or Canada
        validateAddress("Brazil", "655 Rua Um", "");
    }

    /**
     * This method validates the address for different countries and scenarios during lead conversion.
     * It first updates the lead address, then performs the lead conversion.
     * It then validates the error message and clicks on the lead convert cancel button.
     *
     * @param country String - The country for the lead address.
     * @param street String - The street for the lead address.
     * @param city String - The city for the lead address.
     */
    @Step("Verify that the user gets a validation error message if the address fields are not filled in while converting a Lead where Country is {country}")
    private void validateAddress(String country, String street, String city) {
        updateLeadAddress(country, street, city);
        convertLead();
        validateErrorMessage(country);
        elementClick(driver, leadConvertCancelButton);
    }

    /**
     * This method updates the address of a Lead in Salesforce (SFDC).
     *
     * @param country String - The country for the lead address.
     * @param street String - The street for the lead address.
     * @param city String - The city for the lead address.
     */
    @Step("Update Address on the Lead")
    public void updateLeadAddress(String country, String street, String city) {
        reusableBusinessLibrary.clickEditBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, countryPicklist);

        scrollToElement(driver, driver.findElement(picklistButtonElement("Country")));
        elementClickByJS(driver,driver.findElement(picklistButtonElement("Country")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Country","--None--")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Country","--None--")));



        if (!country.isEmpty()) {
            elementClickByJS(driver,driver.findElement(picklistButtonElement("Country")));
            scrollToElement(driver, driver.findElement(picklistButtonElementOption("Country",country)));
            elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Country",country)));

        }

        street1TextField.clear();
        if (!street.isEmpty()) {
            sendKeysToElement(driver, street1TextField, street);
        }

        cityTextField.clear();
        if (!city.isEmpty()) {
            sendKeysToElement(driver, cityTextField, city);
        }
        zipPostalCodeTextField.clear();

        reusableBusinessLibrary.clickSaveBtn();
        if (isElementDisplayed(driver, reusableBusinessLibrary.skipValidationButton))
        {
            elementClick(driver, reusableBusinessLibrary.skipValidationButton);
            loggerManager.getLogger().info("Clicked on Skip Validation button");
        }
        else {
            loggerManager.getLogger().info("Skip Validation button not displayed, saving lead without validation");
        }

        waitForAlertAndAccept(driver, Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, showMoreActionsButton);
        waitForElementToBeClickable(driver, showMoreActionsButton);
        Allure.step("Validate that Lead Address is saved", step->{
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Lead address not saved");
            loggerManager.getLogger().info("Lead address saved successfully");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method performs the lead conversion process in Salesforce (SFDC).
     * It waits for the "Lead Converted" message to be visible and validates that the lead is converted successfully.
     */
    @Step("Perform Lead Conversion")
    public void performLeadConversion() {
        waitForElementToBeVisible(driver, showMoreActionsButton);

        if(leadConvertRightPanelButton.isDisplayed()){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }

        try {
            Thread.sleep(7000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, leadConvertButton);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, leadConvertedMessage);
        Allure.step("Validate that Lead is converted successfully", step -> {
            Assert.assertTrue(isElementDisplayed(driver, leadConvertedMessage), "Failed to convert Lead");
            loggerManager.getLogger().info("Lead converted successfully");
        });
        ReusableLibrary.waitForElementToBeVisible(driver, accountHeaderLeadConversionTab);
        takeScreenshot(TCName, driver);
    }

    /**
     * This method validates that the user gets a validation error message if the address fields are not filled in while converting a Lead.
     *
     * @param country String - The country for the lead address.
     */
    @Step("Validate that error message appears on screen if user converts lead without City, State or Postal Code when Country is {country}")
    private void validateErrorMessage(String country) {
        try {
            Allure.step("Validate that error message appears on screen if user converts lead without City, State or Postal Code when Country is " + country, step -> {
                Assert.assertTrue(isElementDisplayed(driver, missingAddressValidationError), "Validation error message not displayed for missing State and Postal Code when Country is " + country + " while converting a Lead");
                loggerManager.getLogger().info("Validation error message displayed for missing City, State or Postal Code when Country is " + country + " while converting a Lead in SFDC");
            });
        } catch (NoSuchElementException | TimeoutException e) {
            loggerManager.getLogger().error("Validation error message not displayed for missing City, State and Postal Code when Country is " + country + " while converting a Lead");
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the user is not able to make the Business Type field blank on the Lead Page in Salesforce (SFDC).
     */
    @Step("Validate that user is not able to make Business type field blank on Lead, if value is populated for that field")
    public void verifyBusinessTypeError(){
        reusableBusinessLibrary.clickEditBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, firstNameTextField);

        elementClickByJS(driver,driver.findElement(picklistButtonElement("Business Type")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Business Type","--None--")));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Business Type","--None--")));


        reusableBusinessLibrary.clickSaveBtn();
        waitForAlertAndAccept(driver, 15);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        Allure.step("Verify that error message appears on screen if user makes Business Type field blank on Lead", step -> {
            try {
                waitForElementToBeVisible(driver, missingBusinessTypeError);
                if (missingBusinessTypeError.isDisplayed()) {
                    loggerManager.getLogger().info("Validation error message displayed for making Business Type field blank on Lead");
                    Assert.assertTrue(true, "Validation error message not displayed on making Business Type field blank on Lead");
                }
            }
            catch(NoSuchElementException e){
                loggerManager.getLogger().error("Validation error message not displayed on making Business Type field blank on Lead");
                Assert.assertTrue(false, "Validation error message not displayed on making Business Type field blank on Lead");
            }
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method converts a Lead to an Account with an Existing Contact in Salesforce (SFDC).
     *
     */
    @Step("Convert Lead to Account with an Existing Contact")
    public void convertLeadToAccountWithExistingContact(String existingContact){
        waitForElementToBeVisible(driver, showMoreActionsButton);
        if(leadConvertRightPanelButton.isDisplayed()){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }

        waitForElementToBeVisible(driver, chooseExistingContactRadioButton);
        scrollToElement(driver, chooseExistingContactRadioButton);
        elementClickByJS(driver, chooseExistingContactRadioButton);
        sendKeysTypeAheadField(searchContactTextField, existingContact);
        elementClick(driver, searchContactOption);
        elementClickByJS(driver, dontCreateOpportunityCheckbox);
        waitForElementToBeVisible(driver, leadConvertButton);
        waitForElementToBeClickable(driver, leadConvertButton);
        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, leadConvertButton);

        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }

        waitForElementToBePresent(driver, convertedAccountAndOppyLink(companyText));
        waitForElementToBeVisible(driver, driver.findElement(convertedAccountAndOppyLink(companyText)));
        Allure.step("Validate that Lead is converted to Account with an Existing Contact", step -> {
            Assert.assertTrue(isElementDisplayed(driver, driver.findElement(convertedAccountAndOppyLink(companyText))), "Failed to convert Lead to Account with an Existing Contact");
            loggerManager.getLogger().info("Lead converted to Account with an Existing Contact successfully");
        });
        takeScreenshot(TCName, driver);
    }



    /**
     * This method opens the Account created as part of the Lead Conversion process in Salesforce (SFDC).
     *
     * @param companyName String - The name of the company for which the Account was created.
     */
    @Step("Open Account created as part of Lead Conversion process")
    public void openConvertedAccount(String companyName){
        loggerManager.getLogger().info("Opening Converted Account " + companyName);
        waitForElementToBePresent(driver, convertedAccountAndOppyLink(companyName));
        waitForElementToBeVisible(driver, driver.findElement(convertedAccountAndOppyLink(companyName)));
        elementClick(driver, driver.findElement(convertedAccountAndOppyLink(companyName)));

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
            wait.until(ExpectedConditions.titleIs(companyName + " | Account | Salesforce"));
            Allure.step("Validate that Converted Account " + companyName + " is opened successfully", step-> {
                Assert.assertEquals(driver.getTitle(), companyName + " | Account | Salesforce", "Failed to open Converted Account " + companyName);
                loggerManager.getLogger().info("Converted Account " + companyName + " is opened successfully");
            });

        }
        catch (NoSuchElementException | TimeoutException e){
            loggerManager.getLogger().error("Failed to open Converted Account " + companyName);
        }
        takeScreenshot(TCName, driver);
    }



    /**
     * This method opens the Contact created as part of the Lead Conversion process in Salesforce (SFDC).
     *
     * @param leadName String - The name of the lead for which the Contact was created.
     */
    @Step("Open Contact created as part of Lead Conversion process")
    public void openConvertedContact(String leadName){
        loggerManager.getLogger().info("Opening Converted Contact " + leadName);
        waitForElementToBePresent(driver, convertedContactLink(leadName));
        waitForElementToBeVisible(driver, driver.findElement(convertedContactLink(leadName)));
        waitForElementToBeClickable(driver, driver.findElement(convertedContactLink(leadName)));
        elementClick(driver, driver.findElement(convertedContactLink(leadName)));
        switchToWindowByNumber(driver, 1);
        switchToWindowByNumber(driver, 0);
        driver.close();
        switchToWindowByNumber(driver, 0);

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
            wait.until(ExpectedConditions.titleIs(leadName + " | Contact | Salesforce" ));
            Allure.step("Validate that Converted Contact " + leadName + " is opened successfully", step-> {
                Assert.assertEquals(driver.getTitle(), leadName + " | Contact | Salesforce", "Failed to open Converted Contact " + leadName);
                loggerManager.getLogger().info("Converted Contact " + leadName + " is opened successfully");
            });

        }
        catch (NoSuchElementException | TimeoutException e){
            loggerManager.getLogger().error("Failed to open Converted Contact " + leadName);
        }
        takeScreenshot(TCName, driver);
    }

    /**
     * This method updates the Lead Email in Salesforce (SFDC).
     *
     * @param email String - The new email to be set for the Lead.
     */
    @Step("Update Lead Email to {email}")
    public void updateLeadEmail(String email){
        reusableBusinessLibrary.clickEditBtn();
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, SFCDCEmailTextField);
        SFCDCEmailTextField.clear();
        sendKeysToElement(driver, SFCDCEmailTextField, email);
        reusableBusinessLibrary.clickSaveBtn();
        waitForAlertAndAccept(driver, Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to update Lead email");
        loggerManager.getLogger().info("Lead email updated successfully");
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies that the user gets a validation error message if a contact already exists with the same email at the time of Lead Conversion.
     */
    @Step("Verify that the user gets a validation error message if a contact already exists with same email at the time of Lead Conversion")
    public void verifyContactExistsValidationError(){
        if (isElementDisplayed(driver, contactExistsValidationError)) {
            Assert.assertTrue(true, "Validation error message not displayed for existing Contact while converting a Lead");
            loggerManager.getLogger().info("Validation error message displayed for existing Contact while converting a Lead");
        } else {
            loggerManager.getLogger().error("Validation error message not displayed for existing Contact while converting a Lead");
            Assert.assertTrue(false, "Validation error message not displayed for existing Contact while converting a Lead");
        }
        takeScreenshot(TCName, driver);
    }

    @Step("Create Lead Task in SFDC")
    public void createLeadTaskInSFDC(){
        waitForElementToBeVisible(driver, relatedTab);
        waitForElementToBeClickable(driver, relatedTab);
        elementClickByJS(driver, relatedTab);
        elementClick(driver, newTaskButton);
        reusableBusinessLibrary.selectRecordType("Lead Task");
        reusableBusinessLibrary.clickRecordTypeSelectionNextBtn();

        waitForElementToBeVisible(driver, campaignTextFieldOnLeadTaskForm);
        sendKeysToElement(driver, formTextField("Subject"), "Call");

        elementClick(driver, leadTaskSaveButton);

        waitForElementToBeVisible(driver, openActivitiesRelatedList);
        elementClickByJS(driver, openActivitiesRelatedList);
        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        pageRefresh(driver);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, leadTaskCallRecordLink);
        Allure.step("Validate that the Lead Task is created in SFDC", step -> {
            Assert.assertTrue(isElementDisplayed(driver, leadTaskCallRecordLink), "Failed to create Lead Task in SFDC");
            loggerManager.getLogger().info("Lead Task created successfully in SFDC");
        });

        ReusableLibrary.takeScreenshot(TCName, driver);
        elementClick(driver, leadTaskCallRecordLink);
    }

    @Step("Verify that error message appears when user clicks on 'Convert to Opportunity' button on lead task.")
    public void verifyConvertToOpportunityErrorOnLeadTask(){
        waitForElementToBeVisible(driver, showMoreActionsButtonOnLeadTask);
        waitForElementToBeClickable(driver, showMoreActionsButtonOnLeadTask);
        elementClick(driver, showMoreActionsButtonOnLeadTask);
        elementClick(driver, convertToOpportunityButtonOnLeadTask);

        Allure.step("Verify that error message appears when user clicks on 'Convert to Opportunity' button on lead task.", step -> {
            Assert.assertTrue(isElementDisplayed(driver, leadTaskConversionMessage), "No error message is displayed when user clicks on 'Convert to Opportunity' button on lead task");
            loggerManager.getLogger().info("Error message is displayed when user clicks on 'Convert to Opportunity' button on lead task");
        });
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    /**
     * This method converts a Lead to an Opportunity and can be used in scenarios that require validating errors triggred on clicking the Convert button.
     */
    @Step("Convert the Lead")
    public void convertLead() {
        waitForElementToBeVisible(driver, showMoreActionsButton);

        if(leadConvertRightPanelButton.isDisplayed()){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, leadConvertButton);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        takeScreenshot(TCName, driver);
    }


    @Step("Update the Lead Address and validate the error message when converting the Lead")
    public void validateContactAddress(String country, String street, String existingAccount){
        updateLeadAddress(country, street, "");
        convertLeadToContactWithExistingAccount(existingAccount);
        scrollToTop(driver);
        validateContactErrorMessage(country);
        elementClick(driver, leadConvertCancelButton);
    }

    /**
     * This method converts a Lead to a Contact with an Existing Account in Salesforce (SFDC).
     *
     * @param existingAccount String - The name of the existing account to be associated with the converted Contact.
     */
    @Step("Convert Lead to Contact with Existing Account")
    public void convertLeadToContactWithExistingAccount(String existingAccount){
        waitForElementToBeVisible(driver, showMoreActionsButton);

        if(leadConvertRightPanelButton.isDisplayed()){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }

        waitForElementToBeVisible(driver, chooseExistingAccountRadioButton);
        elementClickByJS(driver, chooseExistingAccountRadioButton);
        sendKeysTypeAheadField(searchAccountTextField, existingAccount);
        waitForElementToBeVisible(driver, searchOption);
        elementClick(driver, searchOption);
        waitForElementToBeVisible(driver, leadConvertButton);
        waitForElementToBeClickable(driver, leadConvertButton);

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, leadConvertButton);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
    }

    @Step("Verify that the user gets a validation error message if the address fields are not filled in while converting a Lead where Country is {country}")
    public void verifyContactAddressValidation(String existingAccount){
        validateContactAddress("India", "Bhopal Bypass Road", existingAccount);
        validateContactAddress("Canada", "Highway 401", existingAccount);
        validateContactAddress("", "", existingAccount);
    }

    @Step("Validate that error message appears on screen if user converts lead without adress details when Country is {country}")
    public void validateContactErrorMessage(String country) {
        try {
            Allure.step("Validate that error message appears on screen if user converts lead without City, State or Postal Code when Country is " + country, step -> {
                Assert.assertTrue(isElementDisplayed(driver, missingContactAddressValidationError), "Validation error message not displayed for missing State and Postal Code when Country is " + country + " while converting a Lead");
                loggerManager.getLogger().info("Validation error message displayed for missing City, State or Postal Code when Country is " + country + " while converting a Lead in SFDC");
            });
        } catch (NoSuchElementException | TimeoutException e) {
            loggerManager.getLogger().error("Validation error message not displayed for missing City, State and Postal Code when Country is " + country + " while converting a Lead");
        }
        takeScreenshot(TCName, driver);
    }

    @Step("Convert Lead to Opportunity with Existing Account and Contact")
    public void convertLeadToOpportunityWithExistingAccountContact(String existingAccount, String existingContact){
        waitForElementToBeVisible(driver, showMoreActionsButton);

        if(leadConvertRightPanelButton.isDisplayed()){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }

        // Choose Existing Account
        waitForElementToBeVisible(driver, chooseExistingAccountRadioButton);
        elementClickByJS(driver, chooseExistingAccountRadioButton);
        sendKeysTypeAheadField(searchAccountTextField, existingAccount);
        waitForElementToBeVisible(driver, searchOption);
        elementClick(driver, searchOption);

        // Choose Existing Contact
        waitForElementToBeVisible(driver, chooseExistingContactRadioButton);
        elementClickByJS(driver, chooseExistingContactRadioButton);
        sendKeysTypeAheadField(searchContactTextField, existingContact);
        waitForElementToBeVisible(driver, searchOption);
        elementClick(driver, searchOption);

        waitForElementToBeVisible(driver, leadConvertButton);
        waitForElementToBeClickable(driver, leadConvertButton);

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, leadConvertButton);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, leadConvertedMessage);
        Allure.step("Validate that Lead is converted successfully", step -> {
            Assert.assertTrue(isElementDisplayed(driver, leadConvertedMessage), "Failed to convert Lead");
            loggerManager.getLogger().info("Lead converted successfully");
        });

        takeScreenshot(TCName, driver);
    }

    @Step("Convert Lead to Account with an Existing Contact")
    public void convertLeadToOpportunityWithExistingContact(String existingContact){
        waitForElementToBeVisible(driver, showMoreActionsButton);
        if(isElementDisplayed(driver, leadConvertRightPanelButton)){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }

        waitForElementToBeVisible(driver, chooseExistingContactRadioButton);
        scrollToElement(driver, chooseExistingContactRadioButton);
        elementClickByJS(driver, chooseExistingContactRadioButton);
        sendKeysTypeAheadField(searchContactTextField, existingContact);
        elementClick(driver, searchOption);
        waitForElementToBeVisible(driver, leadConvertButton);
        waitForElementToBeClickable(driver, leadConvertButton);
        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, leadConvertButton);

        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, leadConvertedMessage);
        Allure.step("Validate that Lead is converted to Opportunity with an Existing Contact", step -> {
            Assert.assertTrue(isElementDisplayed(driver, leadConvertedMessage), "Failed to convert Lead");
            loggerManager.getLogger().info("Lead is converted to Opportunity with an Existing Contact");
        });
        takeScreenshot(TCName, driver);
    }

    @Step("Compare Address Before and After Lead Conversion")
    public void compareAddressBeforeAndAfterLeadConversion(String object, LinkedHashMap<String, String> beforeConversionAddress, LinkedHashMap<String, String> afterConversionAddress){
        loggerManager.getLogger().info(object + " Address before conversion: " + beforeConversionAddress);
        loggerManager.getLogger().info(object + " Address after conversion: " + afterConversionAddress);
        Allure.step("Validate that " + object + " Address information should not be updated for Existing " + object + " used for Lead Conversion", step -> {
            Assert.assertEquals(beforeConversionAddress, afterConversionAddress, object + " Address information is updated on Existing " + object + " used for Lead Conversion");
            loggerManager.getLogger().info(object + " Address information is the same before and after Lead Conversion with Existing " + object);
        });
    }


    @Step("Convert Lead to Account with an Existing Contact")
    public void convertLeadToOpportunityWithExistingAccount(String existingAccount){
        waitForElementToBeVisible(driver, showMoreActionsButton);
        if(leadConvertRightPanelButton.isDisplayed()){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }

        waitForElementToBeVisible(driver, chooseExistingAccountRadioButton);
        scrollToElement(driver, chooseExistingAccountRadioButton);
        elementClickByJS(driver, chooseExistingAccountRadioButton);
        sendKeysTypeAheadField(searchAccountTextField, existingAccount);
        elementClick(driver, searchOption);
        waitForElementToBeVisible(driver, leadConvertButton);
        waitForElementToBeClickable(driver, leadConvertButton);
        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        elementClick(driver, leadConvertButton);

        try {
            Thread.sleep(5000);
        }
        catch (InterruptedException e) {
            loggerManager.getLogger().error(e.getMessage());
        }
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, leadConvertedMessage);
        Allure.step("Validate that Lead is converted to Opportunity with an Existing Account", step -> {
            Assert.assertTrue(isElementDisplayed(driver, leadConvertedMessage), "Failed to convert Lead");
            loggerManager.getLogger().info("Lead is converted to Opportunity with an Existing Account");
        });
        takeScreenshot(TCName, driver);
    }




    /**
     * This method validates the presence of the 'Update Address/Phone' button on the Lead page.
     * It asserts that the button is displayed and logs a success message if it is.
     * If the button is not found or an exception occurs, it logs an error message.
     */
    @Step("Step : Validating Update Address/Phone Button")
    public void verifyUpdateAddressPhoneLink(){
        try{
            Assert.assertTrue(updateAddressPhoneBtn.isDisplayed());
            loggerManager.getLogger().info("'Update Address/Phone' button is available on lead record");
            ReusableLibrary.takeScreenshot("verifyUpdateAddressPhoneLink", driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("'Update Address/Phone' button is not available on lead record");
            Assert.assertTrue(false, "'Update Address/Phone' button is not available on lead record");
        }
    }

    /**
     * This method saves the updated address and phone information on the Lead page.
     * It performs the following steps:
     * 1. Clicks on the 'Update Address/Phone' button.
     * 2. Reads the account name from the Excel sheet using the `readExcelData` method.
     * 3. Searches for the account name in the search field.
     * 4. Selects the account name from the search results.
     * 5. Clicks on the address and phone radio buttons to update the details.
     * 6. Retrieves and stores the updated address and phone details.
     * 7. Takes a screenshot of the updated information.
     * 8. Clicks the 'Save' button to save the changes.
     * If the update is successful, it logs a success message.
     * If an exception occurs, it logs an error message.
     */
    @Step("Step : Saving the Update Address/Phone details")
    public void saveAddressPhoneDetailsInfo(){
        try{
            ReusableLibrary.elementClick(driver, updateAddressPhoneBtn);
            String accName = ReusableLibrary.readExcelData(leadsFilePath, TCName, "AccountName");
            ReusableLibrary.sendKeysToElement(driver,searchAccountName,accName);
            Thread.sleep(3000);
            ReusableLibrary.elementClickByJS(driver, selectAccountName(accName));
            ReusableLibrary.elementClick(driver,accAddressBtn);
            Temp1 = ReusableLibrary.getElementText(driver,updateBtnAddressDetails);
            ReusableLibrary.elementClick(driver,accPhoneBtn);
            Temp2 = ReusableLibrary.getElementText(driver,updateBtnPhoneDetails);
            ReusableLibrary.takeScreenshot("saveUpdateAddressPhoneInfo", driver);
            reusableBusinessLibrary.clickSaveBtn();
            wait.until(ExpectedConditions.titleContains("Lead"));
            loggerManager.getLogger().info("Address/Phone details are updated successfully on lead record as per the validation rule");

        }
        catch(Exception e){
            loggerManager.getLogger().error("Address/Phone details are not updated successfully on lead record as per the validation rule");
            Assert.assertTrue(false, "Address/Phone details are not updated successfully on lead record as per the validation rule");
        }
    }

    /**
     * This method separates the account address details and phone information from given input strings.
     * It splits the address input string by newline characters to extract individual address details.
     * Each line is further split by a colon to form key-value pairs, which are stored in a map.
     * The map contains the address details with keys such as "Country", "Street", "City", "State", and "Zip Code".
     * The phone information is also split by a colon and added to the map with the key "Phone".
     *
     * @param consolidatedAddressInfo The input string containing the account address details.
     * @param phoneInfo The input string containing the phone information.
     * @return A map containing the separated account address details and phone information as key-value pairs.
     */
    public static Map<String, String> separateAddressDetails(String consolidatedAddressInfo,String phoneInfo) {
        try {
            // Split the input string by newline character
            String[] lines = consolidatedAddressInfo.split("\n");

            // Map to store the key-value pairs
            Map<String, String> addressMap = new HashMap<>();

            // Iterate over each line and split by colon to get key-value pairs
            for (String line : lines) {
                String[] parts = line.split(": ");
                if (parts.length == 2) {
                    addressMap.put(parts[0].trim(), parts[1].trim());
                }
            }
            String[] parts = phoneInfo.split(": ");
            if (parts.length == 2) {
                addressMap.put(parts[0].trim(), parts[1].trim());
            }
            return addressMap;
        }catch (Exception e){
            loggerManager.getLogger().error("Exception while separating address details: " + e.getMessage());
            return null;
        }

    }

    /**
     * This method validates the updated address and phone information on the Lead page.
     * It retrieves the previously saved address and phone details, refreshes the page, and compares the updated details with the expected values.
     * It asserts that each address and phone detail matches the expected value and logs a success message if they do.
     * If any detail does not match or an exception occurs, it logs an error message.
     */
    @Step("Step: Verifying the updated Address/Phone details on Lead Record")
    public void validateAddressPhoneDetails(){
        try{
            ReusableLibrary.isElementDisplayed(driver,leadCountryValue);
            ReusableLibrary.pageRefresh(driver);
            separateAddressInfo = separateAddressDetails(Temp1,Temp2);
            softAssert.assertEquals(separateAddressInfo.get("Country"),ReusableLibrary.getElementText(driver,leadCountryValue),"Country is not matching");
            softAssert.assertEquals(separateAddressInfo.get("Street"),ReusableLibrary.getElementText(driver,leadStreet1Value), "Street is not matching");
            softAssert.assertEquals(separateAddressInfo.get("City"),ReusableLibrary.getElementText(driver,leadCityValue), "City is not matching");
            softAssert.assertEquals(separateAddressInfo.get("State"),ReusableLibrary.getElementText(driver,leadStateValue), "State is not matching");
            softAssert.assertEquals(separateAddressInfo.get("Zip Code"),ReusableLibrary.getElementText(driver,leadPostalCodeValue), "Zip Code is not matching");
            softAssert.assertEquals(separateAddressInfo.get("Phone"),ReusableLibrary.getElementText(driver,leadPhoneValue), "Phone is not matching");
            softAssert.assertAll();
            loggerManager.getLogger().info(" Account's Address/Phone details specified in 'Update/Address Phone' should be updated on Lead's Address/Phone details");
            ReusableLibrary.scrollToElement(driver,leadPhoneValue);
            ReusableLibrary.takeScreenshot("validateAddressPhoneDetails", driver);
        }
        catch(Exception e){
            loggerManager.getLogger().error("Account's Address/Phone details specified in 'Update/Address Phone' are not updated on Lead's Address/Phone details");
            Assert.assertTrue(false, "Account's Address/Phone details specified in 'Update/Address Phone' are not updated on Lead's Address/Phone details");
        }
    }

    /**
     * This method clears the Zip Code field on the Lead page.
     */
    @Step("Clear Zip Code on Lead")
    public void clearZipCodeOnLead(){
        reusableBusinessLibrary.clickEditBtn();
        waitForElementToBeVisible(driver, countryPicklist);
        scrollToElement(driver, countryPicklist);
        zipPostalCodeTextField.clear();
        takeScreenshot(TCName, driver);
        reusableBusinessLibrary.clickSaveBtn();
        if(isElementDisplayed(driver, reusableBusinessLibrary.addressValidationConfirmButton))
        {
            elementClick(driver, reusableBusinessLibrary.addressValidationConfirmButton);
            loggerManager.getLogger().info("Clicked on Address Validation Confirm button successfully.");
        }
        else {
            loggerManager.getLogger().info("Address Validation Confirm button not displayed. Saving lead without clicking on the address validation confirm button.");
        }
        waitForAlertAndAccept(driver, Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration")));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, showMoreActionsButton);
        Allure.step("Validate that Lead is saved after clearing Zip Code", step-> {
            Assert.assertTrue(isElementDisplayed(driver, showMoreActionsButton), "Failed to clear Zip Code on the Lead");
            loggerManager.getLogger().info("Zip Code cleared successfully on the Lead");
        });
    }

    /**
     * This method verifies if a value present in the Status picklist on the Lead page.
     *
     * @param status String - The value to be verified in the Status picklist.
     */
    @Step("Verify that the value {status} is present in the Status picklist on Lead")
    public void verifyValueInLeadStatusPicklist(String status){
        //this ensures that lead creation page is opened
        waitForElementToBeVisible(driver, firstNameTextField);

        elementClickByJS(driver,driver.findElement(picklistButtonElement("Lead Status")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Lead Status",status)));

        if (isElementPresent(driver, picklistButtonElementOption("Lead Status",status)))
        {
            loggerManager.getLogger().info(status + " is present in the Status picklist on Lead");
        }
        else
        {
            Assert.fail(status + " is not present in the Status picklist on Lead");
            loggerManager.getLogger().error(status + " is not present in the Status picklist on Lead");
        }

        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies if a value present in the Converted Status picklist on the Lead Conversion page.
     *
     * @param statusOption String - The value to be verified in the Converted Status picklist.
     */
    @Step("Verify that the value {statusOption} is present in the Converted Status dropdown on Lead Conversion screen")
    public void verifyConvertedStatusOption(String statusOption){
        waitForElementToBeVisible(driver, showMoreActionsButton);
        if(isElementDisplayed(driver, leadConvertRightPanelButton)){
            elementClick(driver, leadConvertRightPanelButton);
        }
        else{
            elementClick(driver, showMoreActionsButton);
            elementClick(driver, convertButton);
        }
        waitForElementToBeVisible(driver, convertedStatusDropdown);
        scrollToElement(driver, convertedStatusDropdown);
        elementClickByJS(driver, convertedStatusDropdown);
        waitForElementToBePresent(driver, convertedStatusOption(statusOption));
        waitForElementToBeVisible(driver, driver.findElement(convertedStatusOption(statusOption)));
        Allure.step("Verify that the value {statusOption} is present in the Converted Status dropdown", step -> {
            Assert.assertTrue(isElementDisplayed(driver, driver.findElement(convertedStatusOption(statusOption))), statusOption + " is not present in the Converted Status dropdown on Lead Conversion Page");
            loggerManager.getLogger().info(statusOption + " is present in the Converted Status dropdown on Lead Conversion Page");
        });
        takeScreenshot(TCName, driver);
    }

    /**
     * This method verifies if the lead is converted successfully.
     */
    @Step("Verify that Lead is converted successfully")
    public void verifyLeadConversionMessage(){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, leadConvertedMessage);
        Assert.assertTrue(isElementDisplayed(driver, leadConvertedMessage), "Failed to convert Lead");
        loggerManager.getLogger().info("Lead converted successfully");
        takeScreenshot(TCName, driver);
    }
    /**
     * This method navigates to the corresponding task page.
     * It performs the following steps:
     * 1. Waits for the "Related" tab to be visible.
     * 2. Clicks the "Related" tab using JavaScript.
     * 3. Waits for the lead task call record link to be visible.
     * 4. Clicks the lead task call record link using JavaScript.
     * 5. Logs an informational message if navigation is successful.
     * 6. Logs an error message and fails the test if navigation fails.
     */
    @Step("Step: Navigate to corresponding task")
    public void navigateToTaskFromLeadPage()
    {
        try{
            ReusableLibrary.waitForElementToBeVisible(driver, relatedTab);
            elementClickByJS(driver, relatedTab);
            ReusableLibrary.waitForElementToBeVisible(driver, leadTaskCallRecordLink);
            elementClickByJS(driver, leadTaskCallRecordLink);
            loggerManager.getLogger().info("Navigated to Task Page successfully");
        }
        catch(Exception e){
            loggerManager.getLogger().error("Not Able to navigate to task");
            Assert.assertTrue(false, "Not able to navigate to task");
        }
        wait.until(ExpectedConditions.titleContains("Call"));
        ReusableLibrary.takeScreenshot("navigateToTask", driver);
    }
    /**
     * This method updates the country field for a lead in Salesforce.
     * It performs the following steps:
     * 1. Calls the `editLead` method to enter the edit mode for the lead.
     * 2. Selects the specified country from the country picklist.
     * 3. Saves the changes by calling the `saveOnEditLead` method.
     *
     * @param country The country to be selected for the lead.
     */
    @Step("Step: Edit Lead and update the country field")
    public void updateCountryFieldForLeadInSFDC(String country)
    {
        reusableBusinessLibrary.clickEditBtn();
        //ensure you are on lead creation form
        waitForElementToBeVisible(driver, firstNameTextField);

        //select the country from the picklist
        scrollToElement(driver, driver.findElement(picklistButtonElement("Country")));
        elementClickByJS(driver, driver.findElement(picklistButtonElement("Country")));
        scrollToElement(driver, driver.findElement(picklistButtonElementOption("Country", country)));
        elementClickByJS(driver, driver.findElement(picklistButtonElementOption("Country", country)));

        if(isElementPresent(driver, filledFormPicklistField("Country", country)))
        {
            loggerManager.getLogger().info("Country field selected on lead creation form");
        }
        else
        {
            loggerManager.getLogger().error("Country field not selected on dropdown");
            Assert.fail( "Country field not updated successfully for the Lead in SFDC because country value could not be selected from dropdown");
        }
        reusableBusinessLibrary.clickSaveBtn();

        ReusableLibrary.waitForElementToBeVisible(driver, detailsTab);
        //update the static variable leadCountry to hold the new value for country in the lead
        countryValue = country;
        ReusableLibrary.takeScreenshot("updateCountryFieldForLeadInSFDC", driver);
        loggerManager.getLogger().info("Country field updated successfully for the Lead in SFDC");

    }

}