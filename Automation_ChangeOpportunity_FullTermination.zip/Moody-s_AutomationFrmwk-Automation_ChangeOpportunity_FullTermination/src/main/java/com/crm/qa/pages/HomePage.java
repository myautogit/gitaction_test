package com.crm.qa.pages;

import com.crm.qa.base.TestBase;
import com.crm.qa.util.ReusableBusinessLibrary;
import com.crm.qa.util.ReusableLibrary;
import io.qameta.allure.Allure;
import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.List;

import static com.crm.qa.util.AbstractDataLibrary.*;
import static com.crm.qa.util.ReusableLibrary.*;


public class HomePage extends TestBase {

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    SoftAssert softAssert = new SoftAssert();
    ReusableBusinessLibrary reusableBusinessLibrary = new ReusableBusinessLibrary(driver);

    //Page Factory - OR:
    @FindBy(css = "div[title='User Detail']")
    WebElement userdetailBtn;

    @FindBy(css = ".pbHeader [name='login']")
    WebElement loginAsBtn;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode')]//iframe[contains(@name,'vfFrameId')]")
    WebElement userframe;

    @FindBy(xpath = "//button[contains(@class,'userProfile')]")
    WebElement userProfile;

    @FindBy(xpath = "//h1 [contains(@class,'appName')]")
    WebElement appName;


    @FindBy(xpath = "//span [text()='More']")
    WebElement clickMoreMenu;

    @FindBy(xpath = "//span [text()='Leads']")
    WebElement leadonhome;

    @FindBy(xpath = "//a//span//span [text()='Leads']")
    WebElement leadinMoreMenu;

	@FindBy(xpath = "//a[text()='Log Out']")
	WebElement logOut;

    @FindBy(xpath = "//a[contains(text(),'Log out as')]")
    WebElement logOutAs;

    @FindBy(css = ".utilitybar")
    WebElement utilityBar;

    @FindBy(xpath = "(//span[text()='(Toolbar) Orbis Search Companies']) | (//span[text()='Search in Orbis'])")
    WebElement orbisToolbarSearch;

    @FindBy(xpath = "//input[@name='CompanyName']")
    WebElement companyNameSearch;

    @FindBy(css = "h2[title='Orbis Search']")
    WebElement orbisSearchWindow;

    @FindBy(xpath = "//button[text()='Search']")
    WebElement searchonOrbis;

    @FindBy(css = "article[data-aura-class*='bvd_']:not([class*='hide__header'])")
    WebElement orbisSearchResult;

    @FindAll(@FindBy(xpath = "(//a[@title='Import Company to Salesforce']//lightning-primitive-icon)"))
    List<WebElement> orbisRecordsCanImport;

    @FindBy(name = "sobjectname")
    WebElement importAsSObject;

    @FindBy(xpath = "//button[@title='Import']")
    WebElement importBtn;

    @FindBy(xpath = "//a[text()='Show all']")
    WebElement showAllOrbisRecords;

    @FindBy(css = "[class*='toastContent']")
    WebElement toastMessage;

    @FindBy(css = "iframe[id='iframe']")
    WebElement orbisAccountiframe;

    @FindBy(css = "span[class='recordName']")
    WebElement orbisComponentAccountName;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//*[text()='Change search criteria']")
    WebElement changeSearchCriteria;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//*[@name='CompanyName']")
    WebElement changeSearch_companyNameField;

    @FindBy(xpath = "//div[contains(@class,'windowViewMode-normal')]//*[text()='Search']")
    WebElement changeSearch_searchBtn;

    @FindBy(xpath = "((//a[@title='Import Company to Salesforce']//lightning-primitive-icon)[1])/following::a[@href][1]")
    WebElement orbisRecordtoImport_CompanyNameLnk;

    @FindBy(xpath = "//a[contains(text(),'Actions')]")
    WebElement orbisReport_Actions;

    @FindBy(xpath = "//a[contains(text(),'Update CRM')]")
    WebElement orbisReport_UpdateCRM;

    @FindBy(xpath = "(//button[text()='Confirm'])[1]")
    WebElement orisReport_Confirm;

    @FindBy(css = "select[name='sobjectname']")
    WebElement orbisReport_importAsSObject;

    @FindBy(xpath = "//*[@role='tabpanel']/lightning-spinner[contains(@class,'slds-hide')]")
    WebElement orbisReport_spinnerDisappeared;

    @FindBy(css="a[title='Go to the selected record']")
    WebElement orbisImportedAccountelement;

    @FindBy(xpath = "//div//button[@type='button' and @aria-label='Search']")
    WebElement globalSearchBar;

    @FindBy(xpath = "//input[@placeholder='Search...']")
    WebElement globalSearchTextField;

    public By objectFilterOnSearchResult(String objectName) {
        return By.xpath("//li//a[@title='" + objectName + "']");
    }

    public By searchResultRecord(String recordName) {
        return By.xpath("//a[@title='" + recordName + "']");
    }

    @FindBy(xpath = "//span [text()='Home']")
    WebElement homeTab;


    //Actions:

    // This method logs out from the proxy profile.
    public void logoutFromProxyProfile() {
        loggerManager.getLogger().info("Logging out from proxy profile");
        waitForPageToLoad(Duration.ofSeconds(60));
        try {
            String text = logOutAs.getText();
            String searchText = "Log out as";
            int index = text.indexOf(searchText);
            if (index != -1) {
                text = text.substring(0, index + searchText.length());
            }

            softAssert.assertEquals(text, "Log out as");
            logOutAs.click();
            waitForPageToLoad(Duration.ofSeconds(60));
            loggerManager.getLogger().info("Logged out successfully from proxy profile");
        } catch (Exception e) {
            loggerManager.getLogger().error("Error during logout from proxy profile", e);
        } finally {
            softAssert.assertAll();
        }
    }

    public void logout() {
        elementClickByJS(driver,userProfile);
        elementClickByJS(driver, logOut);
    }

    // This method logs in as the user with the specified profile. Supply the profile name as the key.
    @Step("Step: Login as the user with the specified profile : " + "{key}")
    public void loginAs(String key) {
        String methodname = Thread.currentThread().getStackTrace()[1].getMethodName();
        String baseUrl = getUrl();
        int index = baseUrl.indexOf(".force.com/");
        if (index != -1) {
            baseUrl = baseUrl.substring(0, index + ".force.com/".length());
        }
        // Append with the result from reusableLibrary.readExcelData
        String loginUserUrl = baseUrl + readExcelDataWithSheet(userCredentialsFilePath, prop.getProperty("LoginAs"), key, "Userid");
        driver.get(loginUserUrl);
        elementClick(driver, userdetailBtn);
        waitForPageToLoad(Duration.ofSeconds(360));
        waitforFrametoLoad(driver, userframe);
        if (isElementDisplayed(driver, loginAsBtn)) {
            waitForPageToLoad(Duration.ofSeconds(60));
            loginAsBtn.click();
            waitForPageToLoad(Duration.ofSeconds(60));
            loggerManager.getLogger().info("LoginAs successful with profile: " + key);
            driver.switchTo().defaultContent();
            waitForElementToBeVisible(driver, logOutAs);
            Assert.assertTrue(isElementDisplayed(driver, logOutAs), "Proxy login failed");
            takeScreenshot(methodname, driver);
        }
    }



    /**
     * This method checks the current selected app.
     * If the current app is not "Moodys", it switches to the Moody's app.
     * It logs a message indicating whether the Moody's app is already opened or if it was switched to.
     */
    @Step("Check the current selected App")
    public void checkMoodysApp() {
        try {
            reusableLibrary.isElementDisplayed(driver, appName);
            String appNameText = appName.getText();
            if ("Moodys".equals(appNameText)) {
                loggerManager.getLogger().info("Moody's app is opened");
                ReusableLibrary.takeScreenshot("checkMoodysApp", driver);
            } else {
                reusableBusinessLibrary.switchtoMoodysApp();
                loggerManager.getLogger().info("Switched to Moody's app");
            }
        }
        catch(Exception e){
            reusableBusinessLibrary.switchtoMoodysApp();
            loggerManager.getLogger().info("Switched to Moody's app");
        }
    }

    /**
     * This method opens the Lead tab.
     * If the Lead tab is displayed on the home screen, it clicks on it.
     * Otherwise, it clicks on the "More" menu and then selects the Lead tab from the dropdown.
     * It logs a message indicating from where the Lead page was opened.
     */
    @Step("Open Lead Tab")
    public void openLeadtab(){
        if (leadonhome.isDisplayed()) {
            ReusableLibrary.executeJavaScript(driver, "arguments[0].click();", leadonhome);
            loggerManager.getLogger().info("Opening Lead Page from Home Screen");
            }
        else {
            ReusableLibrary.elementClick(driver, clickMoreMenu);
            ReusableLibrary.executeJavaScript(driver, "arguments[0].click();", leadinMoreMenu);
            loggerManager.getLogger().info("Opening Lead Page from More Menu");
             }
        wait.until(ExpectedConditions.titleContains("Leads"));
        ReusableLibrary.takeScreenshot("openLeadTab", driver);
        }

    @Step("Step: Open Orbis search toolbar")
    public void openOrbisSearch() {
        loggerManager.getLogger().info("Opening Orbis search toolbar");
        if (isElementDisplayed(driver, utilityBar)) {
            Allure.step("Utility bar is displayed", step -> {
                softAssert.assertTrue(isElementDisplayed(driver, utilityBar), "Unable to find utility bar on homepage");
                loggerManager.getLogger().info("Utility bar is displayed on the homepage");
            });
            elementClick(driver, orbisToolbarSearch);
            Allure.step("Orbis search window is displayed", step -> {
                softAssert.assertTrue(isElementDisplayed(driver, orbisSearchWindow), "Unable to open Orbis search window");
                loggerManager.getLogger().info("Orbis search window is displayed");
            });
            takeScreenshot("Orbis search window is displayed", driver);
        } else {
            Allure.step("Utility bar is not displayed on the homepage", step -> {
                Assert.fail("Unable to find Search in Orbis component on the homepage");
            });
            loggerManager.getLogger().warn("Utility bar is not displayed on the homepage");
            takeScreenshot("Utility bar is not displayed on the homepage", driver);
        }
    }


    // This method searches for a company in Orbis.
    // Supply the company name as search parameter.
    @Step("Step: Search for company in Orbis")
    public void orbisSearchwithCompany(String companyName) {
        if (isElementDisplayed(driver, companyNameSearch)) {
            companyNameSearch.click();
            companyNameSearch.sendKeys(companyName);
            searchonOrbis.click();
            waitForPageToLoad(Duration.ofSeconds(60));

            if (isElementDisplayed(driver, orbisSearchResult)) {
                if (isElementDisplayed(driver, showAllOrbisRecords)) {
                    elementClickByJS(driver, showAllOrbisRecords);
                    waitForPageToLoad(Duration.ofSeconds(60));
                }
                loggerManager.getLogger().info("Company search result is displayed");
                Allure.step("Company search result is displayed", step -> {
                    softAssert.assertEquals(isElementDisplayed(driver, orbisSearchResult), true, "Company search result is not displayed");
                });
                takeScreenshot("Company search result is displayed", driver);
            } else {
                Allure.step("Company search result is not displayed", step -> {
                    softAssert.assertEquals(isElementDisplayed(driver, orbisSearchResult), true, "Company search result is not displayed");
                });
                loggerManager.getLogger().warn("Company search result is not displayed");
                takeScreenshot("Company search result is not displayed", driver);
            }
        } else {
            loggerManager.getLogger().warn("Company field is not displayed");
            Allure.step("Company field is not displayed", step -> {
                Assert.fail("Company field is not displayed");
            });
            takeScreenshot("Company field is not displayed", driver);
        }
    }

    // This method imports an Orbis record as a Salesforce object.
    @Step("Step: Import Orbis record as {objectName}")
    public void orbisRecordtoImport(String objectName) {
        waitForOrbisSearchTableToLoad();

        if (orbisRecordsCanImport.size() > 0) {
            loggerManager.getLogger().info("Orbis records found for import");
            Allure.step("Orbis records found for import", step -> {
                softAssert.assertTrue(orbisRecordsCanImport.size() > 0);
            });

            boolean isInsertionSuccessful = false;

            for (WebElement element : orbisRecordsCanImport) {
                waitForPageToLoad(Duration.ofSeconds(60));
                elementClickByJS(driver, element);
                waitForPageToLoad(Duration.ofSeconds(60));
                takeScreenshot("orbisRecordtoImport", driver);
                waitForElementToBePresent(driver, By.name("sobjectname"));
                selectByVisibleText(driver, importAsSObject, objectName);
                waitForPageToLoad(Duration.ofSeconds(60));
                elementClickByJSwithoutLogger(driver, importBtn);

                String toastText = new WebDriverWait(driver, Duration.ofSeconds(240)).until(ExpectedConditions.visibilityOf(toastMessage)).getText().toLowerCase();

                try {
                    if (toastText.contains("succesfully been inserted")) {
                        loggerManager.getLogger().info("Record has been successfully inserted");
                        Allure.step("Record has been successfully inserted", step -> {
                            softAssert.assertTrue(toastText.contains("succesfully been inserted"));
                        });
                        takeScreenshot("Record has been successfully inserted", driver);
                        waitForPageToLoad(Duration.ofSeconds(60));
                        isInsertionSuccessful = true; // Set flag to true if insertion is successful
                        orbisImportedAccountelement_global = driver.findElement(By.xpath("((//a[@title='Import Company to Salesforce']//lightning-primitive-icon)[1])/preceding::*[@title='Redirect to existing Account on Salesforce'][1]"));
                        break; // Exit loop if insertion is successful
                    } else if (toastText.contains("unexpected error in orbis")) {
                        loggerManager.getLogger().error("Unexpected error in Orbis: " + toastText);
                        Allure.step("Unexpected error in Orbis", step -> {
                            softAssert.fail("Unexpected error in Orbis: " + toastText);
                        });
                        takeScreenshot("Unexpected error in Orbis", driver);
                        break; // Exit loop if unexpected error occurs
                    } else if (toastText.contains("populate the phone or email")||toastText.contains("Please Enter Primary City")) {
                        loggerManager.getLogger().warn("Please populate the phone or email of the lead: " + toastText);
                        Allure.step("Please populate the phone or email of the lead");
                    }
                } catch (Exception e) {
                    loggerManager.getLogger().warn("Exception occurred during record insertion", e);
                    Allure.step("Exception during record insertion", step -> {
                        softAssert.fail("Exception during record insertion: " + e.getMessage());
                    });
                    takeScreenshot("Exception during record insertion", driver);
                }
            }

            if (!isInsertionSuccessful) {
                loggerManager.getLogger().error("Record insertion was not successful");
                Allure.step("Record insertion was not successful", step -> {
                    Assert.fail("Record insertion was not successful");
                });
            }
        } else {
            loggerManager.getLogger().warn("No Orbis records found for import");
            Allure.step("No Orbis records found for import", step -> {
                softAssert.assertTrue(orbisRecordsCanImport.size() > 0, "No Orbis records found for import");
            });
            takeScreenshot("No Orbis records found for import", driver);
        }

        softAssert.assertAll();
    }

    // This method waits for the Orbis search table to load.
    public void waitForOrbisSearchTableToLoad() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        try {
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//a[@title='Import Company to Salesforce']//lightning-primitive-icon)[1]")));
            loggerManager.getLogger().info("Orbis search table is present in the DOM");
        } catch (Exception e) {
            loggerManager.getLogger().warn("Orbis search table is not present in the DOM within the timeout period");
        }
    }

    /**
     * This method opens a Salesforce record by its ID.
     * It first retrieves the base URL of the current page, then constructs the URL for the record by appending the record ID.
     * Finally, it navigates to the constructed URL.
     *
     * @param recordID String - The ID of the Salesforce record to be opened.
     */
    @Step("Open SFDC Record by ID")
    public void openSFDCRecordByID(String recordID){
        String baseUrl = getUrl();
        int index = baseUrl.indexOf(".force.com/");
        if (index != -1) {
            baseUrl = baseUrl.substring(0, index + ".force.com/".length());
        }
        String recordLink = baseUrl + recordID;
        loggerManager.getLogger().info("Opening SFDC link:" + recordLink);
        driver.get(recordLink);
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForUrlToContain(driver, recordID + "/view");
        ReusableLibrary.takeScreenshot(TCName, driver);
    }

    
    /**
     * Opens a Salesforce record from the global search.
     * This method performs the following steps:
     * 1. Waits for the page to load.
     * 2. Clicks on the Home tab.
     * 3. Clicks on the global search bar and enters the record name.
     * 4. Filters the search results by the specified object type.
     * 5. Clicks on the search result that matches the record name.
     * 6. Waits for the page to load and verifies that the correct record is opened.
     * @param objectName The type of Salesforce object to search for (e.g., Lead, Account).
     * @param recordName The name of the record to open.
     */
    @Step("Open {objectName} Record: {recordName} from Global Search")
    public void openSFDCRecordFromGlobalSearch(String objectName, String recordName){
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForElementToBeVisible(driver, homeTab);
        elementClickByJS(driver, homeTab);
        waitForElementToBeVisible(driver, globalSearchBar);
        elementClick(driver, globalSearchBar);
        waitForElementToBeVisible(driver, globalSearchTextField);
        sendKeysToElement(driver, globalSearchTextField, recordName);
        globalSearchTextField.sendKeys(Keys.ENTER);
        waitForElementToBePresent(driver, objectFilterOnSearchResult(objectName));
        elementClick(driver, driver.findElement(objectFilterOnSearchResult(objectName)));
        waitForElementToBePresent(driver, searchResultRecord(recordName));
        elementClick(driver, driver.findElement(searchResultRecord(recordName)));
        waitForPageToLoad(Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
        waitForPageTitleToContain(driver, recordName + " | ");
        Allure.step("Validate that " + objectName + ": " + recordName + " is opened in SFDC", step -> {
            Assert.assertTrue(driver.getTitle().contains(recordName + " | "), "Failed to open " + objectName + " record: " + recordName);
            ReusableLibrary.takeScreenshot(TCName, driver);
        });
    }

    // This method locate the orbisResultAccountName element dynamically
    public WebElement getOrbisResultAccountName() {
        String bvdID = reusableLibrary.readExcelData(accountsFilePath, TCName, "BvdID");
        String accountName = reusableLibrary.readExcelData(accountsFilePath, TCName, "Account Name");
        String xpath = "//a[@id='" + bvdID + "'][text()='" + accountName + "']";
        return driver.findElement(By.xpath(xpath));
    }

    public void verifyOrbisResultAccountAvailability() {
    // Wait for the page to load
    waitForPageToLoad(Duration.ofSeconds(60));
    // Wait for the orbisSearchResult element to be visible
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
    wait.until(ExpectedConditions.visibilityOf(orbisSearchResult));
    WebElement orbisResultAccountName = getOrbisResultAccountName();
    Allure.step("Verify that orbis match result account name exists", () -> {
        softAssert.assertNotNull(orbisResultAccountName, "Orbis result match account name not found");
        takeScreenshot("Orbis result match account name exists", driver);
        loggerManager.getLogger().info("Orbis result match account name exists");
    });
    elementClickByJS(driver, orbisResultAccountName);
    // Wait for the page to load
    waitForPageToLoad(Duration.ofSeconds(60));

    // Switch to the orbisAccountiframe
        waitforFrametoLoad(driver, orbisAccountiframe);
        switchToIframeByXpath(driver,orbisAccountiframe);

    // Check if orbisComponentAccountName is displayed
    Allure.step("Check if orbis component account name is displayed", () -> {
        if (isElementDisplayed(driver, orbisComponentAccountName)) {
            // Assert that the text of orbisComponentAccountName matches the expected account name
            String expectedAccountName = reusableLibrary.readExcelData(accountsFilePath, TCName, "Account Name");
            softAssert.assertEquals(orbisComponentAccountName.getText(), expectedAccountName, "Account name does not match");
            takeScreenshot("Orbis component account name element displayed", driver);
            loggerManager.getLogger().info("Orbis component account name element displayed");
        } else {
            softAssert.fail("Orbis component account name element not displayed");
            takeScreenshot("Orbis component account name element not displayed", driver);
            loggerManager.getLogger().error("Orbis component account name element not displayed");
        }
    });
    // Switch back to the default content
    driver.switchTo().defaultContent();
    softAssert.assertAll();
}

    public void orbisSearchShowsRecordNotInSFDC() {
        waitForPageToLoad(Duration.ofSeconds(60));
        if (isElementDisplayed(driver, showAllOrbisRecords)) {
            elementClickByJS(driver, showAllOrbisRecords);
            waitForPageToLoad(Duration.ofSeconds(60));
        }
        Allure.step("Verify if account record not in SFDC is found", () -> {
            waitForElementToBeVisible(driver, orbisSearchResult);
            if (orbisRecordsCanImport.size() > 0) {
                loggerManager.getLogger().info("Account record found which is not in SFDC");
                softAssert.assertTrue(true, "Account record found which is not in SFDC");
            } else {
                loggerManager.getLogger().error("Unable to find account record which is not in SFDC");
                softAssert.fail("Unable to find account record which is not in SFDC");
            }
            takeScreenshot("orbisSearchShowsRecordNotInSFDC", driver);
        });
        softAssert.assertAll();
    }

    public void changeOrbisSearchCriteria(String companyName) {
        waitForPageToLoad(Duration.ofSeconds(60));
        waitForElementToBeVisible(driver, changeSearchCriteria);
        elementClickByJS(driver, changeSearchCriteria);
        waitForElementToBeVisible(driver, changeSearch_companyNameField);
        loggerManager.getLogger().info("Changing search criteria on Orbis to: " + companyName);

        changeSearch_companyNameField.sendKeys(companyName);
        if (isElementDisplayed(driver, changeSearch_searchBtn)) {
            elementClickByJS(driver, changeSearch_searchBtn);
            loggerManager.getLogger().info("Search criteria changed successfully");
            takeScreenshot("Search criteria changed successfully", driver);
        } else {
            loggerManager.getLogger().warn("Search button not found, unable to change search criteria");
            takeScreenshot("Search button not found, unable to change search criteria", driver);
        }
        waitForPageToLoad(Duration.ofSeconds(60));

    }

    // This method imports an Orbis record as a Salesforce object from Orbis report page.
    public void importOrbisAccountwithActionUpdateCRM() {

        Allure.step("Check if Orbis account record to import exists", () -> {
            if (isElementDisplayed(driver, orbisRecordtoImport_CompanyNameLnk)) {
                loggerManager.getLogger().info("Orbis account record found to import");
                takeScreenshot("Orbis account record found to import", driver);
                elementClickByJS(driver, orbisRecordtoImport_CompanyNameLnk);
                waitForPageToLoad(Duration.ofSeconds(60));
            } else {
                loggerManager.getLogger().error("No Orbis account record found to import");
                softAssert.fail("No Orbis account record found to import");
                takeScreenshot("No Orbis account record found to import", driver);
            }
        });


        Allure.step("Verify orbis account reports detail populated", () -> {
            if (isElementDisplayed(driver, orbisAccountiframe)) {
                softAssert.assertTrue(isElementDisplayed(driver, orbisAccountiframe), "Orbis report component found");
                takeScreenshot("Orbis report component found", driver);
                loggerManager.getLogger().info("Orbis report component found");
            } else {
                softAssert.fail("Unable to find orbis report component");
                takeScreenshot("Unable to find orbis report component", driver);
                loggerManager.getLogger().error("Unable to find orbis report component");
            }
        });
        switchToIframeByXpath(driver, orbisAccountiframe);
        waitForElementToBeVisible(driver, orbisReport_Actions);
        elementClickByJS(driver, orbisReport_Actions);
        elementClickByJS(driver, orbisReport_UpdateCRM);

        waitForPageToLoad(Duration.ofSeconds(60));
        waitForElementToBePresent(driver, By.name("sobjectname"));
        switchToWindowByNumber(driver,0);
        selectByVisibleText(driver, orbisReport_importAsSObject, "Account");
        waitForPageToLoad(Duration.ofSeconds(60));
        elementClickByJS(driver,orisReport_Confirm);
        waitForElementToBeVisible(driver, orbisReport_spinnerDisappeared);
        //validate Account record shown as imported to salesforce
        switchToIframeByXpath(driver, orbisAccountiframe);
        waitForElementToBeVisible(driver, orbisReport_Actions);
        elementClickByJS(driver, orbisReport_Actions);
        elementClickByJS(driver, orbisReport_UpdateCRM);
        waitForPageToLoad(Duration.ofSeconds(60));
        waitForElementToBePresent(driver, By.name("sobjectname"));
        switchToWindowByNumber(driver,0);
        Allure.step("Verify orbis account record imported to Salesforce", () -> {
            if (isElementDisplayed(driver, orbisImportedAccountelement)) {
                loggerManager.getLogger().info("Orbis account record imported to Salesforce");
                softAssert.assertTrue(isElementDisplayed(driver, orbisImportedAccountelement), "Orbis account record imported to Salesforce");
                takeScreenshot("Orbis account record imported to Salesforce", driver);
            } else {
                loggerManager.getLogger().error("Orbis account record not imported to Salesforce");
                Assert.fail("Orbis account record not imported to Salesforce");
                takeScreenshot("Orbis account record not imported to Salesforce", driver);
            }
        });
        softAssert.assertAll();
    }

    // This method logs in as the specified user. Supply the user name as the key.
    @Step("Step: Login as the user with the specified user : " + "{key}")
    public void loginAsUser(String key) {
        String methodName = Thread.currentThread().getStackTrace()[1].getMethodName();
        String baseUrl = getUrl();
        int index = baseUrl.indexOf(".force.com/");
        if (index != -1) {
            baseUrl = baseUrl.substring(0, index + ".force.com/".length());
        }
        // Append with the result from reusableLibrary.readExcelData
        String loginUserUrl = baseUrl + readExcelCellValue(userCredentialsFilePath, prop.getProperty("LoginAs"),"User", key, "Userid");
        driver.get(loginUserUrl);
        elementClick(driver, userdetailBtn);
        waitForPageToLoad(Duration.ofSeconds(360));
        waitforFrametoLoad(driver, userframe);
        if (isElementDisplayed(driver, loginAsBtn)) {
            waitForPageToLoad(Duration.ofSeconds(60));
            loginAsBtn.click();
            waitForPageToLoad(Duration.ofSeconds(60));
            loggerManager.getLogger().info("LoginAs successful with profile: " + key);
            driver.switchTo().defaultContent();
            waitForElementToBeVisible(driver, logOutAs);
            Assert.assertTrue(isElementDisplayed(driver, logOutAs), "Proxy login failed");
            takeScreenshot(methodName, driver);
        }
    }

}
