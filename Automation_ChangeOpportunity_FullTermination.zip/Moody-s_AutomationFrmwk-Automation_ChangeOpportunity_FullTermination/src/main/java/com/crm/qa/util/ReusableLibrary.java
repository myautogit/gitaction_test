package com.crm.qa.util;

import com.crm.qa.base.TestBase;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import io.qameta.allure.Allure;
import io.qameta.allure.Attachment;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import static com.crm.qa.util.AbstractDataLibrary.*;

/**
 * This class contains reusable methods/utilities that can be used across the framework
 * Author: Sayon Das
 * Last Modified By: Arshin Shaikh
 * Date: 01/21/2025
 * Comment: Added new methods getColumnNumber and zoomOutScreenUsingRobot
 */

public class ReusableLibrary extends TestBase {

	public static Properties prop;
	private static Select dropdown;
	public static JavascriptExecutor js;
	public static WebDriverWait wait;
	public static Actions actions;


	// This method initializes the properties file.
	public static Properties initializeProperties() {
		FileInputStream ip = null;
		if (prop == null) {
			prop = new Properties();
			try {
				ip = new FileInputStream(configFilePath);
				prop.load(ip);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				loggerManager.getLogger().error(e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
				loggerManager.getLogger().error(e.getMessage());
			} finally {
				try {
					if (ip != null) {
						ip.close();
						//loggerManager.getLogger().info("FileInputStream for properties file closed successfully");
					}
				} catch (IOException e) {
					e.printStackTrace();
					loggerManager.getLogger().error(e.getMessage());
				}
			}
		}
		return prop;
	}


	//This method retrieves the value of a specified key from the properties file
	public static String getConfigProperty(String key) {

		loggerManager.getLogger().info("Reading property value for key: " + key);
		return prop.getProperty(key);
	}

	//This method sets the value of a specified key in the properties file
	public static void setConfigProperty(String key, String value) {
		// Set the property value for the given key in the properties object
		prop.setProperty(key, value);

		// Use try-with-resources to ensure the FileOutputStream is closed
		try (FileOutputStream fos = new FileOutputStream(configFilePath)) {
			// Store the properties object to the config file
			prop.store(fos, null);
		} catch (IOException ex) {
			// Print the stack trace for the IOException
			ex.printStackTrace();
			loggerManager.getLogger().error(ex.getMessage());
		}

		loggerManager.getLogger().info("Property value set successfully for key: " + key);
	}

	/**
	 * This method reads data from a JSON file based on a given key.
	 * It uses a BufferedReader to read the file content into a String.
	 * Then it creates a JSONObject from the content and retrieves the value associated with the provided key.
	 * The value is then returned as a String.
	 *
	 * @param fileLoc String - The location of the JSON file to be read.
	 * @param key String - The key whose associated value is to be retrieved from the JSON file.
	 * @return String - The value associated with the provided key in the JSON file.
	 */
	public static String readJSONFileByKey(String fileLoc, String key) {
		String data = null;
		// Use try-with-resources to ensure the BufferedReader is closed
		try (BufferedReader reader = new BufferedReader(new FileReader(fileLoc));){

			// Read the file content into a String
			String content=new String(Files.readAllBytes(Paths.get(fileLoc)));
			JSONObject jsonObject = new JSONObject(content);
			data= jsonObject.getJSONObject(key).toString();

		} catch (IOException e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
		}

		loggerManager.getLogger().info("Data read successfully from JSON file for key: " + key);

		return data;
	}
	
	/**
	 * This method reads the content of an XML file and returns it as a string.
	 * It uses a BufferedReader to read the file line by line into a StringBuilder.
	 * The StringBuilder is then converted to a string which represents the entire content of the XML file.
	 *
	 * @param fileLoc String - The location of the XML file to be read.
	 * @return String - The content of the XML file as a string.
	 */
	public static String readXMLFile(String fileLoc) {
		String xml2String = null;
		// Use try-with-resources to ensure the BufferedReader is closed
		try (BufferedReader reader = new BufferedReader(new FileReader(fileLoc))){
			StringBuilder sb= new StringBuilder();
			String line = reader.readLine();
			while (line != null) {
				sb.append(line);
				sb.append(System.lineSeparator());
				line = reader.readLine();
			}
			xml2String= sb.toString();
		} catch (IOException e) {
			loggerManager.getLogger().error("TestNG xml is not found at the specified location");
		}
		loggerManager.getLogger().info("Data read successfully from XML file");
		return xml2String;
	}
	

    //This method reads data from an Excel file based on a given test case name and column name
	public static String readExcelData(String filePath, String testCaseName, String columnName) {

		String value = null;

		// Use try-with-resources to ensure the FileOutputStream is closed
		try (FileInputStream fis = new FileInputStream(new File(filePath).getCanonicalPath());
			 Workbook workbook = new XSSFWorkbook(fis)) {

			// Get the Sheet from the Workbook using the sheet name from properties
			Sheet sheet = workbook.getSheet(env);

			// Get an Iterator object for all the rows in the sheet
			Iterator<Row> rows = sheet.iterator();

			int columnNumber = -1;

			// If there is at least one row, get the first row as the header row
			if (rows.hasNext()) {
				Row headerRow = rows.next();

				// For each cell in the header row
				for (Cell cell : headerRow) {
					// If the cell value equals the column name we are looking for
					if (cell.getStringCellValue().equals(columnName)) {
						// Get the column number of the cell
						columnNumber = cell.getColumnIndex();
						break;
					}
				}
			}

			// For each row in the sheet
			while (rows.hasNext()) {
				Row row = rows.next();

				// Get the first cell in the row as the key cell
				Cell keyCell = row.getCell(0);

				// If the key cell is not null, is a string, and equals the test case name
				if (keyCell != null && keyCell.getCellType() == CellType.STRING && keyCell.getStringCellValue().equals(testCaseName)) {
					// Get the cell in the column we are interested in
					Cell valueCell = row.getCell(columnNumber);

					// If the value cell is not null and is a string
					if (valueCell != null && valueCell.getCellType() == CellType.STRING) {
						// Get the string value of the cell
						value = valueCell.getStringCellValue();
						break;
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
		}

		loggerManager.getLogger().info("Data read successfully from Excel file for test case: " + testCaseName + ", column: " + columnName);

		// Return the value we found, or null if we didn't find it
		return value;
	}


	//This method reads rows from an Excel file based on a given column name and column value
	public static List<LinkedHashMap<String, String>> readExcelRows(String filePath, String testCaseName) {
		List<LinkedHashMap<String, String>> list = new ArrayList<>();

		try (FileInputStream fis = new FileInputStream(filePath);

			Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0); // assuming you want to read from the first sheet

            // Get the header row and store the column names
            Row headerRow = sheet.getRow(0);
            List<String> columnNames = new ArrayList<>();
            headerRow.forEach(cell -> columnNames.add(cell.getStringCellValue()));

            for (Row row : sheet) {
                Cell firstCell = row.getCell(0);
                if (firstCell != null && CellType.STRING.equals(firstCell.getCellType()) && testCaseName.equals(firstCell.getStringCellValue())) {
                    LinkedHashMap<String, String> map = new LinkedHashMap<>();
					for (int i = 0; i < columnNames.size(); i++) {
						Cell cell = row.getCell(i);
						String cellValue = null;
						if (cell != null) {
							if (cell.getCellType() == CellType.STRING)
								cellValue = cell.getStringCellValue();
						}
						map.put(columnNames.get(i), cellValue);
					}
                    list.add(map);
                }
            }

		} catch (IOException e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
		}

		loggerManager.getLogger().info("Row Data read successfully from Excel file for test case: " + testCaseName);

        return list;
    }

    //This method reads the entire content of a CSV file and returns it as a string
    public static String readCSV(String filePath) {
        // Create a StringBuilder to store the content of the CSV file
        StringBuilder sb = new StringBuilder();

		// Use a try-with-resources statement to ensure the BufferedReader is closed at the end
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String line;
			// Read each line of the CSV file until there are no more lines
			while ((line = br.readLine()) != null) {
				// Append each line to the StringBuilder
				sb.append(line);
				// Append a line separator to preserve the original CSV format
				sb.append(System.lineSeparator());
			}
		} catch (IOException e) {
			// Print the stack trace if an IOException is caught
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
		}

		loggerManager.getLogger().info("Data read successfully from CSV file" + filePath);

        // Return the content of the CSV file as a string
        return sb.toString();
    }


	//This method writes data to an Excel file based on a given test case name and column name.
	public static void writeToExcel(String filePath, String testCaseName, String columnName, String valueToWrite) {
		Workbook workbook = null;
		try (FileInputStream fis = new FileInputStream(filePath)) {
			workbook = new XSSFWorkbook(fis);
			Sheet sheet = workbook.getSheet(env);

			// Create a map to store column names and their indices
			Map<String, Integer> headerMap = new HashMap<>();
			Row headerRow = sheet.getRow(0);
			// Loop through each cell in the header row
			for (Cell cell : headerRow) {
				// Put the cell value and column index in the map
				headerMap.put(cell.getStringCellValue(), cell.getColumnIndex());
			}

			// Get the column index from the map using the column name
			Integer columnNumber = headerMap.get(columnName);

			// If the column number is not null, proceed
			if (columnNumber != null) {
				Iterator<Row> rows = sheet.iterator();
				// Loop through each row in the sheet
				while (rows.hasNext()) {
					Row row = rows.next();
					// Get the first cell in the row
					Cell keyCell = row.getCell(0);
					// If the first cell value matches the test case name, proceed
					if (keyCell != null && keyCell.getCellType() == CellType.STRING && keyCell.getStringCellValue().equals(testCaseName)) {
						// Get the cell in the column we are interested in
						Cell cellToWrite = row.getCell(columnNumber, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
						// Set the cell value
						cellToWrite.setCellValue(valueToWrite);
						break;
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
		}

		// If the workbook is not null, proceed
		if (workbook != null) {
			try (FileOutputStream fos = new FileOutputStream(filePath)) {
				// Write the workbook to the file
				workbook.write(fos);
			} catch (IOException e) {
				e.printStackTrace();
				loggerManager.getLogger().error(e.getMessage());
			}
		}

		loggerManager.getLogger().info("Data written successfully to Excel file for test case: " + testCaseName + ", column: " + columnName);
	}

	//This method appends data to a CSV file
	public static void appendToCSV(String filePath, String valueToAppend) {
		try (FileWriter writer = new FileWriter(filePath, true)) {

            // Append the specified value to the CSV file
            writer.append(valueToAppend);

		} catch (IOException e) {
			// Print the stack trace for the IOException
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
		}

		loggerManager.getLogger().info("Data appended successfully to CSV file" + filePath);

	}

	// This method takes a screenshot and adds it to the screenshot folder and  Allure report
	@Attachment(value = "Screenshot", type = "image/png")
	public static byte[] takeScreenshot(String testClassName, WebDriver driver) {
		String timestamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(source, new File(takeScreenshotPath + testClassName + "_" + timestamp + ".png"));
			loggerManager.getLogger().info("Screenshot is successfully capture " + testClassName);
		} catch (IOException e) {
			loggerManager.getLogger().error("Exception while taking screenshot " + e.getMessage());
		}
		return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	}


    //	This method is used to decrypt a password
    //	The encrypted password is a string of ASCII codes separated by a delimiter
    //	Each ASCII code corresponds to a character in the decrypted password
    public static String decryptPassword(String str) {
        // Split the encrypted password string by the delimiter
        String[] splitStr = str.split("\\Q" + "|" + "\\E");

        // Create a StringBuilder to build the decrypted password
        StringBuilder builder = new StringBuilder(splitStr.length);

		// For each ASCII code in the split string
		for (String s : splitStr) {
			// Convert the ASCII code to an integer, then to a character, and append it to the StringBuilder
			builder.append((char) Integer.parseInt(s));
		}

        // Convert the StringBuilder to a string to get the decrypted password and return it
        return builder.toString();
    }


	// This method reads the content of a PDF file and returns it as a list of strings.
	// Each string in the list represents the content of one page in the PDF.
	public static List<String> readPDF(String fileName) {
		PdfReader reader = null;

		// Create a list to store the content of the PDF
		List<String> pdfContent = new ArrayList<>();
		try {
			reader = new PdfReader(downloadPath + "/" + fileName);

			// Get the number of pages in the PDF
			int n = reader.getNumberOfPages();

			// Loop through each page in the PDF
			for (int i = 1; i <= n; i++) {
				// Extract the text from the current page and add it to the list
				String str = PdfTextExtractor.getTextFromPage(reader, i);
				pdfContent.add(str);
			}

			// Close the PdfReader instance
			reader.close();
		} catch (IOException e) {
			// Log any IOException that occurs
			loggerManager.getLogger().error(e.getMessage());
		}
		finally {
			// Close the PdfReader instance if it is not null
			if (reader != null)
				reader.close();
		}
		loggerManager.getLogger().info("PDF file read successfully: " + fileName);

		// Return the list of page contents
		return pdfContent;
	}
  
	// This method generates the current date in MM/dd/yyyy format
	public static String getCurrentDateInMMddyyyyFormat(){
    
		// Create a SimpleDateFormat object with the desired format
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");

		// Get the current date
		Date date = new Date();

		// Format the current date
		String strDate = formatter.format(date);

		// Return the formatted date
		return strDate;
	}

	// This method generates the current date in yyyyMMdd_HHmmss format
	public static String getCurrentDateInyyyyMMdd_HHmmssFormat(){
		// Create a SimpleDateFormat object with the desired format
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd_HHmmss");

		// Get the current date
		Date date = new Date();

		// Format the current date
		String strDate = formatter.format(date);

		// Return the formatted date
		return strDate;
	}

	// This method generates the current date in MM/dd/yyyy_HHmmss format
	public static String getCurrentDateInMMddyyyy_HHmmssFormat(){
		// Create a SimpleDateFormat object with the desired format
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy_HHmmss");

		// Get the current date
		Date date = new Date();

		// Format the current date
		String strDate = formatter.format(date);

		// Return the formatted date
		return strDate;
	}

	// This method adds the specified number of days to the current date and returns the new date in MM/dd/yyyy format
	public static String currentDatePlusDays(int days) {
		// Create a Calendar object and set it to the current date
		Calendar calendar = Calendar.getInstance();

		// Add the specified number of days to the calendar
		calendar.add(Calendar.DAY_OF_MONTH, days);

		// Get the new date
		Date futureDate = calendar.getTime();

		// Format the new date
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		String strDate = formatter.format(futureDate);

		// Return the formatted date
		return strDate;
	}

	// This method adds the specified number of months to the current date and returns the new date in MM/dd/yyyy format
	public static String currentDatePlusMonths(int months) {
		// Create a Calendar object and set it to the current date
		Calendar calendar = Calendar.getInstance();

		// Add the specified number of months to the calendar
		calendar.add(Calendar.MONTH, months);

		// Get the new date
		Date futureDate = calendar.getTime();

		// Format the new date
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		String strDate = formatter.format(futureDate);

		// Return the formatted date
		return strDate;
	}

	// This method adds the specified number of years to the current date and returns the new date in MM/dd/yyyy format
	public static String currentDatePlusYears(int years) {
		// Create a Calendar object and set it to the current date
		Calendar calendar = Calendar.getInstance();

		// Add the specified number of years to the calendar
		calendar.add(Calendar.YEAR, years);

		// Get the new date
		Date futureDate = calendar.getTime();

		// Format the new date
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
		String strDate = formatter.format(futureDate);

		// Return the formatted date
		return strDate;
	}

	// This method adds the specified number of days to a custom date and returns the new date in MM/dd/yyyy format
	// The custom date should be in MM/dd/yyyy format
	public static String customDatePlusDays(int days, String date) {
		try {
			// Create a SimpleDateFormat object with the desired format
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

			// Parse the custom date
			Date customDate = formatter.parse(date);

			// Create a Calendar object and set it to the custom date
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(customDate);

			// Add the specified number of days to the calendar
			calendar.add(Calendar.DAY_OF_MONTH, days);

			// Get the new date
			Date futureDate = calendar.getTime();

			// Format the new date
			String strDate = formatter.format(futureDate);

			// Return the formatted date
			return strDate;
		} catch (Exception e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
			return null;
		}
	}

	// This method adds the specified number of months to a custom date and returns the new date in MM/dd/yyyy format
	// The custom date should be in MM/dd/yyyy format
	public static String customDatePlusMonths(int months, String date) {
		try {
			// Create a SimpleDateFormat object with the desired format
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

			// Parse the custom date
			Date customDate = formatter.parse(date);

			// Create a Calendar object and set it to the custom date
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(customDate);

			// Add the specified number of months to the calendar
			calendar.add(Calendar.MONTH, months);

			// Get the new date
			Date futureDate = calendar.getTime();

			// Format the new date
			String strDate = formatter.format(futureDate);

			// Return the formatted date
			return strDate;
		} catch (Exception e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
			return null;
		}
	}
	/**
	 * Subtracts a specified number of days from the given date string.
	 *
	 * @param dateString The date string in the format "yyyy-MM-dd".
	 * @param daysToSubtract The number of days to subtract.
	 * @return The new date string with the specified number of days subtracted.
	 */
	public static String subtractDays(String dateString, int daysToSubtract) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		try {
			LocalDate date = LocalDate.parse(dateString, formatter);
			LocalDate newDate = date.minusDays(daysToSubtract);
			return newDate.format(formatter);
		} catch (DateTimeParseException e) {
			throw new IllegalArgumentException("Invalid date format. Please use 'yyyy-MM-dd'.", e);
		}
	}

	// This method adds the specified number of years to a custom date and returns the new date in MM/dd/yyyy format
	// The custom date should be in MM/dd/yyyy format
	public static String customDatePlusYears(int years, String date) {
		try {
			// Create a SimpleDateFormat object with the desired format
			SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");

			// Parse the custom date
			Date customDate = formatter.parse(date);

			// Create a Calendar object and set it to the custom date
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(customDate);

			// Add the specified number of years to the calendar
			calendar.add(Calendar.YEAR, years);

			// Get the new date
			Date futureDate = calendar.getTime();

			// Format the new date
			String strDate = formatter.format(futureDate);

			// Return the formatted date
			return strDate;
		} catch (Exception e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
			return null;
		}
	}

	// This method generates a random string with the specified prefix
	public static String generateRandomString(String prefix) {

		// Return the random string with the specified prefix
		return prefix + "_" + RandomStringUtils.randomAlphabetic(10);

	}

	// This method generates a random number with the specified length
	public static int generateRandomNumber(int length) {
    
  	// Create a Random object for generating random numbers
		Random random = new Random();

		// Calculate the lower and upper bounds for the random number
		// The lower bound is 10^(length-1) and the upper bound is 10^length
		// For example, if length is 3, the lower bound is 100 and the upper bound is 1000
		int lowerBound = (int) Math.pow(10, length - 1);
		int upperBound = (int) Math.pow(10, length);

		// Generate a random number within the range [lowerBound, upperBound)
		// The generated number will always have the specified length
		// The random number is generated by adding a random integer (between 0 and the difference between upperBound and lowerBound) to the lowerBound

		// Return the generated random number
		return lowerBound + random.nextInt(upperBound - lowerBound);
	}  

	// This method performs a click action on a specified web element
	public static void elementClick(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			actionObject.click();
			loggerManager.getLogger().info(element + " is clicked successfully");
		} catch (Exception e) {
			//This is under observation.
			elementClickByJS(driver, element);
			loggerManager.getLogger().error("Exception while clicking on " + element + " " + e.getMessage());
			//Assert.assertTrue(false, "Failed to click on " + element);
		}

	}

	// This method performs a click action on a specified web element using JavaScript
	public static void elementClickByJS(WebDriver driver, WebElement element) {
		try {
			js = (JavascriptExecutor) driver;
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			js.executeScript("arguments[0].click();", actionObject);
			loggerManager.getLogger().info(element + " is clicked successfully by JS");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while clicking on " + element + " using JS" + e.getMessage());
			Assert.assertTrue(false, "Failed to click on " + element + " by JS");
		}

	}

	// This method performs a right-click action on the specified web element
	public static void contextClickElement(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			actions = new Actions(driver);
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			actions.contextClick(element).perform();
			loggerManager.getLogger().info(element + " is  right clicked successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while right clicking on " + element + " " + e.getMessage());
			Assert.assertTrue(false, "Failed to right click on " + element);
		}
	}

	// This method performs a double-click action on the specified web element
	public static void doubleClickElement(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			actions = new Actions(driver);
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			actions.doubleClick(actionObject).perform();
			loggerManager.getLogger().info(element + " is double clicked successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while double clicking on " + element + " " + e.getMessage());
			Assert.assertTrue(false, "Failed to double click on " + element);
		}
	}

	// This method moves the mouse  pointer to the middle of the specified web element
	public static void moveToElement(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			actions = new Actions(driver);
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			actions.moveToElement(actionObject).perform();
			loggerManager.getLogger().info("Moved to" + element + " successfully");
		} catch (Exception e) {
			//WebElement name is not included. Include that
			loggerManager.getLogger().error("Exception while moving to" + element + " " + e.getMessage());
			Assert.assertTrue(false, "Failed to move to " + element);
		}
	}

	// This method selects an option from a dropdown menu by its visible text
	public static void selectByVisibleText(WebDriver driver, WebElement element, String text) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			Thread.sleep(8000);
			//slowdown execution by waiting to match attribute value
			By locator;
			if (element.getAttribute("id") != null) {
				locator = By.id(element.getAttribute("id"));
			} else {
				locator = By.className(element.getAttribute("class"));
			}
			Boolean actionObject = wait.until(ExpectedConditions.textMatches(locator, Pattern.compile("^(.*)")));
			dropdown = new Select(element);
			dropdown.selectByVisibleText(text);
			loggerManager.getLogger().info(element + " is selected successfully from the dropdown by  Text");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while selecting " + element + "from the dropdown by Text" + e.getMessage());
			Assert.assertTrue(false, "Failed to select value " + text + " from " + element);
		}
	}

	// This method selects an option from a dropdown menu by  its index
	public static void selectByIndex(WebDriver driver, WebElement element, int index) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			dropdown = new Select(element);
			dropdown.selectByIndex(index);
			loggerManager.getLogger().info(element + " is selected successfully from the dropdown By Index");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while selecting " + element + "from the dropdown by Index" + e.getMessage());
			Assert.assertTrue(false, "Failed to select value at index " + index + " from " + element);
		}
	}

	// This method selects an option from a dropdown menu by its value attribute
	public static void selectByValue(WebDriver driver, WebElement element, String value) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			dropdown = new Select(element);
			dropdown.selectByValue(value);
			loggerManager.getLogger().info(element + " is selected successfully from the dropdown By Value");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while selecting " + element + "from the dropdown by Value" + e.getMessage());
			Assert.assertTrue(false, "Failed to select value " + value + " from " + element);
		}
	}

	// This method deselects an option from a dropdown menu by its visible text
	public static void deselectByVisibleText(WebDriver driver, WebElement element, String text) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			dropdown = new Select(element);
			dropdown.deselectByVisibleText(text);
			loggerManager.getLogger().info(element + " is deselected successfully from the dropdown By Text");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while deselecting " + element + "from the dropdown by Text" + e.getMessage());
			Assert.assertTrue(false, "Failed to deselect value " + text + " from " + element);
		}
	}

	// This method deselects an option from a dropdown menu by its index
	public static void deselectByIndex(WebDriver driver, WebElement element, int index) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			dropdown = new Select(element);
			dropdown.deselectByIndex(index);
			loggerManager.getLogger().info(element + " is deselected successfully from the dropdown By Index");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while deselecting " + element + "from the dropdown by Index" + e.getMessage());
			Assert.assertTrue(false, "Failed to deselect value at index " + index + " from " + element);
		}
	}

	// This method deselects an option from a dropdown menu by its value attribute
	public static void deselectByValue(WebDriver driver, WebElement element, String value) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			dropdown = new Select(element);
			dropdown.deselectByValue(value);
			loggerManager.getLogger().info(element + " is deselected successfully from the dropdown By Value");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while deselecting " + element + "from the dropdown by Value" + e.getMessage());
			Assert.assertTrue(false, "Failed to deselect value " + value + " from " + element);
		}
	}

	// This method deselects all selected options from a multi-select dropdown menu
	public static void deselectAll(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			dropdown = new Select(element);
			dropdown.deselectAll();
			loggerManager.getLogger().info("All Values are deselected for " + element + " from the dropdown");
		} catch (Exception e) {
			//add element name
			loggerManager.getLogger().error("Exception while deselecting all values  for  " + element + "from the dropdown" + e.getMessage());
			Assert.assertTrue(false, "Failed to deselect all values from " + element);
		}
	}

	// This method retrieves all options from a specified dropdown menu as a list of WebElements
	public static List<WebElement> getOptions(WebDriver driver, WebElement element) {
		List<WebElement> allOptions = new ArrayList<>();
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			dropdown = new Select(element);
			allOptions = dropdown.getOptions();
			loggerManager.getLogger().info(allOptions.size() + " options found in the dropdown");
			loggerManager.getLogger().info(allOptions + " are visible successfully from the dropdown");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while selecting" + allOptions + "from the dropdown" + e.getMessage());
		}
		return allOptions;
	}

	// This method sends a specified text to a given web element
	public static void sendKeysToElement(WebDriver driver, WebElement element, String text) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			element.sendKeys(text);
			loggerManager.getLogger().info(text + " is entered successfully into the Element");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while entering " + text + " into the Element" + e.getMessage());
			Assert.assertTrue(false, "Failed to enter " + text + " into " + element);
		}
	}

	// This method sends a specified text to a given web element using JavaScript
	public static void sendKeysToElementbyJS(WebDriver driver, WebElement element, String text) {
		try {
			js = (JavascriptExecutor) driver;
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			js.executeScript("arguments[0].value='" + text + "';", actionObject);
			loggerManager.getLogger().info(text + " is entered successfully into the Element by JS");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while entering " + text + " into the Element by JS " + e.getMessage());
			Assert.assertTrue(false, "Failed to enter " + text + " into " + element + " by JS");
		}
	}

	// This method switches the driver's context to the specified iframe using its WebElement
	public static void switchToIframeByXpath(WebDriver driver, WebElement iframe) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(iframe));
			driver.switchTo().frame(iframe);
			loggerManager.getLogger().info("Switched to iframe " + iframe + "successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while switching to iframe " + iframe + " " + e.getMessage());
		}
	}

	// This method switches the driver's context to the specified iframe using its id or name
	public static void switchToIframeByIndex(WebDriver driver, int index) {
		try {
			driver.switchTo().frame(index);
			loggerManager.getLogger().info("Switched to iframe " + index + "by index successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while switching to iframe " + index + " by index " + e.getMessage());
		}
	}

	// This method switches the WebDriver's context back to the default content from within an iframe
	public static void switchToDefaultContent(WebDriver driver) {
		try {
			driver.switchTo().defaultContent();
			loggerManager.getLogger().info("Switched to default content successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while switching to default content " + e.getMessage());
		}
	}

	// This method switches the WebDriver's context to the parent frame of the current frame
	public static void switchToParentFrame(WebDriver driver) {
		try {
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable((WebElement) driver));
			driver.switchTo().parentFrame();
			loggerManager.getLogger().info("Switched to parent frame successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while switching to parent frame " + e.getMessage());
		}
	}

	// This method executes a JavaScript command on a specified web element
	public static void executeJavaScript(WebDriver driver, String script, WebElement element) {
		try {
			js = (JavascriptExecutor) driver;
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			js.executeScript(script, actionObject);
			loggerManager.getLogger().info("JavaScript executed successfully for" + element);
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while executing JavaScript for " + element + " " + e.getMessage());
		}

	}
	// This method scrolls the web page until the specified web element is in the visible viewport of the browser
	public static void scrollToElement(WebDriver driver, WebElement element) {
		try {
			js = (JavascriptExecutor) driver;
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			js.executeScript("arguments[0].scrollIntoView(true);", actionObject);
			loggerManager.getLogger().info(element + "scrolled into view successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception  for " + element + "while scrolling into view " + e.getMessage());
		}

	}

	// This method scrolls the web page to the bottom
	public static void scrollToBottom(WebDriver driver) {
		try {
			js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0, document.body.scrollHeight)");
			loggerManager.getLogger().info("Scrolled to the end of the page successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while scrolling to the end of the page " + e.getMessage());
		}
	}

	// This method scrolls the web page to the top
	public static void scrollToTop(WebDriver driver) {
		try {
			js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollTo(0, 0)");
			loggerManager.getLogger().info("Scrolled to the top of the page successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while scrolling to  the top of the page" + e.getMessage());
		}
	}

	// This method checks if the specified web element is selected. If not, it selects it
	public static boolean isElementSelected(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			if (!actionObject.isSelected()){
				flag = true;
				loggerManager.getLogger().info(element + " is selected");
			}
		} catch (Exception e) {
			flag = false;
			loggerManager.getLogger().error(element + "is not selected");
		}
		return flag;
	}

	// This method checks if the specified  web element is displayed on the web page.
	public static boolean isElementDisplayed(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			if (actionObject.isDisplayed()) {
				flag = true;
				loggerManager.getLogger().info(element + " is displayed");
			}
		} catch (Exception e) {
			flag = false;
			loggerManager.getLogger().error(element+ "is not displayed");
		}
		return flag;
	}

	// This method checks if a specified web element is clickable or not
	public static boolean elementToBeClickable(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			if(actionObject.isEnabled()){
				flag = true;
				loggerManager.getLogger().info(element + " is clickable");
			}
		} catch (Exception e) {
			flag = false;
			loggerManager.getLogger().error(element + " is not clickable");
		}
		return flag;
	}

	// This method finds all elements within the current page using the given locator
	public static List<WebElement> findElements(WebDriver driver, WebElement element) {
		List<WebElement> elements = new ArrayList<>();
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			elements = driver.findElements((By) actionObject);
			loggerManager.getLogger().info("Number of" + elements + "occurrence returned successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while finding elements with " + elements + "properties");
		}
		return elements;
	}

	//This method reads data from an Excel file based on a given test case name, sheet name and column name
	public static String readExcelDataWithSheet(String filePath, String sheetName, String testCaseName, String columnName) {

		String value = null;

		// Use try-with-resources to ensure the FileOutputStream is closed
		try (FileInputStream fis = new FileInputStream(new File(filePath).getCanonicalPath());
			 Workbook workbook = new XSSFWorkbook(fis)) {

			// Attempt to get the sheet name from properties, providing a default if not found or null
			String sheetNameProperty = Optional.ofNullable(sheetName).orElse("defaultSheetName");

			// Get the Sheet from the Workbook using the sheet name from properties
			Sheet sheet = workbook.getSheet(sheetNameProperty);

			// Get an Iterator object for all the rows in the sheet
			Iterator<Row> rows = sheet.iterator();

			int columnNumber = -1;

			// If there is at least one row, get the first row as the header row
			if (rows.hasNext()) {
				Row headerRow = rows.next();

				// For each cell in the header row
				for (Cell cell : headerRow) {
					// If the cell value equals the column name we are looking for
					if (cell.getStringCellValue().equals(columnName)) {
						// Get the column number of the cell
						columnNumber = cell.getColumnIndex();
						break;
					}
				}
			}

			// For each row in the sheet
			while (rows.hasNext()) {
				Row row = rows.next();

				// Get the first cell in the row as the key cell
				Cell keyCell = row.getCell(0);

				// If the key cell is not null, is a string, and equals the test case name
				if (keyCell != null && keyCell.getCellType() == CellType.STRING && keyCell.getStringCellValue().equals(testCaseName)) {
					// Get the cell in the column we are interested in
					Cell valueCell = row.getCell(columnNumber);

					// If the value cell is not null and is a string
					if (valueCell != null && valueCell.getCellType() == CellType.STRING) {
						// Get the string value of the cell
						value = valueCell.getStringCellValue();
						break;
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
			loggerManager.getLogger().error(e.getMessage());
		}

		loggerManager.getLogger().info("Data read successfully from Excel file for test case: " + testCaseName + ", column: " + columnName);

		// Return the value we found, or null if we didn't find it
		return value;
	}
	public static void waitforFrametoLoad(WebDriver driver, WebElement element) {
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element));
			loggerManager.getLogger().info("Frame is loaded successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for frame to load " + e.getMessage());
		}
	}

	/**
	 * This method waits for an alert to be present within the given timeout period and accepts it.
	 * If no alert is present within the timeout period, it logs an error message.
	 *
	 * @param driver WebDriver - The WebDriver instance.
	 * @param timeoutInSeconds int - The maximum time to wait for the alert in seconds.
	 */
	public static void waitForAlertAndAccept(WebDriver driver, int timeoutInSeconds) {
		// Create a WebDriverWait object with the specified timeout
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutInSeconds));
		try {
			// Wait until an alert is present
			wait.until(ExpectedConditions.alertIsPresent());
			// Switch to the alert
			Alert alert = driver.switchTo().alert();
			// Accept the alert
			alert.accept();
		} catch (Exception e) {
			// Print a message to the console if no alert is present
			loggerManager.getLogger().error("No alert is present" + e.getMessage());
		}
	}

	/**
	 * This method performs a control click on a specified web element.
	 *
	 * @param driver WebDriver - The WebDriver instance.
	 * @param element WebElement - The web element to be clicked.
	 */
	public static void controlClickOnElement(WebDriver driver, WebElement element) {
		try {
			// Create a WebDriverWait object with a specified timeout
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));

			// Wait until the element is clickable
			element = wait.until(ExpectedConditions.elementToBeClickable(element));

			// Create an Actions object
			actions = new Actions(driver);

			// Perform a control click on the element
			actions.keyDown(Keys.CONTROL).click(element).keyUp(Keys.CONTROL).build().perform();

			// Log the successful control click action
			loggerManager.getLogger().info("Control click on element " + element + " is performed successfully");
		} catch (Exception e) {
			// Log any exceptions that occur while performing the control click action
			loggerManager.getLogger().error("Exception while performing control click on element " + element + " " + e.getMessage());
			Assert.assertTrue(false, "Failed to perform control click on element " + element);
		}
	}
	/**
	 * This method converts a date string from one format to another.
	 *
	 * @param dateStr String - The date string to be converted.
	 * @param fromFormat String - The original format of the date string.
	 * @param toFormat String - The target format of the date string.
	 * @return String - The converted date string.
	 */
	public static String convertDateFormat(String dateStr, String fromFormat, String toFormat) {
		// Create a SimpleDateFormat object for the original date format
		SimpleDateFormat fromDateFormat = new SimpleDateFormat(fromFormat);

		// Create a SimpleDateFormat object for the target date format
		SimpleDateFormat toDateFormat = new SimpleDateFormat(toFormat);

		// Initialize a Date object
		Date date = null;

		try {
			// Parse the date string into a Date object using the original date format
			date = fromDateFormat.parse(dateStr);
		} catch (ParseException e) {
			// Log an error message if the date string cannot be parsed
			loggerManager.getLogger().error("Exception while parsing date " + e.getMessage());
		}

		// Format the Date object into a string using the target date format and return it
		return toDateFormat.format(date);
	}


	/**
	 * This method switches the driver's context to a window by its index (number).
	 * It first retrieves all the window handles and checks if the window number provided is valid.
	 * If it is, it switches to the window with that index.
	 * If the window number provided is not valid, it logs an error message.
	 *
	 * @param driver WebDriver - The WebDriver instance.
	 * @param windowNumber int - The index of the window to switch to.
	 */
	public static void switchToWindowByNumber(WebDriver driver, int windowNumber) {
		List<String> windowHandles = new ArrayList<>(driver.getWindowHandles());

		if (windowNumber < windowHandles.size()) {
			driver.switchTo().window(windowHandles.get(windowNumber));
			loggerManager.getLogger().info("Switched to window number: " + windowNumber);
		} else {
			loggerManager.getLogger().error("Invalid window number");
		}
	}

	/**
	 * This method switches the driver's context to a window by its title.
	 * It first stores the current window handle so it can return to it if necessary.
	 * It then iterates over all the window handles, switching to each one and checking if its title matches the provided title.
	 * If it finds a match, it returns immediately.
	 * If it doesn't find a match after checking all windows, it switches back to the original window and logs an error message.
	 *
	 * @param driver WebDriver - The WebDriver instance.
	 * @param title String - The title of the window to switch to.
	 */
	public static void switchToWindowByTitle(WebDriver driver, String title) {
		String currentWindowHandle = driver.getWindowHandle();
		List<String> windowHandles = new ArrayList<>(driver.getWindowHandles());

		for (String windowHandle : windowHandles) {
			driver.switchTo().window(windowHandle);
			if (driver.getTitle().equals(title)) {
				loggerManager.getLogger().info("Switched to window with title: " + title);
				return;
			}
		}

		driver.switchTo().window(currentWindowHandle);
		loggerManager.getLogger().error("No window with title: " + title + " found");
	}


	/**
	 * This method selects an option from a picklist (dropdown) element on a web page.
	 * It first clicks on the picklist element to display the options.
	 * Then, it constructs an XPath expression to locate the desired option based on the provided value.
	 * If the option value contains a single quote, it handles it appropriately by using the `concat` function in XPath.
	 * Finally, it clicks on the desired option to select it.
	 *
	 * @param picklistElement WebElement - The picklist (dropdown) element to interact with.
	 * @param optionValue String - The value of the option to be selected from the picklist.
	 */
	public static void selectPicklistOption(WebElement picklistElement, String optionValue) {
		try {
			elementClick(driver, picklistElement);
			String xpathExpression;
			if (optionValue.contains("'")) {
				String[] parts = optionValue.split("'");
				StringBuilder xpathBuilder = new StringBuilder("//a[text()=concat(");
				for (int i = 0; i < parts.length; i++) {
					xpathBuilder.append("'").append(parts[i]).append("'");
					if (i < parts.length - 1) {
						xpathBuilder.append(", \"'\", ");
					}
				}
				xpathBuilder.append(")]");
				xpathExpression = xpathBuilder.toString();
			} else {
				xpathExpression = "//a[text()='" + optionValue + "']";
			}
			WebElement option = driver.findElement(By.xpath(xpathExpression));
			Allure.step("Validate that the option element in the picklist is found", step->{
				Assert.assertTrue(isElementDisplayed(driver, option), "This option is not displayed in the picklist");
			});
			elementClick(driver, option);
		} catch (NoSuchElementException e) {
			loggerManager.getLogger().error("Error selecting picklist option: "+ optionValue, e);
			Assert.fail("Failed to select picklist option: " + picklistElement.getText(), e);
		}

		loggerManager.getLogger().info("Selected picklist option: " + optionValue +"from"+picklistElement.getText()+"successfully");
	}
	/**
	 * This method waits for a specified web element to be visible on the page.
	 * It uses WebDriverWait to poll the DOM every 5 seconds until the element is visible or the timeout period is reached.
	 *
	 * @param driver WebDriver - The WebDriver instance.
	 * @param element WebElement - The web element to wait for.
	 */
	public static void waitForElementToBeVisible(WebDriver driver, WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			wait.pollingEvery(Duration.ofSeconds(5)); // Poll every 5 seconds
			wait.until(ExpectedConditions.visibilityOf(element));
		}
		catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for element to be visible: " + e.getMessage());
		}
	}

	/**
	 * This method waits for a specified web element to be clickable on the page.
	 * It uses WebDriverWait to poll the DOM every 5 seconds until the element is clickable or the timeout period is reached.
	 *
	 * @param driver WebDriver - The WebDriver instance.
	 * @param element WebElement - The web element to wait for.
	 */
	public static void waitForElementToBeClickable(WebDriver driver, WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			wait.pollingEvery(Duration.ofSeconds(5)); // Poll every 5 seconds
			wait.until(ExpectedConditions.elementToBeClickable(element));
		}
		catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for element to be clickable: " + e.getMessage());
		}
	}

	//Use this method when you want to click on an element using JS and want to avoid any delay for logging after click
	public static void elementClickByJSwithoutLogger(WebDriver driver, WebElement element) {
		try {
			js = (JavascriptExecutor) driver;
			wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.elementToBeClickable(element));
			js.executeScript("arguments[0].click();", actionObject);
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while clicking on " + element + " using JS" + e.getMessage());
			Assert.assertTrue(false, "Failed to click on " + element + " by JS");
		}

	}
	/**
	 * This method sends keys to a type-ahead field. It first waits for the element to be visible,
	 * then clears any existing text in the field. It then sends the keys one by one with a delay
	 * of 250 milliseconds between each key. This is useful for type-ahead fields where sending keys
	 * too quickly can cause issues.
	 *
	 * @param element WebElement - The type-ahead field element.
	 * @param value String - The value to be entered into the type-ahead field.
	 */
	public static void sendKeysTypeAheadField(WebElement element, String value) {
		waitForElementToBeVisible(driver, element);
		element.clear();

		try {
			for (int i = 0; i < value.length(); i++) {
				char c = value.charAt(i);
				String s = String.valueOf(c);
				element.sendKeys(s);
				Thread.sleep(200);
			}
			loggerManager.getLogger().info("Text " + value + " entered successfully into type-ahead field: " + element);
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while entering text " + value + " to type-ahead field: " + e.getMessage());
			Assert.assertTrue(false, "Failed to enter text " + value + " to type-ahead field " + element);
		}
	}

	/**
	 * This method checks if an element is present on the page.
	 * @param driver WebDriver - The WebDriver instance.
	 * @param locator By - The locator of the element to wait for.
	 */
	public static boolean isElementPresent(WebDriver driver, By locator){

		if (driver.findElements(locator).size() != 0) {
			loggerManager.getLogger().info("Element with " + locator + " is present");
			return true;
		} else {
			loggerManager.getLogger().error("Element with " + locator + " is not present");
			return false;
		}
	}

	/**
	 * This method waits until the page title matches the specified title.
	 * @param driver WebDriver - The WebDriver instance.
	 * @param title String - The title of the page to wait for.
	 */
	public static void waitForPageTitle(WebDriver driver, String title) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("pageLoadTimeoutDuration"))));
			wait.until(ExpectedConditions.titleIs(title));
			loggerManager.getLogger().info("Page title is " + title);
		}
		catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for page title: " + e.getMessage());
			Assert.assertTrue(false, "Page title is not " + title);
		}
	}

	/**
	 * This method waits for a specific element to be present in the DOM.
	 * @param driver WebDriver - The WebDriver instance.
	 * @param locator By - The locator of the element to wait for.
	 */
	public static void waitForElementToBePresent(WebDriver driver, By locator) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			wait.pollingEvery(Duration.ofSeconds(5)); // Poll every 5 seconds
			wait.until(ExpectedConditions.presenceOfElementLocated(locator));
		}
		catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for element to be clickable: " + e.getMessage());
		}
	}

	/**
	 * This method retrieves the text content of a specified web element.
	 * It waits for the element to be visible before extracting the text.
	 * If the element is not found or an exception occurs, it logs an error message.
	 *
	 * @param driver  The WebDriver instance used to interact with the web page.
	 * @param element The WebElement from which the text is to be retrieved.
	 * @return The text content of the specified web element.
	 */
	public static String getElementText(WebDriver driver, WebElement element) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));

			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			text = actionObject.getText();
			loggerManager.getLogger().info("Text retrieved from element: " + text);
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while retrieving text from element: " + e.getMessage());
		}
		return text;
	}

	/**
	 * This method refreshes the current web page.
	 * It uses the WebDriver instance to navigate to the current URL again.
	 * If an exception occurs during the refresh, it logs an error message.
	 *
	 * @param driver The WebDriver instance used to interact with the web page.
	 */
	public static void pageRefresh(WebDriver driver) {
		try {
			driver.navigate().refresh();
			loggerManager.getLogger().info("Page is refreshed successfully");
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while refreshing the page: " + e.getMessage());
		}
	}

	/**
	 * This method waits for the page URL to contain the specified string.
	 */
	public static void waitForUrlToContain(WebDriver driver, String expectedUrlPart) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			wait.until(ExpectedConditions.urlContains(expectedUrlPart));
		}
		catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for URL to contain: " + expectedUrlPart + e.getMessage());
		}
	}

	/** This method waits for the page title to contain the specified string
	 *
	 * @param driver - The WebDriver instance used to interact with the web page.
	 * @param titlePart - The string that the page title should contain
	 */
	public static void waitForPageTitleToContain(WebDriver driver, String titlePart) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(getConfigProperty("pageLoadTimeoutDuration"))));
			wait.until(ExpectedConditions.titleContains(titlePart));
		}
		catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for page title to contain: " + titlePart + e.getMessage());
		}
	}


	/**
	 * This method scrolls within a web element by a specified offset.
	 */
	public static void scrollWithinElement(WebDriver driver, WebElement element, int scrollHeight) {
		if (isElementScrollable(element)) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].scrollBy(arguments[1], arguments[2]);", element, 0, scrollHeight);
		} else {
			loggerManager.getLogger().error("Element is not scrollable");
		}
	}

	/**
	 * This method checks if an element is scrollable.
	 */
	public static boolean isElementScrollable(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return (Boolean) js.executeScript(
				"return arguments[0].scrollHeight > arguments[0].clientHeight;", element);
	}

	/**
	 * This method uploads a file using the Robot class.
	 * It first copies the file path to the clipboard, then uses the Robot class to paste the path and press Enter.
	 * If an exception occurs during the upload, it logs an error message.
	 * @param filePath - The path of the file to upload.
	 */
	public static void uploadFileUsingRobot(String filePath) {
		try {
			System.out.println("Path of File to upload: " + filePath);
			// Copy the file path to the clipboard
			StringSelection stringSelection = new StringSelection(filePath);
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);

			// Create a new Robot instance
			Robot robot = new Robot();
			robot.delay(5000);

			// Press Ctrl+V to paste the file path
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			robot.delay(1000);
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.delay(1000);

			// Press Enter to complete the file upload
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);

		} catch (AWTException e) {
			loggerManager.getLogger().error("Exception while uploading file using Robot class: " + e.getMessage());
		}
	}

	/**
	 * This method retrieves the value of a specified attribute from a given web element.
	 * It performs the following steps:
	 * 1. Waits for the web element to be visible on the page.
	 * 2. Retrieves the value of the specified attribute from the web element.
	 * 3. Logs a message indicating the attribute value retrieved from the element.
	 * 4. Returns the attribute value as a string.
	 *
	 * @param driver WebDriver - The WebDriver instance used to interact with the web page.
	 * @param element WebElement - The web element from which the attribute value is to be retrieved.
	 * @param attributeName String - The name of the attribute whose value is to be retrieved.
	 * @return String - The value of the specified attribute from the web element.
	 */
	public static String getElementAttributeValue(WebDriver driver, WebElement element, String attributeName) {
		String text = "";
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			WebElement actionObject = wait.until(ExpectedConditions.visibilityOf(element));
			text = actionObject.getAttribute(attributeName);
			loggerManager.getLogger().info("Attribute value retrieved from element: " + text);
		} catch (Exception e) {
			loggerManager.getLogger().error("Exception while retrieving Attribute value from element: " + e.getMessage());
		}
		return text;
	}
	/**
	 * This method retrieves the text from an alert popup.
	 * It performs the following steps:
	 * 1. Waits for an alert to be present on the page.
	 * 2. Switches the driver's context to the alert.
	 * 3. Retrieves the text from the alert.
	 * 4. Logs an error message if no alert is present.
	 * 5. Returns the alert text as a string.
	 *
	 * @return String - The text from the alert popup.
	 */
	public static String getAlterText(){
		String text="";
		try {
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			text=alert.getText();
		} catch (Exception e) {
			loggerManager.getLogger().error("No alert is present" + e.getMessage());
		}
		return text;
	}

	/**
	 * This method extracts the first sequence of numbers from the given text.
	 * The sequence may include commas, which are removed in the returned result.
	 *
	 * @param text The input string containing the sequence of numbers.
	 * @return A string representing the extracted number without commas, or null if no sequence is found.
	 */
	public static String extractNumber(String text) {
		Pattern pattern = Pattern.compile("\\d+(?:,\\d{3})*(?:\\.\\d+)?|\\d+");
		Matcher matcher = pattern.matcher(text);
		if (matcher.find()) {
			String number = matcher.group();
			if (number.contains(".")) {
				String[] parts = number.split("\\.");
				if (parts.length > 1 && parts[1].equals("00")) {
					return parts[0].replaceAll(",", "");
				} else {
					return number.replaceAll(",", "");
				}
			} else {
				return number.replaceAll(",", "");
			}
		}
		return null;
	}

	public static boolean containsNumber(String text) {
		Pattern pattern = Pattern.compile("\\d+");
		Matcher matcher = pattern.matcher(text);
		return matcher.find();
	}

	/**
	 * This method sets the screen zoom level to the specified percentage using JavaScript.
	 *
	 * @param driver - The WebDriver instance.
	 * @param zoomPercentage - The percentage value to set the screen zoom level to.
	 */
	public static void setScreenZoom(WebDriver driver, int zoomPercentage) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.body.style.zoom='" + zoomPercentage + "%'");
	}

	/**
	 * This method returns the index of a specified option in a dropdown list.
	 *
	 * @param driver - The WebDriver instance.
	 * @param element - The WebElement representing the dropdown list.
	 * @param optionText - The text of the option to find.
	 */
	public static int getOptionIndex(WebDriver driver, WebElement element, String optionText) {
		Select select = new Select(element);
		List<WebElement> options = select.getOptions();

		for (int i = 0; i < options.size(); i++) {
			if (options.get(i).getText().equals(optionText)) {
				return i;
			}
		}
		return -1; // Return -1 if the option is not found
	}

	/**
	 * This method returns the column number of a given column name in a table.
	 *
	 * @param driver - The WebDriver instance
	 * @param tableElement - The WebElement representing the table
	 * @param columnName - The name of the column
	 * @return - The column number or -1 if the column is not found
	 */
	public static int getColumnNumber(WebDriver driver, WebElement tableElement, String columnName) {
		List<WebElement> headers = tableElement.findElements(By.tagName("th"));

		for (int i = 0; i < headers.size(); i++) {
			if (headers.get(i).getText().equalsIgnoreCase(columnName)) {
				return i + 1; // Column numbers are 1-based
			}
		}
		return -1; // Column not found
	}

	/**
	 * This method checks if the current page is vertically scrollable.
	 * It uses JavaScript to determine if the scroll height of the document is greater than the client height.
	 *
	 * @param driver WebDriver - The WebDriver instance.
	 * @return boolean - True if the page is vertically scrollable, false otherwise.
	 */
	public static boolean isPageVerticallyScrollable(WebDriver driver) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		return (Boolean) js.executeScript("return document.documentElement.scrollHeight > document.documentElement.clientHeight;");
	}

	/**
	 * This method waits for an element to disappear from the page.
	 *
	 * @param driver - The WebDriver instance.
	 * @param element - The WebElement to wait for.
	 */
	public static void waitForElementToDisappear(WebDriver driver, WebElement element) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.parseInt(prop.getProperty("elementVisibilityDynamicWaitDuration"))));
			wait.pollingEvery(Duration.ofSeconds(5)); // Poll every 5 seconds
			wait.until(ExpectedConditions.invisibilityOf(element));
		}
		catch (Exception e) {
			loggerManager.getLogger().error("Exception while waiting for the element to disappear: {}", e.getMessage());
		}
	}

	/**
	 * This method waits for an alert to be present within the given timeout period and accepts it.
	 * If no alert is present within the timeout period, it logs an error message.
	 */
	public static void acceptAlert() {
		try {
			Thread.sleep(5000);
			driver.navigate().refresh();
			Thread.sleep(5000);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = driver.switchTo().alert();
			alert.accept();
		} catch (Exception e) {
			loggerManager.getLogger().error("No alert is present" + e.getMessage());
		}
	}

	/**
	 * This method returns the index of a WebElement from a List with a specific text.
	 *
	 * @param elements List<WebElement> - The list of WebElements to search through.
	 * @param text String - The text to search for in the WebElements.
	 * @return int - The index of the WebElement with the specified text, or -1 if not found.
	 */
	public static int getElementIndexByText(List<WebElement> elements, String text) {
		for (int i = 0; i < elements.size(); i++) {
			if (elements.get(i).getText().equals(text)) {
				return i + 1; // Indexes are 1-based
			}
		}
		return -1; // Return -1 if the element with the specified text is not found
	}

	/**
	 * This method returns the value of a cell from an Excel sheet based on the row number and column name.
	 *
	 * @param filePath String - The path of the Excel file.
	 * @param sheetName String - The name of the sheet in the Excel file.
	 * @param primaryKey String - The name of the primary key column in the Excel sheet.
	 * @param primaryKeyValue String - The value of the primary key to search for in the Excel sheet.
	 * @param columnName String - The name of the column to retrieve the value from.
	 * @return int - The index of the WebElement with the specified attribute value, or -1 if not found.
	 */
	public static String readExcelCellValue(String filePath, String sheetName, String primaryKey, String primaryKeyValue, String columnName) {
		String cellValue = null;

		try (FileInputStream fis = new FileInputStream(filePath);
			 Workbook workbook = new XSSFWorkbook(fis)) {
  			 Sheet sheet = workbook.getSheet(sheetName);
			   if (sheet == null) {
					throw new IllegalArgumentException("Sheet " + sheetName + " does not exist in the file " + filePath);
			   }
			   Iterator<Row> rows = sheet.iterator();
			   int primaryKeyColumnIndex = -1;
			   int targetColumnIndex = -1;
			   if (rows.hasNext()) {
					Row headerRow = rows.next();
					for (Cell cell : headerRow) {
						if (cell.getStringCellValue().equals(primaryKey)) {
							primaryKeyColumnIndex = cell.getColumnIndex();
						}
						if (cell.getStringCellValue().equals(columnName)) {
						targetColumnIndex = cell.getColumnIndex();
						}
					}
			   }

				if (primaryKeyColumnIndex == -1 || targetColumnIndex == -1) {
					throw new IllegalArgumentException("Primary key or target column not found in the sheet " + sheetName);
				}

				while (rows.hasNext()) {
					Row row = rows.next();
					Cell primaryKeyCell = row.getCell(primaryKeyColumnIndex);
					if (primaryKeyCell != null && primaryKeyCell.getCellType() == CellType.STRING &&
							primaryKeyCell.getStringCellValue().equals(primaryKeyValue)) {
						Cell targetCell = row.getCell(targetColumnIndex);
						if (targetCell != null) {
							cellValue = targetCell.getStringCellValue();
						}
						break;
					}
				}

			} catch (IOException e) {
				loggerManager.getLogger().error("Exception while reading Excel file: " + e.getMessage());
			}
			return cellValue;
		}
}
