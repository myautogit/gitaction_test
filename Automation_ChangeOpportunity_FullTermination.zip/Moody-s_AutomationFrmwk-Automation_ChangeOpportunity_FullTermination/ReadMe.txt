Tags needs to included in the Tests are as follows:
Sanity
SalesforceObjectName with subfuction (e.g. LeadCreation, LeadConversion, LeadEditUpdate etc.)
If it is a different application then ApplicationName (e.g. Marketo etc.)
Scenario tag i.e Positive or Negative

e.g.

@Tags({@Tag("Sanity"), @Tag("LeadConversion"), @Tag("Positive")} )